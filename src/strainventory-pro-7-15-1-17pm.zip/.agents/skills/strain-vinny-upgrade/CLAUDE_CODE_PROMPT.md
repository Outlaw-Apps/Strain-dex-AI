# 🚀 Strain-Vinny Upgrade — Claude Code Prompt

Paste this entire prompt into Claude Code at the root of your project.

---

## Context

This project uses the following tech stack:
- **Frontend:** Vite + React + TypeScript
- **Styling:** Tailwind CSS + shadcn/ui
- **Backend / DB:** Supabase (Postgres + Edge Functions)
- **AI Model:** DeepSeek (currently `deepseek-chat`) → upgrading to `deepseek-v4-pro`
- **Mobile:** Capacitor (Android)
- **Desktop:** Electron
- **Testing:** Vitest + Playwright
- **Package Manager:** Bun + npm

---

## Your Mission

You are upgrading four distinct areas of this app. Work through them in order and pause for my confirmation between each major section.

---

## TASK 1 — Upgrade DeepSeek Model to `deepseek-v4-pro`

1. Search the entire codebase for every occurrence of `deepseek-chat` (check `.env`, `.env.example`, any config files, Edge Functions, API client files, and any hardcoded strings in TypeScript/JavaScript).
2. Replace all occurrences with `deepseek-v4-pro`.
3. Also search for any references to `DeepSeek-V3.2` or `deepseek-v3` and update version strings/comments to reflect the new model.
4. If there is a model configuration object or constant (e.g., `MODEL_NAME`, `AI_MODEL`, `DEEPSEEK_MODEL`), centralize it into a single source-of-truth constant so future upgrades only require one change.
5. Show me a summary of every file changed and the exact line-by-line diffs.

> ⚠️ Do NOT change any other API parameters (temperature, max_tokens, system prompts) in this step — that comes in Task 3.

---

## TASK 2 — Strain-Vinny Avatar Redesign (5 Options)

Strain-Vinny is the AI co-pilot / assistant avatar currently displayed as a small robot icon. We want something more flashy, vibrant, and cannabis-brand-appropriate.

1. Locate all files where the Strain-Vinny avatar/icon is defined or rendered (SVG, PNG imports, Lucide icons, inline JSX, CSS classes, etc.).
2. **Generate 5 distinct avatar options** as inline SVG React components. Each option should be:
   - Fully self-contained (no external image dependencies)
   - Rendered in approximately 48×48px (scalable via props)
   - Themed around cannabis culture, AI/tech, or a bold mascot personality
   - More visually striking than the current robot — think: crystalline trichome figure, glowing neural leaf, retro neon bud, cyberpunk eye, cosmic plant spirit, etc.
   - Implemented in a file like `src/components/StrainVinnyAvatar.tsx` with each option as a named export: `VinnyOption1`, `VinnyOption2`, … `VinnyOption5`
3. Create a temporary **Avatar Preview Page** at route `/vinny-preview` that shows all 5 options side-by-side with their names, so I can pick my favorite visually.
4. Add a `VINNY_AVATAR_OPTION` constant (default `1`) in the config so switching options later is a one-line change.
5. Do NOT delete the old avatar yet — keep it as `VinnyLegacy` export for rollback.

---

## TASK 3 — Web Search First + Dynamic Prompts

Upgrade Strain-Vinny's AI behavior so it searches the web before answering and uses richer, more dynamic prompts to fully leverage `deepseek-v4-pro`.

### 3A — Web Search Integration

1. Find the primary AI request handler (likely in a Supabase Edge Function or a client-side API call file).
2. Integrate a web search step that runs **before** the DeepSeek call:
   - Use the existing search tool if one exists, or add a lightweight search via the [Serper API](https://serper.dev) or [Tavily API](https://tavily.com) — add a `VITE_SEARCH_API_KEY` and `VITE_SEARCH_PROVIDER` env variable.
   - Fetch the top 3–5 search results (title + snippet + URL).
   - Inject the results into the DeepSeek system prompt as a `[WEB CONTEXT]` block so the model can cite and reason over fresh data.
3. Add a `webSearchEnabled` boolean flag (default `true`) that can be toggled per-request or globally via a settings key in Supabase.
4. If search fails or times out (>3s), fall back to the model without web context and log a warning.

### 3B — Dynamic System Prompts

Replace any static/hardcoded system prompt strings with a dynamic prompt builder. The builder should:

1. Accept a context object: `{ userQuery, webResults?, conversationHistory?, userPreferences?, currentPage? }`
2. Compose a prompt that:
   - Establishes Strain-Vinny's personality (knowledgeable, chill, direct, cannabis-industry expert)
   - Injects `[WEB CONTEXT]` from search results when available
   - Adds relevant conversation history (last N turns, configurable)
   - Adapts tone/depth based on `userPreferences` (novice vs expert mode)
   - Ends with a clear instruction style optimized for DeepSeek's reasoning capabilities (e.g., chain-of-thought encouragement, structured output hints)
3. Export as `buildStrainVinnyPrompt(context)` from `src/lib/vinnyPrompt.ts` (or equivalent path).
4. Write Vitest unit tests for the prompt builder covering: empty context, web results present, expert mode, novice mode.

---

## TASK 4 — Live Messenger Notifications

Add real-time live notifications to the messenger/chat feature.

1. Locate the messenger component and its data-fetching logic.
2. Implement **Supabase Realtime** subscriptions on the relevant messages table:
   - Subscribe on component mount, unsubscribe on unmount.
   - On new message INSERT, trigger a notification using the pattern below.
3. Build a `useMessengerNotifications` React hook (`src/hooks/useMessengerNotifications.ts`) that:
   - Accepts `{ channelId, userId }` params
   - Returns `{ unreadCount, latestMessage, clearNotifications }`
   - Plays a subtle sound cue on new message (use the Web Audio API, no external files)
   - Shows a browser Notification (request permission on first use, gracefully skip if denied)
   - Updates the document `<title>` with unread count: e.g., `(3) StrainVentory`
4. Add a notification badge (red dot + count) to the messenger nav item / tab icon using Tailwind + shadcn/ui Badge component.
5. Ensure notifications are suppressed when the user is actively viewing that channel (i.e., the window is focused AND the channel is open).
6. Test the Supabase Realtime subscription works in both the Capacitor (Android) and Electron (Desktop) environments — note any platform-specific caveats in a `NOTIFICATIONS.md` file.

---

## Completion Checklist

Before finishing, confirm all of the following:

- [ ] `deepseek-chat` → `deepseek-v4-pro` updated everywhere, centralized constant created
- [ ] 5 Strain-Vinny avatar options rendered and visible at `/vinny-preview`
- [ ] Web search runs before AI calls, graceful fallback on failure
- [ ] `buildStrainVinnyPrompt()` implemented and unit-tested
- [ ] `useMessengerNotifications` hook live with Supabase Realtime
- [ ] Notification badge visible on messenger nav item
- [ ] `NOTIFICATIONS.md` documenting Capacitor + Electron behavior
- [ ] No TypeScript errors (`bun run typecheck` or `tsc --noEmit` passes)
- [ ] Existing Vitest + Playwright tests still pass

Show me the final diff summary and any follow-up recommendations.
