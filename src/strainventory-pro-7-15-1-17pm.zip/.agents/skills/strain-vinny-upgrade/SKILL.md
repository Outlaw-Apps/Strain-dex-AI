---
name: strain-vinny-upgrade
description: >
  Use this skill to upgrade a Vite + React + TypeScript + Supabase + DeepSeek app with four
  improvements: (1) swap the AI model string to a new DeepSeek version, (2) redesign an AI
  avatar/mascot with 5 generated SVG options and a preview route, (3) add web search grounding
  and dynamic prompt building before AI calls, and (4) wire up Supabase Realtime live
  notifications in a messenger/chat feature. Trigger this skill whenever the user mentions
  upgrading DeepSeek, redesigning an AI avatar or mascot, adding web-search-first AI behavior,
  dynamic system prompts, or live messenger/chat notifications in a React + Supabase stack.
---

# Strain-Vinny Upgrade Skill

A structured four-task upgrade workflow for a Vite + React + TypeScript + Supabase + DeepSeek
application. Each task is self-contained and should be confirmed with the user before moving on.

## Tech Stack Assumptions

| Layer | Technology |
|---|---|
| Frontend | Vite + React + TypeScript |
| Styling | Tailwind CSS + shadcn/ui |
| Backend / DB | Supabase (Postgres + Edge Functions) |
| AI Model | DeepSeek (model string is the upgrade target) |
| Mobile | Capacitor (Android) |
| Desktop | Electron |
| Testing | Vitest (unit) + Playwright (e2e) |
| Package Manager | Bun + npm |

If the user's stack differs, adapt the patterns below accordingly.

---

## Task Execution Order

Always confirm with the user between tasks. The four tasks are:

1. **Model Upgrade** — Find + replace model string, centralize into a constant
2. **Avatar Redesign** — Generate 5 SVG avatar options, preview route, config toggle
3. **Web Search + Dynamic Prompts** — Search-before-LLM pipeline, prompt builder + tests
4. **Live Messenger Notifications** — Supabase Realtime hook, badge, browser notifications

---

## TASK 1 — Model String Upgrade

**Goal:** Replace the old model string everywhere and centralize it.

### Steps

1. `grep -r "deepseek-chat" .` — find all occurrences across `.env`, Edge Functions, TypeScript files, config objects.
2. Replace every instance with the new model string (e.g., `deepseek-v4-pro`).
3. Also update any version comments/strings (`V3.2`, `deepseek-v3`, etc.).
4. Create a single constant, e.g.:
   ```ts
   // src/lib/aiConfig.ts
   export const DEEPSEEK_MODEL = "deepseek-v4-pro";
   ```
5. Replace hardcoded strings in all call sites with this import.
6. Show a diff summary of every changed file.

### Verification

```bash
grep -r "deepseek-chat" . --include="*.ts" --include="*.tsx" --include="*.env*"
# Should return zero results
```

---

## TASK 2 — Avatar Redesign (5 SVG Options)

**Goal:** Generate 5 distinct SVG React avatar components for the AI mascot.

### Locating the Current Avatar

Search for: icon component names, SVG files, Lucide icon imports, image imports related to the mascot name (e.g., `Vinny`, `copilot`, `assistant`, `avatar`).

### Avatar Design Principles

Each of the 5 options must be:
- Self-contained inline SVG (no external assets)
- ~48×48px default, scalable via `size` prop
- Visually distinct from each other
- More striking than a generic robot icon

**Suggested themes** (adapt to the app's brand):
1. Crystalline trichome figure (geometric, icy blues)
2. Glowing neural leaf (neon green circuitry on dark)
3. Retro neon bud mascot (80s arcade aesthetic)
4. Cyberpunk eye / iris (purple + gold)
5. Cosmic plant spirit (aurora colors, flowing)

### Implementation Pattern

```tsx
// src/components/StrainVinnyAvatar.tsx
interface VinnyAvatarProps { size?: number; className?: string; }

export const VinnyOption1 = ({ size = 48, className }: VinnyAvatarProps) => (
  <svg width={size} height={size} viewBox="0 0 48 48" className={className}>
    {/* ... */}
  </svg>
);
// VinnyOption2 … VinnyOption5
export const VinnyLegacy = ({ size = 48 }: VinnyAvatarProps) => (/* old icon */);
```

### Config Toggle

```ts
// src/lib/aiConfig.ts
export const VINNY_AVATAR_OPTION: 1 | 2 | 3 | 4 | 5 = 1;
```

### Preview Route

Add `/vinny-preview` route that renders all 5 options in a grid (can be removed after selection). Use Tailwind card styling with the option number and name labeled below each avatar.

---

## TASK 3 — Web Search First + Dynamic Prompts

### 3A — Search Pipeline

**Architecture:**

```
User query
   ↓
[Search API call] ← 3s timeout, catch → skip gracefully
   ↓ top 3-5 results (title + snippet + URL)
[buildStrainVinnyPrompt(context)]
   ↓
[DeepSeek API call]
   ↓
Response to user
```

**Environment variables to add:**
```
VITE_SEARCH_API_KEY=...
VITE_SEARCH_PROVIDER=serper   # or: tavily
```

**Search providers:**
- [Serper](https://serper.dev) — POST `https://google.serper.dev/search`, header `X-API-KEY`
- [Tavily](https://tavily.com) — POST `https://api.tavily.com/search`, body `{ api_key, query }`

**Fallback pattern:**
```ts
let webResults: SearchResult[] = [];
try {
  webResults = await searchWeb(query, { timeout: 3000 });
} catch (e) {
  console.warn("[Vinny] Web search failed, proceeding without context:", e);
}
```

**Toggle flag:**
```ts
// per-request or global Supabase setting
const webSearchEnabled: boolean = true;
```

### 3B — Dynamic Prompt Builder

**File:** `src/lib/vinnyPrompt.ts`

```ts
interface PromptContext {
  userQuery: string;
  webResults?: SearchResult[];
  conversationHistory?: Message[];
  userPreferences?: { expertMode?: boolean };
  currentPage?: string;
}

export function buildStrainVinnyPrompt(ctx: PromptContext): string {
  // 1. Persona block
  // 2. [WEB CONTEXT] block (if webResults)
  // 3. Conversation history (last N turns)
  // 4. User preference tone adaptation
  // 5. DeepSeek reasoning instruction
}
```

**Vitest tests to write:**
- Empty context → valid prompt string returned
- Web results present → `[WEB CONTEXT]` appears in output
- Expert mode → prompt instructs advanced terminology
- Novice mode → prompt instructs simple explanations

---

## TASK 4 — Live Messenger Notifications

### Hook: `useMessengerNotifications`

**File:** `src/hooks/useMessengerNotifications.ts`

```ts
interface UseMessengerNotificationsParams {
  channelId: string;
  userId: string;
}

interface UseMessengerNotificationsReturn {
  unreadCount: number;
  latestMessage: Message | null;
  clearNotifications: () => void;
}

export function useMessengerNotifications(
  params: UseMessengerNotificationsParams
): UseMessengerNotificationsReturn
```

### Supabase Realtime Subscription Pattern

```ts
useEffect(() => {
  const channel = supabase
    .channel(`messages:${channelId}`)
    .on(
      "postgres_changes",
      { event: "INSERT", schema: "public", table: "messages",
        filter: `channel_id=eq.${channelId}` },
      (payload) => handleNewMessage(payload.new as Message)
    )
    .subscribe();

  return () => { supabase.removeChannel(channel); };
}, [channelId]);
```

### Notification Behaviors

| Trigger | Action |
|---|---|
| New message, window unfocused | Browser Notification + sound + title badge |
| New message, window focused, different channel | Badge update only |
| New message, window focused, same channel | Suppress all notifications |
| User opens channel | Call `clearNotifications()` |

### Sound Cue (Web Audio API — no external files)

```ts
function playNotificationSound() {
  const ctx = new AudioContext();
  const osc = ctx.createOscillator();
  const gain = ctx.createGain();
  osc.connect(gain); gain.connect(ctx.destination);
  osc.frequency.value = 520;
  gain.gain.setValueAtTime(0.1, ctx.currentTime);
  gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.3);
  osc.start(); osc.stop(ctx.currentTime + 0.3);
}
```

### Document Title Badge

```ts
document.title = unreadCount > 0 ? `(${unreadCount}) StrainVentory` : "StrainVentory";
```

### Nav Badge (shadcn/ui)

```tsx
import { Badge } from "@/components/ui/badge";
// In messenger nav item:
{unreadCount > 0 && (
  <Badge variant="destructive" className="absolute -top-1 -right-1 h-5 w-5 p-0 flex items-center justify-center text-xs">
    {unreadCount > 99 ? "99+" : unreadCount}
  </Badge>
)}
```

### Platform Notes (`NOTIFICATIONS.md`)

Document:
- **Capacitor (Android):** Supabase Realtime works over WebSocket. Browser Notification API not available — use `@capacitor/local-notifications` instead. Web Audio API works.
- **Electron:** Both Browser Notification API and Web Audio API work. For native system notifications, can optionally use Electron's `Notification` class.

---

## Completion Verification

```bash
# No old model strings
grep -r "deepseek-chat" . --include="*.ts" --include="*.tsx" --include="*.env*"

# TypeScript clean
bun run typecheck   # or: npx tsc --noEmit

# Tests pass
bun run test        # Vitest
bun run test:e2e    # Playwright
```

### Final Checklist

- [ ] Model string updated everywhere, constant centralized
- [ ] 5 avatar SVG options at `/vinny-preview`, `VinnyLegacy` preserved
- [ ] Web search pipeline with graceful fallback
- [ ] `buildStrainVinnyPrompt()` with Vitest tests
- [ ] `useMessengerNotifications` hook with Supabase Realtime
- [ ] Notification badge on messenger nav item
- [ ] `NOTIFICATIONS.md` with Capacitor + Electron notes
- [ ] No TypeScript errors, all tests pass

---

## References

- [DeepSeek API Docs](https://platform.deepseek.com/api-docs)
- [Supabase Realtime Docs](https://supabase.com/docs/guides/realtime)
- [Serper API](https://serper.dev/api-reference)
- [Tavily API](https://docs.tavily.com)
- [shadcn/ui Badge](https://ui.shadcn.com/docs/components/badge)
- [Capacitor Local Notifications](https://capacitorjs.com/docs/apis/local-notifications)
