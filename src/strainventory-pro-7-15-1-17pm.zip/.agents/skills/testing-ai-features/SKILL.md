# Testing AI Features (DeepSeek Integration)

## Overview
StrainVentory uses DeepSeek as the exclusive AI provider for two edge functions:
- `generate-draft` — Generates structured product drafts (flavor, aroma, terpenes, effects, etc.)
- `assistant-chat` — Powers the "Refined Strain Vinny" copilot chat

Both functions require a signed-in Supabase user. The client sends the public key via `apikey` and the user's access token via `Authorization: Bearer <access_token>`.

## Prerequisites
- Node.js and npm installed
- Dependencies installed: `npm install`
- Dev server running: `npm run dev` (Vite, typically port 8080-8086 — Vite auto-increments if ports are in use)
- Logged in as an admin user
- Edge functions deployed with `--no-verify-jwt` flag (see Deployment section)

## Devin Secrets Needed
- `STRAINVENTORY_LOGIN_PASSWORD` — Login password for the test user (permanent secret)
- `DEEPSEEK_API_KEY` — Must be set in Supabase edge function secrets (not vault.secrets). Set via: `supabase secrets set DEEPSEEK_API_KEY=sk-...`

## Edge Function Auth Pattern

All AI edge functions use the same auth pattern:
1. **Gateway level**: `verify_jwt = false` in `supabase/config.toml` — avoids ES256 tokens being rejected before the function code runs.
2. **Function level**: `requireAuthenticatedUser()` verifies the Bearer token with Supabase Auth and rejects anon-key-only requests.
3. **Client side**: Direct `fetch()` with `apikey` header plus `Authorization: Bearer <access_token>`.

This pattern means:
- Functions require a current user session.
- Session errors come from the function instead of the Edge gateway.
- Thread tracking and role checks use the real authenticated user.

## Deployment Checklist

When deploying AI edge functions, you **must** use the `--no-verify-jwt` flag:

```bash
supabase functions deploy assistant-chat --no-verify-jwt
supabase functions deploy generate-draft --no-verify-jwt
supabase functions deploy generate-product-draft --no-verify-jwt
```

Without this flag, the Supabase gateway defaults to `verify_jwt = true` and rejects requests **before** the function code runs, returning a 401 error like `"Authentication required for assistant-chat."`

The `config.toml` file has `verify_jwt = false` for these functions, which should be picked up by `supabase functions deploy --all`, but explicit `--no-verify-jwt` is more reliable.

**Common deployment issue**: If you get 401 errors after deploying, check:
1. Was `--no-verify-jwt` used? (Gateway config)
2. Was the latest code pulled before deploying? (`git pull origin main` first)
3. Verify via Supabase API: `GET /v1/projects/{ref}/functions` should show `verify_jwt: false`

## Testing Auto-Generate Profile

**UI Path:** Sidebar → Product Intake → Enter product name + brand → Click "Auto-Generate" button in Profile card header

**What happens:**
1. Button shows "Generating..." spinner
2. Bottom bar shows "Strain Vinny is analyzing your product..."
3. Edge function `generate-draft` is called via direct `fetch()` with the public key and user access token.
4. DeepSeek returns structured JSON with sections
5. Toast shows result

**Expected results:**
- If DEEPSEEK_API_KEY is configured: Success toast. Fields may be empty if research context found no matches (DeepSeek follows prompt not to guess). This is correct behavior.
- If DEEPSEEK_API_KEY is NOT configured: Error toast containing "DEEPSEEK_API_KEY" and setup instruction "supabase secrets set DEEPSEEK_API_KEY=sk-..."
- If you see a 401 error before function logs appear, the function was likely deployed without `--no-verify-jwt`; if function logs show `Sign in required` or `Invalid or expired session`, refresh the app session and retry.

**Key code paths:**
- Client: `src/pages/ProductIntake.tsx` → `handleAutoGenerateProfile()`
- Edge function: `supabase/functions/_shared/generateDraft.ts` → `resolveProviderConfig()` + `generateDraft()`
- Constants: `src/lib/constants.ts` → `EDGE_FUNCTIONS.GENERATE_DRAFT`

## Testing Full AI Draft Workflow

**UI Path:** Product Intake → Enter product name + brand → Scroll down → Click "Generate AI Draft" (gold button with sparkles) → Navigates to `/ai-draft`

**What happens:**
1. Page navigates to `/ai-draft`
2. Progress bar shows generation progress (research + draft generation)
3. Draft renders with structured sections and confidence scores
4. "Regenerate" button available

**Expected results:**
- 7 sections rendered: Vendor Information, Cannabinoid Profile, Terpene Profile, Aroma Profile, Taste Profile, Effects Profile, Medical Uses, Product Descriptions
- Each section has a confidence badge (Brand Verified, Needs Review, Web Inferred)
- Overall confidence percentage displayed

## Testing Assistant Chat (Copilot)

**UI Path:** Click "Copilot" FAB button (bottom-right corner, fixed position) → Type message → Click "Send to Vinny"

**Auth pattern:** Both `generate-draft` and `assistant-chat` now use the same anon-key pattern. The client sends a direct `fetch()` with `apikey` header and best-effort JWT in `Authorization` header.

**What to verify:**
1. **Message sending**: Type a message, click "Send to Vinny", button shows "Sending..."
2. **Response**: Assistant message bubble appears with actual content (cannabis-related recommendations)
3. **No auth errors**: No "Assistant request failed (401)" toast, no "Your session may have expired" message
4. **Thread persistence**: Close panel, reopen — thread dropdown shows the conversation, status says "Recent thread resumed from your assistant history."
5. **Action recommendations**: Assistant may include structured actions with "Confirm Action" buttons

**Thread status text indicators:**
- "Starting a fresh assistant thread." — New conversation (no existing threads)
- "Recent thread resumed from your assistant history." — Existing thread loaded from DB

**Key code paths:**
- Client: `src/components/assistant/AssistantCopilotPanel.tsx` → `handleSendMessage()`
- Edge function: `supabase/functions/assistant-chat/index.ts`
- Copilot button: `src/components/assistant/GlobalAssistantDrawer.tsx`
- Thread hydration: `AssistantCopilotPanel.tsx` → `hydrateAssistant()` (queries `assistant_threads` and `assistant_messages` tables)

## Intercepting API Responses

To inspect what DeepSeek actually returns, install a fetch interceptor in the browser console:

```js
const originalFetch = window.fetch;
window.fetch = async function(...args) {
  const response = await originalFetch.apply(this, args);
  if (args[0]?.includes?.('generate-draft') || args[0]?.includes?.('assistant-chat')) {
    const clone = response.clone();
    const data = await clone.json();
    console.log('AI RESPONSE:', args[0], JSON.stringify(data).substring(0, 2000));
  }
  return response;
};
```

## Supabase Secrets Management

- Edge function secrets are separate from `vault.secrets` — querying `vault.secrets` via MCP will NOT show edge function secrets
- The Supabase MCP might not have permissions to create vault secrets (`permission denied for function create_secret`)
- Set secrets via CLI: `supabase secrets set DEEPSEEK_API_KEY=sk-...`
- Or via Dashboard: Project Settings → Edge Functions → Add Secret
- You can verify function configuration via Supabase MCP: list functions to check `verify_jwt` status

## Common Issues

- **401 "Authentication required" error**: The Supabase gateway is rejecting requests before the function code runs. Deploy with `--no-verify-jwt` flag. See Deployment Checklist.
- **401 after redeployment**: User may have deployed old code without `git pull origin main` first. The deployed function code may still have mandatory JWT auth checks.
- **Caps Lock during typing**: Computer-use keyboard input is affected by Caps Lock state. Toggle it off with `Caps_Lock` key before typing form inputs.
- **Port conflicts**: Vite auto-increments ports (8080 → 8081 → ... → 8086). Check terminal output for actual URL.
- **Empty profile fields after Auto-Generate**: This is expected behavior when DeepSeek's research context finds no matches. The function completed successfully — it's not an error.
- **FK constraint on anonymous user ID**: The anonymous fallback UUID (`00000000-...`) may not exist in `auth.users`, causing DB insert failures for unauthenticated requests. This only affects the anonymous path, not normal logged-in usage.
