# Testing the Electron Desktop App

## Overview
StrainVentory has an Electron desktop wrapper (`electron/main.cjs`, `electron/preload.cjs`) that loads the React/Vite web app as a cross-platform desktop application.

## Prerequisites
- Node.js and npm installed
- Dependencies installed: `npm install`
- Display server available (X11 on Linux, native on Windows/Mac)

## Dev Mode Testing (Electron)
```bash
npm run electron:dev
```
This starts the Vite dev server on port 8080 and launches Electron pointing to it. DevTools will auto-open.

**What to verify:**
- Electron window appears with title "Strain-ventory"
- Auth page loads with logo, email/password fields, "Sign In" button
- DevTools panel opens automatically
- No "require is not defined" errors (would indicate ESM/CJS mismatch)

## Dev Mode Testing (Web Browser)
For testing web features without Electron overhead:
```bash
npx vite --port 8081
```
Then open `http://localhost:8081` in the browser. Note: ports 8080-8082 might be in use from previous sessions; Vite will auto-increment to the next available port — check the terminal output for the actual URL.

**Login**: Navigate to `/auth`, enter email + password, click "Sign In".

## Production Mode Testing
```bash
npm run electron:preview
```
Builds the Vite app then launches Electron.

**Important limitation:** `app.isPackaged` is `false` when running unpackaged via `npx electron .`, so the `app://` custom protocol handler does NOT activate. The app falls back to trying `http://localhost:8080`. To properly test production mode, you must package the app:
```bash
npm run electron:build        # current platform
npm run electron:build:win    # Windows
npm run electron:build:mac    # macOS
npm run electron:build:linux  # Linux AppImage
```

## Syntax Validation (Quick Check)
If you can't run the full app (e.g., no display), verify the Electron files are at least syntactically valid:
```bash
node --check electron/main.cjs
node --check electron/preload.cjs
```

## Architecture Notes
- `electron/main.cjs` and `electron/preload.cjs` use `.cjs` extension because `package.json` has `"type": "module"`. Without `.cjs`, Electron would try to load them as ESM and crash with `require is not defined`.
- The custom `app://` protocol in `main.cjs` serves files from `dist/` with SPA fallback (any non-file path returns `index.html`).
- Path traversal protection validates resolved paths stay within `DIST_PATH`.
- `electron-builder` config is in `package.json` under the `"build"` key.

## Payroll Feature Testing
The payroll feature is at `/payroll` (Dashboard) and `/payroll/run` (Run Payroll).

**Test data setup** (requires Supabase admin API or MCP):
1. Create/verify a test user with admin + staff roles in `user_roles` table
2. Upsert an `employee_payroll_profiles` row with `is_active=true`, an `hourly_rate`, and OT/DT multipliers
3. Ensure the employee has `time_entries` with `clock_in`/`clock_out` timestamps in the target date range

**Key UI paths:**
- Sidebar: "Payroll" (DollarSign icon) -> `/payroll` (PayrollDashboard)
- "Run Payroll" button -> `/payroll/run` (PayrollRun, admin-only)
- "Calculate Payroll" button -> computes CA OT/DT from time entries
- "Process & Save" button -> creates pay_period + payslips in Supabase, navigates back to dashboard

**Calculation engine** (`src/lib/payroll/payroll.engine.ts`):
- Uses `clock_in`/`clock_out` timestamps directly (NOT `total_hours` field)
- Splits overnight shifts at midnight boundaries (`groupByDate`)
- CA rules: Regular <=8h, OT 8-12h (1.5x), DT >12h (2.0x) per calendar day
- Deductions capped at grossPay (never negative net pay)
- All date math uses local time to avoid UTC timezone misattribution

**Expected behavior after processing:**
- Dashboard shows pay period with date range, total wages, premium hours, "PROCESSED" badge
- "Total Paid Out" card only counts periods with status "paid" (not "processed")
- "Total Premium Hours" = OT + DT hours combined

## Supabase MCP Limitations
- The Supabase MCP `execute_sql` tool might be **read-only** for DDL (CREATE TABLE, ALTER TABLE). If migrations fail via MCP, ask the user to run them via [Supabase SQL Editor](https://supabase.com/dashboard/project/PROJECT_ID/sql/new).
- DML (INSERT, UPDATE, SELECT) typically works fine via MCP.
- The `apply_migration` tool might also fail in read-only mode.

## Common Issues
- **D-Bus errors on Linux:** `Failed to connect to the bus` warnings are harmless on headless/minimal Linux environments.
- **GPU errors on Linux:** `Exiting GPU process due to errors during initialization` is normal when no GPU is available; Electron falls back to software rendering.
- **Autofill errors in DevTools:** `Request Autofill.enable failed` messages in console are benign Chromium DevTools warnings.
- **Port conflicts:** If `npx vite --port 8081` says port is in use, check terminal output for the actual port. Previous dev server sessions may have left orphaned processes.
- **RLS policy errors on migration re-run:** If you see "policy already exists" errors, the migration was already applied. This is harmless.

## Devin Secrets Needed
- `STRAIN_VENTORY_TEST_EMAIL` — Test user email for login (e.g., `devin-test@strain-ventory.test`)
- `STRAIN_VENTORY_TEST_PASSWORD` — Test user password
- Supabase credentials (already in `.env`): `VITE_SUPABASE_URL`, `VITE_SUPABASE_ANON_KEY`
- For admin operations (creating users, updating roles): Supabase service role key or admin API access
