---
name: testing-ui-dependencies
description: Test runtime UI dependencies (lucide-react, sonner, vaul, next-themes) after major version bumps. Use when verifying dependency updates don't break icons, toasts, drawers, or theming.
---

# Testing UI Dependencies

## Overview
StrainVentory uses several UI libraries that need runtime verification after major version bumps:
- **lucide-react** — Icon library used across sidebar, auth page, and all forms
- **sonner** — Toast notification system (error/success/info toasts)
- **vaul** — Bottom drawer component (mobile Copilot panel)
- **next-themes** — Theme provider for light/dark mode toggle

## Devin Secrets Needed
- `STRAINVENTORY_LOGIN_PASSWORD` — Login password for the test user

## Prerequisites
- `npm install` completed
- `npm run dev` running (Vite, typically port 8080)

## Testing Lucide-React Icons

**Best locations to verify:**
1. **Auth page** (`/auth`): Has ~12 icons (Hash, KeyRound, Lock, Mail, Eye/EyeOff, ArrowRight, LogIn, Sparkles, RotateCcw, Leaf, UserPlus)
2. **Sidebar** (any authenticated page): 13+ icons (LayoutDashboard, Library, Upload, ImageIcon, FileCheck, Bot, LogOut, ClipboardCheck, ShoppingCart, Settings, DollarSign, PackagePlus, ClipboardList, MessageCircle, User)
3. **Product Intake** (`/product-intake`): Form icons and section headers

**Pass criteria:** All icons render as visible SVG elements, no empty boxes or missing glyphs.

**Tip:** The auth page defaults to PIN mode. Click "Sign in with email" to see additional icons (Mail, LogIn, Sparkles).

## Testing Sonner Toasts

**Easiest triggers:**
1. **Error toast:** On auth page (email mode), enter an email but leave password empty → click Sign In → `toast.error("Please fill in all fields.")`
2. **Success toast:** Log in with valid credentials → `toast.success("Welcome back!")`
3. **Any page with forms:** Most form submissions trigger toast on success/error

**Pass criteria:** Toast appears with styled background/border, correct text, and auto-dismisses.

**Note:** Sonner toasts may auto-dismiss quickly (< 2 seconds). If visual capture is difficult, use CDP/Playwright to check the DOM: `document.querySelectorAll('[data-sonner-toast]')` will show active toasts with their text content. The toaster element is `[data-sonner-toaster]`.

**Sonner component location:** `src/components/ui/sonner.tsx` wraps the Sonner `Toaster` with theme-aware styling.

## Testing Vaul Drawer

**How to trigger:**
- The vaul Drawer is only used on **mobile viewport** (< 768px width)
- On desktop (>= 768px), the same Copilot button opens a **Sheet** (from radix-ui) instead
- Component: `src/components/assistant/GlobalAssistantDrawer.tsx`

**Steps:**
1. Set viewport to mobile width via CDP: `Emulation.setDeviceMetricsOverride` with `width: 400, height: 768, mobile: true`
2. Click the "Copilot" FAB button (bottom-right, has Bot icon)
3. Drawer should slide up from bottom

**Pass criteria:**
- Drawer header shows "Refined Strain Vinny"
- Description: "Premium assistant guidance with confirm-gated actions."
- AssistantCopilotPanel renders inside with chat content

**Important:** After testing, reset viewport with `Emulation.clearDeviceMetricsOverride` followed by `Emulation.setDeviceMetricsOverride` at desktop resolution (1024x768) and reload. Simply calling `clearDeviceMetricsOverride` may not immediately restore the layout — explicitly setting a desktop viewport override + reload is more reliable.

**Desktop alternative:** On desktop viewport, clicking the Copilot FAB opens a Sheet (right panel) instead. This tests the Sheet component but not vaul specifically.

## Testing Theme Toggle (next-themes)

**Location:** Theme toggle button is in the sidebar header area, top-right corner near the app logo (coordinate ~139, 80 on a 1024x768 viewport).

**Steps:**
1. Click the toggle icon (Moon icon in light mode, Sun icon in dark mode)
2. Entire page should switch themes

**Pass criteria:**
- Background, text, cards, sidebar all switch between light and dark colors
- Toggle is reversible (click again returns to original theme)
- No flash of unstyled content during transition

## Login Credentials
- Email: `deananwomack@gmail.com`
- Password: Use `STRAINVENTORY_LOGIN_PASSWORD` secret
- The auth page has two modes: PIN (default) and Email. Click "Sign in with email" to switch.

## Common Issues
- Chrome notification permission popup may appear after login — dismiss with "Block"
- The app might show a Supabase Realtime connection warning in console — this is normal for local dev
- React Router v6 deprecation warnings in console are pre-existing and not related to dependency updates
