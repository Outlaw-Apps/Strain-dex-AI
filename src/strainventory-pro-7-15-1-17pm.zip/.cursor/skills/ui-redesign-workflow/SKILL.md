---
name: ui-redesign-workflow
description: Review an app's existing interface and execute user-requested UI redesigns safely. Use when the user asks for UI design updates, visual refreshes, restyling, layout changes, or improved look and feel. Supports both automatic triggering on UI redesign requests and explicit invocation.
---

# UI Redesign Workflow

## Core directive

For UI design, look through the app thoroughly to understand the current UI. Make a backup, suggest new ideas, and implement new UI according to the user's requests.

## When to use this skill

Use this workflow when the user asks to:
- redesign screens or components
- restyle pages, typography, spacing, or colors
- improve visual consistency or UX flow
- modernize the app's look while keeping functionality

## Workflow

Copy this checklist and update status during work:

```markdown
UI Redesign Progress
- [ ] 1) Audit current UI thoroughly
- [ ] 2) Create a safe backup point
- [ ] 3) Present redesign ideas aligned to request
- [ ] 4) Implement approved UI changes
- [ ] 5) Verify behavior, styling consistency, and responsiveness
```

### 1) Audit current UI thoroughly

- Inspect existing layout structure, page hierarchy, and component reuse.
- Identify current design tokens and conventions (colors, spacing, radius, typography, shadows, motion).
- Note UX pain points and visual inconsistencies relevant to the user's request.
- Avoid changing behavior until the redesign direction is clear.

### 2) Create a safe backup point

- Create a reversible backup before edits:
  - preferred: feature branch or checkpoint commit
  - acceptable: duplicate critical style/component files when requested
- Confirm backup approach in the response before major edits.
- Do not use destructive git commands.

### 3) Present redesign ideas aligned to request

- Provide 2-3 focused options with clear tradeoffs.
- Keep proposals scoped to requested areas.
- Use concrete language (for example: "compact card layout with stronger hierarchy") instead of vague style terms.
- Ask for confirmation if multiple design directions are viable.

### 4) Implement approved UI changes

- Apply changes incrementally and keep files organized.
- Respect project conventions and existing component patterns.
- Keep imports at top-level; avoid inline imports.
- Prefer reusable style primitives over one-off overrides.
- Preserve accessibility: semantic structure, contrast, focus visibility, keyboard flow.

### 5) Verify quality before completion

- Run relevant checks (lint/build/tests as appropriate).
- Validate responsive breakpoints and empty/loading/error states.
- Confirm no functional regressions while visual changes are applied.
- Summarize:
  - what changed
  - why this design matches the request
  - any follow-up refinements that could be done next

## Response format

Use this structure for user-facing updates:

```markdown
## UI audit findings
- ...

## Redesign options
- Option A: ...
- Option B: ...

## Implemented changes
- ...

## Validation
- Commands run: ...
- Results: ...
```

## Guardrails

- Do not remove existing functionality unless the user explicitly requests it.
- Do not claim redesign completion without verifying visual and functional integrity.
- Keep redesign scoped; avoid unrelated refactors.
