# UI Redesign Prompt Examples

## Example 1: Full-page redesign

```text
Use the ui-redesign-workflow skill.
Redesign the Catalog Library page to feel cleaner and more modern while keeping all current functionality.
Start by auditing the current UI and listing pain points.
Create a backup checkpoint before edits.
Give me 2 redesign directions, then implement the one you recommend.
Prioritize better visual hierarchy, spacing, and mobile responsiveness.
```

## Example 2: Component-level refresh

```text
Use the ui-redesign-workflow skill.
Update the product cards and filter toolbar styling in the catalog area.
Do not change behavior.
Audit first, back up, propose 2 options, then implement.
Focus on readability, consistent button styles, and better empty/loading states.
```

## Example 3: Design consistency pass

```text
Use the ui-redesign-workflow skill.
Run a UI consistency pass across the app and fix inconsistent typography, spacing, and color usage.
Audit the current design tokens and patterns first, then suggest a small token cleanup plan.
Create a backup before edits.
Implement only approved changes and validate lint/build after updates.
```
