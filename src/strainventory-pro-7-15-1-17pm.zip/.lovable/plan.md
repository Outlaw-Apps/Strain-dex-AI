
# Strain Vinny → Operational Agent (Phase 1)

## Resolved requirements (from your answers)
- **Approval gates:** POS overrides + compliance-sensitive writes only. Everything else Vinny can execute directly for authorized roles (still logged + reversible where possible).
- **Permissions:** Role-based **per tool** — each tool declares `allowed_roles` in a `tool_registry`; admins configure.
- **Navigation:** **Hybrid** — headless orchestration by default (calls services, shows timeline), with contextual "Open this page" buttons at key steps.
- **Web search:** Reuse existing **Google CSE** (`GOOGLE_CSE_API_KEY` / `GOOGLE_CSE_CX`) with inline `[W1]` citations, same pattern Vinny already uses.

## Preserve (do not touch)
- Existing `vinnyPrompt.ts` persona, tone, avatar, `AssistantCopilotPanel`, `GlobalAssistantDrawer`, current chat streaming, existing action envelope (`AssistantActionEnvelope`), and the existing assistant Edge Function. Phase 1 **extends** these — no rewrites.

## Phase 1 scope

### 1. Architecture
```text
┌─ AssistantCopilotPanel (existing) ─────────────────┐
│  Chat stream (existing)                            │
│  + WorkflowTimeline  (new)                         │
│  + ActionCard list   (new — replaces raw envelope) │
│  + NavigationHints   (new — "Open this page")      │
└──────────────────┬─────────────────────────────────┘
                   │ tool_calls
┌──────────────────▼───────────────────────┐
│  Tool Registry (client + edge)           │
│   - name, description, input schema      │
│   - allowed_roles                        │
│   - requires_approval (POS/compliance)   │
│   - handler: service call (no rewrites)  │
└──────────────────┬───────────────────────┘
                   │
┌──────────────────▼───────────────────────┐
│  Orchestrator (headless by default)      │
│   - session memory (store/role/context)  │
│   - step runner + status                 │
│   - audit log writer                     │
└──────────────────────────────────────────┘
```

### 2. Data model (new tables — all with GRANTs + RLS)
- `copilot_sessions` — user, active store/location, workflow, context blob
- `copilot_actions` — one row per tool invocation: tool_name, input, output, status (`draft|awaiting_approval|running|completed|failed`), route_context, session_id
- `copilot_navigation_events` — route/module visited, headless or real
- `approval_requests` — action_id, requested_by, approver, status, reason
- `tool_registry` — name, description, allowed_roles[], requires_approval, category
- `audit_logs` — actor, action, target, before/after JSON, source (`vinny|user|system`)

Reuse existing `assistant_threads` / `assistant_messages` for chat — link `copilot_actions.thread_id`.

### 3. Tool registry (Phase 1 stubs; wired to real services where they exist)
Read-only + safe tools live now; write tools land in later phases.

| Tool | Phase | Status |
|---|---|---|
| `navigateToPage` | 1 | live (real UI or timeline entry) |
| `openModule` | 1 | live |
| `searchInventory` | 1 | live (reuses `useProducts`) |
| `reviewTimecards` | 1 | live (read-only summary via `useTimeEntries`) |
| `webSearch` | 1 | live (existing Google CSE) |
| `logAuditEvent` | 1 | live |
| `createTask`, `updateTask` | 1 | live (new lightweight tasks table) |
| `sendEmployeeMessage` | 2 | draft-mode UI stub only in P1 |
| `createEmployee`, `assignRole`, `requestDocument` | 2 | stub |
| `createPOSCart`, `applyDiscount`, `requestManagerOverride` | 3 | stub (gated) |
| `createPayrollDraft`, `flagPayrollException` | 4 | stub |

### 4. UI additions (inside existing panel — no new drawer)
- **WorkflowTimeline** — vertical stepper: each `copilot_action` renders with status badge (`Draft`, `Awaiting Approval`, `Running`, `Completed`, `Failed`), duration, and expandable input/output.
- **ActionCard** — replaces the current raw JSON envelope render. Shows tool name, plain-English summary (Vinny's voice), inputs, and either `Run`, `Approve & Run`, or `Open page` per navigation model.
- **Source split** — internal facts vs. web results (`[W1]` chips) already patterned; keep it, extend to action outputs.
- **Session context chip** — shows current store/location/role Vinny is operating as.

### 5. Navigation model (hybrid)
- Orchestrator records a `navigation_event` for every logical step and continues headlessly.
- When a step benefits from the user seeing the page (e.g. approvals, POS), Vinny renders an inline "Open Employee Onboarding" button (`react-router` navigate).
- Workflow context persists in `copilot_sessions.context` so navigating away doesn't lose the flow.

### 6. Personality
Extend `vinnyPrompt.ts` with:
- Tool-calling instructions (when to prefer action vs. answer)
- Approval-awareness ("If tool.requires_approval, produce an action card, do not execute")
- Progress-narration style ("Alright, pulling up timecards now — one sec…")
No changes to persona lines, avatar, or existing formatting rules.

### 7. Safety & audit
- Every tool run writes to `audit_logs` (actor, tool, input hash, before/after, thread_id).
- Approval-required tools cannot execute without a matching `approval_requests.status = 'approved'` row.
- Vinny never bypasses RLS — all writes go through existing hooks/services which already enforce policies.

## Out of scope for Phase 1
Employee messaging send, POS write actions, payroll drafts, document generation, report builders. UI stubs render but return "coming in Phase N".

## Open questions / assumptions
1. **Tasks table** — you don't have a `tasks` table yet; I'll add one in P1 for `createTask`/`updateTask`. OK?
2. **Approval routing** — when a tool requires approval, notify: (a) all admins via existing messaging, or (b) a specific `approver_user_id` set per store? Default: all admins.
3. **"Open page" scope** — safe to auto-navigate for read-only pages (Inventory, Timecards), require click for write pages (POS, Onboarding). OK?
4. **Store/location context** — you have `business_settings` but no multi-location table. Assume single store per workspace for P1; multi-location deferred.

## Risks
- Tool-calling with current Gemini/OpenAI mix requires the Responses API for OpenAI; I'll keep Vinny on his current model and add tool-call parsing in the Edge Function.
- Timeline UI is stateful — I'll persist to `copilot_actions` so refresh doesn't lose progress.
- Adding 7 new tables — migration is large but idempotent, follows your existing GRANT+RLS pattern.

## Deliverables (Phase 1 only)
1. Migration: 7 new tables + RLS + GRANTs + `tool_registry` seed rows.
2. `src/lib/copilot/` — orchestrator, tool registry types, session hook.
3. `src/hooks/useCopilotSession.ts`, `useCopilotActions.ts`.
4. `src/components/assistant/WorkflowTimeline.tsx`, `ActionCard.tsx`, `NavigationHint.tsx`, `SessionContextChip.tsx`.
5. Edit `AssistantCopilotPanel.tsx` to compose the new components (no rewrite).
6. Edit `vinnyPrompt.ts` — append tool-calling + approval sections.
7. Edge Function update: parse tool calls, write `copilot_actions`, stream progress.
8. Tests: tool registry role gating, approval gating, timeline reducer.

Confirm the four open questions above (or accept defaults) and I'll start on Phase 1.
