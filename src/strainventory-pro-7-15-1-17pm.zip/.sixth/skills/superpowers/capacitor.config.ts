import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.superpowers',
  appName: 'superpowers',
  webDir: 'dist'
};

export default config;
