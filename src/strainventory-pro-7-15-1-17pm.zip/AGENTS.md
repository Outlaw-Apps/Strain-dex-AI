# AGENTS.md — StrainVentory

> Guidelines, workflows, and commands for AI agents working in this repository.

## Project Overview

StrainVentory is a cannabis dispensary management platform built with:

- **Frontend**: React 18 + TypeScript + Vite + Tailwind CSS + shadcn/ui
- **Backend**: Supabase (Postgres, Auth, Edge Functions, Storage)
- **Desktop**: Electron wrapper (`electron/main.cjs`)
- **State**: TanStack Query + React Context (`ProductDraftContext`, `AuthContext`)

## Repository Structure

```
src/
├── components/       # Reusable UI components (shadcn/ui wrappers, layout, POS)
│   ├── layout/       # AppSidebar, AppLayout, ProtectedRoute
│   ├── pos/          # Point-of-Sale components (CartPanel, ProductGrid, etc.)
│   ├── settings/     # EmployeeTimeClock, settings sub-panels
│   └── ui/           # Base UI primitives (Button, Card, BarcodeScanner, ManagerOverrideButton)
├── context/          # React context providers (Auth, ProductDraft)
├── hooks/            # Custom hooks (useProducts, useTimeEntries, useBarcodeScanner, useManagerOverride, etc.)
├── integrations/     # Supabase client & generated types
├── lib/              # Utility modules (constants, payroll, dailyLimits, catalogImages, etc.)
├── pages/            # Route-level page components
│   ├── ProductIntake.tsx
│   ├── ImageFinder.tsx
│   ├── Settings.tsx
│   ├── PointOfSale.tsx
│   ├── ShiftClose.tsx
│   ├── EmployeeOnboarding.tsx
│   ├── PayrollDashboard.tsx / PayrollRun.tsx
│   └── ...
├── test/             # Vitest unit tests
└── types/            # Shared TypeScript types
supabase/
├── functions/        # Supabase Edge Functions (Deno)
│   ├── fetch-product-images/   # DuckDuckGo image search for product images
│   ├── generate-draft/         # AI draft generation
│   └── dynamic-service/        # Dynamic service router
├── migrations/       # SQL migration files (must be idempotent — use IF NOT EXISTS)
└── config.toml
electron/             # Electron desktop wrapper
e2e/                  # Playwright end-to-end tests
```

## Commands

### Development

| Command | Description |
|---------|-------------|
| `npm run dev` | Start Vite dev server (web) |
| `npm run build` | Production build |
| `npm run lint` | Run ESLint |
| `npm run test` | Run Vitest unit tests |
| `npm run test:watch` | Run Vitest in watch mode |
| `npm run test:e2e` | Run Playwright end-to-end tests (run `npx playwright install` once after clone if browsers are missing) |
| `npm run electron:dev` | Start Electron dev mode (Vite + Electron) |
| `npm run electron:build` | Build Electron distributable |

### Performance Audit

| Command | Description |
|---------|-------------|
| `npm run build` | Produce a fresh production bundle with per-asset size output |
| `node -e "const fs=require('fs');const path=require('path');const dir='dist/assets';const files=fs.readdirSync(dir).map(name=>{const p=path.join(dir,name);const s=fs.statSync(p);return s.isFile()?{name,size:s.size}:null;}).filter(Boolean).sort((a,b)=>b.size-a.size).slice(0,15);console.table(files);"` | Print the 15 largest built assets for quick hotspot triage |

### Pre-commit

Always run before committing:

```bash
npm run lint && npm run build
```

### Pre-release Checklist

Run all of these before tagging a release:

```bash
npm run lint          # 0 errors, 0 warnings
npm run build         # Clean production build
npm run test          # All unit tests green
npm run test:e2e      # All E2E tests green (requires Playwright browsers)
```

### Supabase

#### Edge Functions

Edge functions live in `supabase/functions/`. They use Deno and are deployed via the Supabase CLI.

```bash
supabase functions serve   # Local dev
supabase functions deploy <function-name>
```

#### Migrations

All migration files in `supabase/migrations/` **must be idempotent**:

- Use `CREATE TABLE IF NOT EXISTS` instead of bare `CREATE TABLE`
- Use `DROP POLICY IF EXISTS` before `CREATE POLICY`
- Use `CREATE OR REPLACE FUNCTION` for functions
- Use `DROP TRIGGER IF EXISTS` before `CREATE TRIGGER`

This prevents `relation already exists` errors when migrations are re-applied against an existing database.

## Workflows

### Adding a New Page

1. Create the page component in `src/pages/`
2. Add the route in `src/App.tsx` inside the `<ProtectedRoute>` layout
3. Add sidebar navigation in `src/components/layout/AppSidebar.tsx`
4. Add any required hooks in `src/hooks/`

### Adding a New Form with Required Fields

1. Mark required fields with `<span className="text-destructive">*</span>` in labels
2. Add validation logic that checks all required fields
3. Import `useManagerOverride` and `ManagerOverrideButton` to support admin override
4. Wrap validation with `if (!managerOverride.overrideActive) { ... }`
5. Place `<ManagerOverrideButton override={managerOverride} />` in the page header

### Barcode Scanner Integration

Use the `BarcodeScanner` component + `useBarcodeScanner` hook:

```tsx
import { BarcodeScanner } from "@/components/ui/BarcodeScanner";

<BarcodeScanner
  open={scannerOpen}
  onOpenChange={setScannerOpen}
  onScan={(result) => handleBarcode(result.text)}
  title="Scan SKU Barcode"
/>
```

Supports camera, hardware wedge, and manual entry modes.

The camera scanner includes:
- Progressive resolution fallback (1280→640→environment→any)
- Automatic retry on transient camera failures (up to 2 retries)
- Autofocus hints for devices that support continuous focus
- Video-readiness gate (waits for `loadeddata` before decoding)
- Stream-ended auto-recovery (re-acquires camera if the track drops)

### Performance Regression Audit (Bundle-Focused)

1. Build with `npm run build` and capture emitted chunk sizes.
2. Rank largest assets with the Node command in `Commands > Performance Audit`.
3. Compare current hotspots with the latest build section in `health-report.md`.
4. Prioritize fixes that remove eager bytes first (large static images, scanner/code-split boundaries, and font payload).

### Daily Limit Tracking

The POS enforces California daily purchase limits:
- **Flower**: 28.5 g
- **Concentrate**: 8 g

Logic lives in `src/lib/dailyLimits.ts` (`computeDailyLimits`).

Category resolution order:
1. Explicit `limit_category` field on the product (`"Flower"` or `"Concentrate"`)
2. Inferred from `product_type` (e.g. `"Wax"`, `"Live Resin"` → Concentrate)
3. Fallback to `type` field

When adding new product types, update the `CONCENTRATE_TYPES` / `FLOWER_TYPES` sets in `src/lib/dailyLimits.ts` so they are correctly tracked.

### Image Finder

The image finder uses DuckDuckGo image search via the `fetch-product-images` edge function.
Client-side: `useCatalogImageSearch` hook → `ImageFinder` page.
The edge function includes retry logic, rate-limit backoff, and multiple vqd token extraction patterns.

### Manager Override System

Admin accounts can bypass mandatory form validation on any page:

- **Hook**: `useManagerOverride()` — returns `{ canOverride, overrideActive, toggleOverride }`
- **Component**: `<ManagerOverrideButton override={...} />` — toggle button, only visible to admins
- **Timeclock**: Admins can edit/delete any time entry inline from the EmployeeTimeClock component
- **Integrated pages**: ProductIntake, EmployeeOnboarding, EmployeeTimeClock

### Payroll Override

Employee payroll overrides are managed via `PayrollEmployeeOverride` in `src/lib/payroll.ts`.
Admins can override hours, rates, bonuses, deductions per employee per pay period.

### Employee Onboarding

New employees are onboarded via `src/pages/EmployeeOnboarding.tsx`.
Records are stored in the `employees` table. The migration (`20260403200000_create_employees_table.sql`) is idempotent.
Document uploads go to the `employee-documents` Supabase Storage bucket.

## Code Conventions

- **Imports**: Always at the top of the file; use `@/` path alias
- **Components**: Functional components with TypeScript props interfaces
- **Hooks**: Custom hooks prefixed with `use`, placed in `src/hooks/`
- **Styling**: Tailwind utility classes; use `cn()` from `@/lib/utils` for conditional classes
- **Toasts**: Use `toast` from `sonner` for user notifications
- **Animations**: Framer Motion (`motion.div`) for page/component transitions
- **State**: TanStack Query for server state; React Context for global app state
- **Types**: Prefer explicit interfaces over `any`; use Supabase generated types
- **Fast Refresh**: Each `.tsx` file should only export React components. Move shared constants or utility functions to `src/lib/` to avoid the `react-refresh/only-export-components` lint warning.

## Environment Variables

Required in `.env`:

```
VITE_SUPABASE_URL=<your-supabase-url>
VITE_SUPABASE_PUBLISHABLE_KEY=<your-anon-key>
```

## Testing

- Unit tests: `npm run test` (Vitest)
- E2E tests: `npm run test:e2e` (Playwright)
- Desktop: See `.agents/skills/testing-electron-desktop/SKILL.md`

## PR Guidelines

- Run `npm run lint && npm run build` before creating a PR
- Keep changes scoped and focused
- Follow existing code style and component patterns
- Never commit `.env` or credentials
