# Deployment Guide — StrainVentory on GitHub + Vercel + Supabase

This guide walks you through taking the exported codebase and deploying it
end-to-end with **your own** Supabase project and a Vercel frontend. No
Lovable infrastructure is required after export.

---

## 0. Prerequisites

- Node.js 20+ and npm
- A GitHub account and empty repository
- A Vercel account
- A Supabase account (free tier is fine to start)
- The [Supabase CLI](https://supabase.com/docs/guides/cli): `npm i -g supabase`

---

## 1. Create your Supabase project

1. Go to https://supabase.com/dashboard → **New project**.
2. Save these values from **Project Settings → API**:
   - Project URL → `VITE_SUPABASE_URL`
   - `anon` / `public` key → `VITE_SUPABASE_PUBLISHABLE_KEY` **and** `VITE_SUPABASE_ANON_KEY`
   - `service_role` key → keep secret, backend-only
   - Project Ref (e.g. `abcdxyz…`) → `VITE_SUPABASE_PROJECT_ID`
3. Copy the DB connection string from **Project Settings → Database**.

---

## 2. Clone the repo locally and install

```bash
git clone git@github.com:<you>/<repo>.git
cd <repo>
npm install
cp .env.example .env.local
# fill in VITE_SUPABASE_URL, VITE_SUPABASE_PUBLISHABLE_KEY, VITE_SUPABASE_ANON_KEY
```

Sanity-check the toolchain:

```bash
npm run dev       # http://localhost:8080
npm run build
npm run preview
```

---

## 3. Apply database migrations

The full schema lives in `supabase/migrations/`. Link and push:

```bash
supabase login
supabase link --project-ref <YOUR_PROJECT_REF>
supabase db push
```

This creates every table, RLS policy, trigger, function, and enum used by the
app. Migrations are idempotent — safe to re-run.

Regenerate the typed client if you make schema changes:

```bash
npm run types:generate
```

---

## 4. Configure Supabase Auth

**Auth → URL Configuration**

- **Site URL**: your Vercel production URL, e.g. `https://app.example.com`
- **Additional Redirect URLs** (one per line):
  ```
  http://localhost:8080
  http://localhost:8080/**
  https://<your-vercel-project>.vercel.app
  https://<your-vercel-project>.vercel.app/**
  https://app.example.com
  https://app.example.com/**
  ```
  Include the wildcard variants so `/auth`, `/reset-password`, and preview
  deployments all work.

**Auth → Providers**

- **Email**: enable. For dev, turn OFF "Confirm email" so signups work
  without SMTP. For production, wire up SMTP or Resend and turn it back on.
- **Google / Apple / GitHub** (optional): enable in Supabase, then paste
  the Supabase callback URL (`https://<project>.supabase.co/auth/v1/callback`)
  into the provider's OAuth console as an authorized redirect URI.

**Auth → Policies**

- Leaked password protection: **ON** (Password HIBP).
- Minimum password length: 8+.
- Rate limits: leave defaults unless you see 429s at scale.

---

## 5. Storage buckets

Buckets are created by the migrations, but verify in **Storage**:

| Bucket                | Public? | Purpose                          |
| --------------------- | ------- | -------------------------------- |
| `product-images`      | Yes     | Catalog product photos           |
| `avatars`             | No      | User avatars (signed URLs)       |
| `message-attachments` | No      | Messenger attachments            |

RLS policies for storage are included in the migrations. If you rename a
bucket, also update `VITE_PRODUCT_IMAGES_BUCKET` / `VITE_AVATARS_BUCKET`.

---

## 6. Deploy Edge Functions

```bash
supabase functions deploy assistant-chat
supabase functions deploy generate-draft
supabase functions deploy generate-product-draft
supabase functions deploy fetch-product-images
supabase functions deploy provision-pin-user
supabase functions deploy pos-webhook
supabase functions deploy admin-users
supabase functions deploy metrc-proxy
supabase functions deploy sync-strain-knowledge
supabase functions deploy send-transactional-email
supabase functions deploy process-email-queue
supabase functions deploy preview-transactional-email
supabase functions deploy handle-email-unsubscribe
supabase functions deploy handle-email-suppression
supabase functions deploy dispatch-scheduled-emails
supabase functions deploy cleanup-message-attachments
supabase functions deploy dynamic-service
supabase functions deploy ai-diagnostics
```

Set backend secrets (values never appear in the browser):

```bash
supabase secrets set DEEPSEEK_API_KEY=sk-...
supabase secrets set DEEPSEEK_MODEL=deepseek-chat
supabase secrets set GOOGLE_CSE_API_KEY=...
supabase secrets set GOOGLE_CSE_CX=...
supabase secrets set POS_WEBHOOK_SECRET="$(openssl rand -hex 32)"
supabase secrets set RESEND_API_KEY=...   # only if using Resend
```

`SUPABASE_URL`, `SUPABASE_ANON_KEY`, `SUPABASE_SERVICE_ROLE_KEY`, and
`SUPABASE_JWKS` are auto-injected — do **not** set them manually.

---

## 7. Push to GitHub

```bash
git remote add origin git@github.com:<you>/<repo>.git
git push -u origin main
```

---

## 8. Deploy to Vercel

1. https://vercel.com/new → **Import Git Repository** → pick your repo.
2. Framework preset: **Vite** (auto-detected).
3. Build command: `npm run build` — Output directory: `dist`.
4. **Environment Variables** — add for `Production`, `Preview`, `Development`:

   | Variable                          | Value                                     |
   | --------------------------------- | ----------------------------------------- |
   | `VITE_APP_ENV`                    | `production`                              |
   | `VITE_SUPABASE_URL`               | `https://<ref>.supabase.co`               |
   | `VITE_SUPABASE_PUBLISHABLE_KEY`   | anon key                                  |
   | `VITE_SUPABASE_ANON_KEY`          | same anon key (alias)                     |
   | `VITE_SUPABASE_PROJECT_ID`        | project ref                               |
   | `VITE_SITE_URL`                   | `https://app.example.com`                 |
   | `VITE_PRODUCT_IMAGES_BUCKET`      | `product-images`                          |
   | `VITE_AVATARS_BUCKET`             | `avatars`                                 |
   | `VITE_SENTRY_DSN` (optional)      | your DSN                                  |

5. Deploy. Vercel picks up `vercel.json` which handles SPA rewrites (all
   client routes fall through to `index.html`) and long-cache headers.

---

## 9. Custom domain

1. Vercel → Project → **Settings → Domains** → add `app.example.com`.
2. Add the CNAME / A record shown by Vercel to your DNS.
3. Update Supabase **Auth → Site URL** and **Additional Redirect URLs** to
   include the new domain (see step 4).
4. Update `VITE_SITE_URL` in Vercel env and redeploy.

---

## 10. Verify the deployment

- Load the production URL → sign up with a test email.
- Confirm you can create a product, upload an image, run through POS
  checkout with a PIN, and see the record in Supabase Table Editor.
- Refresh a nested route (e.g. `/pos`) — it should NOT 404.
- Check `Auth → Users` — new user shows up with the right role.
- Watch Vercel deployment logs and `supabase functions logs <name>` for
  errors on first traffic.

---

## Troubleshooting

- **`Missing VITE_SUPABASE_*`** at runtime → env var not set in Vercel for
  that environment (Production vs Preview).
- **CORS errors from an edge function** → the function must respond to
  `OPTIONS` with `corsHeaders`. All shipped functions already do; only
  applies if you fork one.
- **OAuth "redirect_uri mismatch"** → the exact URL (including trailing
  slash) is not in Supabase **Additional Redirect URLs**.
- **Nested route 404 on refresh** → `vercel.json` missing or the deploy
  predates it; redeploy.
