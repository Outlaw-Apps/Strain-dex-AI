## The Core Idea

Right now the hooks look like this:

```
useCustomers.ts  →  supabase.from("customers").select(...)
```

After the refactor they look like this:

```
useCustomers.ts  →  CustomerRepo.findAll()
CustomerRepo.ts  →  supabase.from("customers").select(...)
```

***

## Step 1 — Create the folder structure

```
src/
  lib/
    data/
      CustomerRepo.ts       ← Supabase implementation (now)
      CustomerRepo.mock.ts  ← optional mock for tests
    repos.ts                ← barrel export of all repos
  integrations/
    supabase/
      client.ts             ← stays exactly where it is
```

***

## Step 2 — Define the interface + Supabase implementation

Create `src/lib/data/CustomerRepo.ts`:

```typescript
// src/lib/data/CustomerRepo.ts
import { supabase } from "@/integrations/supabase/client";

// ── Types ─────────────────────────────────────────────────────────────────────
// Move the Customer interface here so it's owned by the data layer,
// not the hook layer. Hooks import from here.
export interface Customer {
  id: string;
  customer_number: string;
  name: string;
  email: string;
  phone: string;
  notes: string;
  license_number: string | null;
  date_of_birth: string | null;
  last_age_verified_at: string | null;
  created_at: string;
  updated_at: string;
}

export type CreateCustomerInput = {
  name: string;
  phone: string;
  email?: string;
  license_number?: string;
  date_of_birth?: string;
  last_age_verified_at?: string;
};

// ── Interface contract ────────────────────────────────────────────────────────
// This is what the hooks depend on. Future backends must satisfy this shape.
export interface ICustomerRepo {
  findAll(): Promise<Customer[]>;
  search(query: string): Promise<Customer[]>;
  findByLicense(licenseNumber: string): Promise<Customer | null>;
  create(input: CreateCustomerInput): Promise<Customer>;
}

// ── Supabase implementation ───────────────────────────────────────────────────
export const CustomerRepo: ICustomerRepo = {
  async findAll() {
    const { data, error } = await supabase
      .from("customers")
      .select("*")
      .order("created_at", { ascending: false });
    if (error) throw error;
    return (data ?? []) as Customer[];
  },

  async search(query: string) {
    if (!query || query.length < 2) return [];
    const { data, error } = await supabase
      .from("customers")
      .select("*")
      .or(
        `customer_number.ilike.%${query}%,name.ilike.%${query}%,` +
        `phone.ilike.%${query}%,license_number.ilike.%${query}%`
      )
      .limit(10);
    if (error) throw error;
    return (data ?? []) as Customer[];
  },

  async findByLicense(licenseNumber: string) {
    const { data, error } = await supabase
      .from("customers")
      .select("*")
      .eq("license_number", licenseNumber)
      .maybeSingle();
    if (error) throw error;
    return data as Customer | null;
  },

  async create(input: CreateCustomerInput) {
    const num = `C-${Date.now().toString(36).toUpperCase()}`;
    const { data, error } = await supabase
      .from("customers")
      .insert({
        customer_number: num,
        name: input.name,
        phone: input.phone,
        email: input.email ?? "",
        license_number: input.license_number ?? null,
        date_of_birth: input.date_of_birth ?? null,
        last_age_verified_at: input.last_age_verified_at ?? null,
      })
      .select()
      .single();
    if (error) throw error;
    return data as Customer;
  },
};
```

***

## Step 3 — Refactor the hook to use the repo

Now `useCustomers.ts` has **zero Supabase imports**. It only talks to `CustomerRepo`:

```typescript
// src/hooks/useCustomers.ts
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { CustomerRepo, type Customer, type CreateCustomerInput } from "@/lib/data/CustomerRepo";

// Re-export Customer type so existing imports don't break
export type { Customer };

export const useCustomers = () =>
  useQuery({
    queryKey: ["customers"],
    queryFn: () => CustomerRepo.findAll(),
    staleTime: 60_000,
  });

export const useCustomerSearch = (query: string) =>
  useQuery({
    queryKey: ["customers", "search", query],
    queryFn: () => CustomerRepo.search(query),
    enabled: query.length >= 2,
    staleTime: 10_000,
  });

export const useCreateCustomer = () => {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (input: CreateCustomerInput) => CustomerRepo.create(input),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["customers"] }),
  });
};

export const useCustomerByLicense = (licenseNumber: string | null) =>
  useQuery({
    queryKey: ["customers", "license", licenseNumber],
    queryFn: () => CustomerRepo.findByLicense(licenseNumber!),
    enabled: !!licenseNumber,
    staleTime: 30_000,
  });
```

The hook went from 72 lines to 30. All the query logic is now in one place.

***

## Step 4 — Barrel export for cleanliness

Create `src/lib/repos.ts`:

```typescript
// src/lib/repos.ts
// Single import point for all repos.
// Swap any implementation here when migrating off Supabase.

export { CustomerRepo }    from "./data/CustomerRepo";
export { ProductRepo }     from "./data/ProductRepo";
export { OrderRepo }       from "./data/OrderRepo";
export { InventoryRepo }   from "./data/InventoryRepo";
// add more as you create them
```

Hooks then import from `@/lib/repos` instead of digging into individual files:

```typescript
import { CustomerRepo } from "@/lib/repos";
```

***

## Step 5 — Repeat the pattern for every hook

| Hook file | Repo to create | Key methods to extract |
| :-- | :-- | :-- |
| `useProducts.ts` | `ProductRepo.ts` | `findAll`, `findById`, `search`, `create`, `update` |
| `useOrders.ts` | `OrderRepo.ts` | `findByDate`, `create`, `updateStatus`, `void` |
| `useTodaysSales.ts` | Extends `OrderRepo` | `findToday`, `sumRevenue` |
| `useProfiles.ts` | `ProfileRepo.ts` | `getById`, `update` |
| `useUserRoles.ts` | `RoleRepo.ts` | `getRolesForUser` |
| `useActiveEmployees.ts` | `EmployeeRepo.ts` | `findActive`, `findAll` |
| `useShiftReports.ts` | `ShiftRepo.ts` | `create`, `close`, `findByDate` |
| `useTimeEntries.ts` | `TimeEntryRepo.ts` | `clockIn`, `clockOut`, `findByEmployee` |
| `useMessages.ts` | `MessageRepo.ts` | `findByThread`, `send`, `markRead` |
| `useBusinessSettings.ts` | `SettingsRepo.ts` | `get`, `update` |

***

## What "swapping the backend" looks like later

When I move to my self-hosted backend, I only do this:

```typescript
// Before (Supabase):
export const CustomerRepo: ICustomerRepo = {
  async findAll() {
    const { data, error } = await supabase.from("customers").select("*")...
  }
}

// After (your own API):
export const CustomerRepo: ICustomerRepo = {
  async findAll() {
    const res = await fetch("/api/customers", { headers: authHeaders() });
    if (!res.ok) throw new Error(await res.text());
    return res.json() as Promise<Customer[]>;
  }
}
```

Every hook, every component, every page — **zero changes**. The interface contract ensures TypeScript will immediately tell me if my new backend implementation is missing a method or returning the wrong shape.

***

## Rule of thumb going forward

- Hooks own **React Query config** (keys, staleTime, enabled) and **UI invalidation logic**
- Repos own **data access** (queries, mutations, error mapping, retries)
- Components and pages import only from hooks — never directly from repos or Supabase

If you ever find yourself writing `supabase.from(...)` inside a `.tsx` file, that's the signal to push it down into a repo method first.
