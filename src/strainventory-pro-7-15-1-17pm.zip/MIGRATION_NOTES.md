# Migration Notes — Leaving Lovable Cloud

Audit of Lovable-specific surfaces found in this codebase and how each was
handled for a clean handoff to GitHub + Vercel + Supabase.

## Lovable-specific dependencies found

| Surface                                | Status   | Notes |
| -------------------------------------- | -------- | ----- |
| `lovable-tagger` (Vite dev plugin)     | Optional | Loaded lazily in `vite.config.ts`. Safe to remove: `npm remove lovable-tagger`. Build succeeds either way. |
| `lovable-agent-playwright-config`      | Optional | Only referenced in `playwright-fixture.ts`. If you don't use Lovable's managed Playwright config, replace with `export { test, expect } from "@playwright/test";`. |
| `.claude/`, `.cursor/`, `.sixth/`, `.workspace/` | Ignore | Editor/agent scratch dirs. Not shipped. Fine to keep or delete. |
| `id-preview--*.lovable.app` URLs       | None in code | The preview URL exists at hosting layer only. No code references. |
| Lovable Cloud "managed Supabase"       | Replaceable | The app talks to Supabase via the standard `@supabase/supabase-js` client at `src/integrations/supabase/client.ts`. Point `VITE_SUPABASE_URL` / `VITE_SUPABASE_PUBLISHABLE_KEY` at your own project. |
| Lovable AI Gateway (`LOVABLE_API_KEY`) | Replaceable | Used by edge functions that call AI models through Lovable's gateway. After export, set `DEEPSEEK_API_KEY` (or your provider of choice) and update the fetch URL in the affected edge functions. Search: `grep -r LOVABLE_API_KEY supabase/functions`. |
| `componentTagger` markers in JSX       | Cosmetic | Injected by `lovable-tagger` at dev-time only; strip nothing — production builds already exclude them. |
| Supabase config auto-managed by Lovable| Replaced | `supabase/config.toml` is committed and portable. `supabase link` + `supabase db push` works standalone. |

## What was changed in this export

- **`vite.config.ts`** — `lovable-tagger` import made lazy so the project
  still builds if the package is uninstalled.
- **`vercel.json`** (new) — SPA rewrites so client-side routes don't 404 on
  refresh; long-cache headers for `/assets/*`; basic security headers.
- **`.env.example`** — expanded with every variable the app reads, plus
  `VITE_SUPABASE_ANON_KEY` as an explicit alias for
  `VITE_SUPABASE_PUBLISHABLE_KEY`, and a documented list of backend-only
  secrets to set via `supabase secrets set`.
- **`DEPLOYMENT.md`** (new) — end-to-end deploy runbook.
- **`PRODUCTION_READINESS_CHECKLIST.md`** (new) — go-live gate.

## What was intentionally NOT changed

- **Business logic, RLS policies, edge functions, and UI code**. They are
  already stack-standard (React + Vite + Supabase) and would risk
  regressions if rewritten. The app runs against any Supabase project.
- **`src/integrations/supabase/client.ts`** and `types.ts` — auto-generated;
  regenerate types with `npm run types:generate` after schema changes.
- **Electron / Capacitor wrappers** — kept as-is. Independent of the web
  deploy; ignore if you only ship to Vercel.

## Manual steps that remain (owner-only decisions)

1. Decide whether to keep `lovable-tagger` and `lovable-agent-playwright-config`.
   Remove with `npm remove lovable-tagger lovable-agent-playwright-config` if
   you want zero Lovable footprint.
2. Choose an AI provider for edge functions that were pointed at Lovable AI
   Gateway. Set `DEEPSEEK_API_KEY` (or OpenAI/Anthropic/etc.) and update the
   fetch URL. Affected functions: `assistant-chat`, `generate-draft`,
   `generate-product-draft`, `ai-diagnostics`, `sync-strain-knowledge`.
3. Configure a real transactional email sender (Resend/SendGrid/SES) if you
   want emails in production — the `send-transactional-email` and
   `process-email-queue` functions expect `RESEND_API_KEY` by default.
4. Set Auth **Site URL** and redirect URLs in Supabase to match your Vercel
   domain (see `DEPLOYMENT.md` step 4).
5. Rotate any credentials that were shared with Lovable Cloud (Supabase
   service_role, third-party API keys) after full cutover.

## Known limitations

- **Real-time features** (messenger, notifications) rely on Supabase
  Realtime. Verify the tables you care about have realtime enabled in the
  Supabase dashboard (Database → Replication).
- **Metrc integration** requires a valid Metrc API key per state. The
  `metrc-proxy` edge function forwards calls but does not include keys.
- **Camera / barcode scanning** requires HTTPS in production — Vercel
  provides that automatically.

## Values I need from you

To fully finalize the handoff, please provide (or set yourself in Vercel /
Supabase — none should be pasted into chat):

- Supabase project URL and anon key
- Production domain (e.g. `app.example.com`)
- OAuth provider credentials if you want Google / Apple / GitHub login
- `DEEPSEEK_API_KEY` (or alternative AI provider) if you want AI drafting
- `GOOGLE_CSE_API_KEY` + `GOOGLE_CSE_CX` if you want image search
- `RESEND_API_KEY` if you want transactional email
