# Live Messenger Notifications

Real-time notifications for the StrainVentory messenger, backed by Supabase
Realtime on the `conversation_messages` table.

## Architecture

```
useMessengerNotifications (src/hooks/useMessengerNotifications.ts)
        │  one Supabase channel per signed-in user
        ▼
MessengerNotificationsProvider (src/context/MessengerNotificationsContext.tsx)
        │  shares state via React context
        ├── AppSidebar  → red badge on the Messages nav item
        └── Messages    → sets activeChannelId; calls clearNotifications()
```

- Subscribes on mount, unsubscribes on unmount.
- Skips messages where `sender_id === userId` (don't notify about your own).
- Suppresses the chime + badge increment when **window is focused AND** the
  message arrives in the currently-open `activeChannelId`.
- Plays a two-note Web Audio sine chime (no external audio files).
- Requests the browser `Notification` permission once on first mount; if
  denied, gracefully skips the OS notification.
- Updates `document.title` to `(N) StrainVentory` while there are unread
  messages, restores the original title on unmount.

## Platform behavior

### Web (Vite dev / production build)

Works out of the box. `Notification.requestPermission()` is invoked the first
time a signed-in user mounts the provider. The Web Audio chime requires a
prior user gesture in some browsers (Chromium policy); the first
notification chime after login may be silent until the user interacts with
the page.

### Capacitor (Android)

- **Realtime subscription**: works — Capacitor's WebView shares the same
  Supabase JS client as the web build.
- **Browser `Notification` API**: NOT available in the Capacitor WebView.
  The notification call is wrapped in a try/catch and silently no-ops.
  For real Android push, install [`@capacitor/local-notifications`][1] and
  swap `showBrowserNotification` to call `LocalNotifications.schedule(...)`
  when running under Capacitor (detect via `Capacitor.isNativePlatform()`).
- **Document title**: ignored by Android; harmless.
- **Audio**: Web Audio works inside the WebView.

### Electron (Desktop)

- **Realtime subscription**: works.
- **Browser `Notification` API**: works in renderer; Electron forwards to OS
  notifications. On Windows you may need to set `app.setAppUserModelId(...)`
  in `electron/main.cjs` for the OS to surface notifications without
  Electron's default branding.
- **Document title**: visible on the window title bar, but most users won't
  see it when the app is backgrounded. Consider also setting the dock /
  taskbar badge (`app.setBadgeCount(unreadCount)` on macOS/Linux) for a
  better unread cue.
- **Audio**: works.

## Caveats

- The current chime is decorative; if the page is loaded but the user has
  never interacted with it, autoplay policies may block the first chime.
- Browser `Notification` permission is requested implicitly on hook mount.
  This is intentional — the page is already authenticated when the hook
  runs — but if you want a more explicit UX, gate the request behind a
  user-initiated "Enable notifications" button.
- The provider mounts inside `AppLayout`, which is itself behind
  `ProtectedRoute`. Public routes (e.g. `/auth`, `/vinny-preview`) get no
  notifications — by design.

[1]: https://capacitorjs.com/docs/apis/local-notifications
