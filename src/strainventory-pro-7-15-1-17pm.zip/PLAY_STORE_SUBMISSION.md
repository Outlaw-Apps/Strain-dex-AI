# Google Play (Paid App) Submission Checklist

## Pricing model
- Configure this app as a **Paid app** in Google Play Console (`Monetize > Products > App pricing`) before first publish.
- Paid/free status cannot be changed after first publication, so confirm pricing before rollout.

## Build configuration in this repo
- Android package ID: `com.strainventory.app`.
- Release version metadata is set in `android/app/build.gradle` (`versionCode`, `versionName`).
- Internet permission is enabled for API-powered catalog and image search.

## Submission readiness checks
1. Build web assets: `npm run build`.
2. Sync Capacitor Android shell: `npx cap sync android`.
3. Build signed release AAB from Android Studio (`Build > Generate Signed Bundle / APK`).
4. Upload AAB to Play Console internal testing.
5. Validate:
   - AI draft fields only include factual values or blank values.
   - Image finder returns verified real catalog/product imagery.
   - No hard-coded mock metrics/content appears in dashboard or review flows.

## Policy notes
- Avoid medical claims unless sourced and compliant with applicable law.
- Keep uncertain or missing product data blank for manual editor completion.
