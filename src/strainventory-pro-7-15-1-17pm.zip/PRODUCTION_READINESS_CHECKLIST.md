# Production Readiness Checklist

Work top-to-bottom before flipping traffic to production.

## Repo & build

- [ ] `npm install` on a clean clone succeeds
- [ ] `npm run lint` passes
- [ ] `npm run build` produces a `dist/` with no warnings you can't explain
- [ ] `npm run preview` serves the production bundle and loads without errors
- [ ] `npm run test` all green
- [ ] `npm run test:e2e` all green (or explicitly skipped with reason)
- [ ] No `console.log` / `debugger` in production code paths
- [ ] `.env.local` is in `.gitignore` and no secrets in git history

## Supabase — database

- [ ] `supabase db push` applied cleanly to the production project
- [ ] Every `public.*` table has RLS **enabled**
- [ ] Every `public.*` table has at least one policy scoped to `auth.uid()`
- [ ] Every `public.*` table has explicit `GRANT` statements for the roles
      its policies allow (no reliance on default grants)
- [ ] `user_roles` table exists and roles are stored there (never on `profiles`)
- [ ] `has_role(uuid, app_role)` is `SECURITY DEFINER` with a fixed `search_path`
- [ ] `supabase linter` reports no ERROR-level findings
- [ ] Indexes exist on every FK and on columns used in WHERE clauses of hot queries
- [ ] Backups: point-in-time recovery enabled (Supabase Pro) OR scheduled logical dumps

## Supabase — auth

- [ ] Site URL points to production domain
- [ ] Additional Redirect URLs include prod domain + wildcard + Vercel preview domain
- [ ] Email confirmation: ON for production
- [ ] Password HIBP check: ON
- [ ] Min password length: 8+
- [ ] Anonymous sign-ins: OFF (unless intentionally on)
- [ ] Signups: enabled/disabled matches product intent
- [ ] OAuth providers: callback URL correctly configured in each provider console
- [ ] SMTP or Resend configured; test email delivered

## Supabase — storage

- [ ] `product-images`: public, RLS policies for insert/update scoped to auth users
- [ ] `avatars`: private, users can read/write only their own path
- [ ] `message-attachments`: private, only conversation members can read
- [ ] File-size limits set per bucket
- [ ] MIME-type restrictions where appropriate

## Supabase — edge functions

- [ ] All required functions deployed (`supabase functions list`)
- [ ] Each function validates its input (Zod or equivalent) and returns 400 on bad input
- [ ] Each function validates JWT in code (project uses signing keys, `verify_jwt = false` in `config.toml`)
- [ ] CORS headers on every response, including errors
- [ ] Every third-party call surfaces provider error status + body to the caller
- [ ] Secrets set: `DEEPSEEK_API_KEY`, `GOOGLE_CSE_API_KEY`, `GOOGLE_CSE_CX`, `POS_WEBHOOK_SECRET`, `RESEND_API_KEY` (as applicable)

## Vercel

- [ ] Project linked to correct GitHub repo/branch
- [ ] Production env vars set for `VITE_SUPABASE_URL`, `VITE_SUPABASE_PUBLISHABLE_KEY`, `VITE_SUPABASE_ANON_KEY`, `VITE_SITE_URL`, `VITE_APP_ENV=production`
- [ ] Preview env vars set (usually same values or a staging Supabase project)
- [ ] `vercel.json` SPA rewrite in place — refresh on `/pos`, `/settings`, etc. does not 404
- [ ] Custom domain attached and HTTPS active
- [ ] Deployment protection configured if this is not a public app

## Frontend hardening

- [ ] Auth: `onAuthStateChange` listener registered early; `getUser()` used for anything that must trust the user
- [ ] Protected routes redirect unauthenticated users to `/auth`
- [ ] Loading, empty, and error states on every data view
- [ ] Forms validate client-side AND server-side (RLS/CHECK/triggers)
- [ ] Network failures show a toast, don't leave silent broken UI
- [ ] Session expiry → user is redirected to `/auth`, not stuck on a blank screen
- [ ] Images use `loading="lazy"` where below the fold
- [ ] No client-side admin checks based on localStorage/hardcoded IDs — only `has_role()`

## SEO / meta

- [ ] `<title>` and `<meta name="description">` real and unique per major route
- [ ] `og:title`, `og:description`, `og:type`, `twitter:card` set
- [ ] `public/robots.txt` and `public/sitemap.xml` reflect the production domain
- [ ] Canonical tags on public pages

## Observability

- [ ] Sentry (or equivalent) DSN wired — error visible in dashboard after a forced throw
- [ ] Vercel analytics or logs reviewed for the first 24 hours
- [ ] Supabase logs → Postgres and Edge Functions monitored for errors

## Post-cutover

- [ ] Rotate `SUPABASE_SERVICE_ROLE_KEY` and any third-party API keys shared during migration
- [ ] Remove `lovable-tagger` and `lovable-agent-playwright-config` if you want zero Lovable footprint
- [ ] Document runbooks: password reset, user delete, bucket cleanup, DB restore
- [ ] First backup verified restorable
