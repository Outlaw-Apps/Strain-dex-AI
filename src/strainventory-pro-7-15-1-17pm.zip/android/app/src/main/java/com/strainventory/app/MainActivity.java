package com.strainventory.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
