import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.strainventory.app',
  appName: 'Strain-ventory',
  webDir: 'dist'
};

export default config;
