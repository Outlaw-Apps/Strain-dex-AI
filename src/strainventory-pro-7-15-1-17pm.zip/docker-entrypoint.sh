#!/bin/sh
set -eu

CONFIG_TEMPLATE="/usr/share/nginx/html/config.template.js"
CONFIG_OUTPUT="/usr/share/nginx/html/config.js"

export VITE_SUPABASE_URL="${VITE_SUPABASE_URL:-http://127.0.0.1:54321}"
export VITE_SUPABASE_PUBLISHABLE_KEY="${VITE_SUPABASE_PUBLISHABLE_KEY:-public-anon-key}"
export VITE_EDGE_FUNCTION_BASE_URL="${VITE_EDGE_FUNCTION_BASE_URL:-${VITE_SUPABASE_URL%/}/functions/v1}"

envsubst '${VITE_SUPABASE_URL} ${VITE_SUPABASE_PUBLISHABLE_KEY} ${VITE_EDGE_FUNCTION_BASE_URL}' \
  < "$CONFIG_TEMPLATE" > "$CONFIG_OUTPUT"

exec "$@"
