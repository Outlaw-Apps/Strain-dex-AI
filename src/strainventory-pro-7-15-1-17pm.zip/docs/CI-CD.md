# CI/CD Pipeline

`.github/workflows/deploy.yml` runs on every push and orchestrates staging/production deploys with automated smoke checks.

## Triggers

| Event | Target |
|-------|--------|
| Push to `main` | `production` |
| Push to `staging` | `staging` |
| Manual `workflow_dispatch` | Choose `staging` or `production` |

## Pipeline Stages

1. **resolve-target** — Picks `staging` vs `production` based on branch / manual input. Exposes `target` + `mode` outputs.
2. **verify** — `npm ci`, `npm run lint`, `npm run test`. Fails fast on lint/test errors.
3. **build** — Runs `vite build --mode <target>` so `VITE_APP_ENV` and bucket suffixes resolve to the right environment (`appConfig.ts`). Uploads `dist/` as a build artifact and prints the top 10 largest chunks.
4. **smoke** — Downloads the built artifact, serves it with `vite preview`, and runs `tests/app-smoke.spec.ts` against the real production bundle (not dev server). Uploads the Playwright HTML report.
5. **deploy** — Calls `DEPLOY_HOOK_URL` (Lovable Publish webhook, Vercel deploy hook, Netlify build hook, custom S3 sync, etc.) with the commit SHA + target.
6. **post-deploy-smoke** — Probes the live `DEPLOY_URL` with retry until it returns HTTP 200.

## GitHub Environments

Configure two GitHub Environments: **`staging`** and **`production`**. Add protection rules on `production` (required reviewers, branch restriction to `main`).

### Per-environment secrets

| Secret | Purpose |
|--------|---------|
| `VITE_SUPABASE_URL` | Target project's API URL |
| `VITE_SUPABASE_PUBLISHABLE_KEY` | Anon key |
| `VITE_SUPABASE_PROJECT_ID` | Project ref |
| `VITE_SITE_URL` | Public origin (used for OAuth redirects) |
| `VITE_EDGE_FUNCTION_BASE_URL` | Optional edge function gateway |
| `VITE_PRODUCT_IMAGES_BUCKET` | Optional bucket override |
| `VITE_AVATARS_BUCKET` | Optional bucket override |
| `VITE_SENTRY_DSN` | Error tracking (optional) |
| `DEPLOY_HOOK_URL` | Webhook the deploy job POSTs to |
| `DEPLOY_TOKEN` | Bearer token for the deploy hook |
| `DEPLOY_URL` | Public URL probed after deploy |

`VITE_RELEASE_TAG` is set automatically to the commit SHA.

> **Never** put service-role keys, AI provider keys, or SMTP credentials in GitHub secrets used by the front-end build. Those belong in Lovable Cloud / Supabase Edge Function secrets. See `docs/DEPLOYMENT-CHECKLIST.md` §5.

## Local Equivalents

```bash
# Mirror the verify + build stage locally
npm run lint && npm run test
npx vite build --mode staging       # or --mode production

# Mirror the smoke stage
npx vite preview --port 4273 --strictPort &
PLAYWRIGHT_REUSE_SERVER=1 npx playwright test tests/app-smoke.spec.ts
```

## Failure Behavior

- Lint, unit test, build, or smoke failures **block** the deploy job from running.
- If `DEPLOY_HOOK_URL` is unset, the deploy job emits a warning and exits 0 so you can wire hosting later without red builds.
- Post-deploy smoke retries 5× with 10s spacing before failing.
