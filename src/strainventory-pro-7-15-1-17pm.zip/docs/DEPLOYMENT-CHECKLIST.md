# Staging / Production Deployment Checklist

> Use this checklist every time you promote StrainVentory from local dev → staging → production.

---

## 1. Choose the Right Environment File

| Target | Copy this example file | Key variable |
|--------|------------------------|--------------|
| Local development | `.env.example` → `.env.local` | `VITE_APP_ENV=development` |
| Staging / preview pilot | `.env.staging.example` → `.env.staging` | `VITE_APP_ENV=staging` |
| Production live | `.env.production.example` → `.env.production` | `VITE_APP_ENV=production` |

**Never commit any `.env` file.** They are already ignored by `.gitignore`.

### How `VITE_APP_ENV` drives behavior

`src/lib/appConfig.ts` reads `VITE_APP_ENV` and resolves it into the active `AppEnvironment`. This controls:

- **Storage bucket suffixes** — Staging automatically appends `-staging` to buckets so you never overwrite production assets.
- **Release tag** — Surfaced in Sentry / error reports.
- **Edge Function routing** — `VITE_EDGE_FUNCTION_BASE_URL` can point to a staging gateway.

| `VITE_APP_ENV` | Product images bucket | Avatars bucket | Release tag fallback |
|----------------|----------------------|----------------|---------------------|
| `development` | `product-images` | `avatars` | `dev` |
| `staging` | `product-images-staging` | `avatars-staging` | `staging` |
| `production` | `product-images` | `avatars` | `prod` |

> Override any bucket name explicitly with `VITE_PRODUCT_IMAGES_BUCKET` or `VITE_AVATARS_BUCKET` if your Supabase project uses custom names.

---

## 2. Frontend Build Verification

Run these **before every deploy** regardless of target:

```bash
# 1. Lint clean
npm run lint

# 2. Unit tests green
npm run test

# 3. Production build succeeds
npm run build
```

For **staging / production** builds, pass the correct mode explicitly:

```bash
# Staging
vite build --mode staging

# Production
vite build --mode production
```

Verify the build output contains no unexpected chunk bloat:

```bash
node -e "const fs=require('fs'),p=require('path');const d='dist/assets';const f=fs.readdirSync(d).map(n=>{const s=fs.statSync(p.join(d,n));return s.isFile()?{name:n,size:(s.size/1024).toFixed(1)+'KB'}:null;}).filter(Boolean).sort((a,b)=>parseFloat(b.size)-parseFloat(a.size)).slice(0,10);console.table(f);"
```

---

## 3. Supabase (Backend) Verification

### 3.1 Project & Connection

- [ ] `VITE_SUPABASE_URL` matches the target project URL.
- [ ] `VITE_SUPABASE_PUBLISHABLE_KEY` matches the target project's **anon / public** key.
- [ ] `VITE_SUPABASE_PROJECT_ID` is set (used by CLI and some edge function paths).
- [ ] If using a custom edge-function gateway, `VITE_EDGE_FUNCTION_BASE_URL` is set; otherwise it defaults to `${VITE_SUPABASE_URL}/functions/v1`.

### 3.2 Database Schema

Run these checks against the **target** database (staging or production):

- [ ] All tables from `supabase/migrations/` exist and are populated:
  - `products`, `customers`, `orders`, `order_items`
  - `profiles`, `user_roles`, `employees`, `time_entries`
  - `schedules`, `shift_reports`, `conversation_members`, `conversation_messages`
- [ ] RLS is **enabled** on every user-facing table.
- [ ] `GRANT` statements exist for every public table (anon / authenticated / service_role as appropriate).
- [ ] The `has_role` security-definer function is present.
- [ ] Triggers `handle_new_user_profile` and `handle_new_user_role` are active so new sign-ups get a profile and default `staff` role.

### 3.3 Edge Functions

The following functions must be deployed to the target project:

- [ ] `generate-draft`
- [ ] `generate-product-draft`
- [ ] `fetch-product-images`
- [ ] `dynamic-service`
- [ ] `assistant-chat`
- [ ] `admin-users`
- [ ] `metrc-proxy`
- [ ] `pos-webhook`
- [ ] `provision-pin-user`
- [ ] Email queue workers (`process-email-queue`, `dispatch-scheduled-emails`, `send-transactional-email`, `handle-email-unsubscribe`, `handle-email-suppression`)

Deploy command:

```bash
supabase functions deploy <function-name>
```

Verify each deployed function responds with a 200 OK to a `HEAD` or `GET` health probe.

### 3.4 Auth Configuration

- [ ] Email / password auth is enabled.
- [ ] Google OAuth is configured (required by default).
- [ ] Site URL and redirect URLs match `VITE_SITE_URL` (or the actual deployed front-end origin).
- [ ] **Production only:** Turn off `ENABLE_EMAIL_AUTOCONFIRM`. Emails must be confirmed via SMTP.
- [ ] **Production only:** Configure real SMTP (SendGrid, Amazon SES, etc.) for password resets and magic links.

---

## 4. Storage Verification

| Bucket | Required access | Check |
|--------|----------------|-------|
| `product-images` (or `-staging`) | Public read | Anyone can view product photos |
| `avatars` (or `-staging`) | Private read | Only authenticated users can fetch avatars |
| `employee-documents` | Private read | Employee onboarding docs restricted |

- [ ] Buckets exist in the target Supabase project.
- [ ] Public / private flags match the table above.
- [ ] RLS policies on `storage.objects` restrict upload/delete to authenticated staff or admins.
- [ ] CORS rules on buckets allow the deployed front-end origin.

---

## 5. Backend Secrets — Where They Go

**Rule of thumb:**

- **Front-end (Vite)** → `.env.*` files (never committed)
- **Edge Functions / server** → Lovable Cloud secrets (or Supabase secrets for self-hosted)

### 5.1 Front-End Environment Variables

Set in the correct `.env.*` file:

| Variable | Purpose |
|----------|---------|
| `VITE_SUPABASE_URL` | Supabase project API URL |
| `VITE_SUPABASE_PUBLISHABLE_KEY` | Public anon key (safe in browser) |
| `VITE_SUPABASE_PROJECT_ID` | Project reference ID |
| `VITE_APP_ENV` | `development` / `staging` / `production` |
| `VITE_SITE_URL` | Public origin for OAuth redirects |
| `VITE_PRODUCT_IMAGES_BUCKET` | Override product-images bucket name |
| `VITE_AVATARS_BUCKET` | Override avatars bucket name |
| `VITE_EDGE_FUNCTION_BASE_URL` | Custom edge-function gateway |
| `VITE_SENTRY_DSN` | Error tracking (optional) |
| `VITE_RELEASE_TAG` | Build identifier in error reports |

> **Do NOT** put service-role keys, JWT secrets, or AI provider API keys into any `VITE_*` variable. They are exposed to the browser.

### 5.2 Backend / Edge Function Secrets

These are set via **Lovable Cloud secrets** (runtime secrets) and are injected into Edge Functions at runtime. They are **never** stored in `.env` files.

| Secret Name | Used By | How to Obtain |
|-------------|---------|---------------|
| `DEEPSEEK_API_KEY` | `generate-draft`, `generate-product-draft` | DeepSeek platform → API Keys |
| `DEEPSEEK_MODEL` | AI draft functions | Optional model override (e.g. `deepseek-chat`) |
| `GOOGLE_CSE_API_KEY` | `fetch-product-images` | Google Custom Search → Programmable Search → API key |
| `GOOGLE_CSE_CX` | `fetch-product-images` | Google Custom Search → Search engine ID |
| `GEMINI_API_KEY` | `dynamic-service` (image validation) | Google AI Studio → API key |
| `POS_WEBHOOK_SECRET` | `pos-webhook` | Generate via `openssl rand -hex 32` |
| `SMTP_HOST` / `SMTP_USER` / `SMTP_PASS` | Email functions | Your transactional email provider |

For self-hosted deployments, set these in `.env.selfhost` instead (they are consumed by the Docker stack, not the browser).

---

## 6. Per-Environment Deployment Steps

### Staging Deploy (Internal Pilot)

1. [ ] Copy `.env.staging.example` → `.env.staging` and fill values.
2. [ ] Ensure the staging Supabase project is separate from production.
3. [ ] Run `npm run lint && npm run test && vite build --mode staging`.
4. [ ] Verify the build bundles point to the staging Supabase URL.
5. [ ] Deploy Edge Functions to the staging project.
6. [ ] Confirm `product-images-staging` and `avatars-staging` buckets exist.
7. [ ] Run the manual smoke tests from `verification-checklist.md` against the staging URL.
8. [ ] Share the staging preview URL with pilot staff.

### Production Deploy (Go Live)

1. [ ] Copy `.env.production.example` → `.env.production` and fill values.
2. [ ] Confirm production Supabase project is on a paid plan (required for custom domains and higher limits).
3. [ ] Run `npm run lint && npm run test && vite build --mode production`.
4. [ ] Deploy Edge Functions to the production project.
5. [ ] Confirm `product-images` and `avatars` buckets exist and are publicly / privately configured.
6. [ ] Verify auth redirect URLs include the production domain.
7. [ ] Enable SMTP and disable email auto-confirm.
8. [ ] Tighten RLS policies: remove any `anon` grants that are not strictly public.
9. [ ] Run the full `verification-checklist.md` smoke tests.
10. [ ] Publish / deploy the front-end to the hosting platform (Lovable Publish, Vercel, etc.).

---

## 7. Post-Deploy Validation

After the front-end is live:

- [ ] Load the site and confirm no console errors.
- [ ] Sign in via Google OAuth (or email) and confirm the auth callback lands on `/`.
- [ ] Upload a product image and verify it appears in the catalog.
- [ ] Run a test POS transaction and confirm stock decrements.
- [ ] Trigger an AI draft generation and confirm the edge function responds.
- [ ] Verify the `releaseTag` in `appConfig` matches the expected environment.

---

## Quick Reference: Files That Change Per Environment

| File | Dev | Staging | Production |
|------|-----|---------|------------|
| `.env.local` | ✅ | ❌ | ❌ |
| `.env.staging` | ❌ | ✅ | ❌ |
| `.env.production` | ❌ | ❌ | ✅ |
| `public/config.js` | Optional runtime overrides | Optional runtime overrides | Optional runtime overrides |

The `public/config.js` file can override any `appConfig` value at runtime without rebuilding. Use it for emergency URL switches or feature toggles in deployed containers.
