# Self-Hosting StrainVentory

This guide walks you through running the entire StrainVentory stack on your own
infrastructure, replacing the managed Supabase cloud service with a fully
self-hosted Supabase instance.

---

## Architecture Overview

```
┌─────────────────┐     ┌──────────────────────────────────────────────────┐
│  StrainVentory   │────▶│  Kong API Gateway  (port 8000)                   │
│  (Vite / React)  │     │    ├── /rest/v1      → PostgREST                 │
│  (port 8080)     │     │    ├── /auth/v1      → GoTrue (Auth)             │
│                  │     │    ├── /realtime/v1   → Supabase Realtime         │
│  Electron        │     │    ├── /storage/v1   → Supabase Storage           │
│  (optional)      │     │    └── /functions/v1 → Deno Edge Runtime          │
└─────────────────┘     └───────────────────────┬──────────────────────────┘
                                                │
                                    ┌───────────▼───────────┐
                                    │   PostgreSQL 15        │
                                    │   (port 5432)          │
                                    └────────────────────────┘
```

## Prerequisites

| Tool             | Minimum Version |
|------------------|-----------------|
| Docker           | 24+             |
| Docker Compose   | 2.20+           |
| Node.js          | 18+             |
| Git              | 2.x             |

## Quick Start

### 1. Clone the repo

```bash
git clone https://github.com/deananwomack-code/strain-ventory.git
cd strain-ventory
```

### 2. Configure environment

```bash
cp .env.selfhost.example .env.selfhost
```

Edit `.env.selfhost` and fill in:

| Variable           | How to generate |
|--------------------|-----------------|
| `JWT_SECRET`       | `openssl rand -base64 48` |
| `POSTGRES_PASSWORD`| Any strong password |
| `ANON_KEY`         | JWT with role `anon` signed by `JWT_SECRET` |
| `SERVICE_ROLE_KEY` | JWT with role `service_role` signed by `JWT_SECRET` |

> **Tip:** Use [supabase.com/docs/guides/self-hosting#api-keys](https://supabase.com/docs/guides/self-hosting#api-keys) to generate the JWT keys.

### 3. Start the backend

```bash
docker compose -f docker-compose.selfhost.yml --env-file .env.selfhost up -d
```

Wait for all services to be healthy:

```bash
docker compose -f docker-compose.selfhost.yml ps
```

### 4. Apply database migrations

Migrations in `supabase/migrations/` are automatically applied when the
database container starts for the first time (mounted at
`/docker-entrypoint-initdb.d/migrations`).

To apply new migrations to an existing database:

```bash
# Connect via psql
docker compose -f docker-compose.selfhost.yml exec db \
  psql -U postgres -d postgres -f /docker-entrypoint-initdb.d/migrations/<migration_file>.sql
```

### 5. Point the front-end at your self-hosted instance

Create or update your `.env`:

```env
VITE_SUPABASE_URL=http://localhost:8000
VITE_SUPABASE_PUBLISHABLE_KEY=<your ANON_KEY>
VITE_SUPABASE_PROJECT_ID=selfhost
```

### 6. Start the front-end

```bash
npm install
npm run dev
```

The app will be available at `http://localhost:8080`.

---

## Services Reference

| Service    | Internal Port | Description |
|------------|--------------|-------------|
| `db`       | 5432         | PostgreSQL 15 with Supabase extensions |
| `rest`     | 3000         | PostgREST — auto-generates REST API from schema |
| `auth`     | 9999         | GoTrue — handles signup, login, JWT tokens |
| `realtime` | 4000         | Supabase Realtime — WebSocket subscriptions |
| `storage`  | 5000         | Supabase Storage — file uploads (product images) |
| `functions`| 8000         | Deno Edge Runtime — runs Edge Functions |
| `kong`     | 8000 (ext)   | API Gateway — routes all traffic |
| `studio`   | 3000 (ext)   | Supabase Studio — admin UI (optional) |
| `meta`     | 8080         | PG Meta — used by Studio for schema inspection |

## Edge Functions

The self-hosted stack mounts `supabase/functions/` directly into the Deno Edge
Runtime container. Your existing Edge Functions work without modification:

- **admin-users** — User management (create, list, role assignment)
- **generate-draft** / **generate-product-draft** — AI-powered product draft generation
- **fetch-product-images** — Google Custom Search image fetcher
- **dynamic-service** — Image search + Gemini analysis

Set the required API keys in `.env.selfhost`:
- `AI_PROVIDER`, `DEEPSEEK_API_KEY` or `OPENAI_API_KEY`
- `GOOGLE_CSE_API_KEY`, `GOOGLE_CSE_CX`, `GEMINI_API_KEY`

## Database Schema

### Tables

| Table          | Description |
|----------------|-------------|
| `products`     | Cannabis product catalog with AI-generated drafts |
| `customers`    | Customer records with license/age verification |
| `orders`       | Point-of-sale transaction records |
| `order_items`  | Line items for each order |
| `user_roles`   | Role assignments (admin, staff, reviewer) |
| `profiles`     | User display names and badge numbers |
| `time_entries` | Employee clock-in/clock-out tracking |

### Roles

| Role       | Description |
|------------|-------------|
| `admin`    | Full access to all features |
| `staff`    | Standard employee access |
| `reviewer` | Can review and approve product drafts |

New users are auto-assigned the `staff` role. The first user gets `admin`.

### Storage Buckets

| Bucket           | Public | Description |
|------------------|--------|-------------|
| `product-images` | Yes    | Product catalog images |

## Backup & Restore

```bash
# Backup
docker compose -f docker-compose.selfhost.yml exec db \
  pg_dump -U postgres -Fc postgres > backup_$(date +%Y%m%d).dump

# Restore
docker compose -f docker-compose.selfhost.yml exec -T db \
  pg_restore -U postgres -d postgres --clean < backup.dump
```

## Production Considerations

1. **TLS/SSL** — Put Kong behind a reverse proxy (nginx, Caddy, Traefik) with
   proper TLS certificates.
2. **SMTP** — Configure real SMTP for email verification and password resets.
3. **RLS Policies** — The current development migration opens all policies.
   Tighten them before going to production.
4. **Secrets** — Never commit `.env.selfhost` to version control.
5. **Updates** — Pin Docker image tags and test upgrades in staging first.
6. **Monitoring** — Consider adding Prometheus/Grafana for observability.

## Migrating from Supabase Cloud

1. Export data from your Supabase project:
   ```bash
   # From the Supabase dashboard: Settings → Database → Connection String
   pg_dump -h db.<project-ref>.supabase.co -U postgres -Fc postgres > cloud_backup.dump
   ```
2. Start your self-hosted stack (steps 1–3 above).
3. Restore the backup:
   ```bash
   docker compose -f docker-compose.selfhost.yml exec -T db \
     pg_restore -U postgres -d postgres --clean < cloud_backup.dump
   ```
4. Update your front-end `.env` to point at the self-hosted URL.
5. Transfer storage files from the Supabase Storage UI or API.
