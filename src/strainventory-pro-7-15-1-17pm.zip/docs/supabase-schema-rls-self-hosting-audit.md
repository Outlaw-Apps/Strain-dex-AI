# Supabase schema, RLS, and self-hosting audit

> Last updated: 2026-06-05 (v3 migration)

## Schema inventory

The migrations define these application tables:

- Identity and access: `user_roles`, `profiles`, `user_credentials`
- Catalog/POS: `products`, `customers`, `orders`, `order_items`, `pos_audit_events`, `shift_reports`, `pos_sales`
- Discounts: `discount_definitions`, `order_discount_events`
- Payroll/HR: `employees`, `employee_payroll_profiles`, `pay_periods`, `payslips`, `time_entries`
- Assistant/knowledge bridge: `assistant_threads`, `assistant_messages`, `assistant_action_logs`, `strain_knowledge_entries`, `strain_knowledge_images`, `ai_search_domains`
- Messaging: `conversations`, `conversation_members`, `conversation_messages`
- Legacy synced catalog: `strains`
- Business config: `business_settings`
- Infrastructure: `applied_migrations` (self-host migration tracking)

Storage buckets:

- `product-images` — public, stores catalog/product imagery.
- `employee-documents` — private, stores onboarding documents.

## RLS policy model (development mode)

### Current state (after v3 migration)

Every public table (except `applied_migrations`) has a permissive `"Development full access"` policy granting all authenticated users full CRUD (`USING (true)`, `WITH CHECK (true)`). This overrides any earlier restrictive policies via Postgres' OR-based permissive policy evaluation.

Additionally:
- `products` and `strains` have public (anon) SELECT for pre-auth catalog access.
- Storage buckets have authenticated full access + public read for product-images.
- Service role has unrestricted storage access for Edge Functions.
- All public tables have explicit `GRANT ALL` to `authenticated` and `service_role` roles.

### Migration history

| Migration | Purpose |
|-----------|---------|
| `20260516000000` | First dev-mode open policies (static table list) |
| `20260516043000` | Admin-only `user_roles` + `pos_sales` (broke dev access) |
| `20260529230000` | v2: dynamic sweep of all tables, auth triggers, backfill |
| `20260605230000` | **v3**: re-sweep + GRANT ALL + anon catalog + realtime pub + health check |

### Production hardening (future)

When role-based restrictions are ready, create a single migration that:
1. Drops all `"Development full access"` policies.
2. Revokes broad `GRANT ALL` on tables.
3. The underlying RBAC policies (admin/staff/reviewer) are preserved and will take effect.

## Supabase-specific dependencies

The application depends on these Supabase platform features:

- **Auth**: `auth.users` foreign keys, GoTrue API for signup/login.
- **Auth triggers**: auto-create `profiles` and `user_roles` on signup.
- **Edge Functions**: AI drafting, image search, assistant chat, admin user management, PIN provisioning, POS webhook, strain knowledge sync, dynamic service router.
- **Storage**: `storage.objects` RLS, bucket management.
- **Realtime**: publication of `conversations`, `conversation_members`, `conversation_messages`, `products`, `orders`, `pos_audit_events`.
- **Service-role secrets**: used by Edge Functions for privileged DB access.
- **Client SDK**: `@supabase/supabase-js` in frontend and Edge Functions.

All are compatible with the Supabase self-hosted stack (see `docker-compose.selfhost.yml`).

## Self-hosting readiness

### Completed

- [x] Runtime frontend config via `window.STRAINVENTORY_CONFIG` + `config.js`.
- [x] `VITE_EDGE_FUNCTION_BASE_URL` for independent function routing.
- [x] Nginx static hosting with `docker-entrypoint.sh` envsubst.
- [x] Full `docker-compose.selfhost.yml` with all Supabase services (db, auth, rest, realtime, storage, kong, studio, meta, functions, migrate).
- [x] Kong API gateway config (`selfhost/kong.yml`).
- [x] Edge Functions main router (`selfhost/functions/main/index.ts`).
- [x] DB role init script (`selfhost/db-init/01-strainventory-roles.sql`).
- [x] Idempotent migration runner (`selfhost/apply-migrations.sh` + `migrate-entrypoint.sh`).
- [x] `.env.selfhost.example` with all required + optional variables.
- [x] Auth triggers for auto-provisioning new users (profile + role).
- [x] Admin bootstrap (first user → admin, backfill for existing users).
- [x] `selfhost_health_check()` monitoring function.
- [x] Realtime publication setup for messaging + POS tables.
- [x] Service role grants for Edge Function access.

### Remaining steps

1. Add database smoke tests (`supabase db reset` + authenticated CRUD).
2. Add TLS/reverse proxy example (Caddy/Traefik) for production deployments.
3. Create production hardening migration when RBAC is finalized.
4. Document backup/restore workflow for the self-hosted Postgres volume.
5. Add Prometheus/health-check endpoint to the web container.
