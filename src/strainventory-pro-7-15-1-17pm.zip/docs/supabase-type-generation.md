# Supabase type generation

`src/integrations/supabase/types.ts` is generated from the live Postgres schema.
Keeping it in sync prevents the drift that produces the `"... is not assignable
to parameter of type 'never'"` errors when hooks query tables the client doesn't
know about.

## Commands

| Command | What it does |
|---------|--------------|
| `npm run types:generate` | Regenerates `src/integrations/supabase/types.ts` from the linked project. |
| `npm run types:check`    | Fails (non-zero exit) if the on-disk types differ from what would be generated. Used by CI. |
| `npm run dev`            | Runs `types:check` as a `predev` step and prints a warning if drift is detected (does not block the dev server). |

## Configuration

The script (`scripts/generate-supabase-types.sh`) resolves the target project in
this order:

1. `SUPABASE_DB_URL` — direct Postgres URL (use this for self-hosted / local
   stacks).
2. `SUPABASE_PROJECT_REF` — env var override.
3. `supabase/.temp/project-ref` — written by `npx supabase link --project-ref <ref>`.

For Supabase Cloud you also need `SUPABASE_ACCESS_TOKEN` exported (or stored as
a GitHub Actions secret) so the CLI can authenticate.

## Workflow

1. Author a migration via the Lovable migration tool (or `supabase migration new`).
2. After it runs, execute `npm run types:generate`.
3. Commit the updated `src/integrations/supabase/types.ts` alongside the SQL.
4. CI (`.github/workflows/supabase-types.yml`) runs `npm run types:check` on
   every PR that touches migrations or the types file and fails if they drift.
