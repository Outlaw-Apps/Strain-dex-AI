# Shift reconciliation and POS audit journal — design spec

**Date:** 2026-04-06  
**App:** StrainVentory  
**Status:** Approved for implementation (aligned with go-live plan)

## Problem

Dispensary owners need **cash accountability** and a **durable record** of POS activity for internal audits without integrating third-party track-and-trace APIs on day one.

## Solution overview

1. **Append-only `pos_audit_events`** — records notable POS events (`order_completed`, `shift_closed`, `journal_export`).  
2. **`shift_reports`** — end-of-period snapshot: aggregated sales by payment bucket, optional opening float and counted cash, variance notes.  
3. **Shift Close UI** (`/shift-close`) — pick period (defaults to today), review aggregates from `orders`, enter drawer counts, save report + audit event.  
4. **CSV export** — client-side download of recent audit events + shift reports for the selected window.

## Data model

- **`pos_audit_events`**: `event_type`, `metadata` (JSON), `created_by`, `created_at`.  
- **`shift_reports`**: `period_start`, `period_end`, aggregates (`order_count`, `total_sales`, `total_cash`, `total_card`, `total_other`), optional `opening_float`, `counted_cash`, `expected_cash`, `variance_notes`, `notes`.

## Payment bucketing

- **Cash**: payment method string contains `cash` (case-insensitive).  
- **Card**: contains `card`, `debit`, `credit`, or `tap`.  
- **Other**: everything else.

## Security (RLS)

- Authenticated users: `SELECT` + `INSERT` on both tables (matches existing `orders` policies).  
- No updates/deletes on `pos_audit_events` (append-only at app layer; DB could add restrictive policies later).

## Testing

- **Vitest**: `aggregateOrdersForShift`, `bucketPaymentMethod`, `expectedDrawerCash` in `src/lib/shiftReconciliation.ts`.  
- **Playwright**: authenticated smoke visits `/shift-close` and asserts heading visible.  
- **Manual**: complete shift close for a test day; verify row in Supabase.

## Out of scope (v1)

- PDF generation server-side  
- METRC/BioTrack CSV templates  
- Automatic shift open/close from time clock
