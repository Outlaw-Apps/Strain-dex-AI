# Deployment Notes — Geofence Fix + Configurable AI Domains

**Branch:** `main`
**Spec:** `docs/superpowers/specs/2026-04-18-geofence-and-ai-domains-design.md`

## Pre-flight verification (already done)
- `npm run lint` → 0 errors
- `npm run test` → 81 / 81 pass (added: 14 ai-domain tests, 4 geofence tests)
- `npm run build` → clean

## Deploy steps

### 1. Database migrations
```bash
supabase db push
# or: supabase migration up
```
Applies:
- `20260418120000_geofence_default_radius_250.sql` — bumps default radius 150 → 250 (existing rows untouched)
- `20260418130000_ai_search_domains.sql` — new `ai_search_domains` table, RLS, seed (8 allow + 1 block: `leafly.com/menu`)

### 2. Regenerate Supabase types
```bash
supabase gen types typescript --linked > src/integrations/supabase/types.ts
```
The `ai_search_domains` table is currently typed inline in `types.ts`; the generator will normalize it.

### 3. Deploy edge functions
```bash
supabase functions deploy assistant-chat
supabase functions deploy generate-draft
supabase functions deploy generate-product-draft
```
(Any function that calls `generateDraft.ts` needs redeploy; check `supabase/functions/` and deploy each one that imports from `_shared/generateDraft.ts` or `_shared/cannabisResearch.ts`.)

### 4. Build Electron desktop installer
```bash
npm run electron:build
```

### 5. Manual QA checklist
- **Geofence — desktop**: clock in from inside the store (success), from far away (blocked with distance message), with location denied (permission_denied message), as admin → "Manager Override" button appears.
- **Geofence — mobile browser**: same three scenarios on a phone.
- **Settings → AI Sources**: as admin, see two cards (Allowed, Blocked) seeded with the trusted sources + the `leafly.com/menu` block. Add a test domain, toggle, delete.
- **AI generation**: trigger a draft for a strain that exists on Leafly. Confirm the `external_fallback` does NOT include any `leafly.com/menu/...` URLs but DOES include other Leafly content.

## Rollback
- Revert the migrations: `supabase migration down` (last 2).
- Re-deploy the prior edge functions from the previous git tag.
- Roll back the Electron installer.

## Known limitations (deferred)
- Edge function caches the AI domain policy for 5 min — admin edits take up to 5 min to take effect. A "Refresh sources" button can be added later.
- The accuracy buffer is capped at 400m. Sites in dense urban canyons or basement-level WiFi may still hit edge cases; manager override covers them.
- No per-store geofences yet (single dispensary location).
