# Geofence Fix & Configurable AI Search Domains — Design

**Date:** 2026-04-18
**Target:** Production deployment in 2 days
**Author:** Brainstorming session (Strain-ventory)

## 1. Problem

Two pre-deploy blockers in StrainVentory:

1. **Geofencing is broken in two ways at once.** Staff are blocked from clocking in even when physically inside the dispensary, and the location permission/error dialog appears repeatedly. This affects both the Electron desktop terminal and the mobile browser.
2. **AI website sources are hardcoded.** The strain-research edge function uses a fixed list of trusted domains baked into `supabase/functions/_shared/cannabisResearch.ts`. Changing the sources requires a code change and edge-function redeploy — unacceptable for a live business.

## 2. Root Cause Analysis

### 2.1 Geofence — desktop (Electron)
- `electron/main.cjs` does not register a `session.setPermissionRequestHandler`. By default Electron denies `navigator.geolocation`, so `getCurrentPosition` rejects with `PERMISSION_DENIED` on every clock-in attempt.
- Even when permission is granted, Electron has no native geolocation provider unless a Google API key is supplied; the renderer call simply fails.

### 2.2 Geofence — radius vs. accuracy
- Default radius is 150 m (`business_settings.geofence_radius_meters` = 150).
- Desktop devices use WiFi-based geolocation, which routinely returns positions accurate to ±200–500 m. A 150 m radius rejects users who are physically inside the building.
- `useGeofence.ts` ignores `pos.coords.accuracy` entirely, so there is no allowance for known measurement error.

### 2.3 Geofence — UX
- All location errors are surfaced as the same generic message ("Could not get location"), so admins can't distinguish denied permission from poor signal.
- There is no manager override path when GPS misbehaves.

### 2.4 AI sources
- `TRUSTED_CANNABIS_RESEARCH_SOURCES` in `cannabisResearch.ts` is a `const` array. Adding/removing a domain requires editing TypeScript, redeploying `assistant-chat` and `generate-draft`.
- No blocklist exists, so even if a result URL is undesired (competitor, low-quality site, broken HTML), there is no way to suppress it without code changes.

## 3. Solution Overview

### 3.1 Geofence
Three coordinated changes:

**a) Electron permission handler + geolocation bridge** (`electron/main.cjs`)
- On `app.whenReady()`, call `session.defaultSession.setPermissionRequestHandler` to grant `geolocation` for the app's own origin.
- Optionally expose an IPC channel (`geofence:get-position`) so the renderer can fall back to a main-process geolocation lookup if needed in future. (Phase 2 — not required for v1 if the permission handler alone is sufficient.)

**b) Accuracy-aware geofence logic** (`src/hooks/useGeofence.ts`)
- Pass `{ enableHighAccuracy: true, timeout: 10000, maximumAge: 60000 }` to `getCurrentPosition` so a fresh fix is cached for 60 seconds and we don't re-prompt on every click.
- Compute `effectiveRadius = settings.geofence_radius_meters + Math.min(pos.coords.accuracy, MAX_ACCURACY_BUFFER)` where `MAX_ACCURACY_BUFFER = 400` (m). This way mobile (typically <50 m accuracy) stays strict, while desktop (200–500 m) gets a forgiving but bounded buffer.
- Distinguish error codes: return a typed result `{ kind: 'inside' | 'outside' | 'permission_denied' | 'unavailable' | 'timeout', distanceMeters, accuracyMeters }`.

**c) Settings UX** (`src/pages/Settings.tsx`)
- Migration bumps default radius from 150 → 250 m for new installs (existing rows preserved).
- "Use Current Location" button now also displays the last detected accuracy reading so admins can validate the device.
- On geofence failure, admins are shown the existing inline manager-override affordance by default (reusing the current `useManagerOverride` pattern); there is no separate Settings toggle for this in v1.

### 3.2 AI Search Domains
Single new database table; admin-managed CRUD; edge functions read from it at runtime.

**Table: `ai_search_domains`**

| Column | Type | Notes |
|---|---|---|
| `id` | `uuid` PK default `gen_random_uuid()` | |
| `domain` | `text not null unique` | Lowercased host or `host/path-prefix` (no scheme). Examples: `leafly.com`, `menu.leafly.com`, `leafly.com/menu` |
| `mode` | `text not null check (mode in ('allow','block'))` | Which list this row belongs to |
| `label` | `text` | Display name shown in Settings |
| `enabled` | `boolean not null default true` | Quick on/off without delete |
| `created_at` | `timestamptz not null default now()` | |
| `updated_at` | `timestamptz not null default now()` | Trigger: bump on update |

**RLS**
- `select` for `authenticated` (so client + edge function can read).
- `insert/update/delete` for admins only (use existing `is_admin(auth.uid())` helper or inline `user_roles` join — match existing pattern in this repo).

**Seed**
Existing trusted sources inserted as `mode = 'allow'`, `enabled = true`:
`allbud.com`, `leafly.com`, `content.myhavenstores.com`, `shopphaven.com`, `weedmaps.com`, `chronicguru.com`, `coronaculture.com`, `culturecannabisclub.com`.

Plus one block entry to keep AI off Leafly's menu pages while still allowing the strain content:
`leafly.com/menu` (`mode = 'block'`).

**Resolution rule** (applied in `cannabisResearch.ts`):
1. Load all `enabled = true` rows.
2. Let `allow = rows where mode='allow'`, `block = rows where mode='block'`.
3. **Parse each entry** into `{ host, pathPrefix }`. If the entry contains `/`, the part before is the host and everything after (including the leading `/`) is the path prefix; otherwise the whole entry is the host with no path prefix.
4. If `allow` is non-empty → only URLs matching an allow entry's host (and path prefix, if present) may be searched; otherwise all domains are eligible.
5. Any URL matching a `block` entry is dropped, regardless of allowlist state. **Block matching:**
   - If the block entry has no path prefix → matches any URL on that host (host equals the entry, or ends with `.<entry>` for subdomains).
   - If the block entry has a path prefix → matches only URLs whose host matches **and** whose pathname starts with the prefix. So `leafly.com/menu` blocks `https://www.leafly.com/menu/foo` but not `https://www.leafly.com/strains/blue-dream`.
6. Cache result for 5 minutes per edge-function cold start to avoid hitting the DB on every draft.

**Edge function changes** (`supabase/functions/_shared/cannabisResearch.ts`)
- Replace the `const TRUSTED_CANNABIS_RESEARCH_SOURCES` export with a runtime `loadResearchSources(client)` function.
- Update `gatherDraftResearch` to accept an injected source list (or fetch lazily) and apply the blocklist filter to `extractDuckDuckGoResultUrls` output.
- Callers (`assistant-chat`, `generate-draft`) pass the admin Supabase client they already create.

**Settings UI** — new tab **"AI Sources"** in `src/pages/Settings.tsx`:
- Two side-by-side cards: **Allowed Domains**, **Blocked Domains**.
- Each row: domain text, label, enabled toggle, delete button.
- "Add domain" input with mode selector (allow/block). Auto-strip `https?://` and `www.` prefixes. **Path prefixes are allowed for block entries** (e.g. `leafly.com/menu`); for allow entries the path is stripped (allowing a path on an allow row would be misleading since the allowlist gates which sites the AI can visit, not which pages it must visit).
- Admin-only (gated by existing `isAdmin` from `useUserRoles`).
- New hook `useAiSearchDomains()` modeled on `useBusinessSettings`.

## 4. Component Boundaries

- `useGeofence` returns a typed result; `EmployeeTimeClock` decides UI/messaging based on the `kind`. Hook stays free of UI concerns.
- `useAiSearchDomains` owns all CRUD + cache invalidation; the new Settings tab is a thin presentation layer.
- The edge function never trusts the client — it reads the table itself with the service-role client it already has.
- `cannabisResearch.ts` exports two pure helpers (`filterCandidateUrls(urls, sources)`, `resolveSearchSources(rows)`) that are unit-testable without network.

## 5. Files Touched

**New**
- `supabase/migrations/<timestamp>_ai_search_domains.sql`
- `supabase/migrations/<timestamp>_geofence_default_radius_250.sql`
- `src/hooks/useAiSearchDomains.ts`
- `src/components/settings/AiSourcesSettings.tsx`
- `src/test/aiSearchDomains.test.ts`
- `src/test/useGeofence.test.ts` (if not present)

**Modified**
- `electron/main.cjs` — permission handler
- `src/hooks/useGeofence.ts` — typed result + accuracy buffer
- `src/components/settings/EmployeeTimeClock.tsx` — handle new error kinds + override button
- `src/pages/Settings.tsx` — add "AI Sources" tab; surface accuracy reading
- `src/hooks/useBusinessSettings.ts` — no-op (defaults handled in DB)
- `supabase/functions/_shared/cannabisResearch.ts` — runtime source loader + blocklist filter
- `supabase/functions/assistant-chat/index.ts` — pass admin client through
- `supabase/functions/generate-draft/index.ts` — pass admin client through (verify)
- `src/integrations/supabase/types.ts` — regenerate after migration

## 6. Testing

**Unit (Vitest)**
- `resolveSearchSources` — empty input, allow-only, block-only, mixed, disabled rows.
- `filterCandidateUrls` — block-list trumps allowlist; subdomain matching (`menu.leafly.com` matches `leafly.com`); path-scoped block (`leafly.com/menu` blocks `/menu/foo` but not `/strains/blue-dream`); path-scoped block does not block sibling paths (`/strains` survives).
- `useGeofence` — accuracy buffer math; each error code maps to the right `kind`.

**Manual QA**
1. Electron app: clock in from inside the store → success; clock in from outside (move 1km) → blocked with distance message; deny permission → see permission-denied message.
2. Mobile browser (real phone): same three scenarios.
3. Admin opens Settings → AI Sources → adds a `block` row for `weedmaps.com`. Run a draft generation and confirm no Weedmaps URL appears in `external_fallback`.
4. Admin removes all `allow` rows, adds one `allow` for `leafly.com`. Confirm only Leafly URLs are queried.

**Pre-release**
```
npm run lint
npm run build
npm run test
npm run test:e2e
```

## 7. Two-Day Deployment Plan

**Day 1 (infra + geofence)**
- Write migration: `ai_search_domains` (table, RLS, seed, updated_at trigger).
- Write migration: bump default `geofence_radius_meters` to 250.
- Update `electron/main.cjs` with permission handler.
- Refactor `useGeofence.ts`: typed result, accuracy buffer, error-code mapping.
- Update `EmployeeTimeClock.tsx`: branch on result kind, wire manager override.
- Smoke test on dev: lint + build + unit tests green.

**Day 2 morning (AI sources)**
- Add `useAiSearchDomains` hook.
- Add `AiSourcesSettings` component + new tab in `Settings.tsx`.
- Refactor `cannabisResearch.ts` to load sources at runtime; export pure helpers.
- Update `assistant-chat` + `generate-draft` to use new loader.
- Unit tests for resolution + URL filtering.

**Day 2 afternoon (release)**
- Manual QA on Electron + mobile (geofence) and Settings → AI Sources (CRUD + draft generation).
- `npm run lint && npm run build && npm run test && npm run test:e2e`.
- `supabase migration up` (or `supabase db push`).
- `supabase functions deploy assistant-chat generate-draft`.
- Regenerate `src/integrations/supabase/types.ts`.
- Build Electron installer; tag release.

## 8. Risks & Mitigations

| Risk | Mitigation |
|---|---|
| Electron permission handler still doesn't return a real fix on Windows desktops without Google API key | Accept WiFi-based fix from OS; the accuracy buffer covers the slop. Worst case: enable manager override toggle and document. |
| Allowlist with no enabled rows accidentally disables all AI research | Seed file installs the existing 8 domains as `allow + enabled`; UI warns when removing the last allow row. |
| Edge function cache holds a stale source list after admin edits | 5-minute TTL is acceptable per UX expectation; document; add a "Refresh sources" button later if needed (out of scope). |
| Existing rows in `business_settings` keep 150 m radius | Migration only changes the column default; admins can save 250 manually from Settings if desired. |

## 9. Out of Scope

- Per-store geofences (multi-tenant locations).
- Persisted geolocation history / audit log.
- Per-domain weighting or per-domain query templates for AI search.
- Replacing DuckDuckGo with a paid SERP API.
