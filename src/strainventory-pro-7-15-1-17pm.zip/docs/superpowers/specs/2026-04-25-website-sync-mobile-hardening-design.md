# Website Sync And Mobile Hardening Design

## Summary

Add a review-safe Website Sync workflow for importing dispensary website data into StrainVentory, with Corona Culture as the first real target. The first implementation must import all available menu, product, store, and deal data as review drafts only. It must not update live catalog records, POS inventory, stock counts, or pricing until staff explicitly promotes reviewed data through the existing catalog/review workflow.

In the same implementation pass, harden the mobile UI across the app. The highest-risk screens are POS, table-heavy catalog/review/payroll workflows, settings/admin screens, the dashboard, and the global assistant drawer.

## Goals

- Support flexible website sync sources, starting with Corona Culture.
- Treat the accessible Weedmaps/Culture listing as a practical public-source adapter or comparison source while the primary Corona Culture/TREEZ source is investigated.
- Import all available products, categories, prices, package sizes, potency details, deals, promos, store hours, store status, and source metadata into review-only draft records.
- Preserve a hard safety boundary: no sync path may mutate live catalog, POS stock, inventory, or pricing directly.
- Give staff a clear Website Sync page for running syncs, viewing import history, and reviewing staged drafts.
- Improve mobile behavior across all major screens, prioritizing POS and table-heavy workflows.

## Next Upgrades

- Building a public storefront in this pass.
- Embedding the existing dispensary website as the primary experience.
- Automatically publishing imported website data to live inventory.
- Completing every future provider integration before Corona Culture is useful.
- Replacing the existing catalog/review workflow.

## Architecture

The sync workflow is an internal import pipeline:

1. Source adapters fetch or receive external website/menu data.
2. Adapters normalize external records into a shared shape.
3. A sync run records status, counts, warnings, and diagnostics.
4. Normalized records are saved as website import drafts.
5. Staff reviews imported drafts before anything can move into normal catalog/review workflows.

Initial source adapter:

- `corona-culture`: the first named source for Corona Culture.
- The implementation should support multiple source modes behind the same source identity, such as public page scraping, provider listing ingestion, API/feed imports, or manual export upload.
- The first practical public source may use Weedmaps/Culture listing data if the main Corona Culture site remains age-gated or provider-controlled.

## Screens And User Flow

Add a protected Website Sync page, likely at `/website-sync`, with a sidebar entry such as `Website Sync` or `Menu Sync`.

The page should include:

- A Corona Culture source card.
- Last sync status, timestamp, item counts, and warning summary.
- Actions for `Run Sync`, `View Last Import`, and `Review Drafts`.
- A grouped result view for products/menu items, categories, prices/package sizes, THC/CBD/potency details, deals/promos, and store info.

After a sync, imported items should be marked with clear statuses:

- `New`
- `Changed`
- `Unmatched`
- `Needs Review`
- `Duplicate Candidate`
- `Failed Parse`

Staff should be able to inspect imported data with source evidence, then approve, reject, archive, or move selected information into the existing catalog/review path. The first implementation can keep promotion conservative if the existing review flow needs a narrower handoff.

## Data Model

The design needs three core concepts.

### Website Sync Source

Tracks configured external sources.

Expected fields:

- source name
- source type, such as `public_site`, `provider_listing`, `api`, or `manual_export`
- base URL or provider URL
- enabled flag
- last sync status
- last sync timestamp

### Website Sync Run

Tracks each attempted sync.

Expected fields:

- source ID
- status
- started and finished timestamps
- counts by record type
- warning list
- error message when failed
- diagnostics or source metadata

### Website Import Draft

Tracks each imported product, deal, category, or store-info record before review.

Expected fields:

- source ID and sync run ID
- source URL
- external ID when available
- record type
- normalized data
- raw source payload
- confidence or match score
- likely product/catalog match when available
- review status
- last-seen timestamp

Review statuses:

- `new`
- `needs_review`
- `approved`
- `rejected`
- `archived`

## Error Handling

The sync pipeline fails closed.

- If Corona Culture blocks scraping or age-gates content, the sync run records a warning and falls back to a provider/listing source when configured.
- If only partial product data is available, the draft is still saved and marked `needs_review`.
- If the source layout changes, the adapter records a failed sync run with diagnostics and does not mutate live records.
- Duplicate candidates are grouped and surfaced for review instead of silently merged.
- Network failures and rate limits should be visible in the sync history.

## Mobile Hardening Scope

The mobile pass should focus on layout resilience rather than visual novelty.

Target areas:

- App shell: reduce mobile padding, prevent horizontal overflow, and constrain sheets/drawers to viewport width.
- POS: make the product grid, scanner entry points, cart, customer panel, and daily-limit panel stack cleanly on small screens.
- Catalog/review/payroll tables: support compact mobile layouts or deliberate horizontal scroll with clear containment.
- Settings/admin screens: make tabs, action buttons, and settings rows wrap or scroll cleanly.
- Dashboard: ensure hero text, metric cards, charts, and operational cards fit at narrow widths.
- Global assistant drawer: avoid fixed desktop widths on mobile and prevent content from exceeding viewport height.

## Testing And Verification

Sync verification:

- Unit-test source normalization with saved Corona Culture/Weedmaps-like fixture data.
- Verify products, deals, categories, and store info become review drafts.
- Verify no sync path writes directly to live catalog, POS stock, inventory, or pricing.
- Verify failures create sync-run errors or warnings instead of partial live changes.

UI verification:

- Test the Website Sync page source card, run status, grouped results, and review actions.
- Run responsive checks for POS, Catalog Library, Payroll Run, Settings, Dashboard, and the assistant drawer.
- Use mobile viewport screenshots or Playwright checks to catch horizontal overflow.
- Confirm drawers and sheets stay inside the viewport.
- Confirm tables either scroll within a clear container or become compact/card-like rows.

Manual acceptance:

- Run a Corona Culture sync from the UI.
- Confirm all imported records land as review drafts.
- Confirm staff can review or reject imports without changing live product data.
- Confirm mobile navigation and key actions remain reachable on narrow screens.

## Implementation Notes

- Keep migrations idempotent with `IF NOT EXISTS` and guarded policies/triggers, matching repository conventions.
- Prefer existing Supabase, TanStack Query, shadcn/ui, and route patterns.
- Keep adapter logic isolated from UI components.
- Avoid scraping claims that are not confirmed by live traces; source adapters should expose warnings when evidence is partial.
- Add `.superpowers/` to local ignore handling before committing if companion artifacts remain untracked.
