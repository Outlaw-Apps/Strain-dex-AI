import { test, expect } from "@playwright/test";

const email = process.env.PLAYWRIGHT_AUTH_EMAIL;
const password = process.env.PLAYWRIGHT_AUTH_PASSWORD;

test.describe("smoke", () => {
  test("guest can load auth page", async ({ page }) => {
    await page.goto("/auth");
    await expect(page.getByRole("heading", { name: /strain-ventory/i })).toBeVisible();
    await expect(page.getByRole("heading", { name: /sign in with id \+ pin/i })).toBeVisible();
    await page.getByRole("button", { name: /sign in with email/i }).click();
    await expect(page.getByRole("heading", { name: /^sign in$/i })).toBeVisible();
    await expect(page.getByLabel("Email")).toBeVisible();
    await expect(page.getByLabel("Password")).toBeVisible();
  });

  test("guest sees 404 for unknown routes", async ({ page }) => {
    await page.goto("/not-a-real-route-e2e-xyz");
    await expect(page.getByRole("heading", { name: "404" })).toBeVisible();
    await expect(page.getByText(/page not found/i)).toBeVisible();
  });

  test.describe("authenticated smoke", () => {
    test.skip(!email || !password, "Set PLAYWRIGHT_AUTH_EMAIL and PLAYWRIGHT_AUTH_PASSWORD to run the logged-in smoke flow.");

    test("can sign in and reach core catalog routes", async ({ page }) => {
      await page.goto("/auth");

      await page.getByRole("button", { name: /sign in with email/i }).click();
      await page.getByLabel("Email").fill(email!);
      await page.getByLabel("Password").fill(password!);
      await page.getByRole("button", { name: /sign in/i }).click();

      await expect(page).toHaveURL(/\/$/);
      await expect(page.getByRole("heading", { name: /dashboard/i })).toBeVisible();

      await page.getByRole("link", { name: /product intake/i }).click();
      await expect(page).toHaveURL(/\/product-intake$/);
      await page.getByLabel(/brand/i).fill("Pacific Stone");
      await page.getByLabel(/product name/i).fill("Blue Dream");
      await page.getByRole("button", { name: /generate ai draft/i }).click();

      await expect(page).toHaveURL(/\/ai-draft$/);
      await expect(page.getByRole("heading", { name: /ai draft generator/i })).toBeVisible();

      await page.goto("/catalog");
      await expect(page.getByRole("heading", { name: /catalog library/i })).toBeVisible();

      await page.goto("/review");
      await expect(page.getByRole("heading", { name: /review & edit/i })).toBeVisible();

      await page.goto("/pos");
      await expect(page.getByRole("heading", { name: /point of sale/i })).toBeVisible();

      await page.goto("/shift-close");
      await expect(page.getByRole("heading", { name: /shift close/i })).toBeVisible();

      await page.goto("/settings");
      await expect(page.getByRole("heading", { name: /^settings$/i })).toBeVisible();
    });
  });
});
