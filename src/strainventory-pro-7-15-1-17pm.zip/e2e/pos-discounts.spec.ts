import { test, expect } from "@playwright/test";

const email = process.env.PLAYWRIGHT_AUTH_EMAIL;
const password = process.env.PLAYWRIGHT_AUTH_PASSWORD;

test.describe("POS discounts", () => {
  test.skip(!email || !password, "Set PLAYWRIGHT_AUTH_EMAIL and PLAYWRIGHT_AUTH_PASSWORD.");

  test("opens discounts dialog from cart", async ({ page }) => {
    await page.goto("/auth");
    await page.getByRole("button", { name: /sign in with email/i }).click();
    await page.getByLabel("Email").fill(email!);
    await page.getByLabel("Password").fill(password!);
    await page.getByRole("button", { name: /sign in/i }).click();

    await expect(page).toHaveURL(/\/$/);

    await page.goto("/pos");
    await expect(page.getByRole("heading", { name: /point of sale/i })).toBeVisible();

    await page.getByTestId("pos-discounts-button").click();
    await expect(page.getByTestId("pos-discounts-dialog")).toBeVisible();
    await expect(page.getByRole("heading", { name: /discounts & promotions/i })).toBeVisible();
  });
});
