const { app, BrowserWindow, protocol, net, shell, session } = require('electron');
const path = require('path');
const fs = require('fs');
const url = require('url');

// Register custom protocol before app is ready
protocol.registerSchemesAsPrivileged([
  {
    scheme: 'app',
    privileges: {
      standard: true,
      secure: true,
      supportFetchAPI: true,
      corsEnabled: true,
    },
  },
]);

const isDev = !app.isPackaged;
const DIST_PATH = path.resolve(path.join(__dirname, '..', 'dist'));

function createWindow() {
  const mainWindow = new BrowserWindow({
    width: 1400,
    height: 900,
    minWidth: 900,
    minHeight: 600,
    title: 'StrainVentory',
    icon: path.join(__dirname, '..', 'public', 'favicon.ico'),
    webPreferences: {
      preload: path.join(__dirname, 'preload.cjs'),
      contextIsolation: true,
      nodeIntegration: false,
    },
    show: false,
  });

  // Show window once content is ready to avoid flash
  mainWindow.once('ready-to-show', () => {
    mainWindow.show();
  });

  if (isDev) {
    const devServerUrl = process.env.VITE_DEV_SERVER_URL || 'http://localhost:8080';
    mainWindow.loadURL(devServerUrl);
    mainWindow.webContents.openDevTools();
  } else {
    mainWindow.loadURL('app://./');
  }

  // Open external links in the default browser
  mainWindow.webContents.setWindowOpenHandler(({ url: linkUrl }) => {
    if (linkUrl.startsWith('https://') || linkUrl.startsWith('http://')) {
      shell.openExternal(linkUrl);
    }
    return { action: 'deny' };
  });
}

// Origins allowed to use geolocation inside the desktop app.
// Dev: Vite dev server. Prod: our custom app:// scheme.
const GEOLOCATION_ALLOWED_ORIGINS = new Set([
  'http://localhost:8080',
  'http://localhost:5173',
  'app://.',
]);

const isGeolocationOriginAllowed = (origin) => {
  if (!origin) return false;
  if (GEOLOCATION_ALLOWED_ORIGINS.has(origin)) return true;
  if (process.env.VITE_DEV_SERVER_URL && origin === process.env.VITE_DEV_SERVER_URL) return true;
  return false;
};

// Derive an origin from a requesting URL in a way that works for custom schemes like `app://`.
// Node's `URL` class returns the opaque string "null" for non-standard schemes even after
// `registerSchemesAsPrivileged` (which only affects Chromium's parser), so fall back to
// `scheme://host`. Returns `null` if the URL cannot be parsed at all.
const originFromRequestingUrl = (requestingUrl) => {
  if (!requestingUrl) return null;
  try {
    const parsed = new URL(requestingUrl);
    if (parsed.origin && parsed.origin !== 'null') return parsed.origin;
    return `${parsed.protocol}//${parsed.host}`;
  } catch {
    return null;
  }
};

app.whenReady().then(() => {
  // Grant geolocation to our own renderer so the time-clock geofence works.
  // Without this, navigator.geolocation rejects with PERMISSION_DENIED in Electron.
  session.defaultSession.setPermissionRequestHandler((_webContents, permission, callback, details) => {
    if (permission === 'geolocation') {
      const origin = originFromRequestingUrl(details?.requestingUrl);
      callback(isGeolocationOriginAllowed(origin));
      return;
    }
    // Allow all other permissions (e.g. media/camera for BarcodeScanner).
    callback(true);
  });

  session.defaultSession.setPermissionCheckHandler((_webContents, permission, requestingOrigin) => {
    if (permission === 'geolocation') {
      return isGeolocationOriginAllowed(requestingOrigin);
    }
    // Allow all other permissions (e.g. media/camera for BarcodeScanner).
    // Returning `null`/`false` here would deny checks like `CheckMediaAccessPermission`
    // and break the barcode scanner in the desktop app.
    return true;
  });

  // Register custom protocol handler for production builds
  if (!isDev) {
    protocol.handle('app', (request) => {
      const { pathname } = new URL(request.url);
      const decodedPath = decodeURIComponent(pathname);
      const filePath = path.resolve(path.join(DIST_PATH, decodedPath));

      // Prevent path traversal outside DIST_PATH
      if (!filePath.startsWith(DIST_PATH + path.sep) && filePath !== DIST_PATH) {
        return net.fetch(url.pathToFileURL(path.join(DIST_PATH, 'index.html')).toString());
      }

      // Serve the file if it exists, otherwise fall back to index.html (SPA routing)
      if (fs.existsSync(filePath) && fs.statSync(filePath).isFile()) {
        return net.fetch(url.pathToFileURL(filePath).toString());
      }

      return net.fetch(url.pathToFileURL(path.join(DIST_PATH, 'index.html')).toString());
    });
  }

  createWindow();

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) {
      createWindow();
    }
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});
