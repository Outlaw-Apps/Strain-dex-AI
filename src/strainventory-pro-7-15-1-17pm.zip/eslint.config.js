import js from "@eslint/js";
import globals from "globals";
import reactHooks from "eslint-plugin-react-hooks";
import reactRefresh from "eslint-plugin-react-refresh";
import tseslint from "typescript-eslint";

export default tseslint.config(
  {
    ignores: [
      "dist/**",
      "android/app/build/**",
      "node_modules/**",
      ".claude/**",
      ".codex/**",
      ".superpowers/**",
      ".npm-cache/**",
      "test-results/**",
      "release/**",
      "supabase/apps/**",
    ],
  },
  {
    extends: [js.configs.recommended, ...tseslint.configs.recommended],
    files: ["**/*.{ts,tsx}"],
    languageOptions: {
      ecmaVersion: 2020,
      globals: globals.browser,
    },
    plugins: {
      "react-hooks": reactHooks,
      "react-refresh": reactRefresh,
    },
    rules: {
      ...reactHooks.configs.recommended.rules,
      "react-refresh/only-export-components": ["warn", {
        allowConstantExport: true,
        allowExportNames: [
          "badgeVariants",
          "buttonVariants",
          "navigationMenuTriggerStyle",
          "toggleVariants",
          "toast",
          "useFormField",
          "useSidebar",
          "AuthProvider",
          "useAuth",
          "ProductDraftProvider",
          "useProductDraft",
          "MessengerNotificationsProvider",
          "useMessengerNotificationsContext",
        ],
      }],
      "@typescript-eslint/no-unused-vars": "off",
    },
  },
);

