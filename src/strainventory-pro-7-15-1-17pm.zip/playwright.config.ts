import { defineConfig, devices } from "@playwright/test";

const DEFAULT_PORT = 4273;
const rawPort = process.env.PLAYWRIGHT_PORT;
const parsedPort =
  rawPort == null ? DEFAULT_PORT : Number.parseInt(rawPort, 10);

if (
  !Number.isInteger(parsedPort) ||
  parsedPort < 1 ||
  parsedPort > 65535 ||
  (rawPort != null && rawPort.trim() !== String(parsedPort))
) {
  throw new Error(
    `Invalid PLAYWRIGHT_PORT: ${JSON.stringify(
      rawPort,
    )}. Expected an integer between 1 and 65535.`,
  );
}

const PORT = parsedPort;
const baseURL = `http://127.0.0.1:${PORT}`;

export default defineConfig({
  testDir: "./tests",
  testMatch: /.*\.spec\.ts/,
  reporter: process.env.CI
    ? [["html", { outputFolder: "playwright-report", open: "never" }], ["list"]]
    : "list",
  use: {
    baseURL,
    trace: "on-first-retry",
  },
  webServer: {
    command: `npm run dev -- --host 127.0.0.1 --port ${PORT} --strictPort`,
    url: baseURL,
    reuseExistingServer: process.env.PLAYWRIGHT_REUSE_SERVER
      ? process.env.PLAYWRIGHT_REUSE_SERVER === "1"
      : !process.env.CI,
    timeout: 120000,
  },
  projects: [
    {
      name: "chromium",
      use: {
        ...devices["Desktop Chrome"],
      },
    },

    {
      name: "firefox",
      use: {
        ...devices["Desktop Firefox"],
      },
    },
  ],
});
