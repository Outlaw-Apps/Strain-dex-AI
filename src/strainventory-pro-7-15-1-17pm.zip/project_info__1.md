# How to Create a Skill Manually — Complete Guide

Based on inspecting the existing `skill-creator` skill at `C:\Users\Deana\.claude\skills\skill-creator\`, here's everything you need to know.

---

## Folder Structure

A skill lives at:
- **Windows**: `%USERPROFILE%\.claude\skills\<skill-name>\` → `C:\Users\Deana\.claude\skills\<skill-name>\`
- **macOS/Linux**: `~/.claude/skills/<skill-name>/`

### Full layout (optional subdirectories shown):

```
.claude/skills/<skill-name>/
├── SKILL.md          # REQUIRED — YAML frontmatter + markdown instructions
├── scripts/          # Optional — executable scripts the skill can invoke
├── references/       # Optional — reference docs, schemas, API specs loaded as context
└── assets/           # Optional — templates, images, config files
```

Only `SKILL.md` is mandatory. The three subdirectories are optional and can be any combination.

---

## SKILL.md Format

### Required YAML frontmatter

```yaml
---
name: your-skill-name        # kebab-case, must match folder name
description: What it does. Use when [trigger conditions].
---
```

### Required body

Markdown instructions. No specific structure is enforced, but the convention is:

```markdown
# Your Skill Name

## Purpose
What this skill does, who it's for.

## Instructions
### Step 1: [First Major Step]
Clear explanation.

### Step 2: [Next Step]
...
```

---

## Rules (from the existing skill-creator skill)

| Rule | Detail |
|------|--------|
| Folder naming | **kebab-case** (lowercase, hyphens, e.g. `my-cool-skill`) |
| File name | Exactly `SKILL.md` — case-sensitive on Linux/macOS |
| Required frontmatter fields | `name` and `description` |
| Description format | Must include **what** it does AND **when** to use it |
| Forbidden | XML angle brackets (`<` `>`) in frontmatter — they break YAML parsing |
| Convention | Keep SKILL.md focused on core instructions; put lengthy reference docs in `references/` |

---

## Example: Full SKILL.md for a `demo-skill`

```markdown
---
name: demo-skill
description: Demonstrates the skill folder structure. Use when learning how to create a new skill or scaffolding a template.
---

# Demo Skill

## Purpose
This is a template skill showing the complete folder structure. Replace this with your own skill content.

## Instructions

### Step 1: Understand the folder layout
The skill folder lives at `~/.claude/skills/<skill-name>/` and contains:
- **SKILL.md** — Required. YAML frontmatter + markdown instructions.
- **scripts/** — Optional. Executable scripts the LLM can invoke (shell, Python, etc.).
- **references/** — Optional. Reference material loaded as context (schemas, API docs, policies).
- **assets/** — Optional. Static files like templates, images, or config files used by the skill.

### Step 2: Write concise instructions
Keep SKILL.md focused on actionable steps. Put lengthy reference material in `references/`.

### Step 3: Test your skill
Trigger the skill by asking the LLM to do what your description says. Iterate on the instructions based on results.

## Notes
- Folder name must be **kebab-case** (e.g., `my-cool-skill`)
- File name must be exactly `SKILL.md` (case-sensitive on some systems)
- No XML angle brackets (`<` `>`) in YAML frontmatter — they break parsing
- The `description` field must cover **what** the skill does AND **when** to use it
```

---

## Steps to Create Your Own

1. **Create the folder**  
   `mkdir %USERPROFILE%\.claude\skills\<your-skill-name>\`

2. **Create SKILL.md** inside that folder with the YAML frontmatter and instructions

3. **Optionally create** `scripts\`, `references\`, `assets\` subdirectories

4. **Done** — the skill is loaded automatically when its description matches the user's request

---

## Next Step

What skill do you want to create? Tell me the **name** (kebab-case) and a **description** (what it does + when to use it), and I'll walk you through the exact SKILL.md content and which subdirectories would be useful.