window.STRAINVENTORY_CONFIG = {
  supabaseUrl: "${VITE_SUPABASE_URL}",
  supabasePublishableKey: "${VITE_SUPABASE_PUBLISHABLE_KEY}",
  edgeFunctionBaseUrl: "${VITE_EDGE_FUNCTION_BASE_URL}",
};
