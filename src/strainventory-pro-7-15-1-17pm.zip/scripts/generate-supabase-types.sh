#!/usr/bin/env bash
# Regenerate src/integrations/supabase/types.ts from the linked Supabase project.
#
# Usage:
#   npm run types:generate          # write to src/integrations/supabase/types.ts
#   npm run types:check             # fail if the generated types drift from disk
#
# Configuration (env vars):
#   SUPABASE_PROJECT_REF   Project ref to introspect. Defaults to the value in
#                          supabase/.temp/project-ref written by `supabase link`.
#   SUPABASE_DB_URL        If set, used instead of --project-id (useful for
#                          self-hosted / local Postgres).
set -euo pipefail

OUT_FILE="src/integrations/supabase/types.ts"
MODE="${1:-write}"

PROJECT_REF="${SUPABASE_PROJECT_REF:-}"
if [[ -z "${PROJECT_REF}" && -f supabase/.temp/project-ref ]]; then
  PROJECT_REF="$(tr -d '[:space:]' < supabase/.temp/project-ref)"
fi

run_gen() {
  if [[ -n "${SUPABASE_DB_URL:-}" ]]; then
    npx --yes supabase gen types typescript --db-url "$SUPABASE_DB_URL" --schema public "$@"
  elif [[ -n "$PROJECT_REF" ]]; then
    npx --yes supabase gen types typescript --project-id "$PROJECT_REF" --schema public "$@"
  else
    echo "✖ No SUPABASE_PROJECT_REF or SUPABASE_DB_URL configured." >&2
    echo "  Run \`npx supabase link --project-ref <ref>\` first, or set SUPABASE_PROJECT_REF." >&2
    exit 1
  fi
}

case "$MODE" in
  write)
    echo "→ Generating Supabase types into $OUT_FILE"
    TMP="$(mktemp)"
    run_gen > "$TMP"
    mkdir -p "$(dirname "$OUT_FILE")"
    mv "$TMP" "$OUT_FILE"
    echo "✓ Wrote $OUT_FILE"
    ;;
  check)
    echo "→ Checking $OUT_FILE for schema drift"
    TMP="$(mktemp)"
    run_gen > "$TMP"
    if ! diff -u "$OUT_FILE" "$TMP" > /dev/null; then
      echo "✖ Supabase types are out of date. Run \`npm run types:generate\` and commit the result." >&2
      diff -u "$OUT_FILE" "$TMP" || true
      rm -f "$TMP"
      exit 1
    fi
    rm -f "$TMP"
    echo "✓ Supabase types are in sync."
    ;;
  *)
    echo "Unknown mode: $MODE (expected 'write' or 'check')" >&2
    exit 1
    ;;
esac
