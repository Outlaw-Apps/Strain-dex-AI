#!/usr/bin/env bash
# ============================================================================
# StrainVentory — Apply Migrations to a Self-Hosted Database
# ============================================================================
# Usage:
#   ./selfhost/apply-migrations.sh [DATABASE_URL]
#
# If DATABASE_URL is not passed as an argument it falls back to the
# DATABASE_URL environment variable, then to the default local Compose URL.
#
# The script applies every .sql file in supabase/migrations/ in sorted order
# using a simple idempotent "applied_migrations" tracking table so files are
# never run twice.
# ============================================================================

set -euo pipefail

DB_URL="${1:-${DATABASE_URL:-postgres://postgres:${POSTGRES_PASSWORD:-postgres}@localhost:5432/${POSTGRES_DB:-postgres}}}"

MIGRATIONS_DIR="$(cd "$(dirname "$0")/../supabase/migrations" && pwd)"

echo "==> Connecting to database..."
echo "==> Migrations directory: $MIGRATIONS_DIR"

# Create tracking table if it does not exist
psql "$DB_URL" -v ON_ERROR_STOP=1 <<'SQL'
CREATE TABLE IF NOT EXISTS public.applied_migrations (
  name TEXT PRIMARY KEY,
  applied_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
SQL

applied=$(psql "$DB_URL" -t -A -c "SELECT name FROM public.applied_migrations ORDER BY name;")

count=0
for file in "$MIGRATIONS_DIR"/*.sql; do
  base=$(basename "$file")

  if echo "$applied" | grep -qxF "$base"; then
    continue
  fi

  echo "    Applying: $base"
  psql "$DB_URL" -v ON_ERROR_STOP=1 -f "$file"

  psql "$DB_URL" -v ON_ERROR_STOP=1 -v "mig_name=$base" -c \
    "INSERT INTO public.applied_migrations (name) VALUES (:'mig_name') ON CONFLICT DO NOTHING;"

  count=$((count + 1))
done

if [ "$count" -eq 0 ]; then
  echo "==> All migrations already applied."
else
  echo "==> Applied $count migration(s) successfully."
fi
