-- ============================================================================
-- StrainVentory self-host: set login passwords for Supabase internal roles.
-- ============================================================================
-- The supabase/postgres image creates the internal service roles
-- (authenticator, supabase_auth_admin, supabase_storage_admin, ...) WITHOUT a
-- password.  Connections from inside the container over 127.0.0.1 use `trust`
-- auth, but the Supabase services connect over the Docker network, where
-- pg_hba requires scram-sha-256.  With no password set, GoTrue, PostgREST and
-- Storage fail SASL auth and crash-loop on startup.
--
-- This script runs as part of the image init flow (the migrate.sh init-scripts
-- pass) on a fresh data volume, after the baseline scripts have created the
-- roles.  It assigns each service role the POSTGRES_PASSWORD so they can
-- authenticate over the network.
--
-- Note: psql does not interpolate :variables inside dollar-quoted blocks, so
-- the ALTER ROLE statements are issued directly rather than from a DO block.
-- ============================================================================

\set pgpass `echo "$POSTGRES_PASSWORD"`

ALTER ROLE authenticator WITH LOGIN PASSWORD :'pgpass';
ALTER ROLE supabase_auth_admin WITH LOGIN PASSWORD :'pgpass';
ALTER ROLE supabase_storage_admin WITH LOGIN PASSWORD :'pgpass';

-- Realtime connects with `search_path = _realtime` and creates its Ecto
-- migration table there on boot.  The schema is not part of the baseline
-- image, so create it up front or realtime crash-loops with
-- "no schema has been selected to create in".
CREATE SCHEMA IF NOT EXISTS _realtime;
GRANT ALL PRIVILEGES ON SCHEMA _realtime TO postgres, supabase_admin;
