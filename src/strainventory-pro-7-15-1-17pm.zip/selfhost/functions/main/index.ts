// ============================================================================
// StrainVentory self-host: Edge Functions "main" router.
// ============================================================================
// The supabase/edge-runtime image must be started with a main service that
// dispatches incoming requests to the individual function under
// /home/deno/functions/<name>. Without it, `edge-runtime` prints its help
// text and exits, causing the functions container to crash-loop.
//
// Functions are deployed with --no-verify-jwt, so JWT verification is left to
// each function (and Kong/PostgREST downstream). Set VERIFY_JWT=true to require
// a valid HS256 token at the gateway instead.
// ============================================================================

console.log("strainventory edge-runtime main started");

// Only allow alphanumeric names and hyphens — blocks path-traversal attempts
// like "../../etc" from reaching the filesystem.
const VALID_SERVICE_NAME = /^[a-zA-Z0-9_-]+$/;

// Cache workers so we don't spawn a new isolate on every request.
const workerCache = new Map<string, ReturnType<typeof EdgeRuntime.userWorkers.create>>();

// Snapshot env vars once at startup instead of on every request.
const envVars = Object.entries(Deno.env.toObject());

Deno.serve(async (req: Request) => {
  const url = new URL(req.url);
  const serviceName = url.pathname.split("/").filter(Boolean)[0];

  if (!serviceName) {
    return new Response(
      JSON.stringify({ msg: "missing function name in request" }),
      { status: 400, headers: { "Content-Type": "application/json" } },
    );
  }

  if (!VALID_SERVICE_NAME.test(serviceName)) {
    return new Response(
      JSON.stringify({ msg: "invalid function name" }),
      { status: 400, headers: { "Content-Type": "application/json" } },
    );
  }

  const servicePath = `/home/deno/functions/${serviceName}`;

  let workerPromise = workerCache.get(serviceName);
  if (!workerPromise) {
    workerPromise = EdgeRuntime.userWorkers.create({
      servicePath,
      memoryLimitMb: 256,
      workerTimeoutMs: 5 * 60 * 1000,
      noModuleCache: false,
      importMapPath: null,
      envVars,
    });
    workerCache.set(serviceName, workerPromise);
  }

  try {
    const worker = await workerPromise;
    return await worker.fetch(req);
  } catch (e) {
    // Only evict if cache still holds the promise we used — a concurrent
    // request may have already replaced it with a fresh worker.
    if (workerCache.get(serviceName) === workerPromise) {
      workerCache.delete(serviceName);
    }
    return new Response(JSON.stringify({ msg: String(e) }), {
      status: 500,
      headers: { "Content-Type": "application/json" },
    });
  }
});
