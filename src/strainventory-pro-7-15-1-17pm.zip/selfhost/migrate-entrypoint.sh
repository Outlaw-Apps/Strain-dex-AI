#!/usr/bin/env bash
# ============================================================================
# StrainVentory self-host: one-shot migration runner.
# ============================================================================
# App migrations are intentionally NOT mounted into the Postgres init dir.
# Several migrations reference `storage.buckets.public`, a column the
# supabase/postgres baseline schema does not have — it is added by storage-api
# when it first runs its own migrations. Running the app migrations at DB-init
# time therefore aborts the whole init (ON_ERROR_STOP), leaving the schema
# half-created.
#
# Instead this container waits until:
#   1. Postgres accepts connections, and
#   2. storage-api has migrated the storage schema (buckets.public exists),
# then applies the StrainVentory migrations idempotently.
# ============================================================================
set -euo pipefail

: "${POSTGRES_PASSWORD:?POSTGRES_PASSWORD is required}"
DB_HOST="${POSTGRES_HOST:-db}"
DB_PORT="${POSTGRES_PORT:-5432}"
DB_NAME="${POSTGRES_DB:-postgres}"
export PGPASSWORD="$POSTGRES_PASSWORD"

DB_URL="postgres://supabase_admin:${POSTGRES_PASSWORD}@${DB_HOST}:${DB_PORT}/${DB_NAME}?sslmode=disable"

PG_MAX_RETRIES=60
echo "==> Waiting for Postgres at ${DB_HOST}:${DB_PORT} (up to $((PG_MAX_RETRIES * 2))s)..."
pg_attempt=0
until psql "$DB_URL" -tAc "select 1" >/dev/null 2>&1; do
  pg_attempt=$((pg_attempt + 1))
  if [ "$pg_attempt" -ge "$PG_MAX_RETRIES" ]; then
    echo "!! Postgres did not become ready after $((PG_MAX_RETRIES * 2))s — aborting." >&2
    exit 1
  fi
  sleep 2
done

echo "==> Waiting for storage-api to migrate the storage schema..."
for _ in $(seq 1 150); do
  have_public=$(psql "$DB_URL" -tAc \
    "select count(*) from information_schema.columns where table_schema='storage' and table_name='buckets' and column_name='public'" \
    2>/dev/null || echo 0)
  if [ "${have_public}" = "1" ]; then
    break
  fi
  sleep 2
done

if [ "${have_public:-0}" != "1" ]; then
  echo "!! storage.buckets.public never appeared — storage-api may be unhealthy." >&2
  exit 1
fi

echo "==> Applying StrainVentory migrations..."
DATABASE_URL="$DB_URL" /repo/selfhost/apply-migrations.sh "$DB_URL"
echo "==> Migration runner finished."
