-- ============================================================================
-- StrainVentory — Complete Schema Reference (for self-hosting)
-- ============================================================================
-- This file contains the cumulative schema from all migrations as of
-- 2026-05-29, including the development-mode open RLS policies.
--
-- Use it as a reference when setting up a fresh self-hosted PostgreSQL
-- instance.  The canonical source of truth is the individual migration
-- files in supabase/migrations/.
--
-- Prerequisites: run against a Supabase-compatible Postgres database with
-- the auth, storage, and extensions schemas already in place.
-- ============================================================================

-- ── Enum types ───────────────────────────────────────────────────────────────

DO $$ BEGIN
  CREATE TYPE public.app_role AS ENUM ('admin', 'staff', 'reviewer');
EXCEPTION WHEN duplicate_object THEN NULL;
END $$;


-- ── Tables ───────────────────────────────────────────────────────────────────

-- user_roles
CREATE TABLE IF NOT EXISTS public.user_roles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  role app_role NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (user_id, role)
);

-- products
CREATE TABLE IF NOT EXISTS public.products (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  brand TEXT NOT NULL,
  type TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'draft',
  confidence INTEGER NOT NULL DEFAULT 0,
  thc TEXT NOT NULL DEFAULT '',
  cbd TEXT NOT NULL DEFAULT '',
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  strain TEXT NOT NULL DEFAULT '',
  sku TEXT NOT NULL DEFAULT '',
  package_size TEXT NOT NULL DEFAULT '',
  terpenes TEXT NOT NULL DEFAULT '',
  aroma TEXT NOT NULL DEFAULT '',
  taste TEXT NOT NULL DEFAULT '',
  effects TEXT NOT NULL DEFAULT '',
  medical_uses TEXT NOT NULL DEFAULT '',
  short_description TEXT NOT NULL DEFAULT '',
  long_description TEXT NOT NULL DEFAULT '',
  images JSONB NOT NULL DEFAULT '[]'::jsonb,
  created_by UUID REFERENCES auth.users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  price NUMERIC(10,2) NOT NULL DEFAULT 0,
  in_stock BOOLEAN NOT NULL DEFAULT true,
  quantity INTEGER NOT NULL DEFAULT 0,
  stock INTEGER NOT NULL DEFAULT 0,
  product_type TEXT,
  batch_number TEXT DEFAULT '',
  genetics TEXT DEFAULT '',
  limit_category TEXT,
  strain_type TEXT,
  weight_grams NUMERIC DEFAULT 0,
  external_pos_id TEXT,
  last_synced_at TIMESTAMPTZ,
  sale_price NUMERIC(10,2),
  sale_starts_at TIMESTAMPTZ,
  sale_ends_at TIMESTAMPTZ,
  sale_label TEXT,
  clearance_price NUMERIC(10,2),
  clearance_reason TEXT,
  clearance_active BOOLEAN NOT NULL DEFAULT false
);

CREATE UNIQUE INDEX IF NOT EXISTS products_external_pos_id_key
  ON public.products (external_pos_id) WHERE external_pos_id IS NOT NULL;

-- customers
CREATE TABLE IF NOT EXISTS public.customers (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_number TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL DEFAULT '',
  email TEXT NOT NULL DEFAULT '',
  phone TEXT NOT NULL DEFAULT '',
  notes TEXT NOT NULL DEFAULT '',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  license_number TEXT,
  date_of_birth DATE,
  last_age_verified_at TIMESTAMPTZ,
  is_employee BOOLEAN NOT NULL DEFAULT false,
  is_senior BOOLEAN NOT NULL DEFAULT false,
  is_military BOOLEAN NOT NULL DEFAULT false,
  is_police BOOLEAN NOT NULL DEFAULT false,
  is_fire BOOLEAN NOT NULL DEFAULT false,
  service_discount_note TEXT
);

CREATE UNIQUE INDEX IF NOT EXISTS customers_license_number_unique
  ON public.customers (license_number) WHERE license_number IS NOT NULL;

-- orders
CREATE TABLE IF NOT EXISTS public.orders (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_id UUID REFERENCES public.customers(id) ON DELETE SET NULL,
  payment_method TEXT NOT NULL DEFAULT 'cash',
  subtotal NUMERIC(10,2) NOT NULL DEFAULT 0,
  tax NUMERIC(10,2) NOT NULL DEFAULT 0,
  total NUMERIC(10,2) NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'completed',
  created_by UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  external_id TEXT,
  discount_total NUMERIC(10,2) NOT NULL DEFAULT 0,
  discount_summary TEXT NOT NULL DEFAULT '',
  discount_snapshot_json JSONB NOT NULL DEFAULT '{}'::jsonb
);

CREATE UNIQUE INDEX IF NOT EXISTS orders_external_id_key
  ON public.orders (external_id) WHERE external_id IS NOT NULL;

-- order_items
CREATE TABLE IF NOT EXISTS public.order_items (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id UUID NOT NULL REFERENCES public.orders(id) ON DELETE CASCADE,
  product_id UUID NOT NULL REFERENCES public.products(id) ON DELETE RESTRICT,
  product_name TEXT NOT NULL,
  weight TEXT NOT NULL DEFAULT '3.5g',
  quantity INTEGER NOT NULL DEFAULT 1,
  unit_price NUMERIC(10,2) NOT NULL DEFAULT 0,
  total_price NUMERIC(10,2) NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  base_unit_price NUMERIC(10,2) DEFAULT 0,
  discounted_unit_price NUMERIC(10,2) DEFAULT 0,
  discount_amount NUMERIC(10,2) NOT NULL DEFAULT 0,
  applied_discount_ids JSONB NOT NULL DEFAULT '[]'::jsonb
);

-- discount_definitions
CREATE TABLE IF NOT EXISTS public.discount_definitions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  type TEXT NOT NULL,
  scope TEXT NOT NULL DEFAULT 'ticket',
  percent_off NUMERIC(6,3),
  pricing_mode TEXT,
  eligible_product_ids UUID[] DEFAULT NULL,
  eligible_categories TEXT[] DEFAULT NULL,
  stackable BOOLEAN NOT NULL DEFAULT false,
  requires_approval BOOLEAN NOT NULL DEFAULT false,
  requires_customer_flag TEXT DEFAULT NULL,
  start_at TIMESTAMPTZ,
  end_at TIMESTAMPTZ,
  priority INTEGER NOT NULL DEFAULT 100,
  metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS discount_definitions_priority_idx
  ON public.discount_definitions (priority DESC);

-- order_discount_events
CREATE TABLE IF NOT EXISTS public.order_discount_events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id UUID NOT NULL REFERENCES public.orders(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  discount_definition_id UUID REFERENCES public.discount_definitions(id) ON DELETE SET NULL,
  event_kind TEXT NOT NULL DEFAULT 'checkout',
  reason TEXT,
  manager_override BOOLEAN NOT NULL DEFAULT false,
  payload JSONB NOT NULL DEFAULT '{}'::jsonb
);

CREATE INDEX IF NOT EXISTS order_discount_events_order_idx
  ON public.order_discount_events (order_id);

-- time_entries
CREATE TABLE IF NOT EXISTS public.time_entries (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  clock_in TIMESTAMPTZ NOT NULL DEFAULT now(),
  clock_out TIMESTAMPTZ,
  notes TEXT NOT NULL DEFAULT '',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- profiles
CREATE TABLE IF NOT EXISTS public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name TEXT NOT NULL DEFAULT '',
  avatar_url TEXT NOT NULL DEFAULT '',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  badge_number TEXT
);

CREATE UNIQUE INDEX IF NOT EXISTS profiles_badge_number_unique
  ON public.profiles (badge_number) WHERE badge_number IS NOT NULL;

-- employees
CREATE TABLE IF NOT EXISTS public.employees (
  id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
  full_name TEXT NOT NULL,
  date_of_birth DATE,
  phone TEXT NOT NULL,
  email TEXT NOT NULL,
  emergency_contact TEXT,
  role TEXT NOT NULL CHECK (role IN ('budtender', 'shift_lead', 'inventory', 'security')),
  badge_number TEXT,
  live_scan_status TEXT DEFAULT 'pending',
  mmic_number TEXT,
  government_id_url TEXT,
  sop_handbook_acknowledged BOOLEAN NOT NULL DEFAULT false,
  status TEXT DEFAULT 'pending_review',
  assigned_role TEXT NOT NULL DEFAULT 'staff',
  created_by UUID REFERENCES auth.users(id),
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  approved_at TIMESTAMPTZ,
  approved_by UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  rejected_at TIMESTAMPTZ,
  rejection_reason TEXT,
  user_id UUID REFERENCES auth.users(id) ON DELETE SET NULL
);

CREATE INDEX IF NOT EXISTS employees_status_idx ON public.employees(status);
CREATE INDEX IF NOT EXISTS employees_user_id_idx ON public.employees(user_id);

-- employee_payroll_profiles
CREATE TABLE IF NOT EXISTS public.employee_payroll_profiles (
  id TEXT NOT NULL DEFAULT '',
  employee_id UUID DEFAULT gen_random_uuid() REFERENCES auth.users(id) ON DELETE CASCADE,
  hourly_rate NUMERIC(10,2) NOT NULL DEFAULT 0,
  overtime_multiplier NUMERIC(3,2) NOT NULL DEFAULT 1.5,
  doubletime_multiplier NUMERIC(3,2) NOT NULL DEFAULT 2.0,
  deductions NUMERIC(10,2) NOT NULL DEFAULT 0,
  tax_filing_status TEXT NOT NULL DEFAULT 'single',
  direct_deposit_routing TEXT,
  direct_deposit_account TEXT,
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

CREATE UNIQUE INDEX IF NOT EXISTS employee_payroll_profiles_employee_id_key
  ON public.employee_payroll_profiles (employee_id);

-- pay_periods
CREATE TABLE IF NOT EXISTS public.pay_periods (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  start_date DATE NOT NULL DEFAULT CURRENT_DATE,
  end_date DATE NOT NULL DEFAULT CURRENT_DATE,
  status TEXT DEFAULT 'draft',
  total_wages NUMERIC(12,2) DEFAULT 0,
  total_ot_hours NUMERIC(8,2) DEFAULT 0,
  created_by UUID REFERENCES auth.users(id),
  created_at TIMESTAMPTZ DEFAULT now()
);

-- payslips
CREATE TABLE IF NOT EXISTS public.payslips (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  employee_id UUID DEFAULT gen_random_uuid() REFERENCES auth.users(id) ON DELETE CASCADE,
  pay_period_id UUID REFERENCES public.pay_periods(id),
  regular_hours NUMERIC(8,2) NOT NULL DEFAULT 0,
  ot_hours NUMERIC(8,2) NOT NULL DEFAULT 0,
  doubletime_hours NUMERIC(8,2) DEFAULT 0,
  gross_pay NUMERIC(12,2) NOT NULL DEFAULT 0,
  deductions NUMERIC(12,2) DEFAULT 0,
  net_pay NUMERIC(12,2) NOT NULL DEFAULT 0,
  pdf_url TEXT,
  created_at TIMESTAMPTZ DEFAULT now()
);

CREATE UNIQUE INDEX IF NOT EXISTS payslips_pay_period_id_employee_id_key
  ON public.payslips (pay_period_id, employee_id);

-- pos_audit_events
CREATE TABLE IF NOT EXISTS public.pos_audit_events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  event_type TEXT NOT NULL,
  metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_by UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- shift_reports
CREATE TABLE IF NOT EXISTS public.shift_reports (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  period_start TIMESTAMPTZ NOT NULL,
  period_end TIMESTAMPTZ NOT NULL,
  closed_by UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  order_count INTEGER NOT NULL DEFAULT 0,
  total_sales NUMERIC(12,2) NOT NULL DEFAULT 0,
  total_cash NUMERIC(12,2) NOT NULL DEFAULT 0,
  total_card NUMERIC(12,2) NOT NULL DEFAULT 0,
  total_other NUMERIC(12,2) NOT NULL DEFAULT 0,
  opening_float NUMERIC(12,2),
  counted_cash NUMERIC(12,2),
  expected_cash NUMERIC(12,2),
  variance_notes TEXT NOT NULL DEFAULT '',
  notes TEXT NOT NULL DEFAULT '',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- business_settings (singleton)
CREATE TABLE IF NOT EXISTS public.business_settings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  geofence_enabled BOOLEAN NOT NULL DEFAULT true,
  geofence_lat NUMERIC(10,8),
  geofence_lng NUMERIC(11,8),
  geofence_radius_meters INTEGER NOT NULL DEFAULT 150,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

INSERT INTO public.business_settings (id, geofence_enabled, geofence_radius_meters)
VALUES ('00000000-0000-0000-0000-000000000001', false, 150)
ON CONFLICT (id) DO NOTHING;

-- strains (The Vault)
CREATE TABLE IF NOT EXISTS public.strains (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc', now()),
  name TEXT NOT NULL,
  brand TEXT DEFAULT 'Outlaw-Tech Select',
  type TEXT,
  status TEXT DEFAULT 'Draft',
  description TEXT,
  price NUMERIC(10,2) DEFAULT 0.00,
  stock INTEGER DEFAULT 0,
  thc NUMERIC(5,2),
  cbd NUMERIC(5,2),
  terpenes TEXT[],
  lineage TEXT,
  flavor_in TEXT,
  flavor_out TEXT,
  aroma TEXT
);

-- strain_knowledge_entries
CREATE TABLE IF NOT EXISTS public.strain_knowledge_entries (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  stable_key TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  type TEXT NOT NULL CHECK (type IN ('indica', 'sativa', 'hybrid')),
  thc TEXT NOT NULL DEFAULT '',
  cbd TEXT NOT NULL DEFAULT '',
  cbn TEXT,
  effects JSONB NOT NULL DEFAULT '[]'::jsonb,
  flavors JSONB NOT NULL DEFAULT '[]'::jsonb,
  aromas JSONB NOT NULL DEFAULT '[]'::jsonb,
  description TEXT NOT NULL DEFAULT '',
  terpenes JSONB NOT NULL DEFAULT '[]'::jsonb,
  lineage TEXT NOT NULL DEFAULT '',
  grow_difficulty TEXT NOT NULL DEFAULT 'moderate' CHECK (grow_difficulty IN ('easy', 'moderate', 'hard')),
  flowering_time TEXT NOT NULL DEFAULT '',
  source_updated_at TIMESTAMPTZ NOT NULL,
  source_device_id TEXT,
  source_app TEXT,
  source_user_id UUID REFERENCES auth.users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS strain_knowledge_entries_name_idx
  ON public.strain_knowledge_entries (name);

-- strain_knowledge_images
CREATE TABLE IF NOT EXISTS public.strain_knowledge_images (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  entry_id UUID NOT NULL REFERENCES public.strain_knowledge_entries(id) ON DELETE CASCADE,
  local_photo_id INTEGER NOT NULL DEFAULT -1,
  file_name TEXT NOT NULL,
  content_type TEXT NOT NULL,
  data_uri TEXT NOT NULL,
  added_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS strain_knowledge_images_entry_id_idx
  ON public.strain_knowledge_images (entry_id);

-- assistant_threads
CREATE TABLE IF NOT EXISTS public.assistant_threads (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  title TEXT NOT NULL DEFAULT 'Assistant Thread',
  audience_role TEXT NOT NULL DEFAULT 'employee' CHECK (audience_role IN ('employee', 'vendor', 'management')),
  page_context JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS assistant_threads_user_id_idx
  ON public.assistant_threads (user_id, updated_at DESC);

-- assistant_messages
CREATE TABLE IF NOT EXISTS public.assistant_messages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  thread_id UUID NOT NULL REFERENCES public.assistant_threads(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  role TEXT NOT NULL CHECK (role IN ('user', 'assistant')),
  content TEXT NOT NULL,
  context JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS assistant_messages_thread_id_idx
  ON public.assistant_messages (thread_id, created_at);

-- assistant_action_logs
CREATE TABLE IF NOT EXISTS public.assistant_action_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  thread_id UUID REFERENCES public.assistant_threads(id) ON DELETE CASCADE,
  message_id UUID REFERENCES public.assistant_messages(id) ON DELETE SET NULL,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  intent TEXT NOT NULL,
  summary TEXT NOT NULL,
  proposed_changes JSONB NOT NULL DEFAULT '[]'::jsonb,
  execution_payload JSONB NOT NULL DEFAULT '{}'::jsonb,
  status TEXT NOT NULL DEFAULT 'recommended' CHECK (status IN ('recommended', 'confirmed', 'executed', 'failed', 'dismissed')),
  error TEXT,
  confirmed_at TIMESTAMPTZ,
  executed_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS assistant_action_logs_user_id_idx
  ON public.assistant_action_logs (user_id, created_at DESC);

-- ai_search_domains
CREATE TABLE IF NOT EXISTS public.ai_search_domains (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  domain TEXT NOT NULL UNIQUE,
  mode TEXT NOT NULL CHECK (mode IN ('allow', 'block')),
  label TEXT,
  enabled BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS ai_search_domains_mode_enabled_idx
  ON public.ai_search_domains (mode, enabled);

-- user_credentials (short-ID / PIN login)
CREATE TABLE IF NOT EXISTS public.user_credentials (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  short_id TEXT NOT NULL,
  display_name TEXT,
  created_by UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (user_id)
);

CREATE UNIQUE INDEX IF NOT EXISTS user_credentials_short_id_lower_key
  ON public.user_credentials (lower(short_id));

-- conversations
CREATE TABLE IF NOT EXISTS public.conversations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  is_group BOOLEAN NOT NULL DEFAULT false,
  title TEXT,
  created_by UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  last_message_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  last_message_preview TEXT,
  last_sender_id UUID REFERENCES auth.users(id) ON DELETE SET NULL
);

CREATE INDEX IF NOT EXISTS conversations_last_message_at_idx
  ON public.conversations (last_message_at DESC);

-- conversation_members
CREATE TABLE IF NOT EXISTS public.conversation_members (
  conversation_id UUID NOT NULL REFERENCES public.conversations(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  joined_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  last_read_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY (conversation_id, user_id)
);

CREATE INDEX IF NOT EXISTS conversation_members_user_id_idx
  ON public.conversation_members (user_id);

-- conversation_messages
CREATE TABLE IF NOT EXISTS public.conversation_messages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  conversation_id UUID NOT NULL REFERENCES public.conversations(id) ON DELETE CASCADE,
  sender_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  body TEXT NOT NULL CHECK (length(body) > 0 AND length(body) <= 4000),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS conversation_messages_conversation_created_idx
  ON public.conversation_messages (conversation_id, created_at);

-- pos_sales (external POS webhook data)
CREATE TABLE IF NOT EXISTS public.pos_sales (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  provider TEXT NOT NULL,
  external_id TEXT NOT NULL,
  event TEXT NOT NULL DEFAULT 'sale.created',
  total NUMERIC(10,2) NOT NULL DEFAULT 0,
  items JSONB NOT NULL DEFAULT '[]'::jsonb,
  customer_id TEXT,
  payload JSONB NOT NULL DEFAULT '{}'::jsonb,
  occurred_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (provider, external_id)
);


-- ── Enable RLS on all tables ─────────────────────────────────────────────────

ALTER TABLE public.user_roles               ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.products                 ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.customers                ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.orders                   ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.order_items              ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.discount_definitions     ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.order_discount_events    ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.time_entries             ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.profiles                 ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.employees                ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.employee_payroll_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.pay_periods              ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.payslips                 ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.pos_audit_events         ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.shift_reports            ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.business_settings        ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.strains                  ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.strain_knowledge_entries ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.strain_knowledge_images  ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.assistant_threads        ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.assistant_messages       ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.assistant_action_logs    ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.ai_search_domains        ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_credentials         ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.conversations            ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.conversation_members     ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.conversation_messages    ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.pos_sales                ENABLE ROW LEVEL SECURITY;


-- ── Functions (SECURITY DEFINER) ─────────────────────────────────────────────

CREATE OR REPLACE FUNCTION public.has_role(_user_id UUID, _role app_role)
RETURNS BOOLEAN LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = _user_id AND role = _role)
$$;

CREATE OR REPLACE FUNCTION public.get_user_roles(_user_id UUID)
RETURNS app_role[] LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT COALESCE(array_agg(role), ARRAY[]::app_role[]) FROM public.user_roles WHERE user_id = _user_id
$$;

CREATE OR REPLACE FUNCTION public.short_id_exists(_short_id TEXT)
RETURNS BOOLEAN LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.user_credentials WHERE lower(short_id) = lower(_short_id))
$$;

CREATE OR REPLACE FUNCTION public.is_conversation_member(
  _conversation_id UUID, _user_id UUID
)
RETURNS BOOLEAN LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.conversation_members
    WHERE conversation_id = _conversation_id AND user_id = _user_id
  )
$$;

CREATE OR REPLACE FUNCTION public.handle_new_user_profile()
RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  INSERT INTO public.profiles (id, full_name)
  VALUES (NEW.id, COALESCE(NEW.raw_user_meta_data->>'full_name', NEW.email, 'User'))
  ON CONFLICT (id) DO NOTHING;
  RETURN NEW;
END;
$$;

CREATE OR REPLACE FUNCTION public.handle_new_user_role()
RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE assigned_role public.app_role;
BEGIN
  IF EXISTS (SELECT 1 FROM public.user_roles WHERE role = 'admin') THEN
    assigned_role := 'staff';
  ELSE
    assigned_role := 'admin';
  END IF;
  INSERT INTO public.user_roles (user_id, role) VALUES (NEW.id, assigned_role)
    ON CONFLICT (user_id, role) DO NOTHING;
  RETURN NEW;
END;
$$;

CREATE OR REPLACE FUNCTION public.prevent_last_admin_role_removal()
RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF (TG_OP = 'DELETE' AND OLD.role = 'admin')
    OR (TG_OP = 'UPDATE' AND OLD.role = 'admin' AND NEW.role <> 'admin')
  THEN
    IF NOT EXISTS (
      SELECT 1 FROM public.user_roles WHERE role = 'admin' AND user_id <> OLD.user_id
    ) THEN
      RAISE EXCEPTION 'Cannot remove the last admin role.';
    END IF;
  END IF;
  IF TG_OP = 'DELETE' THEN RETURN OLD; END IF;
  RETURN NEW;
END;
$$;

CREATE OR REPLACE FUNCTION public.decrement_inventory(product_id UUID, qty INTEGER)
RETURNS INTEGER LANGUAGE sql SECURITY DEFINER SET search_path = public AS $$
  WITH updated AS (
    UPDATE public.products
    SET stock = GREATEST(COALESCE(stock, 0) - GREATEST(qty, 0), 0),
        in_stock = GREATEST(COALESCE(stock, 0) - GREATEST(qty, 0), 0) > 0,
        last_synced_at = now(), updated_at = now()
    WHERE id = product_id
    RETURNING 1
  )
  SELECT COUNT(*)::INTEGER FROM updated
$$;

CREATE OR REPLACE FUNCTION public.process_pos_sale(
  _provider TEXT, _external_id TEXT, _total NUMERIC, _items JSONB,
  _customer_id TEXT, _payload JSONB, _occurred_at TIMESTAMPTZ
)
RETURNS BOOLEAN LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  sale_item JSONB; sale_product_id UUID; sale_quantity INTEGER; decrement_count INTEGER;
BEGIN
  INSERT INTO public.pos_sales (
    provider, external_id, event, total, items, customer_id, payload, occurred_at
  ) VALUES (
    _provider, _external_id, 'sale.created',
    COALESCE(_total, 0), COALESCE(_items, '[]'::jsonb),
    _customer_id, COALESCE(_payload, '{}'::jsonb), COALESCE(_occurred_at, now())
  ) ON CONFLICT (provider, external_id) DO NOTHING;

  IF NOT FOUND THEN RETURN FALSE; END IF;

  FOR sale_item IN
    SELECT value FROM jsonb_array_elements(COALESCE(_items, '[]'::jsonb))
  LOOP
    sale_product_id := NULLIF(sale_item->>'product_id', '')::UUID;
    sale_quantity := GREATEST(COALESCE(NULLIF(sale_item->>'quantity', '')::INTEGER, 0), 0);
    SELECT public.decrement_inventory(sale_product_id, sale_quantity) INTO decrement_count;
    IF decrement_count = 0 THEN
      RAISE EXCEPTION 'No product found for POS sale item "%".', sale_item->>'product_id';
    END IF;
  END LOOP;
  RETURN TRUE;
END;
$$;

-- Function permissions
REVOKE EXECUTE ON FUNCTION public.has_role(UUID, public.app_role) FROM PUBLIC, anon;
REVOKE EXECUTE ON FUNCTION public.get_user_roles(UUID) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.has_role(UUID, public.app_role) TO authenticated, service_role;
GRANT EXECUTE ON FUNCTION public.get_user_roles(UUID) TO authenticated, service_role;
GRANT EXECUTE ON FUNCTION public.short_id_exists(TEXT) TO authenticated;
GRANT EXECUTE ON FUNCTION public.is_conversation_member(UUID, UUID) TO authenticated;
REVOKE EXECUTE ON FUNCTION public.decrement_inventory(UUID, INTEGER) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.decrement_inventory(UUID, INTEGER) TO service_role;
REVOKE EXECUTE ON FUNCTION public.process_pos_sale(TEXT, TEXT, NUMERIC, JSONB, TEXT, JSONB, TIMESTAMPTZ) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.process_pos_sale(TEXT, TEXT, NUMERIC, JSONB, TEXT, JSONB, TIMESTAMPTZ) TO service_role;


-- ── Triggers ─────────────────────────────────────────────────────────────────

DROP TRIGGER IF EXISTS on_auth_user_created_assign_role ON auth.users;
CREATE TRIGGER on_auth_user_created_assign_role
  AFTER INSERT ON auth.users FOR EACH ROW
  EXECUTE FUNCTION public.handle_new_user_role();

DROP TRIGGER IF EXISTS on_auth_user_created_profile ON auth.users;
CREATE TRIGGER on_auth_user_created_profile
  AFTER INSERT ON auth.users FOR EACH ROW
  EXECUTE FUNCTION public.handle_new_user_profile();

DROP TRIGGER IF EXISTS prevent_last_admin_role_delete ON public.user_roles;
CREATE TRIGGER prevent_last_admin_role_delete
  BEFORE DELETE ON public.user_roles FOR EACH ROW
  EXECUTE FUNCTION public.prevent_last_admin_role_removal();

DROP TRIGGER IF EXISTS prevent_last_admin_role_update ON public.user_roles;
CREATE TRIGGER prevent_last_admin_role_update
  BEFORE UPDATE OF role ON public.user_roles FOR EACH ROW
  EXECUTE FUNCTION public.prevent_last_admin_role_removal();


-- ── RLS Policies (development mode — fully open for authenticated users) ─────
-- During development, every authenticated user gets full CRUD on all tables.
-- Tighten these for production by replacing with role-based policies.

DO $$
DECLARE
  tbl RECORD;
BEGIN
  FOR tbl IN
    SELECT tablename FROM pg_tables WHERE schemaname = 'public' ORDER BY tablename
  LOOP
    EXECUTE format('DROP POLICY IF EXISTS "Development full access" ON public.%I', tbl.tablename);
    EXECUTE format(
      'CREATE POLICY "Development full access" ON public.%I '
      'FOR ALL TO authenticated USING (true) WITH CHECK (true)',
      tbl.tablename
    );
  END LOOP;
END
$$;

-- ── Storage ──────────────────────────────────────────────────────────────────

INSERT INTO storage.buckets (id, name, public) VALUES
  ('product-images', 'product-images', true),
  ('employee-documents', 'employee-documents', false)
ON CONFLICT (id) DO NOTHING;

CREATE POLICY "Dev full access product images"
  ON storage.objects FOR ALL TO authenticated
  USING (bucket_id = 'product-images') WITH CHECK (bucket_id = 'product-images');

CREATE POLICY "Public read product images"
  ON storage.objects FOR SELECT TO public
  USING (bucket_id = 'product-images');

CREATE POLICY "Dev full access employee documents"
  ON storage.objects FOR ALL TO authenticated
  USING (bucket_id = 'employee-documents') WITH CHECK (bucket_id = 'employee-documents');

CREATE POLICY "Service role full storage access"
  ON storage.objects FOR ALL TO service_role
  USING (true) WITH CHECK (true);

-- ── Health check (self-hosting) ──────────────────────────────────────────────

CREATE OR REPLACE FUNCTION public.selfhost_health_check()
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  result JSONB;
  table_count INTEGER;
  user_count INTEGER;
  has_admin BOOLEAN;
  migration_count INTEGER;
BEGIN
  SELECT COUNT(*) INTO table_count
  FROM pg_tables WHERE schemaname = 'public';

  SELECT COUNT(*) INTO user_count
  FROM auth.users;

  SELECT EXISTS(SELECT 1 FROM public.user_roles WHERE role = 'admin')
  INTO has_admin;

  SELECT COUNT(*) INTO migration_count
  FROM public.applied_migrations;

  result := jsonb_build_object(
    'status', 'ok',
    'timestamp', now(),
    'tables', table_count,
    'users', user_count,
    'has_admin', has_admin,
    'migrations_applied', migration_count,
    'version', '3.0.0'
  );

  RETURN result;
END;
$$;

REVOKE EXECUTE ON FUNCTION public.selfhost_health_check() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.selfhost_health_check() TO authenticated, service_role;
