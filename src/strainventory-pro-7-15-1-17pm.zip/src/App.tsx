import { Suspense, lazy } from "react";
import ProtectedRoute from "@/components/layout/ProtectedRoute";
import Auth from "@/pages/Auth";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, HashRouter, Route, Routes } from "react-router-dom";
import { Loader2 } from "lucide-react";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { ProductDraftProvider } from "@/context/ProductDraftContext";
import { AuthProvider } from "@/context/AuthContext";
import OfflineSyncProvider from "@/components/OfflineSyncProvider";
import ErrorBoundary from "@/components/ErrorBoundary";
import { routerFuture } from "@/lib/routerFuture";
import { shouldUseHashRouter } from "@/lib/runtime";

import AppLayout from "@/components/layout/AppLayout";
const Dashboard = lazy(() => import("@/pages/Dashboard"));
// AIDraftGenerator route removed — generation is now an inline splash on Product Intake.
const ImageFinder = lazy(() => import("@/pages/ImageFinder"));
const CatalogLibrary = lazy(() => import("@/pages/CatalogLibrary"));
const BulkIntake = lazy(() => import("@/pages/BulkIntake"));
const ReviewWorkspace = lazy(() => import("@/pages/ReviewWorkspace"));
const ProductDetail = lazy(() => import("@/pages/ProductDetail"));
const PointOfSale = lazy(() => import("@/pages/PointOfSale"));
const AssistantPage = lazy(() => import("@/pages/Assistant"));
const MessagesPage = lazy(() => import("@/pages/Messages"));
const SettingsPage = lazy(() => import("@/pages/Settings"));
const EmployeeOnboarding = lazy(() => import("@/pages/EmployeeOnboarding"));
const PayrollDashboard = lazy(() => import("@/pages/PayrollDashboard"));
const PayrollRun = lazy(() => import("@/pages/PayrollRun"));
const ProductIntake = lazy(() => import("@/pages/ProductIntake"));
const ShiftClose = lazy(() => import("@/pages/ShiftClose"));
const VinnyPreview = lazy(() => import("@/pages/VinnyPreview"));
const Unsubscribe = lazy(() => import("@/pages/Unsubscribe"));
const Schedule = lazy(() => import("@/pages/Schedule"));
const LabelMaker = lazy(() => import("@/pages/LabelMaker"));
const PrivacyPolicy = lazy(() => import("@/pages/PrivacyPolicy"));
const TermsOfUse = lazy(() => import("@/pages/TermsOfUse"));
const GlobalCatalogGuide = lazy(() => import("@/pages/GlobalCatalogGuide"));
const NotFound = lazy(() => import("@/pages/NotFound"));

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 60_000,
      gcTime: 5 * 60_000,
      refetchOnWindowFocus: false,
      retry: 1,
    },
  },
});

const AppFallback = () => (
  <div className="flex min-h-screen items-center justify-center bg-background text-foreground">
    <div className="flex items-center gap-3 rounded-xl border border-border bg-card px-4 py-3 shadow-soft">
      <Loader2 className="h-4 w-4 animate-spin text-accent" />
      <span className="text-sm text-muted-foreground">Loading workspace…</span>
    </div>
  </div>
);

const Router = shouldUseHashRouter() ? HashRouter : BrowserRouter;

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <AuthProvider>
        <OfflineSyncProvider>
          <ProductDraftProvider>
            <Toaster />
            <Sonner />
            <Router future={routerFuture}>
              <ErrorBoundary>
                <Suspense fallback={<AppFallback />}>
                  <Routes>
                    <Route path="/auth" element={<Auth />} />
                    <Route path="/unsubscribe" element={<Unsubscribe />} />
                    <Route path="/privacy" element={<PrivacyPolicy />} />
                    <Route path="/terms" element={<TermsOfUse />} />
                    <Route path="/guides/global-catalog" element={<GlobalCatalogGuide />} />
                    <Route
                      path="/vinny-preview"
                      element={(
                        <ProtectedRoute>
                          <VinnyPreview />
                        </ProtectedRoute>
                      )}
                    />
                    <Route
                      element={(
                        <ProtectedRoute>
                          <AppLayout />
                        </ProtectedRoute>
                      )}
                    >
                      <Route path="/" element={<Dashboard />} />
                      <Route path="/ai-draft" element={<ProductIntake />} />
                      <Route path="/image-finder" element={<ImageFinder />} />
                      <Route path="/catalog" element={<CatalogLibrary />} />
                      <Route path="/bulk-intake" element={<BulkIntake />} />
                      <Route path="/review" element={<ReviewWorkspace />} />
                      <Route path="/catalog/:id" element={<ProductDetail />} />
                      <Route path="/assistant" element={<AssistantPage />} />
                      <Route path="/messages" element={<MessagesPage />} />
                      <Route path="/pos" element={<PointOfSale />} />
                      <Route path="/shift-close" element={<ShiftClose />} />
                      <Route path="/schedule" element={<Schedule />} />
                      <Route path="/label-maker" element={<LabelMaker />} />
                      <Route path="/settings" element={<SettingsPage />} />
                      <Route path="/onboarding" element={<EmployeeOnboarding />} />
                      <Route path="/payroll" element={<PayrollDashboard />} />
                      <Route path="/payroll/run" element={<PayrollRun />} />
                    </Route>
                    <Route path="*" element={<NotFound />} />
                  </Routes>
                </Suspense>
              </ErrorBoundary>
            </Router>
          </ProductDraftProvider>
        </OfflineSyncProvider>
      </AuthProvider>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
