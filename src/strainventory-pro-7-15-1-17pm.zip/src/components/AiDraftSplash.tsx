import { motion, AnimatePresence } from "framer-motion";
import { Sparkles } from "lucide-react";
import { Progress } from "@/components/ui/progress";
import { StrainVinnyAvatar } from "@/components/StrainVinnyAvatar";

interface AiDraftSplashProps {
  open: boolean;
  progress: number;
  productName?: string;
}

const stageLabel = (progress: number) => {
  if (progress < 30) return "Matching brand records…";
  if (progress < 60) return "Cross-referencing strain data…";
  if (progress < 85) return "Composing descriptions & profiles…";
  return "Finalizing confidence scores…";
};

const AiDraftSplash = ({ open, progress, productName }: AiDraftSplashProps) => {
  return (
    <AnimatePresence>
      {open && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.25 }}
          className="fixed inset-0 z-[80] flex items-center justify-center bg-background/80 backdrop-blur-sm"
          role="dialog"
          aria-live="polite"
          aria-label="Generating AI draft"
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.96, y: 8 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.97 }}
            transition={{ duration: 0.3 }}
            className="w-[min(420px,90vw)] rounded-2xl border border-border bg-card p-8 shadow-soft text-center space-y-5"
          >
            <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-2xl bg-muted">
              <StrainVinnyAvatar className="h-10 w-10" />
            </div>
            <div className="space-y-1.5">
              <div className="flex items-center justify-center gap-1.5 text-[11px] uppercase tracking-widest text-muted-foreground">
                <Sparkles className="h-3 w-3" />
                Strain Vinny
              </div>
              <h2 className="text-display text-xl font-semibold text-foreground">
                Generating AI draft
              </h2>
              {productName && (
                <p className="text-sm text-muted-foreground truncate">{productName}</p>
              )}
            </div>
            <div className="space-y-2">
              <Progress value={Math.min(progress, 100)} className="h-2" />
              <div className="flex justify-between text-[11px] text-muted-foreground">
                <span className="italic">{stageLabel(progress)}</span>
                <span className="tabular-nums">{Math.min(Math.round(progress), 100)}%</span>
              </div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default AiDraftSplash;
