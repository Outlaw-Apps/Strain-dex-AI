// src/components/CyberButton.tsx
import React from 'react';

interface CyberButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  children: React.ReactNode;
  variant?: 'cyan' | 'pink';
}

export function CyberButton({ children, variant = 'cyan', ...props }: CyberButtonProps) {
  const isCyan = variant === 'cyan';
  
  // Tailwind classes dynamically applied based on the variant prop
  const baseClasses = "relative px-6 py-2 font-mono font-bold uppercase tracking-widest transition-all duration-300";
  const colorClasses = isCyan 
    ? "bg-transparent text-cyber-cyan border-2 border-cyber-cyan hover:bg-cyber-cyan hover:text-void hover:shadow-neon-cyan"
    : "bg-transparent text-cyber-pink border-2 border-cyber-pink hover:bg-cyber-pink hover:text-void hover:shadow-neon-pink";
  
  // The magic clip-path that chops the top-right and bottom-left corners
  const clipPathClass = "[clip-path:polygon(10px_0,100%_0,100%_calc(100%-10px),calc(100%-10px)_100%,0_100%,0_10px)]";

  return (
    <button 
      className={`${baseClasses} ${colorClasses} ${clipPathClass}`}
      {...props}
    >
      {children}
    </button>
  );
}