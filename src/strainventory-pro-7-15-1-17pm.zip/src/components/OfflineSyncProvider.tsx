import { useEffect, useRef, useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { WifiOff } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { flushPendingProductUpserts } from "@/lib/offlineProductQueue";

const OfflineSyncProvider = ({ children }: { children: React.ReactNode }) => {
  const queryClient = useQueryClient();
  const syncing = useRef(false);
  const [isOffline, setIsOffline] = useState(!navigator.onLine);

  useEffect(() => {
    const syncPending = async () => {
      if (syncing.current) {
        return;
      }

      syncing.current = true;
      try {
        const { flushed } = await flushPendingProductUpserts(supabase);
        if (flushed > 0) {
          queryClient.invalidateQueries({ queryKey: ["products"] });
          toast.success(`${flushed} queued product change${flushed === 1 ? "" : "s"} synced.`);
        }
      } finally {
        syncing.current = false;
      }
    };

    const handleOnline = () => {
      setIsOffline(false);
      toast.success("You're back online.");
      syncPending();
    };

    const handleOffline = () => {
      setIsOffline(true);
      toast.warning("You're offline. Changes will sync when you reconnect.");
    };

    syncPending();
    window.addEventListener("online", handleOnline);
    window.addEventListener("offline", handleOffline);
    return () => {
      window.removeEventListener("online", handleOnline);
      window.removeEventListener("offline", handleOffline);
    };
  }, [queryClient]);

  return (
    <>
      {isOffline && (
        <div className="fixed bottom-0 left-0 right-0 z-50 flex items-center justify-center gap-2 bg-warning/90 px-4 py-2 text-sm font-medium text-warning-foreground backdrop-blur-sm">
          <WifiOff className="h-4 w-4 shrink-0" />
          <span>You&apos;re offline — changes will sync automatically when you reconnect.</span>
        </div>
      )}
      {children}
    </>
  );
};

export default OfflineSyncProvider;
