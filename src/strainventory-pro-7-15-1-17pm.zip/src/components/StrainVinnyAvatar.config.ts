import {
  VINNY_AVATAR_OPTION,
} from "@/components/StrainVinnyAvatar.constants";
import type { VinnyAvatarOption } from "@/components/StrainVinnyAvatar";
import {
  VinnyOption1,
  VinnyOption2,
  VinnyOption3,
  VinnyOption4,
  VinnyOption5,
  VinnyOption6,
  VinnyOption7,
} from "@/components/StrainVinnyAvatar";

type AvatarProps = Readonly<{
  className?: string;
  size?: number | string;
  title?: string;
}>;

export const VINNY_OPTIONS: ReadonlyArray<{
  id: VinnyAvatarOption;
  name: string;
  tagline: string;
  Component: (props: AvatarProps) => JSX.Element;
}> = [
  {
    id: 7,
    name: "Strain Vinny",
    tagline: "The real-deal avatar",
    Component: VinnyOption7,
  },
  {
    id: 6,
    name: "Concierge Vinny",
    tagline: "Friendly, professional male concierge",
    Component: VinnyOption6,
  },
  {
    id: 1,
    name: "Crystalline Trichome",
    tagline: "Frosty, premium, diamond-cut",
    Component: VinnyOption1,
  },
  {
    id: 2,
    name: "Neural Leaf",
    tagline: "AI-meets-flower, wired up",
    Component: VinnyOption2,
  },
  {
    id: 3,
    name: "Retro Neon Bud",
    tagline: "Synthwave dispensary energy",
    Component: VinnyOption3,
  },
  {
    id: 4,
    name: "Cyberpunk Eye",
    tagline: "All-seeing strain oracle",
    Component: VinnyOption4,
  },
  {
    id: 5,
    name: "Cosmic Plant Spirit",
    tagline: "Galaxy-grown, cosmic vibes",
    Component: VinnyOption5,
  },
] as const;
