import type { VinnyAvatarOption } from "@/components/StrainVinnyAvatar";

// Single source-of-truth for which avatar variant ships in the app.
// Switch to a new design by changing this one line.
export const VINNY_AVATAR_OPTION: VinnyAvatarOption = 7;
