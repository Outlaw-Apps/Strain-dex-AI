import vinnyAsset from "@/assets/vinny-headshot.webp.asset.json";
import { VINNY_AVATAR_OPTION } from "@/components/StrainVinnyAvatar.constants";
import { cn } from "@/lib/utils";

export type VinnyAvatarOption = 1 | 2 | 3 | 4 | 5 | 6 | 7;

type AvatarProps = Readonly<{
  className?: string;
  size?: number | string;
  title?: string;
}>;

type StrainVinnyAvatarProps = AvatarProps &
  Readonly<{
    option?: VinnyAvatarOption;
  }>;

const baseSvgProps = (className?: string, size?: number | string, title?: string) => ({
  viewBox: "0 0 48 48",
  className: cn("vinny-avatar", className),
  width: size,
  height: size,
  fill: "none" as const,
  role: title ? "img" : undefined,
  "aria-hidden": title ? undefined : true,
  "aria-label": title,
});

// Option 1 — Crystalline Trichome
// A frosty diamond-shaped trichome head with glowing eyes and a chin droplet.
export function VinnyOption1({ className, size = 48, title }: AvatarProps) {
  return (
    <svg {...baseSvgProps(className, size, title)} xmlns="http://www.w3.org/2000/svg">
      <defs>
        <linearGradient id="vinny1-body" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#E0FFFA" />
          <stop offset="55%" stopColor="#7FE9D4" />
          <stop offset="100%" stopColor="#1F8A7A" />
        </linearGradient>
        <radialGradient id="vinny1-glow" cx="50%" cy="40%" r="55%">
          <stop offset="0%" stopColor="#FFFFFF" stopOpacity="0.85" />
          <stop offset="100%" stopColor="#FFFFFF" stopOpacity="0" />
        </radialGradient>
      </defs>
      <polygon points="24,3 42,20 24,45 6,20" fill="url(#vinny1-body)" stroke="#0E3B36" strokeWidth="1.5" strokeLinejoin="round" />
      <polygon points="24,3 36,16 24,28 12,16" fill="url(#vinny1-glow)" />
      <circle cx="18" cy="20" r="2.4" fill="#0B1F1B" />
      <circle cx="30" cy="20" r="2.4" fill="#0B1F1B" />
      <circle cx="17.4" cy="19.4" r="0.7" fill="#FFFFFF" />
      <circle cx="29.4" cy="19.4" r="0.7" fill="#FFFFFF" />
      <path d="M19 26.5 Q24 30 29 26.5" stroke="#0B1F1B" strokeWidth="1.5" strokeLinecap="round" fill="none" />
      <circle cx="24" cy="38" r="2" fill="#9FF3E2" stroke="#0E3B36" strokeWidth="1" />
    </svg>
  );
}

// Option 2 — Neural Leaf
// A cannabis leaf silhouette wired with neural-network nodes.
export function VinnyOption2({ className, size = 48, title }: AvatarProps) {
  return (
    <svg {...baseSvgProps(className, size, title)} xmlns="http://www.w3.org/2000/svg">
      <defs>
        <linearGradient id="vinny2-leaf" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#86EFAC" />
          <stop offset="100%" stopColor="#15803D" />
        </linearGradient>
      </defs>
      <circle cx="24" cy="24" r="22" fill="#052E2B" />
      <path
        d="M24 6 L26 14 L33 10 L29 18 L40 16 L31 22 L42 26 L31 26 L36 34 L28 30 L26 40 L24 32 L22 40 L20 30 L12 34 L17 26 L6 26 L17 22 L8 16 L19 18 L15 10 L22 14 Z"
        fill="url(#vinny2-leaf)"
        stroke="#022C22"
        strokeWidth="0.8"
        strokeLinejoin="round"
      />
      <g stroke="#FDE68A" strokeWidth="0.8" opacity="0.85">
        <line x1="24" y1="14" x2="20" y2="22" />
        <line x1="24" y1="14" x2="28" y2="22" />
        <line x1="20" y1="22" x2="24" y2="30" />
        <line x1="28" y1="22" x2="24" y2="30" />
        <line x1="20" y1="22" x2="14" y2="26" />
        <line x1="28" y1="22" x2="34" y2="26" />
      </g>
      <g fill="#FACC15">
        <circle cx="24" cy="14" r="1.5" />
        <circle cx="20" cy="22" r="1.5" />
        <circle cx="28" cy="22" r="1.5" />
        <circle cx="24" cy="30" r="1.5" />
        <circle cx="14" cy="26" r="1.2" />
        <circle cx="34" cy="26" r="1.2" />
      </g>
    </svg>
  );
}

// Option 3 — Retro Neon Bud
// 80s neon-outline cannabis bud with a glowing magenta/cyan vibe.
export function VinnyOption3({ className, size = 48, title }: AvatarProps) {
  return (
    <svg {...baseSvgProps(className, size, title)} xmlns="http://www.w3.org/2000/svg">
      <defs>
        <radialGradient id="vinny3-bg" cx="50%" cy="100%" r="120%">
          <stop offset="0%" stopColor="#3B0764" />
          <stop offset="100%" stopColor="#0B0014" />
        </radialGradient>
        <filter id="vinny3-blur" x="-30%" y="-30%" width="160%" height="160%">
          <feGaussianBlur stdDeviation="1.4" />
        </filter>
      </defs>
      <rect x="0" y="0" width="48" height="48" rx="10" fill="url(#vinny3-bg)" />
      <g stroke="#22D3EE" strokeWidth="0.6" opacity="0.6">
        <line x1="0" y1="38" x2="48" y2="38" />
        <line x1="0" y1="42" x2="48" y2="42" />
        <line x1="0" y1="46" x2="48" y2="46" />
      </g>
      <g filter="url(#vinny3-blur)" opacity="0.7">
        <ellipse cx="24" cy="24" rx="11" ry="14" fill="#F472B6" />
      </g>
      <g stroke="#F0ABFC" strokeWidth="1.6" fill="none" strokeLinecap="round" strokeLinejoin="round">
        <path d="M24 8 C16 14 14 22 18 30 C20 34 22 36 24 38 C26 36 28 34 30 30 C34 22 32 14 24 8 Z" />
        <path d="M24 12 C20 18 19 24 22 30" />
        <path d="M24 12 C28 18 29 24 26 30" />
        <path d="M18 22 L24 24 L30 22" />
        <path d="M19 28 L24 30 L29 28" />
      </g>
      <circle cx="20" cy="20" r="1.2" fill="#FDE68A" />
      <circle cx="28" cy="22" r="1" fill="#FDE68A" />
      <circle cx="24" cy="16" r="0.9" fill="#FDE68A" />
    </svg>
  );
}

// Option 4 — Cyberpunk Eye
// A glowing eye with a cannabis-leaf iris.
export function VinnyOption4({ className, size = 48, title }: AvatarProps) {
  return (
    <svg {...baseSvgProps(className, size, title)} xmlns="http://www.w3.org/2000/svg">
      <defs>
        <radialGradient id="vinny4-iris" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stopColor="#A7F3D0" />
          <stop offset="60%" stopColor="#10B981" />
          <stop offset="100%" stopColor="#064E3B" />
        </radialGradient>
        <linearGradient id="vinny4-frame" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#1F2937" />
          <stop offset="100%" stopColor="#0F172A" />
        </linearGradient>
      </defs>
      <circle cx="24" cy="24" r="22" fill="url(#vinny4-frame)" />
      <path
        d="M4 24 C12 12 36 12 44 24 C36 36 12 36 4 24 Z"
        fill="#020617"
        stroke="#22D3EE"
        strokeWidth="1.4"
      />
      <circle cx="24" cy="24" r="9" fill="url(#vinny4-iris)" stroke="#022C22" strokeWidth="1" />
      <g stroke="#022C22" strokeWidth="0.8" opacity="0.85">
        <path d="M24 16 L24 32" />
        <path d="M16 24 L32 24" />
        <path d="M18 18 L30 30" />
        <path d="M30 18 L18 30" />
      </g>
      <circle cx="24" cy="24" r="3.4" fill="#020617" />
      <circle cx="22.5" cy="22.5" r="1.1" fill="#F0F9FF" />
      <g stroke="#22D3EE" strokeWidth="0.8" strokeLinecap="round" opacity="0.9">
        <line x1="6" y1="14" x2="10" y2="14" />
        <line x1="38" y1="14" x2="42" y2="14" />
        <line x1="6" y1="34" x2="10" y2="34" />
        <line x1="38" y1="34" x2="42" y2="34" />
      </g>
    </svg>
  );
}

// Option 5 — Cosmic Plant Spirit
// A galaxy-filled cannabis silhouette with stars.
export function VinnyOption5({ className, size = 48, title }: AvatarProps) {
  return (
    <svg {...baseSvgProps(className, size, title)} xmlns="http://www.w3.org/2000/svg">
      <defs>
        <radialGradient id="vinny5-cosmos" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stopColor="#FDE68A" />
          <stop offset="35%" stopColor="#A855F7" />
          <stop offset="70%" stopColor="#1E1B4B" />
          <stop offset="100%" stopColor="#020617" />
        </radialGradient>
        <clipPath id="vinny5-clip">
          <path
            d="M24 4 L26 13 L33 9 L30 17 L40 16 L32 22 L42 26 L31 26 L35 33 L28 29 L26 40 L24 32 L22 40 L20 29 L13 33 L17 26 L6 26 L16 22 L8 16 L18 17 L15 9 L22 13 Z"
          />
        </clipPath>
      </defs>
      <circle cx="24" cy="24" r="22" fill="#0B0220" />
      <g clipPath="url(#vinny5-clip)">
        <rect x="0" y="0" width="48" height="48" fill="url(#vinny5-cosmos)" />
        <g fill="#FFFFFF">
          <circle cx="14" cy="14" r="0.6" />
          <circle cx="30" cy="10" r="0.5" />
          <circle cx="34" cy="20" r="0.7" />
          <circle cx="20" cy="28" r="0.5" />
          <circle cx="28" cy="32" r="0.6" />
          <circle cx="12" cy="24" r="0.5" />
          <circle cx="36" cy="30" r="0.5" />
        </g>
      </g>
      <path
        d="M24 4 L26 13 L33 9 L30 17 L40 16 L32 22 L42 26 L31 26 L35 33 L28 29 L26 40 L24 32 L22 40 L20 29 L13 33 L17 26 L6 26 L16 22 L8 16 L18 17 L15 9 L22 13 Z"
        fill="none"
        stroke="#F0ABFC"
        strokeWidth="0.9"
        strokeLinejoin="round"
      />
      <g stroke="#FDE68A" strokeWidth="0.8" strokeLinecap="round">
        <line x1="6" y1="6" x2="6" y2="9" />
        <line x1="4.5" y1="7.5" x2="7.5" y2="7.5" />
        <line x1="42" y1="38" x2="42" y2="41" />
        <line x1="40.5" y1="39.5" x2="43.5" y2="39.5" />
      </g>
    </svg>
  );
}

// Option 6 — Concierge Vinny (default)
// A friendly, professional male concierge: warm smile, refined hair, suit
// collar with a cannabis-leaf lapel pin and a subtle headset cue.
export function VinnyOption6({ className, size = 48, title }: AvatarProps) {
  return (
    <svg {...baseSvgProps(className, size, title)} xmlns="http://www.w3.org/2000/svg">
      <defs>
        <linearGradient id="vinny6-bg" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#0F2A24" />
          <stop offset="100%" stopColor="#1F8A6E" />
        </linearGradient>
        <linearGradient id="vinny6-skin" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#F4D2B0" />
          <stop offset="100%" stopColor="#D9A878" />
        </linearGradient>
        <linearGradient id="vinny6-suit" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#111827" />
          <stop offset="100%" stopColor="#0B1220" />
        </linearGradient>
      </defs>
      {/* Circular background */}
      <circle cx="24" cy="24" r="23" fill="url(#vinny6-bg)" />
      <circle cx="24" cy="24" r="23" fill="none" stroke="#C9A84C" strokeWidth="1" opacity="0.55" />
      {/* Suit / shoulders */}
      <path
        d="M6 46 C8 36 16 33 24 33 C32 33 40 36 42 46 Z"
        fill="url(#vinny6-suit)"
      />
      {/* Shirt + collar */}
      <path d="M20 33 L24 40 L28 33 L28 46 L20 46 Z" fill="#F8FAFC" />
      <path d="M20 33 L24 38 L28 33 L26 42 L24 40 L22 42 Z" fill="url(#vinny6-suit)" />
      {/* Lapel cannabis-leaf pin (gold) */}
      <g transform="translate(19 36)">
        <circle r="1.6" fill="#C9A84C" />
        <path d="M0 -1.2 L0.6 0 L0 1.2 L-0.6 0 Z" fill="#0F2A24" />
      </g>
      {/* Neck */}
      <rect x="21" y="28" width="6" height="6" rx="1.5" fill="url(#vinny6-skin)" />
      {/* Head */}
      <ellipse cx="24" cy="21" rx="8.5" ry="9.5" fill="url(#vinny6-skin)" />
      {/* Hair — modern side-part */}
      <path
        d="M15.5 19 C15.5 12 20 9 24 9 C29 9 33 12 32.6 19 C30 16 27 15 24 16 C21.5 16.8 19 18 17.5 21 C16.5 20.4 15.8 19.8 15.5 19 Z"
        fill="#1F2937"
      />
      {/* Ears */}
      <ellipse cx="15.6" cy="22" rx="1.2" ry="1.8" fill="url(#vinny6-skin)" />
      <ellipse cx="32.4" cy="22" rx="1.2" ry="1.8" fill="url(#vinny6-skin)" />
      {/* Eyes — friendly */}
      <g fill="#0B1F1B">
        <circle cx="20.5" cy="21.2" r="1.1" />
        <circle cx="27.5" cy="21.2" r="1.1" />
      </g>
      <g fill="#FFFFFF">
        <circle cx="20.2" cy="20.9" r="0.35" />
        <circle cx="27.2" cy="20.9" r="0.35" />
      </g>
      {/* Brows */}
      <path d="M18.6 18.6 Q20.5 17.8 22.4 18.6" stroke="#1F2937" strokeWidth="0.9" strokeLinecap="round" fill="none" />
      <path d="M25.6 18.6 Q27.5 17.8 29.4 18.6" stroke="#1F2937" strokeWidth="0.9" strokeLinecap="round" fill="none" />
      {/* Warm smile */}
      <path d="M20.5 25.4 Q24 27.6 27.5 25.4" stroke="#7A2E18" strokeWidth="1.2" strokeLinecap="round" fill="none" />
      {/* Subtle cheek warmth */}
      <circle cx="18.8" cy="24.2" r="1" fill="#E89A78" opacity="0.45" />
      <circle cx="29.2" cy="24.2" r="1" fill="#E89A78" opacity="0.45" />
    </svg>
  );
}

// Option 7 — Custom Photo Avatar
// The uploaded real-world avatar image for Strain Vinny.
export function VinnyOption7({ className, size = 48, title }: AvatarProps) {
  const px = typeof size === "number" ? size : 48;
  return (
    <img
      src={vinnyAsset.url}
      alt={title || "Strain Vinny"}
      className={cn("vinny-avatar rounded-full object-cover", className)}
      width={px}
      height={px}
      style={{ width: px, height: px }}
    />
  );
}

const VINNY_BY_OPTION: Record<VinnyAvatarOption, (props: AvatarProps) => JSX.Element> = {
  1: VinnyOption1,
  2: VinnyOption2,
  3: VinnyOption3,
  4: VinnyOption4,
  5: VinnyOption5,
  6: VinnyOption6,
  7: VinnyOption7,
};

export function StrainVinnyAvatar({
  option = VINNY_AVATAR_OPTION,
  ...props
}: StrainVinnyAvatarProps) {
  const Avatar = VINNY_BY_OPTION[option] ?? VinnyOption1;
  return <Avatar {...props} />;
}

export default StrainVinnyAvatar;
