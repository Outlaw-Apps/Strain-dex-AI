import { Check } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { cn } from "@/lib/utils";
import { useProductDraft } from "@/context/ProductDraftContext";

const steps = [
  { key: "intake", label: "Intake", path: "/product-intake" },
  { key: "drafted", label: "Draft", path: "/ai-draft" },
  { key: "images_selected", label: "Images", path: "/image-finder" },
  { key: "reviewed", label: "Review", path: "/review" },
  { key: "published", label: "Published", path: null },
] as const;

const statusOrder: Record<string, number> = {
  intake: 0,
  drafted: 1,
  images_selected: 2,
  reviewed: 3,
  published: 4,
};

interface WorkflowStepperProps {
  currentStep: "intake" | "drafted" | "images_selected" | "reviewed" | "published";
}

const WorkflowStepper = ({ currentStep }: WorkflowStepperProps) => {
  const navigate = useNavigate();
  const { product } = useProductDraft();
  const completedIndex = statusOrder[product.status] ?? 0;
  const activeIndex = statusOrder[currentStep] ?? 0;

  return (
    <div className="flex items-center gap-1 mb-8">
      {steps.map((step, i) => {
        const isCompleted = completedIndex > i;
        const isActive = activeIndex === i;
        const isClickable = isCompleted && step.path && !isActive;

        return (
          <div key={step.key} className="flex items-center">
            <button
              type="button"
              disabled={!isClickable}
              onClick={() => isClickable && step.path && navigate(step.path)}
              className={cn("flex items-center gap-2", isClickable && "cursor-pointer group")}
            >
              <div
                className={cn(
                  "flex h-7 w-7 items-center justify-center rounded-full text-xs font-semibold transition-colors",
                  isCompleted
                    ? "bg-emerald text-emerald-foreground"
                    : isActive
                      ? "bg-accent text-accent-foreground"
                      : "bg-muted text-muted-foreground"
                )}
              >
                {isCompleted ? <Check className="h-3.5 w-3.5" /> : i + 1}
              </div>
              <span
                className={cn(
                  "text-xs font-medium hidden sm:inline transition-colors",
                  isActive ? "text-foreground" : isCompleted ? "text-emerald group-hover:text-emerald/70" : "text-muted-foreground"
                )}
              >
                {step.label}
              </span>
            </button>
            {i < steps.length - 1 && (
              <div
                className={cn(
                  "h-px w-6 lg:w-10 mx-2",
                  completedIndex > i ? "bg-emerald" : "bg-border"
                )}
              />
            )}
          </div>
        );
      })}
    </div>
  );
};

export default WorkflowStepper;
