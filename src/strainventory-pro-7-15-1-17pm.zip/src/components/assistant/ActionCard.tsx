import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { Play, ShieldAlert, ExternalLink, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { useAuth } from "@/context/AuthContext";
import { useUserRoles } from "@/hooks/useUserRoles";
import { useToolRegistry } from "@/hooks/useToolRegistry";
import { canRunTool } from "@/lib/copilot/toolRegistry";
import {
  executeTool,
  recordAction,
  recordNavigation,
  requestApproval,
  updateActionStatus,
  logAudit,
} from "@/lib/copilot/orchestrator";
import type { AssistantActionEnvelope } from "@/types/assistant";

interface ActionCardProps {
  envelope: AssistantActionEnvelope;
  threadId?: string | null;
  sessionId?: string | null;
  routeContext?: string | null;
}

/**
 * Renders one Vinny-proposed action as a card, gated by tool registry roles
 * and approval requirements. Extends (not replaces) the existing envelope shape.
 */
export default function ActionCard({
  envelope,
  threadId,
  sessionId,
  routeContext,
}: ActionCardProps) {
  const { user } = useAuth();
  const { roles } = useUserRoles();
  const { data: registry = [] } = useToolRegistry();
  const navigate = useNavigate();
  const [running, setRunning] = useState(false);

  const payload = (envelope.execution_payload ?? {}) as Record<string, unknown>;
  const toolName = String(payload.tool ?? envelope.intent);
  const tool = registry.find((t) => t.name === toolName);
  const routeHint = typeof payload.route === "string" ? payload.route : null;

  const allowed = tool ? canRunTool(tool, roles) : true;
  const needsApproval = tool?.requires_approval ?? envelope.requires_confirmation;

  async function handleRun(approvedOverride = false) {
    if (!user) {
      toast.error("Sign in to run copilot actions.");
      return;
    }
    setRunning(true);
    const started = new Date().toISOString();
    const action = await recordAction({
      userId: user.id,
      toolName,
      summary: envelope.summary,
      input: payload as never,
      sessionId: sessionId ?? null,
      threadId: threadId ?? null,
      routeContext: routeContext ?? null,
      status: "running",
    });
    if (!action) {
      setRunning(false);
      return;
    }

    if (needsApproval && !approvedOverride) {
      await requestApproval({ actionId: action.id, requestedBy: user.id, reason: envelope.summary });
      toast.info("Sent for approval.");
      setRunning(false);
      return;
    }

    try {
      const output = tool
        ? await executeTool(tool, { ...payload, created_by: user.id })
        : { skipped: true, reason: "Unknown tool" };
      await updateActionStatus(action.id, {
        status: "completed",
        output: output as never,
        started_at: started,
        finished_at: new Date().toISOString(),
      });
      await logAudit({
        actorId: user.id,
        action: `copilot.${toolName}`,
        targetType: "copilot_action",
        targetId: action.id,
        after: output as never,
      });
      toast.success(`${toolName} completed`);
    } catch (err) {
      const message = err instanceof Error ? err.message : String(err);
      await updateActionStatus(action.id, {
        status: "failed",
        error: message,
        finished_at: new Date().toISOString(),
      });
      toast.error(`${toolName} failed: ${message}`);
    } finally {
      setRunning(false);
    }
  }

  async function handleOpenPage() {
    if (!routeHint || !user) return;
    await recordNavigation({
      userId: user.id,
      route: routeHint,
      mode: "real",
      sessionId: sessionId ?? null,
    });
    navigate(routeHint);
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 4 }}
      animate={{ opacity: 1, y: 0 }}
      className="rounded-lg border border-accent/40 bg-gradient-to-br from-card to-card/50 p-3 shadow-sm"
    >
      <div className="mb-2 flex items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <span className="text-sm font-semibold">{toolName}</span>
          {tool && <Badge variant="outline" className="text-[10px]">Phase {tool.phase}</Badge>}
        </div>
        {needsApproval && (
          <Badge variant="outline" className="gap-1 text-amber-500 text-[10px]">
            <ShieldAlert className="h-3 w-3" /> Approval required
          </Badge>
        )}
      </div>
      <p className="mb-3 text-sm text-muted-foreground">{envelope.summary}</p>
      <div className="flex flex-wrap gap-2">
        {routeHint && (
          <Button size="sm" variant="outline" onClick={handleOpenPage}>
            <ExternalLink className="mr-1 h-3.5 w-3.5" /> Open page
          </Button>
        )}
        {allowed ? (
          <Button size="sm" disabled={running} onClick={() => handleRun(false)}>
            {running ? (
              <Loader2 className="mr-1 h-3.5 w-3.5 animate-spin" />
            ) : (
              <Play className="mr-1 h-3.5 w-3.5" />
            )}
            {needsApproval ? "Send for approval" : "Run"}
          </Button>
        ) : (
          <span className="text-xs text-muted-foreground">Your role can't run this tool.</span>
        )}
      </div>
    </motion.div>
  );
}
