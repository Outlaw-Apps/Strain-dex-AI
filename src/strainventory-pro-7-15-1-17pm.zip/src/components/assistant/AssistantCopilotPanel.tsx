import { useEffect, useMemo, useRef, useState, type KeyboardEvent } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { Check, Loader2, MapPin, Send, ShieldCheck, Sparkles, UserRound, Wand2 } from "lucide-react";
import { toast } from "sonner";
import { motion } from "framer-motion";
import StrainVinnyAvatar from "@/components/StrainVinnyAvatar";
import {
  NEW_ASSISTANT_THREAD_VALUE,
  createWelcomeAssistantMessage,
  mapStoredAssistantMessages,
  toAssistantThreadOption,
  type AssistantThreadOption,
} from "@/lib/assistantHistory";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/context/AuthContext";
import { EDGE_FUNCTIONS, ENV } from "@/lib/constants";
import { useUserRoles } from "@/hooks/useUserRoles";
import { useProductDraft, type GeneratedDraft } from "@/context/ProductDraftContext";
import { buildIntakeAiSuggestionsFromDraft } from "@/lib/aiDraftTools";
import { resolveAssistantPageContext } from "@/lib/assistantContext";
import { describeAssistantError } from "@/lib/assistantErrors";
import type {
  AssistantActionEnvelope,
  AssistantAudienceRole,
  AssistantChatResponse,
  AssistantMessage,
  AssistantMessageRecord,
  AssistantThreadRecord,
} from "@/types/assistant";
import WorkflowTimeline from "@/components/assistant/WorkflowTimeline";
import SessionContextChip from "@/components/assistant/SessionContextChip";
import { useCopilotSession } from "@/hooks/useCopilotSession";
import { useCopilotActions } from "@/hooks/useCopilotActions";

interface AssistantCopilotPanelProps {
  embedded?: boolean;
}

const ROLE_OPTIONS: Array<{ value: AssistantAudienceRole; label: string }> = [
  { value: "employee", label: "Employee" },
  { value: "vendor", label: "Vendor" },
  { value: "management", label: "Management" },
];

function roleFromAppRoles(roles: string[]): AssistantAudienceRole {
  if (roles.includes("admin") || roles.includes("reviewer")) return "management";
  return "employee";
}

function readObject(value: unknown): Record<string, unknown> | null {
  return value && typeof value === "object" && !Array.isArray(value)
    ? (value as Record<string, unknown>)
    : null;
}

function toStringArray(value: unknown): string[] {
  return Array.isArray(value) ? value.map((item) => String(item)) : [];
}

function mergeDistinctLines(values: string[]) {
  const lines = new Map<string, string>();

  for (const value of values) {
    for (const line of value.split(/\r?\n/g)) {
      const cleaned = line.trim();
      if (!cleaned) continue;
      const key = cleaned.toLowerCase();
      if (!lines.has(key)) {
        lines.set(key, cleaned);
      }
    }
  }

  return Array.from(lines.values()).join("\n");
}

export default function AssistantCopilotPanel({ embedded = false }: AssistantCopilotPanelProps) {
  const location = useLocation();
  const navigate = useNavigate();
  const { user, session } = useAuth();
  const { roles } = useUserRoles();
  const { product, setIntake, setDraft } = useProductDraft();

  const defaultRole = useMemo(() => roleFromAppRoles(roles), [roles]);
  const [audienceRole, setAudienceRole] = useState<AssistantAudienceRole>(defaultRole);
  const [threads, setThreads] = useState<AssistantThreadOption[]>([]);
  const [threadId, setThreadId] = useState<string | undefined>(undefined);
  const [input, setInput] = useState("");
  const [sending, setSending] = useState(false);
  const [loadingThreads, setLoadingThreads] = useState(false);
  const [loadingConversation, setLoadingConversation] = useState(false);
  const [actionState, setActionState] = useState<Record<string, "idle" | "running" | "done" | "error">>({});
  const [messages, setMessages] = useState<AssistantMessage[]>([createWelcomeAssistantMessage()]);

  const copilotSession = useCopilotSession(threadId ?? null);
  const copilotActions = useCopilotActions(copilotSession?.id ?? null, 12);
  const [quickBrand, setQuickBrand] = useState("");
  const [quickStrain, setQuickStrain] = useState("");
  const [runningQuickAutofill, setRunningQuickAutofill] = useState(false);

  const pageContext = useMemo(
    () => resolveAssistantPageContext(location.pathname),
    [location.pathname],
  );

  useEffect(() => {
    const recommended = roleFromAppRoles(roles);
    if (audienceRole === "employee" && recommended !== "employee") {
      setAudienceRole(recommended);
    }
  }, [audienceRole, roles]);

  const resetConversation = () => {
    setThreadId(undefined);
    setMessages([createWelcomeAssistantMessage()]);
    setActionState({});
  };

  const appendMessage = (message: AssistantMessage) => {
    setMessages((prev) => [...prev, message]);
  };

  const syncRecentThreads = async (preferredThreadId?: string) => {
    if (!user?.id) {
      setThreads([]);
      return [];
    }

    setLoadingThreads(true);
    let data: AssistantThreadRecord[] = [];
    let error: { message?: string } | null = null;
    try {
      const response = await supabase
        .from("assistant_threads")
        .select("id, title, audience_role, updated_at, page_context")
        .eq("user_id", user.id)
        .order("updated_at", { ascending: false })
        .limit(8);
      data = (response.data ?? []) as AssistantThreadRecord[];
      error = response.error;
    } catch (threadError) {
      setLoadingThreads(false);
      throw threadError;
    }
    setLoadingThreads(false);

    if (error) {
      console.warn("assistant thread load failed", error.message);
      setThreads([]);
      return [];
    }

    const nextThreads = data.map(toAssistantThreadOption);
    setThreads(nextThreads);

    if (preferredThreadId && nextThreads.some((thread) => thread.id === preferredThreadId)) {
      setThreadId(preferredThreadId);
    }

    return nextThreads;
  };

  const loadThreadConversation = async (nextThreadId: string, silent = false) => {
    if (!user?.id) return;

    setLoadingConversation(true);
    const { data, error } = await supabase
      .from("assistant_messages")
      .select("id, role, content, context, created_at")
      .eq("thread_id", nextThreadId)
      .eq("user_id", user.id)
      .order("created_at", { ascending: true })
      .limit(40);
    setLoadingConversation(false);

    if (error) {
      console.warn("assistant conversation load failed", error.message);
      if (!silent) {
        toast.error("Unable to load that assistant thread right now.");
      }
      return;
    }

    setThreadId(nextThreadId);
    setMessages(mapStoredAssistantMessages(data as AssistantMessageRecord[]));
    setActionState({});
  };

  useEffect(() => {
    let cancelled = false;

    const hydrateAssistant = async () => {
      if (!user?.id) {
        setThreadId(undefined);
        setMessages([createWelcomeAssistantMessage()]);
        setActionState({});
        setThreads([]);
        return;
      }

      setLoadingThreads(true);
      const { data: threadRows, error: threadError } = await supabase
        .from("assistant_threads")
        .select("id, title, audience_role, updated_at, page_context")
        .eq("user_id", user.id)
        .order("updated_at", { ascending: false })
        .limit(8);
      if (cancelled) return;
      setLoadingThreads(false);

      if (threadError) {
        console.warn("assistant thread hydrate failed", threadError.message);
        setThreadId(undefined);
        setMessages([createWelcomeAssistantMessage()]);
        setActionState({});
        setThreads([]);
        return;
      }

      const nextThreads = threadRows.map(toAssistantThreadOption);
      setThreads(nextThreads);

      const latestThreadId = nextThreads[0]?.id;
      if (!latestThreadId) {
        setThreadId(undefined);
        setMessages([createWelcomeAssistantMessage()]);
        setActionState({});
        return;
      }

      setLoadingConversation(true);
      const { data: messageRows, error: messageError } = await supabase
        .from("assistant_messages")
        .select("id, role, content, context, created_at")
        .eq("thread_id", latestThreadId)
        .eq("user_id", user.id)
        .order("created_at", { ascending: true })
        .limit(40);
      if (cancelled) return;
      setLoadingConversation(false);

      if (messageError) {
        console.warn("assistant conversation hydrate failed", messageError.message);
        return;
      }

      setThreadId(latestThreadId);
      setMessages(mapStoredAssistantMessages(messageRows as AssistantMessageRecord[]));
      setActionState({});
    };

    void hydrateAssistant();

    return () => {
      cancelled = true;
    };
  }, [user?.id]);

  const insertActionLog = async (
    action: AssistantActionEnvelope,
    status: "recommended" | "confirmed" | "executed" | "failed",
    messageId?: string,
    error?: string,
    threadIdOverride?: string,
  ) => {
    if (!user?.id) return;

    const { error: insertError } = await supabase.from("assistant_action_logs").insert({
      thread_id: threadIdOverride ?? threadId ?? null,
      message_id: messageId ?? null,
      user_id: user.id,
      intent: action.intent,
      summary: action.summary,
      proposed_changes: action.proposed_changes ?? [],
      execution_payload: action.execution_payload ?? {},
      status,
      error: error ?? null,
      confirmed_at: status === "confirmed" || status === "executed" ? new Date().toISOString() : null,
      executed_at: status === "executed" ? new Date().toISOString() : null,
    });

    if (insertError) {
      console.warn("assistant action log insert failed", insertError.message);
    }
  };

  const executeAction = async (action: AssistantActionEnvelope): Promise<void> => {
    const payload = readObject(action.execution_payload) ?? {};
    const intent = action.intent.toLowerCase();

    if (intent.includes("intake")) {
      const patchObj = readObject(payload.intake_patch) ?? {};
      const patch = {
        brand: typeof patchObj.brand === "string" ? patchObj.brand : product.intake.brand,
        strain: typeof patchObj.strain === "string" ? patchObj.strain : product.intake.strain,
        productType:
          typeof patchObj.productType === "string"
            ? patchObj.productType
            : product.intake.productType,
        packageSize:
          typeof patchObj.packageSize === "string"
            ? patchObj.packageSize
            : product.intake.packageSize,
        sku: typeof patchObj.sku === "string" ? patchObj.sku : product.intake.sku,
        vendor: typeof patchObj.vendor === "string" ? patchObj.vendor : product.intake.vendor,
        notes: typeof patchObj.notes === "string" ? patchObj.notes : product.intake.notes,
      };

      const canAutofill = patch.brand.trim() || patch.strain.trim();
      const shouldAutofill = payload.autofill !== false && payload.auto_fill !== false;
      const requestedRoute = typeof payload.route === "string" && payload.route.trim()
        ? payload.route.trim()
        : "/product-intake";

      setIntake(patch);
      navigate(requestedRoute);

      if (!canAutofill) {
        toast.success("Intake recommendation applied. Review and submit when ready.");
        return;
      }

      if (!shouldAutofill) {
        toast.success("Intake recommendation applied. Review and submit when ready.");
        return;
      }

      const { data: { session: latestSession } } = await supabase.auth.getSession();
      const accessToken = latestSession?.access_token ?? session?.access_token;

      if (!accessToken) {
        toast.warning("Intake seed applied, but AI autofill needs you to sign in again.");
        return;
      }

      try {
        const response = await fetch(EDGE_FUNCTIONS.GENERATE_DRAFT, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            apikey: ENV.SUPABASE_PUBLISHABLE_KEY,
            Authorization: `Bearer ${accessToken}`,
          },
          body: JSON.stringify(patch),
        });

        const payloadBody: unknown = await response.json().catch(() => ({}));
        const payloadObject = readObject(payloadBody) ?? {};
        if (!response.ok) {
          const errorMessage =
            typeof payloadObject.error === "string"
              ? payloadObject.error
              : `AI intake autofill failed (${response.status})`;
          throw new Error(errorMessage);
        }

        const newDraft = payloadObject.draft as GeneratedDraft | undefined;
        if (!newDraft) {
          throw new Error("AI intake autofill returned no draft content");
        }

        const suggestions = buildIntakeAiSuggestionsFromDraft(newDraft);
        const enrichedPatch = {
          ...patch,
          strain: suggestions.strain || patch.strain,
          productType: suggestions.productType || patch.productType,
          vendor: suggestions.vendor || patch.vendor,
          notes: mergeDistinctLines([
            patch.notes,
            suggestions.notes,
            newDraft.descriptionShort,
            newDraft.descriptionLong,
          ]),
        };

        setIntake(enrichedPatch);
        setDraft(newDraft);
        toast.success("Intake auto-filled from web research. Review and submit when ready.");
      } catch (error) {
        const message = error instanceof Error ? error.message : "AI intake autofill failed";
        toast.warning(`Intake seed applied, but autofill could not complete: ${message}`);
        throw new Error(message);
      }

      return;
    }

    if (intent.includes("draft")) {
      navigate("/ai-draft");
      toast.success("Draft recommendation confirmed. Opening AI Draft workflow.");
      return;
    }

    if (intent.includes("review")) {
      navigate("/review");
      toast.success("Review recommendation confirmed.");
      return;
    }

    if (intent.includes("image")) {
      navigate("/image-finder");
      toast.success("Image guidance confirmed. Opening Image Finder.");
      return;
    }

    if (intent.includes("catalog")) {
      navigate("/catalog");
      toast.success("Opening Catalog workspace.");
      return;
    }

    if (intent.includes("pos") || intent.includes("checkout")) {
      navigate("/pos");
      toast.success("Opening Point of Sale workspace.");
      return;
    }

    if (intent.includes("vendor")) {
      const payloadMessage = typeof payload.message === "string" ? payload.message : null;
      const payloadText = typeof payload.text === "string" ? payload.text : null;
      const message = payloadMessage ?? payloadText ?? action.summary;

      if (!navigator.clipboard?.writeText) {
        throw new Error("Clipboard access is unavailable in this browser context.");
      }

      await navigator.clipboard.writeText(message);
      toast.success("Vendor follow-up text copied to clipboard.");
      return;
    }

    if (typeof payload.route === "string" && payload.route) {
      navigate(payload.route);
      toast.success("Recommendation confirmed.");
      return;
    }

    toast.success("Recommendation confirmed.");
  };

  const handleConfirmAction = async (action: AssistantActionEnvelope, actionKey: string, messageId?: string) => {
    setActionState((prev) => ({ ...prev, [actionKey]: "running" }));
    await insertActionLog(action, "confirmed", messageId, undefined, threadId);

    try {
      await executeAction(action);
      await insertActionLog(action, "executed", messageId, undefined, threadId);
      setActionState((prev) => ({ ...prev, [actionKey]: "done" }));
    } catch (error) {
      const message = error instanceof Error ? error.message : "Action execution failed";
      await insertActionLog(action, "failed", messageId, message, threadId);
      setActionState((prev) => ({ ...prev, [actionKey]: "error" }));
      toast.error(message);
    }
  };

  const handleThreadSelection = async (value: string) => {
    if (value === NEW_ASSISTANT_THREAD_VALUE) {
      resetConversation();
      return;
    }

    await loadThreadConversation(value);
  };

  const sendMessage = async () => {
    if (!input.trim()) return;
    if (!user) {
      toast.error("Sign in to use the assistant.");
      return;
    }

    const userMessage: AssistantMessage = {
      id: `user-${Date.now()}`,
      role: "user",
      content: input.trim(),
      createdAt: new Date().toISOString(),
    };

    appendMessage(userMessage);
    setInput("");
    setSending(true);
    let assistantReplyReceived = false;

    try {
      const headers: Record<string, string> = {
        "Content-Type": "application/json",
        apikey: ENV.SUPABASE_PUBLISHABLE_KEY,
        Authorization: `Bearer ${session?.access_token ?? ENV.SUPABASE_PUBLISHABLE_KEY}`,
      };

      const response = await fetch(EDGE_FUNCTIONS.ASSISTANT_CHAT, {
        method: "POST",
        headers,
        body: JSON.stringify({
          thread_id: threadId,
          message: userMessage.content,
          audience_role: audienceRole,
          user_profile: {
            display_name: user?.user_metadata?.full_name ?? undefined,
            role: audienceRole,
          },
          page_context: pageContext,
          workspace_snapshot: {
            intake: product.intake,
            route: location.pathname,
          },
        }),
      });

      const data: AssistantChatResponse | undefined = await response.json().catch(() => undefined);

      if (!response.ok) {
        const errMsg =
          (data as unknown as Record<string, unknown>)?.error ?? `Assistant request failed (${response.status})`;
        throw new Error(typeof errMsg === "string" ? errMsg : String(errMsg));
      }
      if (!data?.reply) throw new Error("Assistant did not return a response.");

      const resolvedThreadId = data.thread_id ?? threadId;
      if (resolvedThreadId) {
        setThreadId(resolvedThreadId);
      }

      const actionList = Array.isArray(data.actions)
        ? data.actions.filter((action) => action.requires_confirmation)
        : [];

      appendMessage({
        id: data.message_id ?? `assistant-${Date.now()}`,
        role: "assistant",
        content: data.reply,
        createdAt: new Date().toISOString(),
        actions: actionList,
      });
      assistantReplyReceived = true;

      for (const action of actionList) {
        await insertActionLog(action, "recommended", data.message_id, undefined, resolvedThreadId);
      }

      await syncRecentThreads(resolvedThreadId);
    } catch (err) {
      const httpStatus =
        (err as { context?: { status?: number }; status?: number }).context?.status ??
        (err as { status?: number }).status;
      const isAuthError =
        (err instanceof Error && err.name === "AuthSessionExpiredError") ||
        httpStatus === 401 ||
        httpStatus === 403;
      const description = describeAssistantError(err, {
        assistantReplyReceived,
        isAuthError,
      });

      if (description.severity === "warning") {
        toast.warning(description.toastMessage);
      } else {
        toast.error(description.toastMessage);
      }

      if (description.recoveryMessage) {
        appendMessage({
          id: `assistant-error-${Date.now()}`,
          role: "assistant",
          content: description.recoveryMessage,
          createdAt: new Date().toISOString(),
        });
      } else if (description.severity === "warning") {
        appendMessage({
          id: `assistant-warning-${Date.now()}`,
          role: "assistant",
          content: description.toastMessage,
          createdAt: new Date().toISOString(),
        });
      }

      if (description.shouldAttemptHistoryRecovery) {
        const latestThreads = await syncRecentThreads();
        const recoveryThreadId = threadId ?? latestThreads[0]?.id;
        if (recoveryThreadId) {
          await loadThreadConversation(recoveryThreadId, true);
        }
      }
    } finally {
      setSending(false);
    }
  };

  const handleRunQuickIntakeAutofill = async () => {
    const brand = (quickBrand || product.intake.brand).trim();
    const strain = (quickStrain || product.intake.strain).trim();

    if (!brand && !strain) {
      toast.error("Enter at least a brand or strain to run intake autofill.");
      return;
    }

    const action: AssistantActionEnvelope = {
      intent: "update_intake",
      summary: "Run full intake autofill",
      proposed_changes: [
        "Open intake workspace",
        "Seed provided brand/strain",
        "Auto-fill remaining fields from web-grounded AI research",
      ],
      requires_confirmation: true,
      execution_payload: {
        route: "/product-intake#pi-name",
        autofill: true,
        intake_patch: {
          brand,
          strain,
          productType: product.intake.productType,
          packageSize: product.intake.packageSize,
          sku: product.intake.sku,
          vendor: product.intake.vendor,
          notes: product.intake.notes,
        },
      },
    };

    setRunningQuickAutofill(true);
    try {
      await executeAction(action);
      setQuickBrand("");
      setQuickStrain("");
    } catch (error) {
      const message = error instanceof Error ? error.message : "Intake autofill failed";
      toast.error(message);
    } finally {
      setRunningQuickAutofill(false);
    }
  };

  const selectedThreadValue = threadId ?? NEW_ASSISTANT_THREAD_VALUE;
  let threadStatus = "Starting a fresh assistant thread.";
  if (loadingConversation) {
    threadStatus = "Loading conversation...";
  } else if (threadId) {
    threadStatus = "Recent thread resumed from your assistant history.";
  }

  const textareaRef = useRef<HTMLTextAreaElement | null>(null);

  useEffect(() => {
    textareaRef.current?.focus();
  }, [threadId]);

  const handleComposerKeyDown = (event: KeyboardEvent<HTMLTextAreaElement>) => {
    if ((event.metaKey || event.ctrlKey) && event.key === "Enter") {
      event.preventDefault();
      if (!sending && input.trim()) void sendMessage();
    }
  };

  const shellClass =
    "flex h-full min-h-0 flex-col overflow-hidden rounded-3xl border-2 border-border bg-card shadow-elevated";

  const scrollHeight = "flex-1 min-h-0";

  return (
    <div className={shellClass}>
      {/* ===== Chrome Gold Vinny Header ===== */}
      <div
        className="relative overflow-hidden border-b-2 border-[#3a2c0a] text-[#1a1205]"
        style={{
          backgroundImage:
            "linear-gradient(180deg, #fff4b8 0%, #f0c34a 18%, #b8861b 38%, #8a5f12 50%, #b8861b 62%, #f0c34a 82%, #fff4b8 100%)",
        }}
      >
        <div
          aria-hidden
          className="pointer-events-none absolute inset-0 opacity-40 mix-blend-overlay"
          style={{
            backgroundImage:
              "linear-gradient(90deg, transparent 0%, rgba(255,255,255,0.55) 22%, transparent 40%, rgba(0,0,0,0.25) 55%, transparent 75%, rgba(255,255,255,0.4) 95%, transparent 100%)",
          }}
        />
        <div className="relative flex flex-col gap-2 px-3 py-2 sm:px-5 sm:py-2.5">
          <div className="flex items-center gap-3">
            <div className="relative shrink-0 rounded-full ring-2 ring-[#3a2c0a]/70">
              <StrainVinnyAvatar
                size={40}
                title="Strain Vinny"
                className="h-10 w-10 rounded-full object-cover shadow-md sm:h-11 sm:w-11"
              />
            </div>
            <h2 className="min-w-0 flex-1 whitespace-normal break-words font-serif text-sm font-extrabold leading-tight tracking-tight text-[#1a1205] drop-shadow-[0_1px_0_rgba(255,255,255,0.55)] sm:text-base">
              Strain Vinny, Head of Operations
            </h2>
            <Badge
              variant="outline"
              className="shrink-0 border-[#3a2c0a]/70 bg-[#1a1205]/85 text-[10px] font-semibold uppercase tracking-[0.18em] text-[#f0c34a]"
            >
              <Sparkles className="mr-1 h-3 w-3" aria-hidden />
              Live
            </Badge>
          </div>

          <div className="grid grid-cols-1 gap-1.5 sm:grid-cols-[minmax(0,1fr)_minmax(0,1fr)_auto]">
            <Select value={audienceRole} onValueChange={(value) => setAudienceRole(value as AssistantAudienceRole)}>
              <SelectTrigger
                aria-label="Audience role"
                className="h-8 border-[#3a2c0a]/50 bg-[#1a1205]/80 text-xs text-[#f5e7b0] hover:bg-[#1a1205]"
              >
                <SelectValue placeholder="Audience role" />
              </SelectTrigger>
              <SelectContent>
                {ROLE_OPTIONS.map((option) => (
                  <SelectItem key={option.value} value={option.value}>
                    {option.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={selectedThreadValue} onValueChange={(value) => void handleThreadSelection(value)}>
              <SelectTrigger
                aria-label="Recent assistant threads"
                className="h-8 border-[#3a2c0a]/50 bg-[#1a1205]/80 text-xs text-[#f5e7b0] hover:bg-[#1a1205]"
              >
                <SelectValue placeholder={loadingThreads ? "Loading threads..." : "Recent threads"} />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value={NEW_ASSISTANT_THREAD_VALUE}>Start a new thread</SelectItem>
                {threads.map((thread) => (
                  <SelectItem key={thread.id} value={thread.id}>
                    {thread.title}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Button
              type="button"
              variant="secondary"
              size="sm"
              className="h-8 bg-[#1a1205] text-[#f0c34a] hover:bg-[#2a1d0a]"
              onClick={resetConversation}
            >
              <Wand2 className="mr-1.5 h-3.5 w-3.5" aria-hidden />
              New
            </Button>
          </div>
        </div>
      </div>


      {/* ===== Conversation ===== */}
      <ScrollArea className={scrollHeight}>
        <div
          role="log"
          aria-live="polite"
          aria-label="Assistant conversation"
          className="flex flex-col gap-4 p-4 sm:p-5"
        >
          {messages.map((message) => {
            const isAssistant = message.role === "assistant";
            return (
              <motion.div
                key={message.id}
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.25 }}
                className={isAssistant ? "flex items-start gap-3" : "flex items-start gap-3 flex-row-reverse"}
              >
                <div className="shrink-0">
                  {isAssistant ? (
                    <div className="grid h-9 w-9 place-items-center rounded-full bg-gradient-to-br from-accent/30 to-accent/10 ring-1 ring-accent/40">
                      <StrainVinnyAvatar size={26} title="Strain Vinny" />
                    </div>
                  ) : (
                    <div className="grid h-9 w-9 place-items-center rounded-full bg-foreground text-background">
                      <UserRound className="h-4 w-4" aria-hidden />
                    </div>
                  )}
                </div>
                <div className={isAssistant ? "min-w-0 max-w-[85%] space-y-2" : "min-w-0 max-w-[85%] space-y-2 items-end flex flex-col"}>
                  <div className="flex items-center gap-2">
                    <span className="text-[11px] font-semibold uppercase tracking-[0.18em] text-muted-foreground">
                      {isAssistant ? "Strain Vinny" : "You"}
                    </span>
                  </div>
                  <div
                    className={
                      isAssistant
                        ? "rounded-2xl rounded-tl-sm border-2 border-border bg-muted/50 px-4 py-3 shadow-soft"
                        : "rounded-2xl rounded-tr-sm border-2 border-foreground bg-foreground px-4 py-3 text-background shadow-soft"
                    }
                  >
                    <p className="whitespace-pre-wrap text-sm leading-relaxed">{message.content}</p>
                  </div>

                  {message.actions?.map((action, index) => {
                    const key = `${message.id}:${index}:${action.intent}`;
                    const status = actionState[key] ?? "idle";
                    const changes = toStringArray(action.proposed_changes);

                    return (
                      <div
                        key={key}
                        className="w-full space-y-2 rounded-2xl border border-accent/40 bg-gradient-to-br from-accent/5 to-transparent p-3"
                      >
                        <div className="flex items-start justify-between gap-2">
                          <p className="text-sm font-semibold leading-snug">{action.summary}</p>
                          <Badge variant="secondary" className="shrink-0 text-[10px] uppercase tracking-wider">
                            {action.intent}
                          </Badge>
                        </div>
                        {changes.length > 0 && (
                          <ul className="list-disc space-y-1 pl-4 text-xs text-muted-foreground">
                            {changes.slice(0, 4).map((change) => (
                              <li key={change}>{change}</li>
                            ))}
                          </ul>
                        )}
                        <Button
                          size="sm"
                          className="h-8 w-full gap-1.5 bg-accent text-accent-foreground hover:bg-accent/90"
                          disabled={status === "running" || status === "done"}
                          onClick={() => void handleConfirmAction(action, key, message.id)}
                          aria-label={`Confirm action: ${action.summary}`}
                        >
                          {status === "running" ? (
                            <Loader2 className="h-3.5 w-3.5 animate-spin" aria-hidden />
                          ) : status === "done" ? (
                            <Check className="h-3.5 w-3.5" aria-hidden />
                          ) : (
                            <ShieldCheck className="h-3.5 w-3.5" aria-hidden />
                          )}
                          {status === "done" ? "Confirmed" : "Confirm Action"}
                        </Button>
                      </div>
                    );
                  })}
                </div>
              </motion.div>
            );
          })}

          {sending && (
            <div className="flex items-start gap-3" aria-live="polite">
              <div className="grid h-9 w-9 place-items-center rounded-full bg-gradient-to-br from-accent/30 to-accent/10 ring-1 ring-accent/40">
                <StrainVinnyAvatar size={26} title="Strain Vinny" />
              </div>
              <div className="rounded-2xl rounded-tl-sm border border-border/60 bg-muted/40 px-4 py-3">
                <div className="flex items-center gap-1.5">
                  <span className="h-2 w-2 animate-bounce rounded-full bg-accent [animation-delay:-0.3s]" />
                  <span className="h-2 w-2 animate-bounce rounded-full bg-accent [animation-delay:-0.15s]" />
                  <span className="h-2 w-2 animate-bounce rounded-full bg-accent" />
                  <span className="sr-only">Vinny is thinking</span>
                </div>
              </div>
            </div>
          )}
        </div>
      </ScrollArea>

      {/* ===== Vinny operations rail ===== */}
      {(copilotActions.length > 0 || copilotSession) && (
        <div className="border-t border-border/60 bg-background/40 px-3 pt-3 sm:px-4 space-y-2">
          <SessionContextChip />
          {copilotActions.length > 0 && <WorkflowTimeline actions={copilotActions} />}
        </div>
      )}

      {/* ===== Composer ===== */}
      <div className="border-t border-border/60 bg-background/50 p-3 sm:p-4 space-y-3">
        <details className="group rounded-2xl border border-border/60 bg-muted/30 open:bg-muted/40">
          <summary className="flex cursor-pointer list-none items-center justify-between gap-2 rounded-2xl px-3 py-2 text-xs font-semibold text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring">
            <span className="inline-flex items-center gap-1.5">
              <Wand2 className="h-3.5 w-3.5 text-accent" aria-hidden />
              Quick Intake Autofill
            </span>
            <span className="text-[10px] uppercase tracking-wider text-muted-foreground transition group-open:rotate-180">▾</span>
          </summary>
          <div className="space-y-2 px-3 pb-3">
            <p className="text-[11px] text-muted-foreground">
              Enter brand and product name/strain, or just strain. Vinny will fill the intake form from web-grounded research.
            </p>
            <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
              <Input
                value={quickBrand}
                onChange={(event) => setQuickBrand(event.target.value)}
                placeholder="Brand (optional if strain is provided)"
                aria-label="Brand"
              />
              <Input
                value={quickStrain}
                onChange={(event) => setQuickStrain(event.target.value)}
                placeholder="Product name or strain"
                aria-label="Product name or strain"
              />
            </div>
            <Button
              type="button"
              variant="outline"
              className="w-full"
              disabled={runningQuickAutofill || sending}
              onClick={() => void handleRunQuickIntakeAutofill()}
            >
              {runningQuickAutofill ? (
                <Loader2 className="h-4 w-4 animate-spin" aria-hidden />
              ) : (
                <ShieldCheck className="h-4 w-4" aria-hidden />
              )}
              {runningQuickAutofill ? "Running Intake Autofill..." : "Run Full Intake Autofill"}
            </Button>
          </div>
        </details>

        <div className="relative">
          <label htmlFor="vinny-composer" className="sr-only">
            Message Strain Vinny
          </label>
          <Textarea
            id="vinny-composer"
            ref={textareaRef}
            value={input}
            onChange={(event) => setInput(event.target.value)}
            onKeyDown={handleComposerKeyDown}
            placeholder="Ask for intake guidance, vendor follow-up language, draft refinements, or operational recommendations."
            className="min-h-[96px] resize-none rounded-2xl border-border/70 bg-background pr-12 text-sm shadow-sm focus-visible:ring-accent"
          />
          <div className="absolute bottom-2 right-2 hidden text-[10px] uppercase tracking-wider text-muted-foreground sm:block">
            ⌘ + ↵
          </div>
        </div>
        <Button
          onClick={() => void sendMessage()}
          disabled={sending || !input.trim()}
          className="w-full gap-2 bg-foreground text-background hover:bg-foreground/90"
          size="lg"
        >
          {sending ? <Loader2 className="h-4 w-4 animate-spin" aria-hidden /> : <Send className="h-4 w-4" aria-hidden />}
          {sending ? "Sending..." : "Send to Vinny"}
        </Button>
      </div>
    </div>
  );
}

