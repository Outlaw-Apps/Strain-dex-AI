import { useState } from "react";
import { useLocation } from "react-router-dom";
import { motion } from "framer-motion";

import {
  Drawer,
  DrawerContent,
  DrawerDescription,
  DrawerHeader,
  DrawerTitle,
  DrawerTrigger,
} from "@/components/ui/drawer";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import { useIsMobile } from "@/hooks/use-mobile";
import AssistantCopilotPanel from "@/components/assistant/AssistantCopilotPanel";
import StrainVinnyAvatar from "@/components/StrainVinnyAvatar";

export default function GlobalAssistantDrawer() {
  const [open, setOpen] = useState(false);
  const isMobile = useIsMobile();
  const location = useLocation();

  if (location.pathname === "/assistant") {
    return null;
  }

  const trigger = (
    <motion.button
      type="button"
      aria-label="Open Strain Vinny copilot"
      whileHover={{ scale: 1.05 }}
      whileTap={{ scale: 0.95 }}
      className="fixed bottom-6 right-6 z-50 grid h-16 w-16 place-items-center rounded-full bg-gradient-to-br from-foreground to-accent text-background shadow-xl ring-2 ring-accent/40 focus-visible:outline-none focus-visible:ring-4 focus-visible:ring-accent"
    >
      <span
        aria-hidden
        className="absolute inset-0 animate-ping rounded-full bg-accent/30"
      />
      <span
        aria-hidden
        className="absolute -inset-1 rounded-full bg-accent/20 blur-md"
      />
      <span className="relative grid h-12 w-12 place-items-center rounded-full bg-background/95 shadow-inner">
        <StrainVinnyAvatar size={36} title="Strain Vinny" />
      </span>
      <span className="sr-only">Open Strain Vinny</span>
    </motion.button>
  );

  if (isMobile) {
    return (
      <Drawer open={open} onOpenChange={setOpen}>
        <DrawerTrigger asChild>{trigger}</DrawerTrigger>
        <DrawerContent className="h-[92vh] max-h-[92vh] flex flex-col">
          <DrawerHeader className="sr-only">
            <DrawerTitle>Strain Vinny</DrawerTitle>
            <DrawerDescription>
              Premium assistant guidance with confirm-gated actions.
            </DrawerDescription>
          </DrawerHeader>
          <div className="flex-1 min-h-0 px-2 pb-2">
            <AssistantCopilotPanel embedded />
          </div>
        </DrawerContent>
      </Drawer>
    );
  }

  return (
    <Sheet open={open} onOpenChange={setOpen}>
      <SheetTrigger asChild>{trigger}</SheetTrigger>
      <SheetContent
        side="right"
        className="w-full border-l border-border/60 bg-background p-0 sm:max-w-[520px]"
      >
        <SheetHeader className="sr-only">
          <SheetTitle>Strain Vinny</SheetTitle>
          <SheetDescription>
            Role-aware cannabis operations copilot with recommend + confirm actions.
          </SheetDescription>
        </SheetHeader>
        <div className="h-full p-3 sm:p-4">
          <AssistantCopilotPanel embedded />
        </div>
      </SheetContent>
    </Sheet>
  );
}
