import { useLocation } from "react-router-dom";
import { Badge } from "@/components/ui/badge";
import { useAuth } from "@/context/AuthContext";
import { useUserRoles } from "@/hooks/useUserRoles";
import { MapPin } from "lucide-react";

export default function SessionContextChip() {
  const { user } = useAuth();
  const { roles } = useUserRoles();
  const location = useLocation();
  if (!user) return null;
  const primaryRole = roles[0] ?? "staff";
  return (
    <div className="flex items-center gap-2 text-[11px] text-muted-foreground">
      <Badge variant="outline" className="gap-1">
        <MapPin className="h-3 w-3" />
        {location.pathname}
      </Badge>
      <Badge variant="outline">role: {primaryRole}</Badge>
    </div>
  );
}
