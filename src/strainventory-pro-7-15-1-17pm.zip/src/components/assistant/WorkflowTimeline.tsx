import { motion } from "framer-motion";
import { CheckCircle2, Circle, Loader2, XCircle, Clock, ShieldAlert } from "lucide-react";
import { cn } from "@/lib/utils";
import type { CopilotActionRecord, CopilotActionStatus } from "@/lib/copilot/types";
import { Badge } from "@/components/ui/badge";

const STATUS_META: Record<
  CopilotActionStatus,
  { icon: React.ComponentType<{ className?: string }>; label: string; tone: string }
> = {
  draft: { icon: Circle, label: "Draft", tone: "text-muted-foreground" },
  awaiting_approval: { icon: ShieldAlert, label: "Awaiting Approval", tone: "text-amber-500" },
  running: { icon: Loader2, label: "Running", tone: "text-accent animate-spin" },
  completed: { icon: CheckCircle2, label: "Completed", tone: "text-emerald-500" },
  failed: { icon: XCircle, label: "Failed", tone: "text-destructive" },
};

interface WorkflowTimelineProps {
  actions: CopilotActionRecord[];
  className?: string;
}

export default function WorkflowTimeline({ actions, className }: WorkflowTimelineProps) {
  if (actions.length === 0) return null;

  return (
    <div className={cn("space-y-2 rounded-lg border border-border/60 bg-card/50 p-3", className)}>
      <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
        <Clock className="h-3.5 w-3.5" />
        Workflow timeline
      </div>
      <ol className="relative ml-2 space-y-2 border-l border-border/60 pl-4">
        {actions.slice().reverse().map((a) => {
          const meta = STATUS_META[a.status] ?? STATUS_META.draft;
          const Icon = meta.icon;
          return (
            <motion.li
              key={a.id}
              initial={{ opacity: 0, x: -4 }}
              animate={{ opacity: 1, x: 0 }}
              className="relative"
            >
              <span className="absolute -left-[22px] top-1 grid h-4 w-4 place-items-center rounded-full bg-background">
                <Icon className={cn("h-3.5 w-3.5", meta.tone)} />
              </span>
              <div className="flex items-baseline justify-between gap-2">
                <span className="text-sm font-medium">{a.tool_name}</span>
                <Badge variant="outline" className="text-[10px]">{meta.label}</Badge>
              </div>
              {a.summary && (
                <p className="text-xs text-muted-foreground">{a.summary}</p>
              )}
              {a.route_context && (
                <p className="text-[10px] text-muted-foreground/80">on {a.route_context}</p>
              )}
              {a.error && (
                <p className="text-xs text-destructive">{a.error}</p>
              )}
            </motion.li>
          );
        })}
      </ol>
    </div>
  );
}
