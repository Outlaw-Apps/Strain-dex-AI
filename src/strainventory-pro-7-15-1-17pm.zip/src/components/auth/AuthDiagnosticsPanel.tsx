import { useEffect, useState } from "react";
import { AlertCircle, CheckCircle2, ChevronDown, ChevronUp, Loader2, Stethoscope, Trash2 } from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import {
  type AuthDiagEntry,
  clearAuthDiagnostics,
  labelForStep,
  subscribeAuthDiagnostics,
} from "@/lib/authDiagnostics";

function formatTime(ts: number): string {
  return new Date(ts).toLocaleTimeString(undefined, { hour12: false });
}

function StatusIcon({ status }: { status: AuthDiagEntry["status"] }) {
  if (status === "pending") return <Loader2 className="h-3.5 w-3.5 animate-spin text-muted-foreground" />;
  if (status === "success") return <CheckCircle2 className="h-3.5 w-3.5 text-emerald-500" />;
  return <AlertCircle className="h-3.5 w-3.5 text-destructive" />;
}

const AuthDiagnosticsPanel = () => {
  const [entries, setEntries] = useState<AuthDiagEntry[]>([]);
  const [open, setOpen] = useState(false);

  useEffect(() => subscribeAuthDiagnostics(setEntries), []);

  const last = entries[0];
  const errorCount = entries.filter((e) => e.status === "error").length;

  return (
    <div className="mt-6 rounded-xl border border-border/70 bg-background/70 backdrop-blur">
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        aria-expanded={open}
        className="flex w-full items-center gap-2 rounded-xl px-4 py-3 text-left text-sm transition-colors hover:bg-muted/40"
      >
        <Stethoscope className="h-4 w-4 text-accent" />
        <span className="font-medium text-foreground">Auth diagnostics</span>
        <span className="text-xs text-muted-foreground">
          {last ? (
            <>
              Last: <span className="font-medium text-foreground">{labelForStep(last.step)}</span>{" "}
              · {last.status}
            </>
          ) : (
            "No attempts yet"
          )}
        </span>
        {errorCount > 0 && (
          <span className="ml-1 rounded-full bg-destructive/15 px-2 py-0.5 text-[10px] font-medium text-destructive">
            {errorCount} error{errorCount === 1 ? "" : "s"}
          </span>
        )}
        <span className="ml-auto text-muted-foreground">
          {open ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
        </span>
      </button>

      {open && (
        <div className="border-t border-border/70 px-4 py-3 space-y-3">
          {entries.length === 0 ? (
            <p className="text-xs text-muted-foreground">
              Sign-in attempts will show here with status, timing, and troubleshooting hints.
            </p>
          ) : (
            <>
              <ul className="space-y-2 max-h-72 overflow-y-auto pr-1">
                {entries.map((entry) => (
                  <li
                    key={entry.id}
                    className={cn(
                      "rounded-lg border px-3 py-2 text-xs",
                      entry.status === "error"
                        ? "border-destructive/40 bg-destructive/5"
                        : entry.status === "success"
                          ? "border-emerald-500/30 bg-emerald-500/5"
                          : "border-border/70 bg-muted/30",
                    )}
                  >
                    <div className="flex items-center gap-2">
                      <StatusIcon status={entry.status} />
                      <span className="font-medium text-foreground">{labelForStep(entry.step)}</span>
                      <span className="text-muted-foreground">· {formatTime(entry.startedAt)}</span>
                      {typeof entry.durationMs === "number" && (
                        <span className="ml-auto text-muted-foreground">{entry.durationMs} ms</span>
                      )}
                    </div>
                    {entry.message && (
                      <p
                        className={cn(
                          "mt-1 break-words font-mono text-[11px]",
                          entry.status === "error" ? "text-destructive" : "text-muted-foreground",
                        )}
                      >
                        {entry.message}
                      </p>
                    )}
                    {entry.hint && (
                      <p className="mt-1 rounded-md bg-accent/10 px-2 py-1 text-[11px] text-foreground">
                        💡 {entry.hint}
                      </p>
                    )}
                  </li>
                ))}
              </ul>
              <div className="flex items-center justify-between">
                <p className="text-[11px] text-muted-foreground">
                  Kept in memory for this session only.
                </p>
                <Button
                  type="button"
                  size="sm"
                  variant="ghost"
                  className="h-7 gap-1 text-xs"
                  onClick={() => clearAuthDiagnostics()}
                >
                  <Trash2 className="h-3 w-3" /> Clear
                </Button>
              </div>
            </>
          )}
        </div>
      )}
    </div>
  );
};

export default AuthDiagnosticsPanel;
