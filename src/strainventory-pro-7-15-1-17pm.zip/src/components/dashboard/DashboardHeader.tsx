import { motion } from "framer-motion";

interface DashboardHeaderProps {
  displayName: string;
}

const DashboardHeader = ({ displayName }: DashboardHeaderProps) => (
  <motion.div
    initial={{ opacity: 0, y: -10 }}
    animate={{ opacity: 1, y: 0 }}
    className="flex flex-col sm:flex-row sm:justify-between sm:items-end gap-3 mb-6 sm:mb-8 pb-5 border-b-4 border-foreground/80"
  >
    <div className="min-w-0">
      <p className="text-[10px] sm:text-[11px] font-extrabold uppercase tracking-[0.28em] text-accent mb-2">
        Overview
      </p>
      <h1 className="text-display text-3xl sm:text-4xl lg:text-5xl font-black tracking-tight text-foreground leading-[1.02]">
        Welcome back, <span className="text-accent">{displayName}</span>
      </h1>
      <p className="text-foreground/70 mt-2 text-sm sm:text-base font-medium">
        Here's the pulse of Strain-ventory right now.
      </p>
    </div>
    <div className="flex items-center gap-2 self-start sm:self-auto rounded-full border border-border bg-card px-3 py-1.5 text-xs font-medium text-muted-foreground shrink-0 shadow-soft">
      <span className="relative flex h-2 w-2">
        <span className="absolute inset-0 animate-ping rounded-full bg-success/70" />
        <span className="relative inline-flex h-2 w-2 rounded-full bg-success" />
      </span>
      <span>Live · auto-refreshes</span>
    </div>
  </motion.div>
);

export default DashboardHeader;
