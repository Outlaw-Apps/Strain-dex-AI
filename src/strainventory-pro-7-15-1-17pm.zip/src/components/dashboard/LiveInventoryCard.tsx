import { Package } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import type { Product } from "@/hooks/useProducts";

interface LiveInventoryCardProps {
  products: Product[];
  lowStockThreshold: number;
}

const LiveInventoryCard = ({ products, lowStockThreshold }: LiveInventoryCardProps) => (
  <Card className="shadow-elevated h-full border-2 border-foreground/25 rounded-2xl">
    <CardHeader className="pb-3 border-b-2 border-foreground/10">
      <CardTitle className="flex items-center gap-2 text-base font-extrabold uppercase tracking-wide">
        <Package className="h-5 w-5 text-accent" strokeWidth={2.5} />
        Live Inventory
      </CardTitle>
    </CardHeader>
    <CardContent className="pt-3">
      <div className="divide-y-2 divide-foreground/10">
        {products.slice(0, 6).map((p) => (
          <div key={p.id} className="flex justify-between items-center py-2.5 first:pt-0">
            <div>
              <p className="text-sm font-bold text-foreground">{p.name}</p>
              <p className="text-xs font-medium text-foreground/65">{p.brand} • {p.type}</p>
            </div>
            <Badge
              variant={(p.quantity ?? 0) <= lowStockThreshold ? "destructive" : "secondary"}
              className="tabular-nums font-bold border-2"
            >
              {p.quantity} left
            </Badge>
          </div>
        ))}
      </div>
    </CardContent>
  </Card>
);

export default LiveInventoryCard;
