import { motion } from "framer-motion";
import { LucideIcon } from "lucide-react";
import { cn } from "@/lib/utils";

interface MetricCardProps {
  label: string;
  value: string | number;
  icon: LucideIcon;
  accent?: "gold" | "emerald" | "warning" | "success" | "default";
  delay?: number;
  onClick?: () => void;
}

const accentBar: Record<NonNullable<MetricCardProps["accent"]>, string> = {
  gold: "bg-accent",
  emerald: "bg-emerald",
  warning: "bg-warning",
  success: "bg-success",
  default: "bg-foreground/70",
};

const MetricCard = ({ label, value, icon: Icon, accent = "default", delay = 0, onClick }: MetricCardProps) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.35, delay }}
      onClick={onClick}
      className={cn(
        "group relative overflow-hidden rounded-2xl border-2 border-foreground/25 bg-card p-4 sm:p-5 lg:p-6 shadow-elevated",
        "transition-all duration-300 hover:-translate-y-0.5 hover:shadow-gold hover:border-foreground/60",
        accent === "gold" && "ring-1 ring-accent/40 shadow-[0_0_24px_-4px_hsl(var(--accent)/0.55)]",
        accent === "emerald" && "ring-1 ring-emerald/50 shadow-[0_0_24px_-4px_hsl(var(--emerald)/0.6)]",
        accent === "warning" && "ring-1 ring-warning/50 shadow-[0_0_24px_-4px_hsl(var(--warning)/0.55)]",
        accent === "success" && "ring-1 ring-success/50 shadow-[0_0_24px_-4px_hsl(var(--success)/0.6)]",
        accent === "default" && "ring-1 ring-foreground/30 shadow-[0_0_24px_-4px_hsl(var(--foreground)/0.45)]",
        onClick && "cursor-pointer"
      )}
    >
      {/* Accent rail */}
      <span className={cn("absolute left-0 top-0 h-full w-2", accentBar[accent])} aria-hidden />

      <div className="flex items-start justify-between gap-3 pl-2">
        <div className="space-y-1.5 min-w-0 flex-1">
          <p className="text-[10px] sm:text-[11px] font-extrabold uppercase tracking-[0.2em] text-foreground/70 leading-tight">
            {label}
          </p>
          <p
            className="text-display text-[clamp(1.35rem,2.5vw,2.15rem)] font-black tracking-tight text-foreground tabular-nums leading-none break-all"
            title={String(value)}
          >
            {value}
          </p>
        </div>
        <div
          className={cn(
            "flex h-10 w-10 sm:h-11 sm:w-11 shrink-0 items-center justify-center ring-2 shadow-soft transition-transform group-hover:scale-105",
            label === "Today's Revenue" ? "rounded-full" : "rounded-xl",
            accent === "gold" && (label === "Today's Revenue" ? "bg-accent ring-accent shadow-[0_0_18px_-2px_hsl(var(--accent)/0.85)]" : "gold-gradient ring-accent/60 shadow-[0_0_18px_-2px_hsl(var(--accent)/0.7)]"),
            accent === "emerald" && (label === "Today's Revenue" ? "bg-emerald ring-emerald shadow-[0_0_18px_-2px_hsl(var(--emerald)/0.9)]" : "emerald-gradient ring-emerald/70 shadow-[0_0_18px_-2px_hsl(var(--emerald)/0.75)]"),
            accent === "warning" && "bg-warning ring-warning/70 shadow-[0_0_18px_-2px_hsl(var(--warning)/0.7)]",
            accent === "success" && "bg-success ring-success/70 shadow-[0_0_18px_-2px_hsl(var(--success)/0.75)]",
            accent === "default" && "bg-foreground ring-foreground/40"
          )}
        >
          {label === "Today's Revenue" ? (
            <span
              className={cn(
                "text-2xl sm:text-[1.6rem] font-black leading-none tabular-nums opacity-100",
                accent === "emerald" && "text-emerald-foreground",
                accent === "gold" && "text-accent-foreground",
                accent === "success" && "text-success-foreground",
                accent === "warning" && "text-warning-foreground",
                accent === "default" && "text-background"
              )}
              aria-hidden
            >
              $
            </span>
          ) : (
            <Icon
              className={cn(
                "h-5 w-5",
                accent === "gold" && "text-accent-foreground",
                accent === "emerald" && "text-emerald-foreground",
                accent === "warning" && "text-warning-foreground",
                accent === "success" && "text-success-foreground",
                accent === "default" && "text-background"
              )}
              strokeWidth={2.75}
            />
          )}
        </div>
      </div>
    </motion.div>
  );
};

export default MetricCard;
