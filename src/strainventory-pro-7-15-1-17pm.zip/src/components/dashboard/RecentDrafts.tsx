import { useMemo } from "react";
import { motion } from "framer-motion";
import { useNavigate } from "react-router-dom";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import { useProducts } from "@/hooks/useProducts";

const statusStyles: Record<string, string> = {
  draft: "bg-muted text-muted-foreground",
  review: "bg-warning/15 text-warning",
  approved: "bg-success/15 text-success",
  published: "bg-success/15 text-success",
};

const RecentDrafts = () => {
  const navigate = useNavigate();
  const { data: products = [], isLoading } = useProducts();
  const recentDrafts = useMemo(() => products.slice(0, 5), [products]);

  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, delay: 0.3 }}
      className="rounded-xl border border-border bg-card shadow-soft"
    >
      <div className="border-b border-border px-6 py-4">
        <h3 className="text-sm font-semibold text-card-foreground">Recent Drafts</h3>
      </div>
      <div className="divide-y divide-border">
        {isLoading && <div className="px-6 py-8 text-center text-sm text-muted-foreground">Loading…</div>}
        {!isLoading && recentDrafts.length === 0 && <div className="px-6 py-8 text-center text-sm text-muted-foreground">No products yet.</div>}
        {recentDrafts.map((draft) => (
          <div key={draft.id} onClick={() => navigate(`/catalog/${draft.id}`)} className="flex items-center justify-between px-6 py-3.5 transition-colors hover:bg-muted/40 cursor-pointer">
            <div className="space-y-0.5">
              <p className="text-sm font-medium text-card-foreground">{draft.name}</p>
              <p className="text-xs text-muted-foreground">{draft.brand}</p>
            </div>
            <div className="flex items-center gap-3">
              <span className="text-xs tabular-nums text-muted-foreground">{draft.confidence}%</span>
              <Badge variant="secondary" className={cn("text-[10px] uppercase tracking-wider font-medium", statusStyles[draft.status])}>
                {draft.status}
              </Badge>
            </div>
          </div>
        ))}
      </div>
    </motion.div>
  );
};

export default RecentDrafts;
