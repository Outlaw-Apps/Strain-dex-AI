import { Users } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

interface ActiveEmployee {
  user_id: string;
}

interface TeamOnDutyCardProps {
  activeEmployees: ActiveEmployee[];
  profileMap: Map<string, string>;
}

const TeamOnDutyCard = ({ activeEmployees, profileMap }: TeamOnDutyCardProps) => (
  <Card className="shadow-elevated h-full border-2 border-foreground/25 rounded-2xl">
    <CardHeader className="pb-3 border-b-2 border-foreground/10">
      <CardTitle className="flex items-center gap-2 text-base font-extrabold uppercase tracking-wide">
        <Users className="h-5 w-5 text-accent" strokeWidth={2.5} />
        Team On Duty
      </CardTitle>
    </CardHeader>
    <CardContent className="pt-3">
      {activeEmployees.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-6 text-center">
          <Users className="h-8 w-8 text-foreground/40 mb-2" strokeWidth={2.5} />
          <p className="text-sm font-semibold text-foreground/70">No one clocked in yet.</p>
        </div>
      ) : (
        <div className="divide-y-2 divide-foreground/10">
          {activeEmployees.map((emp) => (
            <div key={emp.user_id} className="flex items-center gap-3 py-2.5 first:pt-0">
              <div className="h-8 w-8 rounded-full bg-accent flex items-center justify-center text-xs font-black text-accent-foreground shrink-0 ring-2 ring-foreground/15">
                {(profileMap.get(emp.user_id) || "?")[0]}
              </div>
              <p className="text-sm font-bold flex-1 truncate">{profileMap.get(emp.user_id) || "Staff"}</p>
              <Badge variant="outline" className="text-[9px] tracking-wider uppercase font-bold border-2 border-success text-success shrink-0">On duty</Badge>
            </div>
          ))}
        </div>
      )}
    </CardContent>
  </Card>
);

export default TeamOnDutyCard;
