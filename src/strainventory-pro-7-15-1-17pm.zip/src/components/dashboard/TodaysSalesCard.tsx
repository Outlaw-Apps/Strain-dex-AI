import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { formatWholeCurrency } from "@/lib/dashboard/formatters";

interface TopStrain {
  name: string;
  qty: number;
}

interface TodaysSalesCardProps {
  revenue: number;
  topStrains: TopStrain[];
}

const TodaysSalesCard = ({ revenue, topStrains }: TodaysSalesCardProps) => (
  <Card className="shadow-elevated h-full border-2 border-foreground/25 rounded-2xl">
    <CardHeader className="pb-3 border-b-2 border-foreground/10">
      <CardTitle className="text-base font-extrabold uppercase tracking-wide">Today's Sales</CardTitle>
    </CardHeader>
    <CardContent className="space-y-5 pt-4">
      <div className="rounded-xl bg-success border-2 border-success px-4 py-4 text-center shadow-soft">
        <p className="text-3xl font-black tabular-nums text-success-foreground">
          {formatWholeCurrency(revenue)}
        </p>
        <p className="text-xs font-bold uppercase tracking-wider text-success-foreground/85 mt-1">Revenue today</p>
      </div>
      <div>
        <p className="text-label text-foreground/70 font-extrabold uppercase tracking-wider mb-2">Top strains sold</p>
        <div className="space-y-1.5">
          {topStrains.map((strain, i) => (
            <div key={i} className="flex justify-between text-sm">
              <span className="text-foreground font-semibold">{strain.name}</span>
              <span className="font-bold tabular-nums text-foreground/70">{strain.qty} sold</span>
            </div>
          ))}
        </div>
      </div>
    </CardContent>
  </Card>
);

export default TodaysSalesCard;
