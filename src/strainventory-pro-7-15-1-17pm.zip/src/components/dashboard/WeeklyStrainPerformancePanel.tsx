import { motion } from "framer-motion";
import { Activity, Flame, Sparkles, TrendingUp, Trophy, Zap } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { BarChart, Bar, XAxis, ResponsiveContainer, Tooltip } from "recharts";
import type { WeeklyStrainPerformance } from "@/lib/dashboardStrainPerformance";
import {
  formatCompactNumber,
  formatMomentum,
  formatWholeCurrency,
} from "@/lib/dashboard/formatters";

interface WeeklyStrainPerformancePanelProps {
  weeklyPerformance: WeeklyStrainPerformance | undefined;
  isLoading: boolean;
}

const WeeklyStrainPerformancePanel = ({
  weeklyPerformance,
  isLoading,
}: WeeklyStrainPerformancePanelProps) => {
  const topPerformer = weeklyPerformance?.topStrains[0];
  const hasWeeklyPerformance = !!weeklyPerformance && weeklyPerformance.totalRevenue > 0;

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.35 }}>
      <Card className="relative overflow-hidden border-accent/25 shadow-gold">
        <div className="pointer-events-none absolute -right-20 -top-20 h-56 w-56 rounded-full bg-accent/15 blur-3xl" />
        <div className="pointer-events-none absolute bottom-0 left-0 h-px w-full bg-gradient-to-r from-transparent via-accent/50 to-transparent" />

        <CardHeader className="relative flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between pb-4">
          <div>
            <div className="mb-2.5 flex items-center gap-2">
              <Badge className="gold-gradient border-0 text-accent-foreground shadow-gold text-xs">
                <Sparkles className="mr-1 h-3 w-3" />
                Live strain radar
              </Badge>
              <Badge variant="outline" className="border-success/30 text-success text-xs">
                {isLoading ? "Syncing…" : formatMomentum(weeklyPerformance?.momentumPercent)}
              </Badge>
            </div>
            <CardTitle className="flex items-center gap-2 text-xl font-bold">
              <Flame className="h-5 w-5 text-accent" />
              Strain Performance • This Week
            </CardTitle>
            <CardDescription className="mt-1">
              Weekly strain winners, sales velocity, inventory pressure, and customer mood signals from POS activity.
            </CardDescription>
          </div>

          <div className="grid grid-cols-3 gap-3 shrink-0">
            {[
              { label: "Revenue", value: formatWholeCurrency(weeklyPerformance?.totalRevenue ?? 0), highlight: true },
              { label: "Units", value: formatCompactNumber(weeklyPerformance?.totalUnits ?? 0) },
              { label: "Leader", value: weeklyPerformance?.leadingType ?? "None" },
            ].map(({ label, value, highlight }) => (
              <div key={label} className="rounded-xl border border-border/70 bg-background/70 px-4 py-3 text-right">
                <p className="text-label text-muted-foreground">{label}</p>
                <p className={`text-lg font-semibold tabular-nums mt-0.5 ${highlight ? "text-success" : "text-foreground"}`}>
                  {value}
                </p>
              </div>
            ))}
          </div>
        </CardHeader>

        <CardContent className="relative">
          {isLoading ? (
            <div className="grid gap-4 lg:grid-cols-3">
              {[0, 1, 2].map((i) => (
                <div key={i} className="h-44 animate-pulse rounded-xl border bg-muted/40" />
              ))}
            </div>
          ) : !hasWeeklyPerformance ? (
            <div className="rounded-xl border border-dashed bg-background/60 p-10 text-center">
              <Activity className="mx-auto mb-3 h-9 w-9 text-muted-foreground/50" />
              <p className="text-base font-semibold">No weekly strain sales yet</p>
              <p className="mx-auto mt-2 max-w-md text-sm text-muted-foreground">
                As orders come through the POS, this panel will rank strains, show daily heat, and flag restock pressure automatically.
              </p>
            </div>
          ) : (
            <div className="grid gap-5 lg:grid-cols-12">
              <div className="lg:col-span-5">
                <div className="h-full rounded-xl border border-border/70 bg-background/70 p-5 shadow-soft">
                  <div className="mb-4 flex items-start justify-between">
                    <div>
                      <p className="text-label text-muted-foreground">Top performer</p>
                      <h3 className="mt-1 text-2xl font-bold section-title">{topPerformer?.name}</h3>
                      <p className="text-xs text-muted-foreground mt-0.5">
                        {topPerformer?.brand} • {topPerformer?.strainType} • {topPerformer?.productType}
                      </p>
                    </div>
                    <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-accent/12 text-accent shrink-0">
                      <Trophy className="h-5 w-5" />
                    </div>
                  </div>

                  <div className="mb-5 grid grid-cols-3 gap-2">
                    {[
                      { label: "Share", value: `${topPerformer?.sharePercent}%` },
                      { label: "Sales", value: formatWholeCurrency(topPerformer?.revenue ?? 0) },
                      { label: "Stock", value: topPerformer?.stockLeft ?? "N/A" },
                    ].map(({ label, value }) => (
                      <div key={label} className="rounded-lg bg-card border border-border/60 p-2.5">
                        <p className="text-label text-muted-foreground">{label}</p>
                        <p className="text-lg font-semibold tabular-nums mt-0.5">{value}</p>
                      </div>
                    ))}
                  </div>

                  <div className="space-y-2.5">
                    {weeklyPerformance.topStrains.slice(0, 4).map((strain, index) => (
                      <div key={strain.id} className="rounded-lg border border-border/60 bg-card/70 p-3">
                        <div className="mb-2 flex items-center justify-between gap-3">
                          <div className="flex items-center gap-2.5">
                            <div className="flex h-7 w-7 items-center justify-center rounded-full bg-accent/12 text-xs font-semibold text-accent shrink-0">
                              {index + 1}
                            </div>
                            <div>
                              <p className="text-sm font-medium">{strain.name}</p>
                              <p className="text-xs text-muted-foreground">{strain.units} units • {strain.strainType}</p>
                            </div>
                          </div>
                          <Badge variant={strain.status === "Restock watch" ? "destructive" : "secondary"} className="shrink-0 text-xs">
                            {strain.status}
                          </Badge>
                        </div>
                        <div className="h-1.5 overflow-hidden rounded-full bg-muted">
                          <div
                            className="h-full rounded-full bg-gradient-to-r from-success to-accent transition-all"
                            style={{ width: `${strain.sharePercent}%` }}
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              <div className="lg:col-span-4">
                <div className="h-full rounded-xl border border-border/70 bg-background/70 p-5 shadow-soft">
                  <div className="mb-4 flex items-center justify-between">
                    <div>
                      <p className="text-label text-muted-foreground">Daily heat</p>
                      <h3 className="text-lg font-semibold mt-0.5">Sales rhythm</h3>
                    </div>
                    <Badge variant="outline" className="border-accent/35 text-xs">
                      <Zap className="mr-1 h-3 w-3 text-accent" />
                      Pulse
                    </Badge>
                  </div>
                  <div className="h-52">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={weeklyPerformance.dailyRevenue}>
                        <XAxis
                          dataKey="label"
                          axisLine={false}
                          tickLine={false}
                          tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }}
                        />
                        <Tooltip
                          cursor={{ fill: "hsl(var(--accent) / 0.10)" }}
                          formatter={(value) => [formatWholeCurrency(Number(value)), "Revenue"]}
                          contentStyle={{
                            borderRadius: "10px",
                            border: "1px solid hsl(var(--border))",
                            background: "hsl(var(--card))",
                            fontSize: "12px",
                          }}
                        />
                        <Bar dataKey="revenue" radius={[8, 8, 3, 3]} fill="hsl(var(--accent))" />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                  <div className="mt-3 grid grid-cols-2 gap-2.5">
                    <div className="rounded-lg bg-card border border-border/60 p-2.5">
                      <p className="text-label text-muted-foreground">Orders</p>
                      <p className="text-xl font-semibold tabular-nums mt-0.5">{weeklyPerformance.orderCount}</p>
                    </div>
                    <div className="rounded-lg bg-card border border-border/60 p-2.5">
                      <p className="text-label text-muted-foreground">Avg / unit</p>
                      <p className="text-xl font-semibold tabular-nums mt-0.5">
                        {formatWholeCurrency(
                          weeklyPerformance.totalUnits
                            ? weeklyPerformance.totalRevenue / weeklyPerformance.totalUnits
                            : 0,
                        )}
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="lg:col-span-3">
                <div className="h-full rounded-xl border border-border/70 bg-background/70 p-5 shadow-soft">
                  <p className="text-label text-muted-foreground mb-4">Mix + action cues</p>
                  <div className="space-y-3.5">
                    {weeklyPerformance.typeMix.map((type) => (
                      <div key={type.type}>
                        <div className="mb-1.5 flex items-center justify-between text-sm">
                          <span className="font-medium text-foreground">{type.type}</span>
                          <span className="tabular-nums text-muted-foreground">{type.sharePercent}%</span>
                        </div>
                        <div className="h-1.5 overflow-hidden rounded-full bg-muted">
                          <div
                            className="h-full rounded-full bg-success transition-all"
                            style={{ width: `${type.sharePercent}%` }}
                          />
                        </div>
                      </div>
                    ))}
                  </div>

                  <div className="mt-5 rounded-lg border border-accent/25 bg-accent/8 p-3.5">
                    <p className="mb-1.5 flex items-center gap-1.5 text-sm font-semibold">
                      <TrendingUp className="h-4 w-4 text-accent" />
                      Next best move
                    </p>
                    <p className="text-xs text-muted-foreground leading-relaxed">
                      Promote {topPerformer?.name} while demand is hot
                      {topPerformer?.stockLeft !== null && topPerformer?.stockLeft !== undefined
                        ? `, and prep a reorder before it drops below ${Math.min(topPerformer.stockLeft, 5)} units.`
                        : "."}
                    </p>
                  </div>

                  {(topPerformer?.effects?.length || topPerformer?.terpenes?.length) ? (
                    <div className="mt-4 flex flex-wrap gap-1.5">
                      {topPerformer?.effects?.map((effect) => (
                        <Badge key={effect} variant="outline" className="border-success/30 text-success text-xs">
                          {effect}
                        </Badge>
                      ))}
                      {topPerformer?.terpenes?.map((terpene) => (
                        <Badge key={terpene} variant="secondary" className="text-xs">
                          {terpene}
                        </Badge>
                      ))}
                    </div>
                  ) : null}
                </div>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default WeeklyStrainPerformancePanel;
