import { useEffect, useMemo, useState } from "react";
import { Loader2, Search, Package } from "lucide-react";
import { toast } from "sonner";
import { useQueryClient } from "@tanstack/react-query";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { syncCatalogImageToProduct, type CatalogImageCandidate } from "@/lib/catalogImages";
import { cn } from "@/lib/utils";

interface ProductRow {
  id: string;
  name: string | null;
  brand: string | null;
  strain: string | null;
  sku: string | null;
}

interface Props {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  image: CatalogImageCandidate | null;
}

export default function AssignToProductDialog({ open, onOpenChange, image }: Props) {
  const [query, setQuery] = useState("");
  const [products, setProducts] = useState<ProductRow[]>([]);
  const [loading, setLoading] = useState(false);
  const [assigningId, setAssigningId] = useState<string | null>(null);
  const queryClient = useQueryClient();

  useEffect(() => {
    if (!open) return;
    let cancelled = false;
    const load = async () => {
      setLoading(true);
      let q = supabase
        .from("products")
        .select("id, name, brand, strain, sku")
        .order("updated_at", { ascending: false })
        .limit(50);
      const term = query.trim();
      if (term) {
        q = q.or(
          `name.ilike.%${term}%,brand.ilike.%${term}%,strain.ilike.%${term}%,sku.ilike.%${term}%`,
        );
      }
      const { data, error } = await q;
      if (cancelled) return;
      if (error) {
        toast.error(error.message);
      } else {
        setProducts((data ?? []) as ProductRow[]);
      }
      setLoading(false);
    };
    const t = setTimeout(load, 200);
    return () => {
      cancelled = true;
      clearTimeout(t);
    };
  }, [open, query]);

  const handleAssign = async (product: ProductRow) => {
    if (!image) return;
    setAssigningId(product.id);
    try {
      await syncCatalogImageToProduct({ supabase, productId: product.id, candidate: image });
      await Promise.all([
        queryClient.invalidateQueries({ queryKey: ["products"] }),
        queryClient.invalidateQueries({ queryKey: ["products", product.id] }),
      ]);
      toast.success(`Image assigned to ${product.name ?? product.strain ?? "product"}.`);
      onOpenChange(false);
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Assignment failed");
    } finally {
      setAssigningId(null);
    }
  };

  const preview = useMemo(() => image, [image]);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl border-2 border-border bg-card">
        <DialogHeader>
          <DialogTitle className="font-serif text-2xl">Assign to Product</DialogTitle>
          <DialogDescription>
            Attach this image to any existing catalog product. It becomes the new primary image.
          </DialogDescription>
        </DialogHeader>

        {preview && (
          <div className="flex items-center gap-3 rounded-lg border border-border bg-muted/30 p-3">
            <img
              src={preview.thumbnailUrl || preview.url}
              alt={preview.alt}
              className="h-16 w-16 rounded-md object-cover"
            />
            <div className="min-w-0 flex-1">
              <p className="truncate text-sm font-medium text-foreground">{preview.alt}</p>
              <p className="truncate text-xs text-muted-foreground">{preview.source}</p>
            </div>
          </div>
        )}

        <div className="relative">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search by name, brand, strain, or SKU…"
            className="h-10 border-border bg-background pl-10"
            autoFocus
          />
        </div>

        <div className="max-h-[360px] overflow-y-auto rounded-lg border border-border">
          {loading ? (
            <div className="flex items-center justify-center py-10">
              <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
            </div>
          ) : products.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-10 text-center">
              <Package className="mb-2 h-6 w-6 text-muted-foreground" />
              <p className="text-sm text-muted-foreground">No products found.</p>
            </div>
          ) : (
            <ul className="divide-y divide-border">
              {products.map((p) => (
                <li
                  key={p.id}
                  className={cn(
                    "flex items-center justify-between gap-3 px-3 py-2.5 transition-colors hover:bg-accent/10",
                  )}
                >
                  <div className="min-w-0">
                    <p className="truncate text-sm font-semibold text-foreground">
                      {p.name || p.strain || "Untitled"}
                    </p>
                    <p className="truncate text-xs text-muted-foreground">
                      {[p.brand, p.strain, p.sku].filter(Boolean).join(" • ") || "—"}
                    </p>
                  </div>
                  <Button
                    size="sm"
                    variant="gold"
                    disabled={assigningId === p.id || !image}
                    onClick={() => void handleAssign(p)}
                  >
                    {assigningId === p.id ? (
                      <Loader2 className="h-3.5 w-3.5 animate-spin" />
                    ) : (
                      "Assign"
                    )}
                  </Button>
                </li>
              ))}
            </ul>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
