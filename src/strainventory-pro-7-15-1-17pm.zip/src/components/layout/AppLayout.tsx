import { useState } from "react";
import { Outlet } from "react-router-dom";
import { Menu } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { useIsMobile } from "@/hooks/use-mobile";
import AppSidebar from "./AppSidebar";
import GlobalAssistantDrawer from "@/components/assistant/GlobalAssistantDrawer";
import { MessengerNotificationsProvider } from "@/context/MessengerNotificationsContext";
import { useBusinessSettings } from "@/hooks/useBusinessSettings";

const AppLayout = () => {
  const isMobile = useIsMobile();
  const [open, setOpen] = useState(false);
  const { settings } = useBusinessSettings();
  const brandName = settings?.business_name?.trim() || "Strain-ventory";

  const shell = isMobile ? (
    <div className="app-ambient-shell min-h-screen">
      <header className="sticky top-0 z-40 flex items-center h-14 border-b border-sidebar-border/70 bg-sidebar/90 px-4 text-sidebar-accent-foreground backdrop-blur-xl">
        <Sheet open={open} onOpenChange={setOpen}>
          <SheetTrigger asChild>
            <Button variant="ghost" size="icon" className="mr-2" aria-label="Open navigation menu">
              <Menu className="h-5 w-5" />
            </Button>
          </SheetTrigger>
          <SheetContent side="left" className="p-0 w-64">
            <AppSidebar onNavigate={() => setOpen(false)} />
          </SheetContent>
        </Sheet>
        <span className="wordmark-shimmer text-sm font-semibold">{brandName}</span>
      </header>
      <main className="min-h-[calc(100vh-3.5rem)]">
        <Outlet />
      </main>
      <GlobalAssistantDrawer />
    </div>
  ) : (
    <div className="app-ambient-shell min-h-screen">
      <AppSidebar />
      <main className="ml-64 min-h-screen">
        <Outlet />
      </main>
      <GlobalAssistantDrawer />
    </div>
  );

  return <MessengerNotificationsProvider>{shell}</MessengerNotificationsProvider>;
};

export default AppLayout;
