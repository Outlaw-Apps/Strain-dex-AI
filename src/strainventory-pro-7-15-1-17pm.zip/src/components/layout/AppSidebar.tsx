import { NavLink, useLocation } from "react-router-dom";
import {
  LayoutDashboard,
  Library,
  Upload,
  ImageIcon,
  FileCheck,
  Bot,
  LogOut,
  ClipboardCheck,
  ShoppingCart,
  Settings,
  DollarSign,
  // PackagePlus removed: Product Intake now uses the Vinny icon in the AI Draft slot.
  ClipboardList,
  MessageCircle,
  User,
  CalendarDays,
  Tag,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { motion } from "framer-motion";
import logoImg from "@/assets/Cannabis_logo.png";
import { StrainVinnyAvatar } from "@/components/StrainVinnyAvatar";
import { useMessengerNotificationsContext } from "@/context/MessengerNotificationsContext";
import ThemeToggle from "@/components/ThemeToggle";
import { useAuth } from "@/context/AuthContext";
import { useUserRoles } from "@/hooks/useUserRoles";
import { useBusinessSettings } from "@/hooks/useBusinessSettings";
import { toast } from "sonner";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Badge } from "@/components/ui/badge";

// ─── Nav structure ────────────────────────────────────────────────────────────

interface NavItem {
  to: string;
  icon: React.ElementType;
  label: string;
  aiPulse?: boolean;
}

interface NavGroup {
  label: string;
  items: NavItem[];
}

function VinnyIcon({ className }: { className?: string }) {
  return (
    <StrainVinnyAvatar className={cn("vinny-sidebar-icon", className)} />
  );
}

const navGroups: NavGroup[] = [
  {
    label: "Catalog",
    items: [
      { to: "/", icon: LayoutDashboard, label: "Dashboard" },
      { to: "/ai-draft", icon: VinnyIcon, label: "Product Intake", aiPulse: true },
      { to: "/image-finder", icon: ImageIcon, label: "Image Finder" },
      { to: "/review", icon: FileCheck, label: "Review & Edit" },
      { to: "/catalog", icon: Library, label: "Catalog" },
      { to: "/label-maker", icon: Tag, label: "Label Maker" },
      { to: "/bulk-intake", icon: Upload, label: "Bulk Intake" },
    ],
  },
  {
    label: "Operations",
    items: [
      { to: "/pos", icon: ShoppingCart, label: "Point of Sale" },
      { to: "/shift-close", icon: ClipboardList, label: "Shift Close" },
      { to: "/schedule", icon: CalendarDays, label: "Schedule" },
      { to: "/payroll", icon: DollarSign, label: "Payroll" },
    ],
  },
  {
    label: "Team",
    items: [
      { to: "/assistant", icon: Bot, label: "Assistant", aiPulse: true },
      { to: "/messages", icon: MessageCircle, label: "Messages" },
    ],
  },
];

// ─── Sub-components ───────────────────────────────────────────────────────────

function SidebarNavItem({
  item,
  onClick,
  badgeCount,
}: {
  item: NavItem;
  onClick?: () => void;
  badgeCount?: number;
}) {
  const location = useLocation();
  const isActive =
    item.to === "/" ? location.pathname === "/" : location.pathname.startsWith(item.to);
  const hasAiPulse = item.aiPulse === true;
  const hasBadge = typeof badgeCount === "number" && badgeCount > 0;

  return (
    <NavLink
      to={item.to}
      onClick={onClick}
      className={cn(
        "group relative flex items-center gap-2.5 rounded-md px-3 py-2 text-sm font-medium transition-colors duration-150",
        hasAiPulse && "pr-7 ai-pulse-marker",
        isActive
          ? "text-sidebar-primary-foreground"
          : "text-sidebar-foreground hover:bg-sidebar-accent/60 hover:text-sidebar-accent-foreground"
      )}
    >
      {isActive && (
        <motion.div
          layoutId="sidebar-active"
          className="nav-metallic-active absolute inset-0 rounded-md"
          transition={{ type: "spring", bounce: 0.15, duration: 0.45 }}
        />
      )}
      <span className="relative z-10 inline-flex shrink-0 items-center">
        <item.icon className="h-4 w-4" />
        {hasBadge && (
          <span
            aria-label={`${badgeCount} unread`}
            className="absolute -right-1.5 -top-1 flex h-4 min-w-4 items-center justify-center rounded-full bg-red-500 px-1 text-[10px] font-semibold leading-none text-white shadow-sm"
          >
            {badgeCount > 9 ? "9+" : badgeCount}
          </span>
        )}
      </span>
      <span className="relative z-10 truncate">{item.label}</span>
    </NavLink>
  );
}

function SidebarSection({
  group,
  onNavigate,
  badgeCounts,
}: {
  group: NavGroup;
  onNavigate?: () => void;
  badgeCounts?: Record<string, number>;
}) {
  return (
    <div className="mb-1">
      <p className="mb-1 px-3 text-[10px] font-semibold uppercase tracking-widest text-sidebar-foreground/40 select-none">
        {group.label}
      </p>
      <div className="space-y-0.5">
        {group.items.map((item) => (
          <SidebarNavItem
            key={item.to}
            item={item}
            onClick={onNavigate}
            badgeCount={badgeCounts?.[item.to]}
          />
        ))}
      </div>
    </div>
  );
}

// ─── Role badge helper ────────────────────────────────────────────────────────

function roleBadgeLabel(roles: string[]): string {
  if (roles.includes("admin")) return "Admin";
  if (roles.includes("reviewer")) return "Reviewer";
  return "Staff";
}

// ─── Main component ───────────────────────────────────────────────────────────

interface AppSidebarProps {
  onNavigate?: () => void;
}

const AppSidebar = ({ onNavigate }: AppSidebarProps) => {
  const location = useLocation();
  const { user, signOut } = useAuth();
  const { roles, isAdmin } = useUserRoles();
  const { settings } = useBusinessSettings();

  const displayBrandName = settings?.business_name?.trim() || "Strain-ventory";
  const displayLogo = settings?.logo_url || logoImg;

  // Badge count on the Messages nav item — sourced from the shared
  // MessengerNotifications context (provided in AppLayout).
  const { unreadCount } = useMessengerNotificationsContext();
  const badgeCounts: Record<string, number> = { "/messages": unreadCount };

  const handleLogout = async () => {
    await signOut();
    toast.success("Signed out.");
  };

  const displayEmail = user?.email ?? "—";

  const { data: myProfile } = useQuery({
    queryKey: ["my-profile", user?.id],
    enabled: !!user?.id,
    staleTime: 60_000,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("profiles")
        .select("full_name, avatar_url")
        .eq("id", user!.id)
        .maybeSingle();
      if (error) throw error;
      return data;
    },
  });

  const displayName =
    myProfile?.full_name?.trim() ||
    (user?.user_metadata?.full_name as string | undefined)?.trim() ||
    displayEmail.split("@")[0];
  const avatarUrl =
    myProfile?.avatar_url ||
    (user?.user_metadata?.avatar_url as string | undefined) ||
    "";


  return (
    <aside className="sidebar-luxe-shell flex h-screen w-64 flex-col overflow-hidden border-r border-sidebar-border md:fixed md:left-0 md:top-0 md:z-40">

      {/* ── Logo bar ── */}
      <div className="flex items-center justify-between px-5 py-5 border-b border-sidebar-border/60">
        <div className="flex items-center gap-3 min-w-0">
          <div className="logo-gold-ring flex h-10 w-10 shrink-0 items-center justify-center rounded-xl p-[2px]">
            <img
              src={displayLogo}
              alt={displayBrandName}
              className="h-full w-full rounded-[0.65rem] object-cover"
            />
          </div>
          <div className="min-w-0">
            <p className="wordmark-shimmer text-sm font-semibold tracking-tight truncate leading-tight">
              {displayBrandName}
            </p>
            <p className="catalog-ai-label mt-0.5 flex items-center gap-1 text-[10px] font-semibold tracking-widest uppercase leading-tight">
              <VinnyIcon className="h-3 w-3" />
              AI Catalog
            </p>
          </div>
        </div>
        <ThemeToggle />
      </div>

      {/* ── Navigation ── */}
      <nav className="sidebar-scrollbar min-h-0 flex-1 overflow-y-auto px-3 py-4 pr-2 space-y-4">
        {navGroups.map((group) => (
          <SidebarSection
            key={group.label}
            group={group}
            onNavigate={onNavigate}
            badgeCounts={badgeCounts}
          />
        ))}

        {/* Admin-only: Employee Onboarding */}
        {isAdmin && (
          <div className="pt-1 border-t border-sidebar-border/60">
            <p className="mb-1 px-3 text-[10px] font-semibold uppercase tracking-widest text-sidebar-foreground/40 select-none">
              Admin
            </p>
            <NavLink
              to="/onboarding"
              onClick={onNavigate}
              className={cn(
                "relative flex items-center gap-2.5 rounded-md px-3 py-2 text-sm font-medium transition-colors duration-150",
                location.pathname.startsWith("/onboarding")
                  ? "text-sidebar-primary-foreground"
                  : "text-sidebar-foreground hover:text-sidebar-accent-foreground hover:bg-sidebar-accent/60"
              )}
            >
              {location.pathname.startsWith("/onboarding") && (
                <motion.div
                  layoutId="sidebar-active"
                  className="nav-metallic-active absolute inset-0 rounded-md"
                  transition={{ type: "spring", bounce: 0.15, duration: 0.45 }}
                />
              )}
              <ClipboardCheck className="relative z-10 h-4 w-4 shrink-0" />
              <span className="relative z-10 truncate">Employee Onboarding</span>
            </NavLink>
          </div>
        )}
      </nav>

      {/* ── Footer ── */}
      <div className="border-t border-sidebar-border px-3 py-3 space-y-1">
        {/* Settings link */}
        <NavLink
          to="/settings"
          onClick={onNavigate}
          className={cn(
            "relative flex items-center gap-2.5 rounded-md px-3 py-2 text-sm font-medium transition-colors duration-150",
            location.pathname.startsWith("/settings")
              ? "text-sidebar-primary-foreground"
              : "text-sidebar-foreground hover:text-sidebar-accent-foreground hover:bg-sidebar-accent/60"
          )}
        >
          {location.pathname.startsWith("/settings") && (
            <motion.div
              layoutId="sidebar-active"
              className="nav-metallic-active absolute inset-0 rounded-md"
              transition={{ type: "spring", bounce: 0.15, duration: 0.45 }}
            />
          )}
          <Settings className="relative z-10 h-4 w-4 shrink-0" />
          <span className="relative z-10">Settings</span>
        </NavLink>

        {/* User card */}
        <div className="user-gold-card flex items-center gap-2.5 rounded-md border px-3 py-2.5">
          <div className="user-gold-avatar flex h-7 w-7 shrink-0 items-center justify-center rounded-full overflow-hidden">
            {avatarUrl ? (
              <img src={avatarUrl} alt={displayName} className="h-full w-full object-cover" />
            ) : (
              <User className="h-3.5 w-3.5" />
            )}
          </div>
          <div className="min-w-0 flex-1">
            <p className="text-xs font-semibold text-sidebar-primary truncate leading-tight">
              {displayName}
            </p>
            <p className="text-[10px] text-sidebar-foreground/50 truncate leading-tight mt-0.5">
              {displayEmail}
            </p>
          </div>
          {roles.length > 0 && (
            <Badge
              variant="secondary"
              className="shrink-0 text-[9px] uppercase tracking-wider bg-sidebar-primary/20 text-sidebar-primary border-0 px-1.5 py-0"
            >
              {roleBadgeLabel(roles)}
            </Badge>
          )}
        </div>

        {/* Sign out */}
        <button
          onClick={handleLogout}
          className="signout-cyan-hover flex w-full items-center gap-2.5 rounded-md px-3 py-2 text-sm text-sidebar-foreground transition-colors duration-150"
        >
          <LogOut className="h-4 w-4 shrink-0" />
          <span>Sign Out</span>
        </button>
      </div>
    </aside>
  );
};

export default AppSidebar;
