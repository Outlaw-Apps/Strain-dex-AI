import { AlertCircle } from "lucide-react";
import { Label } from "@/components/ui/label";

interface FieldGroupProps {
  label: string;
  error?: string;
  required?: boolean;
  hint?: string;
  children: React.ReactNode;
}

const FieldGroup = ({ label, error, required, hint, children }: FieldGroupProps) => (
  <div className="space-y-1.5">
    <Label className="text-sm font-medium text-foreground">
      {label} {required && <span className="text-destructive">*</span>}
    </Label>
    {hint && <p className="text-[11px] text-muted-foreground">{hint}</p>}
    {children}
    {error && (
      <p className="text-xs text-destructive flex items-center gap-1">
        <AlertCircle className="h-3 w-3" /> {error}
      </p>
    )}
  </div>
);

export default FieldGroup;
