import { useMemo, useRef, useState } from "react";
import {
  CheckCircle2, Circle, FileText, Loader2, Plus, Send,
  Upload, Download, ShieldCheck, XCircle,
} from "lucide-react";
import { useUserRoles } from "@/hooks/useUserRoles";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle, DialogTrigger,
} from "@/components/ui/dialog";
import {
  useOnboardingMutations,
  useOnboardingProgress,
  type OnboardingChecklistItem,
} from "@/hooks/useOnboardingProgress";

interface Props {
  employeeId: string;
  employeeName?: string;
  employeeRole?: string;
}

const CATEGORY_LABEL: Record<string, string> = {
  documents: "Documents",
  compliance: "Compliance",
  payroll: "Payroll",
  scheduling: "Scheduling",
  training: "Training",
  general: "General",
};

export default function OnboardingProgressPanel({ employeeId, employeeName, employeeRole }: Props) {
  const { data, isLoading } = useOnboardingProgress(employeeId);
  const m = useOnboardingMutations(employeeId);
  const { isAdmin, isReviewer } = useUserRoles();
  const canVerify = isAdmin || isReviewer;
  const [docOpen, setDocOpen] = useState(false);
  const [docType, setDocType] = useState("");
  const [docLabel, setDocLabel] = useState("");
  const [docNotes, setDocNotes] = useState("");
  const [rejectingId, setRejectingId] = useState<string | null>(null);
  const [rejectReason, setRejectReason] = useState("");
  const [uploadingId, setUploadingId] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [pendingRequestId, setPendingRequestId] = useState<string | null>(null);

  const handleFilePick = (requestId: string) => {
    setPendingRequestId(requestId);
    fileInputRef.current?.click();
  };

  const handleFileChosen = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = "";
    if (!file || !pendingRequestId) return;
    if (file.size > 15 * 1024 * 1024) {
      return;
    }
    setUploadingId(pendingRequestId);
    try {
      await m.uploadDocument.mutateAsync({ id: pendingRequestId, file });
    } finally {
      setUploadingId(null);
      setPendingRequestId(null);
    }
  };

  const openSigned = async (path: string) => {
    const url = await m.getSignedUrl(path);
    if (url) window.open(url, "_blank");
  };

  const statusVariant = (s: string): "default" | "secondary" | "destructive" | "outline" => {
    if (s === "verified") return "default";
    if (s === "rejected") return "destructive";
    if (s === "submitted") return "secondary";
    return "outline";
  };

  const checklist = data?.checklists?.[0];
  const items = checklist?.onboarding_checklist_items ?? [];
  const documents = data?.documents ?? [];

  const grouped = useMemo(() => {
    const g: Record<string, OnboardingChecklistItem[]> = {};
    for (const it of items) {
      (g[it.category] ??= []).push(it);
    }
    return g;
  }, [items]);

  if (isLoading) {
    return (
      <div className="p-6 flex items-center gap-2 text-muted-foreground">
        <Loader2 className="h-4 w-4 animate-spin" /> Loading onboarding progress…
      </div>
    );
  }

  if (!checklist) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Onboarding Checklist</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <p className="text-sm text-muted-foreground">
            No checklist yet for {employeeName ?? "this employee"}. Generate the default
            California dispensary checklist to start tracking progress.
          </p>
          <Button
            variant="gold"
            onClick={() => m.generateChecklist.mutate(employeeRole ?? "default")}
            disabled={m.generateChecklist.isPending}
            className="gap-2"
          >
            {m.generateChecklist.isPending ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              <Plus className="h-4 w-4" />
            )}
            Generate Onboarding Checklist
          </Button>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className="text-lg">
              Onboarding Progress
              {employeeName ? <span className="text-muted-foreground font-normal"> · {employeeName}</span> : null}
            </CardTitle>
            <Badge variant={checklist.status === "completed" ? "default" : "secondary"}>
              {checklist.status.replace("_", " ")}
            </Badge>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <div className="flex items-center justify-between mb-1.5 text-sm">
              <span className="text-muted-foreground">Overall completion</span>
              <span className="font-semibold">{checklist.progress_percent}%</span>
            </div>
            <Progress value={checklist.progress_percent} />
          </div>

          {Object.entries(grouped).map(([category, catItems]) => (
            <div key={category} className="space-y-2">
              <h4 className="text-xs uppercase tracking-wide text-muted-foreground font-semibold">
                {CATEGORY_LABEL[category] ?? category}
              </h4>
              <ul className="space-y-1.5">
                {catItems.map((item) => {
                  const done = item.status === "completed";
                  return (
                    <li key={item.id} className="flex items-start gap-3">
                      <button
                        type="button"
                        onClick={() =>
                          m.toggleItem.mutate({ id: item.id, completed: !done })
                        }
                        className="mt-0.5 shrink-0"
                        aria-label={done ? "Mark incomplete" : "Mark complete"}
                      >
                        {done ? (
                          <CheckCircle2 className="h-5 w-5 text-emerald-500" />
                        ) : (
                          <Circle className="h-5 w-5 text-muted-foreground" />
                        )}
                      </button>
                      <div className="flex-1 min-w-0">
                        <div className={`text-sm ${done ? "line-through text-muted-foreground" : ""}`}>
                          {item.label}
                          {!item.required && (
                            <span className="ml-2 text-xs text-muted-foreground">(optional)</span>
                          )}
                        </div>
                        {item.due_date && (
                          <div className="text-xs text-muted-foreground">Due {item.due_date}</div>
                        )}
                      </div>
                    </li>
                  );
                })}
              </ul>
            </div>
          ))}
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className="text-lg flex items-center gap-2">
              <FileText className="h-4 w-4" /> Document Requests
            </CardTitle>
            <Dialog open={docOpen} onOpenChange={setDocOpen}>
              <DialogTrigger asChild>
                <Button size="sm" variant="outline" className="gap-1.5">
                  <Send className="h-3.5 w-3.5" /> Request
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Request a document</DialogTitle>
                </DialogHeader>
                <div className="space-y-3">
                  <div>
                    <Label htmlFor="doc-type">Document type</Label>
                    <Input
                      id="doc-type"
                      value={docType}
                      onChange={(e) => setDocType(e.target.value)}
                      placeholder="e.g. w4, i9, direct_deposit"
                    />
                  </div>
                  <div>
                    <Label htmlFor="doc-label">Display label</Label>
                    <Input
                      id="doc-label"
                      value={docLabel}
                      onChange={(e) => setDocLabel(e.target.value)}
                      placeholder="e.g. Signed W-4"
                    />
                  </div>
                  <div>
                    <Label htmlFor="doc-notes">Notes (optional)</Label>
                    <Input
                      id="doc-notes"
                      value={docNotes}
                      onChange={(e) => setDocNotes(e.target.value)}
                    />
                  </div>
                </div>
                <DialogFooter>
                  <Button variant="outline" onClick={() => setDocOpen(false)}>Cancel</Button>
                  <Button
                    variant="gold"
                    disabled={!docType || !docLabel || m.requestDocument.isPending}
                    onClick={async () => {
                      await m.requestDocument.mutateAsync({
                        doc_type: docType,
                        label: docLabel,
                        notes: docNotes || undefined,
                      });
                      setDocType(""); setDocLabel(""); setDocNotes("");
                      setDocOpen(false);
                    }}
                  >
                    Send request
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </div>
        </CardHeader>
        <CardContent>
          <input
            ref={fileInputRef}
            type="file"
            className="hidden"
            accept="image/jpeg,image/png,image/webp,application/pdf"
            onChange={handleFileChosen}
          />
          {documents.length === 0 ? (
            <p className="text-sm text-muted-foreground">No outstanding document requests.</p>
          ) : (
            <ul className="space-y-3">
              {documents.map((d) => {
                const isUploading = uploadingId === d.id;
                return (
                  <li key={d.id} className="rounded-md border border-border/60 p-3 space-y-2">
                    <div className="flex items-start justify-between gap-3">
                      <div className="min-w-0">
                        <div className="text-sm font-medium truncate">{d.label}</div>
                        <div className="text-xs text-muted-foreground">
                          {d.doc_type} · requested {new Date(d.requested_at).toLocaleDateString()}
                          {d.due_date ? ` · due ${d.due_date}` : ""}
                        </div>
                        {d.file_name && (
                          <div className="text-xs mt-1">
                            <FileText className="h-3 w-3 inline mr-1" />
                            {d.file_name}
                            {d.file_size ? ` · ${(d.file_size / 1024).toFixed(0)} KB` : ""}
                          </div>
                        )}
                        {d.status === "rejected" && d.rejection_reason && (
                          <div className="text-xs text-destructive mt-1">
                            Rejected: {d.rejection_reason}
                          </div>
                        )}
                      </div>
                      <Badge variant={statusVariant(d.status)} className="shrink-0 capitalize">
                        {d.status}
                      </Badge>
                    </div>

                    <div className="flex flex-wrap items-center gap-2 pt-1">
                      {d.storage_path && (
                        <Button
                          size="sm"
                          variant="outline"
                          className="gap-1.5"
                          onClick={() => openSigned(d.storage_path!)}
                        >
                          <Download className="h-3.5 w-3.5" />
                          View
                        </Button>
                      )}
                      {(d.status === "pending" || d.status === "rejected") && (
                        <Button
                          size="sm"
                          variant="outline"
                          className="gap-1.5"
                          disabled={isUploading}
                          onClick={() => handleFilePick(d.id)}
                        >
                          {isUploading ? (
                            <Loader2 className="h-3.5 w-3.5 animate-spin" />
                          ) : (
                            <Upload className="h-3.5 w-3.5" />
                          )}
                          {d.storage_path ? "Replace file" : "Upload file"}
                        </Button>
                      )}
                      {canVerify && d.status === "submitted" && (
                        <>
                          <Button
                            size="sm"
                            variant="default"
                            className="gap-1.5"
                            onClick={() => m.verifyDocument.mutate(d.id)}
                            disabled={m.verifyDocument.isPending}
                          >
                            <ShieldCheck className="h-3.5 w-3.5" />
                            Verify
                          </Button>
                          <Button
                            size="sm"
                            variant="ghost"
                            className="gap-1.5 text-destructive"
                            onClick={() => {
                              setRejectingId(d.id);
                              setRejectReason(d.rejection_reason ?? "");
                            }}
                          >
                            <XCircle className="h-3.5 w-3.5" />
                            Reject
                          </Button>
                        </>
                      )}
                    </div>
                  </li>
                );
              })}
            </ul>
          )}
        </CardContent>
      </Card>

      <Dialog open={!!rejectingId} onOpenChange={(o) => !o && setRejectingId(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Reject document</DialogTitle>
          </DialogHeader>
          <div className="space-y-2">
            <Label htmlFor="reject-reason">Reason (shared with the employee)</Label>
            <Textarea
              id="reject-reason"
              value={rejectReason}
              onChange={(e) => setRejectReason(e.target.value)}
              placeholder="e.g. Photo is blurry — please re-upload a clear scan."
              rows={3}
            />
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setRejectingId(null)}>Cancel</Button>
            <Button
              variant="destructive"
              disabled={!rejectReason.trim() || m.rejectDocument.isPending}
              onClick={async () => {
                if (!rejectingId) return;
                await m.rejectDocument.mutateAsync({ id: rejectingId, reason: rejectReason.trim() });
                setRejectingId(null);
                setRejectReason("");
              }}
            >
              Reject document
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
