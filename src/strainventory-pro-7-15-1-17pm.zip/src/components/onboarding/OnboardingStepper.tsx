import { motion } from "framer-motion";
import { CheckCircle2, type LucideIcon } from "lucide-react";
import { Progress } from "@/components/ui/progress";
import { cn } from "@/lib/utils";

export interface OnboardingStep {
  label: string;
  icon: LucideIcon;
  description: string;
}

interface OnboardingStepperProps {
  steps: readonly OnboardingStep[];
  currentStep: number;
}

const OnboardingStepper = ({ steps, currentStep }: OnboardingStepperProps) => {
  const progressValue = ((currentStep + 1) / steps.length) * 100;

  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, delay: 0.1 }}
      className="mb-8"
    >
      <div className="flex items-center justify-between mb-4">
        {steps.map((step, idx) => {
          const StepIcon = step.icon;
          const isActive = idx === currentStep;
          const isCompleted = idx < currentStep;
          return (
            <div key={step.label} className="flex-1 flex flex-col items-center relative">
              <div
                className={cn(
                  "w-10 h-10 rounded-full flex items-center justify-center border-2 transition-all duration-300",
                  isActive && "bg-accent border-accent text-accent-foreground shadow-md",
                  isCompleted && "bg-green-500/20 border-green-500 text-green-600",
                  !isActive && !isCompleted && "bg-muted border-border text-muted-foreground",
                )}
              >
                {isCompleted ? <CheckCircle2 className="h-5 w-5" /> : <StepIcon className="h-5 w-5" />}
              </div>
              <p className={cn(
                "text-xs mt-2 font-medium transition-colors",
                isActive ? "text-foreground" : "text-muted-foreground",
              )}>
                {step.label}
              </p>
              <p className="text-[10px] text-muted-foreground hidden sm:block">{step.description}</p>
            </div>
          );
        })}
      </div>
      <Progress value={progressValue} className="h-1.5" />
    </motion.div>
  );
};

export default OnboardingStepper;
