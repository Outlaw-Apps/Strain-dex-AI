import { Shield } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { cn } from "@/lib/utils";
import FieldGroup from "./FieldGroup";
import { LIVE_SCAN_OPTIONS, ROLE_OPTIONS, type StepProps } from "./types";

const StepDCCCompliance = ({ formData, updateField, getError }: StepProps) => (
  <>
    <div className="flex items-center gap-2 mb-1">
      <Shield className="h-5 w-5 text-accent" />
      <h2 className="text-lg font-semibold text-foreground">DCC Compliance</h2>
    </div>
    <p className="text-sm text-muted-foreground mb-4">California Department of Cannabis Control compliance data.</p>

    <FieldGroup label="Role" error={getError("role")} required>
      <Select value={formData.role} onValueChange={(v) => updateField("role", v)}>
        <SelectTrigger className={cn("bg-background", getError("role") && "border-destructive")}>
          <SelectValue placeholder="Select a role…" />
        </SelectTrigger>
        <SelectContent>
          {ROLE_OPTIONS.map((opt) => (
            <SelectItem key={opt.value} value={opt.value}>{opt.label}</SelectItem>
          ))}
        </SelectContent>
      </Select>
    </FieldGroup>

    <FieldGroup label="Local Badge Number" error={getError("badgeNumber")} required>
      <Input
        placeholder="e.g. DCC-2026-0042"
        value={formData.badgeNumber}
        onChange={(e) => updateField("badgeNumber", e.target.value)}
        className={cn("bg-background", getError("badgeNumber") && "border-destructive")}
      />
    </FieldGroup>

    <FieldGroup label="Live Scan Status" error={getError("liveScanStatus")} required>
      <Select value={formData.liveScanStatus} onValueChange={(v) => updateField("liveScanStatus", v)}>
        <SelectTrigger className={cn("bg-background", getError("liveScanStatus") && "border-destructive")}>
          <SelectValue placeholder="Select status…" />
        </SelectTrigger>
        <SelectContent>
          {LIVE_SCAN_OPTIONS.map((opt) => (
            <SelectItem key={opt.value} value={opt.value}>{opt.label}</SelectItem>
          ))}
        </SelectContent>
      </Select>
    </FieldGroup>

    <FieldGroup label="MMIC Number" error={getError("mmicNumber")} hint="Optional — Medical Marijuana ID Card">
      <Input
        placeholder="e.g. MMIC-123456"
        value={formData.mmicNumber}
        onChange={(e) => updateField("mmicNumber", e.target.value)}
        className="bg-background"
      />
    </FieldGroup>
  </>
);

export default StepDCCCompliance;
