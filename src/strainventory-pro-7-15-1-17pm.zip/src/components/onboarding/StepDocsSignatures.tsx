import { AlertCircle, CheckCircle2, FileText, Upload } from "lucide-react";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { cn } from "@/lib/utils";
import FieldGroup from "./FieldGroup";
import type { StepProps } from "./types";

interface StepDocsProps extends StepProps {
  fileInputRef: React.RefObject<HTMLInputElement | null>;
  onFileChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
}

const StepDocsSignatures = ({ formData, updateField, getError, fileInputRef, onFileChange }: StepDocsProps) => (
  <>
    <div className="flex items-center gap-2 mb-1">
      <FileText className="h-5 w-5 text-accent" />
      <h2 className="text-lg font-semibold text-foreground">Documents & Signatures</h2>
    </div>
    <p className="text-sm text-muted-foreground mb-4">Upload required documents and acknowledge policies.</p>

    <FieldGroup label="Government ID" error={getError("governmentIdFile")} required hint="JPEG, PNG, WebP, or PDF — max 10 MB">
      <div
        onClick={() => fileInputRef.current?.click()}
        className={cn(
          "border-2 border-dashed rounded-lg p-6 text-center cursor-pointer transition-colors hover:border-accent hover:bg-accent/5",
          getError("governmentIdFile") ? "border-destructive bg-destructive/5" : "border-border",
          formData.governmentIdFile && "border-green-500 bg-green-500/5",
        )}
      >
        <input
          ref={fileInputRef}
          type="file"
          accept="image/jpeg,image/png,image/webp,application/pdf"
          onChange={onFileChange}
          className="hidden"
        />
        {formData.governmentIdFile ? (
          <div className="flex items-center justify-center gap-2 text-green-600">
            <CheckCircle2 className="h-5 w-5" />
            <span className="text-sm font-medium">{formData.governmentIdFile.name}</span>
          </div>
        ) : (
          <div className="flex flex-col items-center gap-2 text-muted-foreground">
            <Upload className="h-8 w-8" />
            <span className="text-sm">Click to upload Government ID</span>
          </div>
        )}
      </div>
    </FieldGroup>

    <div className="pt-2">
      <div className={cn(
        "flex items-start gap-3 rounded-lg border p-4 transition-colors",
        getError("sopAcknowledged") ? "border-destructive bg-destructive/5" : "border-border",
        formData.sopAcknowledged && "border-green-500/40 bg-green-500/5",
      )}>
        <Checkbox
          id="sop-ack"
          checked={formData.sopAcknowledged}
          onCheckedChange={(checked) => updateField("sopAcknowledged", checked === true)}
        />
        <div className="flex-1">
          <Label htmlFor="sop-ack" className="text-sm font-medium text-foreground cursor-pointer">
            SOP & Employee Handbook Acknowledgment <span className="text-destructive">*</span>
          </Label>
          <p className="text-xs text-muted-foreground mt-1">
            I confirm that the employee has received, reviewed, and acknowledged the Standard Operating Procedures and Employee Handbook.
          </p>
        </div>
      </div>
      {getError("sopAcknowledged") && (
        <p className="text-xs text-destructive mt-1.5 flex items-center gap-1">
          <AlertCircle className="h-3 w-3" /> {getError("sopAcknowledged")}
        </p>
      )}
    </div>
  </>
);

export default StepDocsSignatures;
