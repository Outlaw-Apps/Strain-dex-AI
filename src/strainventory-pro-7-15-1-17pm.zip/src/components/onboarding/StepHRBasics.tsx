import { UserPlus } from "lucide-react";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";
import FieldGroup from "./FieldGroup";
import { getTodayLocal, type StepProps } from "./types";

const StepHRBasics = ({ formData, updateField, getError }: StepProps) => (
  <>
    <div className="flex items-center gap-2 mb-1">
      <UserPlus className="h-5 w-5 text-accent" />
      <h2 className="text-lg font-semibold text-foreground">HR Basics</h2>
    </div>
    <p className="text-sm text-muted-foreground mb-4">Collect the new hire's personal information.</p>

    <FieldGroup label="Legal Full Name" error={getError("fullName")} required>
      <Input
        placeholder="e.g. Maria Elena Rodriguez"
        value={formData.fullName}
        onChange={(e) => updateField("fullName", e.target.value)}
        className={cn("bg-background", getError("fullName") && "border-destructive")}
      />
    </FieldGroup>

    <FieldGroup label="Date of Birth" error={getError("dateOfBirth")} required hint="Must be 21+ per California law">
      <Input
        type="date"
        value={formData.dateOfBirth}
        onChange={(e) => updateField("dateOfBirth", e.target.value)}
        max={getTodayLocal()}
        className={cn("bg-background", getError("dateOfBirth") && "border-destructive")}
      />
    </FieldGroup>

    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
      <FieldGroup label="Phone Number" error={getError("phone")} required>
        <Input
          type="tel"
          placeholder="(555) 123-4567"
          value={formData.phone}
          onChange={(e) => updateField("phone", e.target.value)}
          className={cn("bg-background", getError("phone") && "border-destructive")}
        />
      </FieldGroup>

      <FieldGroup label="Email Address" error={getError("email")} required>
        <Input
          type="email"
          placeholder="employee@dispensary.com"
          value={formData.email}
          onChange={(e) => updateField("email", e.target.value)}
          className={cn("bg-background", getError("email") && "border-destructive")}
        />
      </FieldGroup>
    </div>

    <FieldGroup label="Emergency Contact" error={getError("emergencyContact")} required>
      <Input
        placeholder="Name — Relationship — Phone"
        value={formData.emergencyContact}
        onChange={(e) => updateField("emergencyContact", e.target.value)}
        className={cn("bg-background", getError("emergencyContact") && "border-destructive")}
      />
    </FieldGroup>
  </>
);

export default StepHRBasics;
