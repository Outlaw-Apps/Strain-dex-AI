export interface OnboardingFormData {
  fullName: string;
  dateOfBirth: string;
  phone: string;
  email: string;
  emergencyContact: string;
  role: string;
  badgeNumber: string;
  liveScanStatus: string;
  mmicNumber: string;
  governmentIdFile: File | null;
  sopAcknowledged: boolean;
}

export interface FieldError {
  field: string;
  message: string;
}

export interface StepProps {
  formData: OnboardingFormData;
  updateField: <K extends keyof OnboardingFormData>(field: K, value: OnboardingFormData[K]) => void;
  getError: (field: string) => string | undefined;
}

export const initialOnboardingFormData: OnboardingFormData = {
  fullName: "",
  dateOfBirth: "",
  phone: "",
  email: "",
  emergencyContact: "",
  role: "",
  badgeNumber: "",
  liveScanStatus: "",
  mmicNumber: "",
  governmentIdFile: null,
  sopAcknowledged: false,
};

export const ROLE_OPTIONS = [
  { value: "budtender", label: "Budtender" },
  { value: "shift_lead", label: "Shift Lead" },
  { value: "inventory", label: "Inventory" },
  { value: "security", label: "Security" },
] as const;

export const LIVE_SCAN_OPTIONS = [
  { value: "pending", label: "Pending" },
  { value: "cleared", label: "Cleared" },
] as const;

export const ROLE_TO_APP_ROLE: Record<string, string> = {
  budtender: "staff",
  shift_lead: "staff",
  inventory: "staff",
  security: "staff",
};

export function calculateAge(dob: string): number {
  const [year, month, day] = dob.split("-").map(Number);
  const birth = new Date(year, month - 1, day);
  const today = new Date();
  let age = today.getFullYear() - birth.getFullYear();
  const monthDiff = today.getMonth() - birth.getMonth();
  if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birth.getDate())) {
    age--;
  }
  return age;
}

export function getTodayLocal(): string {
  const d = new Date();
  const yyyy = d.getFullYear();
  const mm = String(d.getMonth() + 1).padStart(2, "0");
  const dd = String(d.getDate()).padStart(2, "0");
  return `${yyyy}-${mm}-${dd}`;
}

export const ONBOARDING_MIME_TO_EXT: Record<string, string> = {
  "image/jpeg": "jpg",
  "image/png": "png",
  "image/webp": "webp",
  "application/pdf": "pdf",
};
