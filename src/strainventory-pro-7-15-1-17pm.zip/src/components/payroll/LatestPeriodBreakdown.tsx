import { ScrollArea } from "@/components/ui/scroll-area";
import PayrollEmptyState from "./PayrollEmptyState";
import { formatCurrency } from "@/lib/payroll/payrollFormatters";

interface Payslip {
  id: string;
  employee_id: string;
  regular_hours: number;
  ot_hours: number;
  gross_pay: number;
  net_pay: number;
}

interface LatestPeriodBreakdownProps {
  payslips: Payslip[];
  profileMap: Map<string, string>;
}

const LatestPeriodBreakdown = ({ payslips, profileMap }: LatestPeriodBreakdownProps) => {
  if (payslips.length === 0) {
    return <PayrollEmptyState message="No payslips for this period yet." />;
  }
  return (
    <ScrollArea className="max-h-80">
      <div className="divide-y divide-border/50">
        {payslips.map((slip) => (
          <div key={slip.id} className="px-5 py-3">
            <div className="flex items-center justify-between">
              <p className="text-sm font-medium text-foreground">
                {profileMap.get(slip.employee_id) ?? slip.employee_id.slice(0, 8)}
              </p>
              <p className="text-sm font-semibold text-accent tabular-nums">
                {formatCurrency(slip.net_pay)}
              </p>
            </div>
            <p className="text-xs text-muted-foreground mt-0.5">
              {slip.regular_hours}h reg · {slip.ot_hours}h OT · Gross {formatCurrency(slip.gross_pay)}
            </p>
          </div>
        ))}
      </div>
    </ScrollArea>
  );
};

export default LatestPeriodBreakdown;
