import { ScrollArea } from "@/components/ui/scroll-area";
import PayrollEmptyState from "./PayrollEmptyState";
import { formatCurrency, formatPayDate } from "@/lib/payroll/payrollFormatters";

interface Payslip {
  id: string;
  created_at: string;
  regular_hours: number;
  ot_hours: number;
  doubletime_hours: number;
  net_pay: number;
}

interface MyPaystubsListProps {
  payslips: Payslip[];
}

const MyPaystubsList = ({ payslips }: MyPaystubsListProps) => {
  if (payslips.length === 0) {
    return <PayrollEmptyState message="No paystubs available yet." />;
  }
  return (
    <ScrollArea className="max-h-96">
      <div className="divide-y divide-border/50">
        {payslips.map((slip) => (
          <div key={slip.id} className="flex items-center justify-between px-5 py-3 hover:bg-muted/20 transition-colors">
            <div>
              <p className="text-sm font-medium text-foreground">
                Pay Period: {formatPayDate(slip.created_at)}
              </p>
              <p className="text-xs text-muted-foreground mt-0.5">
                {slip.regular_hours} reg hrs · {slip.ot_hours} OT · {slip.doubletime_hours} DT
              </p>
            </div>
            <div className="text-right">
              <p className="text-sm font-semibold text-accent tabular-nums">{formatCurrency(slip.net_pay)}</p>
              <p className="text-[10px] text-muted-foreground">Net Pay</p>
            </div>
          </div>
        ))}
      </div>
    </ScrollArea>
  );
};

export default MyPaystubsList;
