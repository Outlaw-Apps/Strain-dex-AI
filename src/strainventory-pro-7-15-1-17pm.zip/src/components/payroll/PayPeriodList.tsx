import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { cn } from "@/lib/utils";
import PayrollEmptyState from "./PayrollEmptyState";
import {
  formatCurrency,
  formatPayDate,
  payrollStatusColors,
} from "@/lib/payroll/payrollFormatters";

interface PayPeriod {
  id: string;
  start_date: string;
  end_date: string;
  status: string;
  total_wages: number | null;
  total_ot_hours: number | null;
}

interface PayPeriodListProps {
  payPeriods: PayPeriod[];
}

const PayPeriodList = ({ payPeriods }: PayPeriodListProps) => {
  if (payPeriods.length === 0) {
    return <PayrollEmptyState message="No pay periods yet. Run your first payroll to get started." />;
  }
  return (
    <ScrollArea className="max-h-96">
      <div className="divide-y divide-border/50">
        {payPeriods.map((pp) => (
          <div key={pp.id} className="flex items-center justify-between px-5 py-3 hover:bg-muted/20 transition-colors">
            <div>
              <p className="text-sm font-medium text-foreground">
                {formatPayDate(pp.start_date)} — {formatPayDate(pp.end_date)}
              </p>
              <p className="text-xs text-muted-foreground mt-0.5">
                {formatCurrency(pp.total_wages ?? 0)} · {pp.total_ot_hours ?? 0} premium hrs
              </p>
            </div>
            <Badge variant="secondary" className={cn("text-[10px] uppercase tracking-wider", payrollStatusColors[pp.status])}>
              {pp.status}
            </Badge>
          </div>
        ))}
      </div>
    </ScrollArea>
  );
};

export default PayPeriodList;
