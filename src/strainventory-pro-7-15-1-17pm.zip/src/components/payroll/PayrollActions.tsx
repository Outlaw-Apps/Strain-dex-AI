import { CheckCircle2, Download, Loader2, Printer } from "lucide-react";
import { Button } from "@/components/ui/button";

interface PayrollActionsProps {
  hasPreviewResults: boolean;
  isProcessing: boolean;
  isIssuing: boolean;
  isExportingSummaryPdf: boolean;
  isPrintingChecks?: boolean;
  savedRunId: string | null;
  issueButtonLabel: string;
  onExportCSV: () => void;
  onExportSummaryPdf: () => void;
  onProcess: () => void;
  onIssuePaychecks: () => void;
  onPrintChecks?: () => void;
}

const PayrollActions = ({
  hasPreviewResults, isProcessing, isIssuing, isExportingSummaryPdf, isPrintingChecks,
  savedRunId, issueButtonLabel,
  onExportCSV, onExportSummaryPdf, onProcess, onIssuePaychecks, onPrintChecks,
}: PayrollActionsProps) => (
  <div className="flex flex-wrap gap-2 justify-end">
    {onPrintChecks && (
      <Button
        variant="outline"
        size="sm"
        className="gap-1.5"
        onClick={onPrintChecks}
        disabled={!hasPreviewResults || isPrintingChecks}
      >
        {isPrintingChecks ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Printer className="h-3.5 w-3.5" />}
        Print Checks
      </Button>
    )}
    <Button variant="outline" size="sm" className="gap-1.5" onClick={onExportCSV}>
      <Download className="h-3.5 w-3.5" />
      CSV
    </Button>
    <Button
      variant="outline"
      size="sm"
      className="gap-1.5"
      onClick={onExportSummaryPdf}
      disabled={!hasPreviewResults || isExportingSummaryPdf}
    >
      {isExportingSummaryPdf ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Download className="h-3.5 w-3.5" />}
      Summary PDF
    </Button>
    <Button
      variant="outline"
      size="sm"
      className="gap-1.5"
      onClick={onProcess}
      disabled={!hasPreviewResults || isProcessing || isIssuing || Boolean(savedRunId)}
    >
      {isProcessing ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <CheckCircle2 className="h-3.5 w-3.5" />}
      Process & Save
    </Button>
    <Button
      variant="gold"
      size="sm"
      className="gap-1.5"
      onClick={onIssuePaychecks}
      disabled={!hasPreviewResults || isProcessing || isIssuing}
    >
      {isIssuing ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <CheckCircle2 className="h-3.5 w-3.5" />}
      {issueButtonLabel}
    </Button>
  </div>
);

export default PayrollActions;
