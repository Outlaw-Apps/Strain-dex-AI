import { useMemo, useRef, useState } from "react";
import { toast } from "sonner";
import { AlertTriangle, CheckCircle2, FileSpreadsheet, Loader2, Printer, Upload, X } from "lucide-react";
import {
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { Card, CardContent } from "@/components/ui/card";
import { cn } from "@/lib/utils";
import {
  buildEmployeeLookup, guessColumn, mapCsvRows, parseCsv,
  type CsvImportRow, type CsvMapping,
} from "@/lib/payroll/csvImport";
import { useCheckTemplates, useIncrementCheckNumber } from "@/hooks/useCheckTemplates";
import { buildChecksPdf } from "@/lib/payroll/checkPdf";

interface PayrollCsvImportDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  profileMap: Map<string, string>;
}

const currencyFormatter = new Intl.NumberFormat("en-US", { style: "currency", currency: "USD" });

const NONE = "__none__";

function downloadBytes(bytes: Uint8Array, name: string) {
  const blob = new Blob([bytes as BlobPart], { type: "application/pdf" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = name;
  document.body.appendChild(a);
  a.click();
  a.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 1_000);
}

export function PayrollCsvImportDialog({ open, onOpenChange, profileMap }: PayrollCsvImportDialogProps) {
  const fileRef = useRef<HTMLInputElement | null>(null);
  const [fileName, setFileName] = useState<string>("");
  const [rows, setRows] = useState<string[][]>([]);
  const [hasHeader, setHasHeader] = useState(true);
  const [mapping, setMapping] = useState<CsvMapping>({
    employee: 0, amount: 1, memo: null, date: null, checkNumber: null,
  });
  const [templateId, setTemplateId] = useState<string>("");
  const [isPrinting, setIsPrinting] = useState(false);
  const [overrides, setOverrides] = useState<Record<number, string>>({}); // rowIndex → employeeId

  const { data: templates = [] } = useCheckTemplates();
  const activeTemplates = useMemo(() => templates.filter((t) => t.is_active), [templates]);
  const incrementCheckNumber = useIncrementCheckNumber();

  const employeeOptions = useMemo(
    () => Array.from(profileMap.entries()).map(([id, name]) => ({ id, name })),
    [profileMap],
  );

  const headers = useMemo<string[]>(() => {
    if (rows.length === 0) return [];
    return hasHeader ? rows[0].map((h) => h.trim()) : rows[0].map((_, i) => `Column ${i + 1}`);
  }, [rows, hasHeader]);

  const mappedRows = useMemo<CsvImportRow[]>(() => {
    if (rows.length === 0) return [];
    const base = mapCsvRows(rows, mapping, profileMap, hasHeader);
    // Apply overrides
    return base.map((r) => {
      const override = overrides[r.rowIndex];
      if (override && override !== r.employeeId) {
        return {
          ...r,
          employeeId: override,
          employeeName: profileMap.get(override) ?? r.employeeName,
          status: "matched" as const,
          message: undefined,
        };
      }
      return r;
    });
  }, [rows, mapping, profileMap, hasHeader, overrides]);

  const readyRows = useMemo(
    () => mappedRows.filter((r) => r.status === "matched" && r.amount > 0),
    [mappedRows],
  );

  const totalAmount = readyRows.reduce((sum, r) => sum + r.amount, 0);

  const reset = () => {
    setFileName("");
    setRows([]);
    setOverrides({});
    setMapping({ employee: 0, amount: 1, memo: null, date: null, checkNumber: null });
    if (fileRef.current) fileRef.current.value = "";
  };

  const handleFile = async (file: File) => {
    if (file.size > 5 * 1024 * 1024) {
      toast.error("CSV files larger than 5 MB are not supported.");
      return;
    }
    const text = await file.text();
    const parsed = parseCsv(text);
    if (parsed.length === 0) {
      toast.error("The CSV appears to be empty.");
      return;
    }
    setFileName(file.name);
    setRows(parsed);
    setOverrides({});

    // Auto-guess columns using the header row
    const guessHeaders = (parsed[0] ?? []).map((h) => h.trim());
    const empIdx = guessColumn(guessHeaders, ["employee", "name", "payee", "employee name"]) ?? 0;
    const amtIdx = guessColumn(guessHeaders, ["amount", "net", "net pay", "pay", "check amount", "total"]) ?? Math.min(1, guessHeaders.length - 1);
    const memoIdx = guessColumn(guessHeaders, ["memo", "note", "description"]);
    const dateIdx = guessColumn(guessHeaders, ["date", "check date", "pay date"]);
    const numIdx = guessColumn(guessHeaders, ["check", "check number", "check #", "number"]);
    setMapping({
      employee: empIdx,
      amount: amtIdx,
      memo: memoIdx,
      date: dateIdx,
      checkNumber: numIdx,
    });
  };

  const summary = useMemo(() => {
    const matched = mappedRows.filter((r) => r.status === "matched").length;
    const unmatched = mappedRows.filter((r) => r.status === "unmatched").length;
    const invalid = mappedRows.filter((r) => r.status === "invalid_amount").length;
    const dupes = mappedRows.filter((r) => r.status === "duplicate").length;
    return { matched, unmatched, invalid, dupes, total: mappedRows.length };
  }, [mappedRows]);

  const printBatch = async () => {
    const tpl = activeTemplates.find((t) => t.id === templateId);
    if (!tpl) {
      toast.error("Select a check template first.");
      return;
    }
    if (readyRows.length === 0) {
      toast.error("No rows are ready to print. Fix unmatched employees or invalid amounts.");
      return;
    }
    setIsPrinting(true);
    try {
      const startNo = tpl.next_check_number;
      let assignedCount = 0;
      const checks = readyRows.map((r) => {
        const useNo = r.checkNumber ?? startNo + assignedCount;
        if (r.checkNumber === null) assignedCount += 1;
        return {
          payee_name: r.employeeName,
          amount: r.amount,
          memo: r.memo || undefined,
          check_number: useNo,
          date: r.date ?? new Date(),
        };
      });
      const bytes = buildChecksPdf({ template: tpl, checks });
      downloadBytes(bytes, `payroll-checks-import-${startNo}.pdf`);
      if (assignedCount > 0) {
        await incrementCheckNumber.mutateAsync({ id: tpl.id, by: assignedCount });
      }
      toast.success(`Printed ${checks.length} check(s) from imported CSV.`);
      onOpenChange(false);
      reset();
    } catch (err) {
      toast.error("Failed to print checks from CSV. See console for details.");
      console.error(err);
    } finally {
      setIsPrinting(false);
    }
  };

  return (
    <Dialog
      open={open}
      onOpenChange={(v) => {
        onOpenChange(v);
        if (!v) reset();
      }}
    >
      <DialogContent className="max-w-4xl max-h-[92vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <FileSpreadsheet className="h-5 w-5 text-accent" />
            Import Payroll CSV
          </DialogTitle>
          <DialogDescription>
            Upload a CSV, map columns to employees and amounts, then print a check batch from the results.
          </DialogDescription>
        </DialogHeader>

        {rows.length === 0 ? (
          <label
            className="flex flex-col items-center justify-center gap-3 border-2 border-dashed border-border rounded-2xl p-10 cursor-pointer hover:border-accent transition-colors"
          >
            <Upload className="h-8 w-8 text-muted-foreground" />
            <div className="text-sm text-foreground font-medium">Click to upload a CSV file</div>
            <div className="text-xs text-muted-foreground">Max 5 MB • UTF-8 encoded</div>
            <input
              ref={fileRef}
              type="file"
              accept=".csv,text/csv"
              className="hidden"
              onChange={(e) => {
                const file = e.target.files?.[0];
                if (file) void handleFile(file);
              }}
            />
          </label>
        ) : (
          <div className="space-y-4">
            <div className="flex items-center justify-between gap-3 flex-wrap">
              <div className="flex items-center gap-2 text-sm text-foreground">
                <FileSpreadsheet className="h-4 w-4 text-accent" />
                <span className="font-medium truncate max-w-[280px]">{fileName}</span>
                <Badge variant="outline" className="text-[10px]">
                  {rows.length - (hasHeader ? 1 : 0)} rows
                </Badge>
              </div>
              <div className="flex items-center gap-3">
                <div className="flex items-center gap-2">
                  <Switch id="has-header" checked={hasHeader} onCheckedChange={setHasHeader} />
                  <Label htmlFor="has-header" className="text-xs">First row is header</Label>
                </div>
                <Button variant="ghost" size="sm" onClick={reset} className="gap-1.5">
                  <X className="h-3.5 w-3.5" /> Clear
                </Button>
              </div>
            </div>

            <Card className="border border-border">
              <CardContent className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 p-4">
                <div>
                  <Label className="text-xs">Employee column <span className="text-destructive">*</span></Label>
                  <Select
                    value={String(mapping.employee)}
                    onValueChange={(v) => setMapping({ ...mapping, employee: Number(v) })}
                  >
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {headers.map((h, i) => (
                        <SelectItem key={i} value={String(i)}>{h}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label className="text-xs">Amount column <span className="text-destructive">*</span></Label>
                  <Select
                    value={String(mapping.amount)}
                    onValueChange={(v) => setMapping({ ...mapping, amount: Number(v) })}
                  >
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {headers.map((h, i) => (
                        <SelectItem key={i} value={String(i)}>{h}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label className="text-xs">Memo column</Label>
                  <Select
                    value={mapping.memo === null ? NONE : String(mapping.memo)}
                    onValueChange={(v) => setMapping({ ...mapping, memo: v === NONE ? null : Number(v) })}
                  >
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value={NONE}>— None —</SelectItem>
                      {headers.map((h, i) => (
                        <SelectItem key={i} value={String(i)}>{h}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label className="text-xs">Date column</Label>
                  <Select
                    value={mapping.date === null ? NONE : String(mapping.date)}
                    onValueChange={(v) => setMapping({ ...mapping, date: v === NONE ? null : Number(v) })}
                  >
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value={NONE}>— None (uses today) —</SelectItem>
                      {headers.map((h, i) => (
                        <SelectItem key={i} value={String(i)}>{h}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label className="text-xs">Check number column</Label>
                  <Select
                    value={mapping.checkNumber === null ? NONE : String(mapping.checkNumber)}
                    onValueChange={(v) => setMapping({ ...mapping, checkNumber: v === NONE ? null : Number(v) })}
                  >
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value={NONE}>— None (auto-assign) —</SelectItem>
                      {headers.map((h, i) => (
                        <SelectItem key={i} value={String(i)}>{h}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label className="text-xs">Check template <span className="text-destructive">*</span></Label>
                  <Select value={templateId} onValueChange={setTemplateId}>
                    <SelectTrigger><SelectValue placeholder="Select template" /></SelectTrigger>
                    <SelectContent>
                      {activeTemplates.length === 0 ? (
                        <div className="px-2 py-1.5 text-xs text-muted-foreground">
                          No active templates — add one in Settings → Payroll
                        </div>
                      ) : activeTemplates.map((t) => (
                        <SelectItem key={t.id} value={t.id}>
                          {t.name} — next #{t.next_check_number}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </CardContent>
            </Card>

            <div className="flex flex-wrap items-center gap-3 text-xs">
              <Badge variant="secondary" className="gap-1"><CheckCircle2 className="h-3 w-3" /> {summary.matched} matched</Badge>
              {summary.unmatched > 0 && (
                <Badge variant="destructive" className="gap-1"><AlertTriangle className="h-3 w-3" /> {summary.unmatched} unmatched</Badge>
              )}
              {summary.invalid > 0 && (
                <Badge variant="destructive" className="gap-1"><AlertTriangle className="h-3 w-3" /> {summary.invalid} invalid amount</Badge>
              )}
              {summary.dupes > 0 && (
                <Badge variant="outline" className="gap-1">{summary.dupes} duplicates skipped</Badge>
              )}
              <span className="text-muted-foreground ml-auto">
                Batch total: <strong className="text-foreground">{currencyFormatter.format(totalAmount)}</strong>
              </span>
            </div>

            <div className="border border-border rounded-xl overflow-hidden max-h-[320px] overflow-y-auto">
              <table className="w-full text-xs">
                <thead className="bg-muted/50 sticky top-0">
                  <tr>
                    <th className="text-left px-3 py-2">Row</th>
                    <th className="text-left px-3 py-2">Source</th>
                    <th className="text-left px-3 py-2">Employee match</th>
                    <th className="text-right px-3 py-2">Amount</th>
                    <th className="text-left px-3 py-2">Memo</th>
                    <th className="text-left px-3 py-2">Status</th>
                  </tr>
                </thead>
                <tbody>
                  {mappedRows.map((r) => (
                    <tr
                      key={r.rowIndex}
                      className={cn(
                        "border-t border-border",
                        r.status === "invalid_amount" && "bg-destructive/5",
                        r.status === "duplicate" && "bg-warning/5",
                      )}
                    >
                      <td className="px-3 py-2 text-muted-foreground">{r.rowIndex}</td>
                      <td className="px-3 py-2 truncate max-w-[140px]">{r.employeeInput || "—"}</td>
                      <td className="px-3 py-2">
                        <Select
                          value={r.employeeId ?? NONE}
                          onValueChange={(v) => {
                            const next = { ...overrides };
                            if (v === NONE) delete next[r.rowIndex];
                            else next[r.rowIndex] = v;
                            setOverrides(next);
                          }}
                        >
                          <SelectTrigger className="h-7 text-xs w-[180px]">
                            <SelectValue placeholder="Pick employee" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value={NONE}>— Skip —</SelectItem>
                            {employeeOptions.map((e) => (
                              <SelectItem key={e.id} value={e.id}>{e.name}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </td>
                      <td className="px-3 py-2 text-right font-mono">
                        {r.status === "invalid_amount" ? "—" : currencyFormatter.format(r.amount)}
                      </td>
                      <td className="px-3 py-2 truncate max-w-[160px]">{r.memo || "—"}</td>
                      <td className="px-3 py-2">
                        {r.status === "matched" ? (
                          <Badge variant="secondary" className="text-[10px]">Ready</Badge>
                        ) : r.status === "unmatched" ? (
                          <Badge variant="destructive" className="text-[10px]">Unmatched</Badge>
                        ) : r.status === "duplicate" ? (
                          <Badge variant="outline" className="text-[10px]">Duplicate</Badge>
                        ) : (
                          <Badge variant="destructive" className="text-[10px]">Bad amount</Badge>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button
            variant="gold"
            onClick={printBatch}
            disabled={rows.length === 0 || readyRows.length === 0 || !templateId || isPrinting}
            className="gap-1.5"
          >
            {isPrinting ? <Loader2 className="h-4 w-4 animate-spin" /> : <Printer className="h-4 w-4" />}
            Print {readyRows.length} Check{readyRows.length === 1 ? "" : "s"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

export default PayrollCsvImportDialog;
