import { FileText } from "lucide-react";

interface EmptyStateProps {
  message: string;
}

const PayrollEmptyState = ({ message }: EmptyStateProps) => (
  <div className="text-center py-8 px-4">
    <FileText className="h-6 w-6 mx-auto mb-2 text-muted-foreground/30" />
    <p className="text-sm text-muted-foreground">{message}</p>
  </div>
);

export default PayrollEmptyState;
