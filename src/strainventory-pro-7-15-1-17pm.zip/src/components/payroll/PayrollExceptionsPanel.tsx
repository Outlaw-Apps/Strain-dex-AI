import { AlertTriangle, CheckCircle2, Loader2 } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import {
  usePayrollExceptions,
  useResolvePayrollException,
} from "@/hooks/usePayrollExceptions";

interface Props {
  payPeriodId?: string;
}

const severityColor: Record<string, string> = {
  error: "bg-destructive/15 text-destructive border-destructive/40",
  warning: "bg-warning/15 text-warning border-warning/40",
  info: "bg-muted text-muted-foreground border-border",
};

const kindLabels: Record<string, string> = {
  missing_clockout: "Missing clock-out",
  high_overtime: "High overtime",
  missing_rate: "Missing pay rate",
  manual: "Manual flag",
};

export default function PayrollExceptionsPanel({ payPeriodId }: Props) {
  const { data: exceptions = [], isLoading } = usePayrollExceptions(payPeriodId);
  const resolve = useResolvePayrollException();

  const open = exceptions.filter((e) => e.status === "open");
  const resolved = exceptions.length - open.length;

  return (
    <Card className="border-2 border-border bg-card shadow-elevated rounded-2xl">
      <CardHeader className="pb-3">
        <CardTitle className="text-base flex items-center gap-2">
          <AlertTriangle className="h-4 w-4 text-accent" />
          Payroll Exceptions
          {open.length > 0 && (
            <Badge variant="destructive" className="ml-1">
              {open.length} open
            </Badge>
          )}
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        {isLoading ? (
          <div className="flex justify-center py-6">
            <Loader2 className="h-5 w-5 animate-spin text-accent" />
          </div>
        ) : exceptions.length === 0 ? (
          <div className="flex items-center gap-2 text-sm text-muted-foreground py-4">
            <CheckCircle2 className="h-4 w-4 text-success" />
            No exceptions flagged for this period.
          </div>
        ) : (
          <>
            <ul className="space-y-2">
              {open.map((exc) => (
                <li
                  key={exc.id}
                  className={`rounded-lg border px-3 py-2 text-sm ${
                    severityColor[exc.severity] ?? severityColor.info
                  }`}
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="min-w-0">
                      <p className="font-semibold">
                        {kindLabels[exc.kind] ?? exc.kind}
                      </p>
                      <p className="text-xs mt-0.5 opacity-90 leading-snug">
                        {exc.message}
                      </p>
                    </div>
                    <Button
                      size="sm"
                      variant="outline"
                      disabled={resolve.isPending}
                      onClick={() =>
                        resolve.mutate(
                          { id: exc.id },
                          {
                            onSuccess: () => toast.success("Exception resolved"),
                            onError: (e: unknown) =>
                              toast.error(
                                e instanceof Error ? e.message : "Failed",
                              ),
                          },
                        )
                      }
                    >
                      Resolve
                    </Button>
                  </div>
                </li>
              ))}
            </ul>
            {resolved > 0 && (
              <p className="text-xs text-muted-foreground pt-1">
                {resolved} resolved / {exceptions.length} total
              </p>
            )}
          </>
        )}
      </CardContent>
    </Card>
  );
}
