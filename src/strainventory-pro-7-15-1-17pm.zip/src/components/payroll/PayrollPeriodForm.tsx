import { CalendarDays, DollarSign, Loader2, Users } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

interface PayrollPeriodFormProps {
  startDate: string;
  endDate: string;
  isCalculating: boolean;
  isLoading: boolean;
  activeProfileCount: number;
  onStartDateChange: (value: string) => void;
  onEndDateChange: (value: string) => void;
  onCalculate: () => void;
}

const PayrollPeriodForm = ({
  startDate, endDate, isCalculating, isLoading, activeProfileCount,
  onStartDateChange, onEndDateChange, onCalculate,
}: PayrollPeriodFormProps) => (
  <>
    <Card className="border-2 border-border bg-card shadow-elevated rounded-2xl">
      <CardHeader className="pb-3">
        <CardTitle className="text-base flex items-center gap-2">
          <CalendarDays className="h-4 w-4 text-accent" />
          Pay Period
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <Label className="text-xs text-muted-foreground">Start Date</Label>
          <Input
            type="date"
            value={startDate}
            onChange={(event) => onStartDateChange(event.target.value)}
            className="mt-1"
          />
        </div>
        <div>
          <Label className="text-xs text-muted-foreground">End Date</Label>
          <Input
            type="date"
            value={endDate}
            onChange={(event) => onEndDateChange(event.target.value)}
            className="mt-1"
          />
        </div>
        <Button
          variant="gold"
          className="w-full gap-2"
          onClick={onCalculate}
          disabled={isCalculating || isLoading}
        >
          {isCalculating ? <Loader2 className="h-4 w-4 animate-spin" /> : <DollarSign className="h-4 w-4" />}
          Calculate Payroll
        </Button>
      </CardContent>
    </Card>

    <Card className="border-2 border-border bg-card shadow-elevated rounded-2xl">
      <CardContent className="p-4">
        <div className="flex items-center gap-3">
          <div className="h-9 w-9 rounded-lg bg-muted flex items-center justify-center">
            <Users className="h-4 w-4 text-muted-foreground" />
          </div>
          <div>
            <p className="text-xs text-muted-foreground">Active Employees</p>
            <p className="text-lg font-semibold text-foreground">
              {isLoading ? "..." : activeProfileCount}
            </p>
          </div>
        </div>
      </CardContent>
    </Card>
  </>
);

export default PayrollPeriodForm;
