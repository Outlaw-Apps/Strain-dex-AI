import { AlertTriangle, Clock } from "lucide-react";
import { ScrollArea } from "@/components/ui/scroll-area";
import { cn } from "@/lib/utils";
import { formatCurrency } from "@/lib/payroll/payrollFormatters";
import type { PayrollBreakdown } from "@/lib/payroll/payroll.types";

interface PayrollPreviewTableProps {
  calculated: boolean;
  breakdowns: PayrollBreakdown[];
  profileMap: Map<string, string>;
}

const HEADINGS = ["EMPLOYEE", "REG HRS", "OT HRS", "DT HRS", "GROSS", "DEDUCT", "NET PAY"] as const;

const PayrollPreviewTable = ({ calculated, breakdowns, profileMap }: PayrollPreviewTableProps) => {
  if (!calculated) {
    return (
      <div className="text-center py-16 px-4">
        <Clock className="h-8 w-8 mx-auto mb-3 text-muted-foreground/30" />
        <p className="text-sm text-muted-foreground">
          Select a pay period and click "Calculate Payroll" to preview results.
        </p>
      </div>
    );
  }

  if (breakdowns.length === 0) {
    return (
      <div className="text-center py-16 px-4">
        <AlertTriangle className="h-8 w-8 mx-auto mb-3 text-warning/50" />
        <p className="text-sm text-muted-foreground">
          No time entries found for active employees in this period.
        </p>
      </div>
    );
  }

  return (
    <ScrollArea className="max-h-[520px]">
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead>
            <tr className="bg-muted/50 border-b-2 border-border">
              {HEADINGS.map((h) => (
                <th key={h} className="px-4 py-3 text-left text-[10px] font-bold text-muted-foreground uppercase tracking-wider">
                  {h}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {breakdowns.map((b) => {
              const hasOT = b.ot_hours > 0 || b.doubletime_hours > 0;
              return (
                <tr key={b.employee_id} className="border-t border-border hover:bg-muted/20 transition-colors">
                  <td className="px-4 py-3">
                    <p className="text-sm font-medium text-foreground">
                      {profileMap.get(b.employee_id) ?? b.employee_id.slice(0, 8)}
                    </p>
                  </td>
                  <td className="px-4 py-3 text-sm tabular-nums text-foreground">{b.regular_hours.toFixed(1)}</td>
                  <td className="px-4 py-3 text-sm tabular-nums">
                    <span className={cn(hasOT && "text-warning font-medium")}>{b.ot_hours.toFixed(1)}</span>
                  </td>
                  <td className="px-4 py-3 text-sm tabular-nums">
                    <span className={cn(b.doubletime_hours > 0 && "text-destructive font-medium")}>
                      {b.doubletime_hours.toFixed(1)}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-sm tabular-nums text-foreground">{formatCurrency(b.gross_pay)}</td>
                  <td className="px-4 py-3 text-sm tabular-nums text-muted-foreground">{formatCurrency(b.deductions)}</td>
                  <td className="px-4 py-3 text-sm font-semibold tabular-nums text-accent">{formatCurrency(b.net_pay)}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </ScrollArea>
  );
};

export default PayrollPreviewTable;
