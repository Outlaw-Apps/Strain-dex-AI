import { motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { cn } from "@/lib/utils";

interface SummaryCardProps {
  icon: React.ElementType;
  label: string;
  value: string;
  accent: "gold" | "default";
  delay: number;
}

const PayrollSummaryCard = ({ icon: Icon, label, value, accent, delay }: SummaryCardProps) => (
  <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay }}>
    <Card className={cn(
      "border-2 border-border bg-card shadow-elevated rounded-2xl transition-all hover:-translate-y-0.5",
      accent === "gold" && "shadow-gold border-accent/40",
    )}>
      <CardContent className="p-4 flex items-center gap-3">
        <div className={cn(
          "h-11 w-11 rounded-xl flex items-center justify-center shrink-0 border-2",
          accent === "gold" ? "gold-gradient border-accent" : "bg-muted border-border",
        )}>
          <Icon className={cn("h-5 w-5", accent === "gold" ? "text-accent-foreground" : "text-muted-foreground")} />
        </div>
        <div className="min-w-0">
          <p className="text-[11px] uppercase tracking-wider font-semibold text-muted-foreground truncate">{label}</p>
          <p className="text-lg sm:text-xl font-semibold text-foreground tabular-nums truncate">{value}</p>
        </div>
      </CardContent>
    </Card>
  </motion.div>
);

export default PayrollSummaryCard;
