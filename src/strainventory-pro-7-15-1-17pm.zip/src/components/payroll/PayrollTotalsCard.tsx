import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { cn } from "@/lib/utils";
import { formatCurrency } from "@/lib/payroll/payrollFormatters";

interface PayrollTotals {
  gross: number;
  net: number;
  ot: number;
  dt: number;
}

interface PayrollTotalsCardProps {
  totals: PayrollTotals;
}

function StatRow({ label, value, bold }: { label: string; value: string; bold?: boolean }) {
  return (
    <div className="flex items-center justify-between">
      <span className="text-sm text-muted-foreground">{label}</span>
      <span className={cn("text-sm tabular-nums", bold ? "font-semibold text-foreground" : "text-foreground")}>
        {value}
      </span>
    </div>
  );
}

const PayrollTotalsCard = ({ totals }: PayrollTotalsCardProps) => (
  <Card className="border-2 border-accent/40 bg-card shadow-elevated shadow-gold rounded-2xl">
    <CardHeader className="pb-2">
      <CardTitle className="text-base">Totals</CardTitle>
    </CardHeader>
    <CardContent className="space-y-2">
      <StatRow label="Total Gross" value={formatCurrency(totals.gross)} bold />
      <StatRow label="Total Net" value={formatCurrency(totals.net)} bold />
      <Separator />
      <StatRow label="OT Hours" value={`${totals.ot.toFixed(1)} hrs`} />
      <StatRow label="DT Hours" value={`${totals.dt.toFixed(1)} hrs`} />
    </CardContent>
  </Card>
);

export default PayrollTotalsCard;
