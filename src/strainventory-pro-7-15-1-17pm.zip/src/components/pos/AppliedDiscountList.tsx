import type { AppliedDiscount } from "@/lib/discounts/types";
import { cn } from "@/lib/utils";

interface Props {
  applied: AppliedDiscount[];
  emptyLabel?: string;
}

export function AppliedDiscountList({ applied, emptyLabel = "None" }: Props) {
  if (applied.length === 0) {
    return <p className="text-[10px] text-muted-foreground">{emptyLabel}</p>;
  }

  return (
    <ul className="space-y-1">
      {applied.map((a) => (
        <li
          key={`${a.definitionId}-${a.summary}`}
          className={cn(
            "flex justify-between gap-2 rounded border border-border/40 bg-muted/20 px-2 py-1 text-[10px]",
            a.automated && "opacity-95",
          )}
        >
          <span className="min-w-0 truncate text-muted-foreground">
            {a.definitionName}
            {a.summary ? ` · ${a.summary}` : ""}
          </span>
          <span className="shrink-0 tabular-nums text-foreground">−${a.amountOff.toFixed(2)}</span>
        </li>
      ))}
    </ul>
  );
}
