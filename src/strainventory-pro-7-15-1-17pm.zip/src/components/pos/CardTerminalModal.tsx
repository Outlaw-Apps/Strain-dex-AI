import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { CreditCard, CheckCircle2, Loader2, Zap } from "lucide-react";
import { Dialog, DialogContent, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { VisuallyHidden } from "@radix-ui/react-visually-hidden";

export type CardTerminalStatus = "awaiting" | "approved" | "posting";

interface Props {
  open: boolean;
  amount: number;
  status: CardTerminalStatus;
  onSimulateTap: () => void;
  onCancel: () => void;
}

const AUTO_TAP_MS = 3000;

export const CardTerminalModal = ({ open, amount, status, onSimulateTap, onCancel }: Props) => {
  const [elapsed, setElapsed] = useState(0);

  useEffect(() => {
    if (!open || status !== "awaiting") {
      setElapsed(0);
      return;
    }
    const start = Date.now();
    const interval = setInterval(() => setElapsed(Date.now() - start), 100);
    const timer = setTimeout(() => onSimulateTap(), AUTO_TAP_MS);
    return () => {
      clearInterval(interval);
      clearTimeout(timer);
    };
  }, [open, status, onSimulateTap]);

  const progress = Math.min(100, (elapsed / AUTO_TAP_MS) * 100);

  return (
    <Dialog open={open} onOpenChange={(o) => { if (!o && status === "awaiting") onCancel(); }}>
      <DialogContent
        className="max-w-md border-2 border-accent/40 bg-card/70 backdrop-blur-xl shadow-[0_0_60px_rgba(255,200,80,0.25)] p-0 overflow-hidden"
      >
        <VisuallyHidden>
          <DialogTitle>Card Payment Terminal</DialogTitle>
          <DialogDescription>Tap, insert, or swipe card to complete payment</DialogDescription>
        </VisuallyHidden>

        <div className="relative">
          {/* Glow background */}
          <div className="absolute inset-0 bg-gradient-to-br from-accent/10 via-transparent to-emerald-500/10 pointer-events-none" />

          <div className="relative p-8 flex flex-col items-center text-center">
            <AnimatePresence mode="wait">
              {status === "awaiting" && (
                <motion.div
                  key="awaiting"
                  initial={{ opacity: 0, y: 12 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -12 }}
                  className="flex flex-col items-center"
                >
                  <div className="relative mb-6">
                    <motion.div
                      animate={{ scale: [1, 1.15, 1], opacity: [0.6, 0.2, 0.6] }}
                      transition={{ duration: 1.6, repeat: Infinity, ease: "easeInOut" }}
                      className="absolute inset-0 rounded-full bg-accent/40 blur-xl"
                    />
                    <motion.div
                      animate={{ scale: [1, 1.08, 1] }}
                      transition={{ duration: 1.6, repeat: Infinity, ease: "easeInOut" }}
                      className="relative h-24 w-24 rounded-full gold-gradient flex items-center justify-center ring-2 ring-accent/60 shadow-gold"
                    >
                      <CreditCard className="h-10 w-10 text-accent-foreground" strokeWidth={2.5} />
                    </motion.div>
                  </div>

                  <h2 className="font-serif text-2xl font-bold text-foreground tracking-tight">
                    Awaiting Terminal…
                  </h2>
                  <p className="mt-1.5 text-sm text-muted-foreground font-medium">
                    Tap, insert, or swipe card to pay
                  </p>
                  <p className="mt-5 text-4xl font-extrabold tabular-nums text-foreground">
                    ${amount.toFixed(2)}
                  </p>

                  <div className="mt-6 w-full h-1.5 bg-muted rounded-full overflow-hidden">
                    <motion.div
                      className="h-full gold-gradient"
                      style={{ width: `${progress}%` }}
                    />
                  </div>

                  <div className="mt-6 flex gap-2 w-full">
                    <Button variant="outline" size="sm" className="flex-1 h-10" onClick={onCancel}>
                      Cancel
                    </Button>
                    <Button variant="gold" size="sm" className="flex-1 h-10 gap-1.5" onClick={onSimulateTap}>
                      <Zap className="h-4 w-4" strokeWidth={2.5} />
                      Simulate Tap
                    </Button>
                  </div>
                </motion.div>
              )}

              {status === "approved" && (
                <motion.div
                  key="approved"
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  className="flex flex-col items-center"
                >
                  <motion.div
                    initial={{ scale: 0 }}
                    animate={{ scale: [0, 1.2, 1] }}
                    transition={{ duration: 0.5, times: [0, 0.6, 1] }}
                    className="relative mb-6"
                  >
                    <div className="absolute inset-0 rounded-full bg-emerald-500/40 blur-2xl animate-pulse" />
                    <div className="relative h-24 w-24 rounded-full bg-emerald-500 flex items-center justify-center ring-4 ring-emerald-400/50 shadow-[0_0_40px_rgba(16,185,129,0.6)]">
                      <CheckCircle2 className="h-12 w-12 text-white" strokeWidth={2.5} />
                    </div>
                  </motion.div>
                  <h2 className="font-serif text-3xl font-extrabold text-emerald-400 tracking-tight drop-shadow-[0_0_12px_rgba(52,211,153,0.5)]">
                    Payment Approved
                  </h2>
                  <p className="mt-2 text-sm text-muted-foreground font-medium">
                    ${amount.toFixed(2)} charged successfully
                  </p>
                </motion.div>
              )}

              {status === "posting" && (
                <motion.div
                  key="posting"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="flex flex-col items-center"
                >
                  <Loader2 className="h-12 w-12 text-accent animate-spin mb-4" />
                  <p className="text-sm font-bold text-foreground">Finalizing order…</p>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};
