import { motion, AnimatePresence } from "framer-motion";
import { ShoppingCart, Minus, Plus, Trash2, CreditCard, Banknote, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { ScrollArea } from "@/components/ui/scroll-area";
import { cn } from "@/lib/utils";
import type { CartItem } from "@/pages/PointOfSale";
import {
  POS_WEIGHT_OPTIONS,
  formatDisplayNumber,
  getCartLineTotal,
  getWeightMultiplier,
  getWeightedUnitPrice,
} from "@/lib/posPricing";
import type { CartPricingResult, TicketPromotionSelection } from "@/lib/discounts/types";
import { DiscountButton } from "@/components/pos/DiscountButton";
import type { Customer } from "@/hooks/useCustomers";
import type { UseManagerOverride } from "@/hooks/useManagerOverride";
import type { PosDiscountPermissions } from "@/hooks/usePosDiscountPermissions";
import { Badge } from "@/components/ui/badge";

interface Props {
  cart: CartItem[];
  processing: boolean;
  isOverLimit: boolean;
  onUpdateQty: (id: string, delta: number) => void;
  onRemove: (id: string) => void;
  onUpdateWeight: (id: string, weight: string) => void;
  onCheckout: (method: string) => void;
  pricing: CartPricingResult;
  taxRate: number;
  customer: Customer | null;
  ticketPromotion: TicketPromotionSelection;
  onTicketPromotionChange: (t: TicketPromotionSelection) => void;
  managerOverride: UseManagerOverride;
  posDiscountPermissions: PosDiscountPermissions;
  employeePricingOk: boolean;
}

export const CartPanel = ({
  cart,
  processing,
  isOverLimit,
  onUpdateQty,
  onRemove,
  onUpdateWeight,
  onCheckout,
  pricing,
  taxRate,
  customer,
  ticketPromotion,
  onTicketPromotionChange,
  managerOverride,
  posDiscountPermissions,
  employeePricingOk,
}: Props) => (
  <div className="flex flex-col flex-1">
    <ScrollArea className="flex-1 p-4">
      <AnimatePresence>
        {cart.map((item) => {
          const priced = pricing.lines.find((l) => l.cartLineId === item.id);
          const pricePerGram = Number(item.price) || 0;
          const listUnit = getWeightedUnitPrice(pricePerGram, item.weight);
          const displayUnit = priced?.discountedUnitPrice ?? listUnit;
          const strikeList = priced && Math.abs(priced.listUnitPrice - priced.discountedUnitPrice) > 0.005;
          const lineTotal =
            priced?.lineTotalFinal ?? getCartLineTotal(pricePerGram, item.weight, item.qty);

          return (
            <motion.div
              key={item.id}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="mb-3 rounded-xl border-2 border-border/60 bg-card p-4 shadow-soft"
            >
              <div className="mb-2.5 flex items-start justify-between">
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-bold text-foreground">{item.name}</p>
                  <p className="text-xs text-muted-foreground font-medium">{item.brand}</p>
                  {(priced?.clearanceApplied || priced?.saleApplied) && (
                    <div className="mt-1.5 flex gap-1">
                      {priced?.clearanceApplied && (
                        <Badge variant="destructive" className="h-5 px-1.5 text-[10px] font-bold">
                          Clearance
                        </Badge>
                      )}
                      {priced?.saleApplied && !priced?.clearanceApplied && (
                        <Badge variant="secondary" className="h-5 border border-accent/40 bg-accent/15 px-1.5 text-[10px] text-accent font-bold">
                          Sale
                        </Badge>
                      )}
                    </div>
                  )}
                </div>
                <button onClick={() => onRemove(item.id)} className="p-1 text-destructive/50 hover:text-destructive transition-colors">
                  <Trash2 className="h-4 w-4" strokeWidth={2.5} />
                </button>
              </div>

              <div className="mb-2.5 flex gap-1.5">
                {POS_WEIGHT_OPTIONS.map((weightOption) => (
                  <button
                    key={weightOption}
                    onClick={() => onUpdateWeight(item.id, weightOption)}
                    className={cn(
                      "rounded-full px-2.5 py-1 text-[11px] font-bold transition-colors border",
                      item.weight === weightOption
                        ? "bg-accent text-accent-foreground border-accent"
                        : "bg-muted text-muted-foreground border-border hover:bg-muted/80",
                    )}
                  >
                    {weightOption}
                  </button>
                ))}
              </div>

              <p className="mb-2.5 text-xs text-muted-foreground font-medium">
                ${pricePerGram.toFixed(2)}/g · {formatDisplayNumber(getWeightMultiplier(item.weight))}g selected
              </p>

              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => onUpdateQty(item.id, -1)}
                    className="flex h-7 w-7 items-center justify-center rounded-lg bg-muted text-muted-foreground transition-colors hover:text-foreground border border-border"
                  >
                    <Minus className="h-3.5 w-3.5" strokeWidth={2.5} />
                  </button>
                  <span className="w-7 text-center text-sm font-bold tabular-nums">{item.qty}</span>
                  <button
                    onClick={() => onUpdateQty(item.id, 1)}
                    className="flex h-7 w-7 items-center justify-center rounded-lg bg-muted text-muted-foreground transition-colors hover:text-foreground border border-border"
                  >
                    <Plus className="h-3.5 w-3.5" strokeWidth={2.5} />
                  </button>
                </div>
                <div className="text-right">
                  <p className="text-xs tabular-nums text-muted-foreground">
                    {strikeList && (
                      <span className="mr-1 line-through">${priced!.listUnitPrice.toFixed(2)}</span>
                    )}
                    <span className="font-medium">${displayUnit.toFixed(2)}</span>
                    <span className="text-muted-foreground/80"> each</span>
                  </p>
                  <span className="text-base font-bold tabular-nums text-foreground">
                    ${lineTotal.toFixed(2)}
                  </span>
                </div>
              </div>
            </motion.div>
          );
        })}
      </AnimatePresence>

      {cart.length === 0 && (
        <div className="py-16 text-center text-muted-foreground">
          <ShoppingCart className="mx-auto mb-3 h-10 w-10 opacity-25" strokeWidth={1.5} />
          <p className="text-sm font-semibold">Cart is empty</p>
          <p className="mt-1 text-xs">Tap a product to add it</p>
        </div>
      )}
    </ScrollArea>

    <div className="space-y-3 border-t-2 border-border p-4 bg-gradient-to-b from-card to-accent/[0.02]">
      <DiscountButton
        customer={customer}
        ticket={ticketPromotion}
        onTicketChange={onTicketPromotionChange}
        previewPricing={pricing}
        managerOverride={managerOverride}
        permissions={posDiscountPermissions}
        employeePricingOk={employeePricingOk}
        disabled={cart.length === 0}
      />

      <div className="space-y-2">
        <div className="flex justify-between text-xs text-muted-foreground font-medium">
          <span>Catalog subtotal</span>
          <span className="tabular-nums">${pricing.listSubtotal.toFixed(2)}</span>
        </div>
        {pricing.discountTotal > 0.005 && (
          <div className="flex justify-between text-xs font-bold text-emerald-600">
            <span>Discounts</span>
            <span className="tabular-nums">−${pricing.discountTotal.toFixed(2)}</span>
          </div>
        )}
        <div className="flex justify-between text-xs font-bold text-foreground">
          <span>Subtotal (pre-tax)</span>
          <span className="tabular-nums">${pricing.taxableSubtotal.toFixed(2)}</span>
        </div>
        <div className="flex justify-between text-xs text-muted-foreground font-medium">
          <span>Tax ({(taxRate * 100).toFixed(0)}%)</span>
          <span className="tabular-nums">${pricing.tax.toFixed(2)}</span>
        </div>
        <Separator className="my-1" />
        {isOverLimit && (
          <p className="py-1.5 text-center text-xs font-bold text-destructive bg-destructive/10 rounded-lg border border-destructive/20">
            Legal daily limit exceeded. Remove items to proceed.
          </p>
        )}
        <div className="flex justify-between text-base font-extrabold text-foreground">
          <span>Total</span>
          <span className="tabular-nums">${pricing.grandTotal.toFixed(2)}</span>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-2.5">
        <Button
          variant="outline"
          size="sm"
          className="gap-2 h-11 text-sm font-bold border-2 border-border"
          onClick={() => onCheckout("Cash")}
          disabled={processing || cart.length === 0 || isOverLimit}
        >
          {processing ? <Loader2 className="h-4 w-4 animate-spin" /> : <Banknote className="h-4 w-4" strokeWidth={2.5} />}
          Cash
        </Button>
        <Button
          variant="gold"
          size="sm"
          className="gap-2 h-11 text-sm font-bold"
          onClick={() => onCheckout("Card")}
          disabled={processing || cart.length === 0 || isOverLimit}
        >
          {processing ? <Loader2 className="h-4 w-4 animate-spin" /> : <CreditCard className="h-4 w-4" strokeWidth={2.5} />}
          Card
        </Button>
      </div>
    </div>
  </div>
);
