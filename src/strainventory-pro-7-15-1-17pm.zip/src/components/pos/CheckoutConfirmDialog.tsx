import { useEffect, useMemo, useState } from "react";
import { createClient } from "@supabase/supabase-js";
import { Loader2, ShieldCheck, User, Cake, KeyRound } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { appConfig } from "@/lib/appConfig";
import { isShortIdEmail, shortIdFromEmail, pinToPassword } from "@/lib/pinAuth";

export interface CheckoutConfirmData {
  customerName: string;
  customerAge: number;
  cashierShortId: string;
}

interface Props {
  open: boolean;
  paymentMethod: string;
  amount: number;
  defaultCustomerName?: string | null;
  onCancel: () => void;
  onConfirm: (data: CheckoutConfirmData) => void;
}

// Use a throwaway client so PIN verification does not disturb the active cashier session.
const verifierClient = createClient(
  appConfig.supabaseUrl || "http://127.0.0.1:54321",
  appConfig.supabasePublishableKey || "public-anon-key",
  { auth: { persistSession: false, autoRefreshToken: false } },
);

export const CheckoutConfirmDialog = ({
  open,
  paymentMethod,
  amount,
  defaultCustomerName,
  onCancel,
  onConfirm,
}: Props) => {
  const [name, setName] = useState("");
  const [age, setAge] = useState("");
  const [pin, setPin] = useState("");
  const [verifying, setVerifying] = useState(false);

  useEffect(() => {
    if (open) {
      setName(defaultCustomerName ?? "");
      setAge("");
      setPin("");
    }
  }, [open, defaultCustomerName]);

  const ageNum = useMemo(() => Number(age), [age]);
  const nameOk = name.trim().length >= 2 && name.trim().length <= 80;
  const ageOk = Number.isFinite(ageNum) && ageNum >= 21 && ageNum <= 120;
  const pinOk = /^\d{4}$/.test(pin);
  const formOk = nameOk && ageOk && pinOk && !verifying;

  const handleConfirm = async () => {
    if (!formOk) return;
    setVerifying(true);
    try {
      const { data: userRes } = await supabase.auth.getUser();
      const email = userRes.user?.email ?? null;
      if (!email || !isShortIdEmail(email)) {
        toast.error("Cashier account does not use a PIN. Sign in with a staff PIN account to continue.");
        return;
      }
      const shortId = shortIdFromEmail(email);
      if (!shortId) {
        toast.error("Could not identify cashier short ID.");
        return;
      }
      const { error } = await verifierClient.auth.signInWithPassword({
        email,
        password: pinToPassword(pin),
      });
      if (error) {
        toast.error("Incorrect PIN. Please try again.");
        return;
      }
      // Discard the verification session locally only.
      // Global signOut would revoke ALL refresh tokens for this user,
      // including the cashier's active session — kicking them to /auth.
      await verifierClient.auth.signOut({ scope: "local" }).catch(() => {});

      onConfirm({
        customerName: name.trim(),
        customerAge: ageNum,
        cashierShortId: shortId,
      });
    } catch (err) {
      console.error("PIN verification error", err);
      toast.error("Unable to verify PIN. Please try again.");
    } finally {
      setVerifying(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={(o) => (!o && !verifying ? onCancel() : undefined)}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-lg font-bold">
            <ShieldCheck className="h-5 w-5 text-accent" strokeWidth={2.5} />
            Confirm Checkout
          </DialogTitle>
          <DialogDescription>
            {paymentMethod} payment of <span className="font-bold text-foreground">${amount.toFixed(2)}</span>.
            Capture customer info and cashier PIN to complete this sale.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-2">
          <div className="space-y-1.5">
            <Label htmlFor="co-name" className="flex items-center gap-1.5 text-xs font-bold uppercase tracking-wide">
              <User className="h-3.5 w-3.5" strokeWidth={2.5} />
              Customer Name <span className="text-destructive">*</span>
            </Label>
            <Input
              id="co-name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Full name on ID"
              maxLength={80}
              autoFocus
            />
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="co-age" className="flex items-center gap-1.5 text-xs font-bold uppercase tracking-wide">
              <Cake className="h-3.5 w-3.5" strokeWidth={2.5} />
              Customer Age <span className="text-destructive">*</span>
            </Label>
            <Input
              id="co-age"
              type="number"
              inputMode="numeric"
              min={21}
              max={120}
              value={age}
              onChange={(e) => setAge(e.target.value.replace(/[^\d]/g, ""))}
              placeholder="21+"
            />
            {age && !ageOk && (
              <p className="text-[11px] font-semibold text-destructive">Customer must be 21 or older.</p>
            )}
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="co-pin" className="flex items-center gap-1.5 text-xs font-bold uppercase tracking-wide">
              <KeyRound className="h-3.5 w-3.5" strokeWidth={2.5} />
              Employee PIN <span className="text-destructive">*</span>
            </Label>
            <Input
              id="co-pin"
              type="password"
              inputMode="numeric"
              autoComplete="one-time-code"
              maxLength={4}
              value={pin}
              onChange={(e) => setPin(e.target.value.replace(/[^\d]/g, "").slice(0, 4))}
              placeholder="••••"
              className="tracking-[0.5em] text-center text-lg font-bold"
            />
            <p className="text-[11px] text-muted-foreground">
              Identifies you for register consolidation and shift reports.
            </p>
          </div>
        </div>

        <DialogFooter className="gap-2">
          <Button variant="outline" onClick={onCancel} disabled={verifying}>
            Cancel
          </Button>
          <Button variant="gold" onClick={handleConfirm} disabled={!formOk}>
            {verifying ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
            Verify &amp; Continue
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};
