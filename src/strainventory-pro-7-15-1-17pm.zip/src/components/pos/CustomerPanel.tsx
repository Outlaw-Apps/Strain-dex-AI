import { useState, useMemo, useEffect } from "react";
import {
  Search,
  UserPlus,
  Star,
  CheckCircle2,
  Clock,
  Package,
  ScanLine,
  ShieldAlert,
  ShieldCheck,
  BadgePercent,
} from "lucide-react";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { BarcodeFormat } from "@zxing/library";
import {
  useCustomerSearch,
  useCreateCustomer,
  useUpdateCustomerDiscountProfile,
  type Customer,
} from "@/hooks/useCustomers";
import { useCustomerOrders } from "@/hooks/useOrders";
import { BarcodeScanner } from "@/components/ui/BarcodeScanner";
import { parseDriversLicense, type DriverLicenseData } from "@/lib/parseDriversLicense";
import { isSeniorEligible } from "@/lib/discounts/eligibility";
import { supabase } from "@/integrations/supabase/client";
import { useQueryClient } from "@tanstack/react-query";
import type { ScanResult } from "@/hooks/useBarcodeScanner";
import type { Product } from "@/hooks/useProducts";

interface Props {
  selectedCustomer: Customer | null;
  onSelectCustomer: (c: Customer | null) => void;
  publishedProducts: Product[];
  onAddToCart: (product: Product) => void;
}

const DL_FORMATS = [BarcodeFormat.PDF_417];

export const CustomerPanel = ({ selectedCustomer, onSelectCustomer, publishedProducts, onAddToCart }: Props) => {
  const qc = useQueryClient();
  const [custSearch, setCustSearch] = useState("");
  const [newName, setNewName] = useState("");
  const [newPhone, setNewPhone] = useState("");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [discountDialogOpen, setDiscountDialogOpen] = useState(false);
  const [discountForm, setDiscountForm] = useState({
    is_employee: false,
    is_senior: false,
    is_military: false,
    is_police: false,
    is_fire: false,
    service_discount_note: "",
  });

  // DL scanner state
  const [scannerOpen, setScannerOpen] = useState(false);
  const [scannedDL, setScannedDL] = useState<DriverLicenseData | null>(null);
  const [ageBlocked, setAgeBlocked] = useState(false);
  const [ageBlockMsg, setAgeBlockMsg] = useState("");

  const { data: searchResults = [] } = useCustomerSearch(custSearch);
  const { data: recentOrders = [] } = useCustomerOrders(selectedCustomer?.id ?? null);
  const createCustomer = useCreateCustomer();
  const updateDiscountProfile = useUpdateCustomerDiscountProfile();

  useEffect(() => {
    if (!discountDialogOpen || !selectedCustomer) return;
    setDiscountForm({
      is_employee: selectedCustomer.is_employee ?? false,
      is_senior: selectedCustomer.is_senior ?? false,
      is_military: selectedCustomer.is_military ?? false,
      is_police: selectedCustomer.is_police ?? false,
      is_fire: selectedCustomer.is_fire ?? false,
      service_discount_note: selectedCustomer.service_discount_note ?? "",
    });
  }, [discountDialogOpen, selectedCustomer]);

  // ─── DL scan handler ────────────────────────────────────────────────────────
  const handleDLScan = async (result: ScanResult) => {
    const normalizedPayload = result.text
      .split("\0").join("")
      .replace(/\r/g, "\n")
      .trim();
    const verification = parseDriversLicense(normalizedPayload);

    if (!verification.data && !verification.passed) {
      // Could not parse at all
      toast.error(verification.reason || "Could not read ID barcode.");
      return;
    }

    if (!verification.passed) {
      // Age blocked or expired
      setAgeBlocked(true);
      setAgeBlockMsg(verification.reason);
      setScannedDL(verification.data);
      return;
    }

    const data = verification.data!;
    setScannedDL(data);
    setAgeBlocked(false);
    setAgeBlockMsg("");

    // Look up existing customer by the just-scanned licence number
    const { data: liveRow } = await supabase
      .from("customers")
      .select("*")
      .eq("license_number", data.licenseNumber)
      .maybeSingle();

    if (liveRow) {
      const stamped = await stampAgeVerified(liveRow.id);
      if (!stamped) return;
      toast.success(`Welcome back, ${liveRow.name}! Age verified ✓`);
      onSelectCustomer({ ...liveRow, last_age_verified_at: new Date().toISOString() } as Customer);
      return;
    }

    // New customer — pre-fill the creation dialog
    setNewName(`${data.firstName} ${data.lastName}`.trim());
    setNewPhone("");
    setDialogOpen(true);
  };

  const stampAgeVerified = async (customerId: string): Promise<boolean> => {
    const { error } = await supabase
      .from("customers")
      .update({ last_age_verified_at: new Date().toISOString() })
      .eq("id", customerId);
    if (error) {
      console.error("Failed to stamp age verification", error);
      toast.error("Failed to mark customer as age verified. Please try again.");
      return false;
    }
    qc.invalidateQueries({ queryKey: ["customers"] });
    return true;
  };

  // ─── Create customer (manual or from DL) ────────────────────────────────────
  const handleCreate = async () => {
    if (!newName.trim()) return;
    try {
      const now = new Date().toISOString();
      const c = await createCustomer.mutateAsync({
        name: newName,
        phone: newPhone,
        license_number: scannedDL?.licenseNumber || undefined,
        date_of_birth: scannedDL?.dateOfBirth || undefined,
        last_age_verified_at: scannedDL ? now : undefined,
      });
      onSelectCustomer(c);
      setDialogOpen(false);
      setNewName("");
      setNewPhone("");
      setScannedDL(null);
      const verb = scannedDL ? "created & age verified ✓" : "created";
      toast.success(`Customer ${c.customer_number} ${verb}`);
    } catch {
      toast.error("Failed to create customer");
    }
  };

  // ─── Dismiss age block ───────────────────────────────────────────────────────
  const dismissAgeBlock = () => {
    setAgeBlocked(false);
    setAgeBlockMsg("");
    setScannedDL(null);
  };

  // ─── Favorites / recommendations ────────────────────────────────────────────
  const favorites = useMemo(() => {
    const counts: Record<string, { name: string; product_id: string; count: number }> = {};
    for (const order of recentOrders) {
      for (const item of order.order_items ?? []) {
        if (!counts[item.product_id]) {
          counts[item.product_id] = { name: item.product_name, product_id: item.product_id, count: 0 };
        }
        counts[item.product_id].count += item.quantity;
      }
    }
    return Object.values(counts).sort((a, b) => b.count - a.count).slice(0, 5);
  }, [recentOrders]);

  const productMap = useMemo(() => {
    const m = new Map<string, Product>();
    publishedProducts.forEach((p) => m.set(p.id, p));
    return m;
  }, [publishedProducts]);

  const recommendations = useMemo(() => {
    if (favorites.length === 0) return [];
    const purchasedIds = new Set(favorites.map((f) => f.product_id));
    const favProducts = favorites.map((f) => productMap.get(f.product_id)).filter(Boolean) as Product[];
    const types = new Set(favProducts.map((p) => p.type));
    return publishedProducts.filter((p) => !purchasedIds.has(p.id) && types.has(p.type)).slice(0, 4);
  }, [favorites, productMap, publishedProducts]);

  const discountBadges = useMemo(() => {
    if (!selectedCustomer?.last_age_verified_at) return [];
    const c = selectedCustomer;
    const badges: string[] = [];
    if (c.is_employee) badges.push("Employee");
    if (isSeniorEligible(c, new Date())) badges.push("Senior eligible");
    if (c.is_military) badges.push("Military");
    if (c.is_police) badges.push("Police");
    if (c.is_fire) badges.push("Fire");
    return badges;
  }, [selectedCustomer]);

  const isSellable = (product: Product | undefined) =>
    Boolean(product?.in_stock && Number(product.quantity) > 0);

  return (
    <div className="border-b border-border">
      {/* Age-block banner */}
      {ageBlocked && (
        <div className="mx-3 mt-3 rounded-md bg-destructive/10 border border-destructive/30 p-3 flex gap-2 items-start">
          <ShieldAlert className="h-4 w-4 text-destructive shrink-0 mt-0.5" />
          <div className="flex-1 min-w-0">
            <p className="text-xs font-semibold text-destructive">Sale Cannot Proceed</p>
            <p className="text-[10px] text-destructive/80 mt-0.5">{ageBlockMsg}</p>
          </div>
          <button type="button" aria-label="Dismiss age restriction" onClick={dismissAgeBlock} className="text-destructive/60 hover:text-destructive text-xs">✕</button>
        </div>
      )}

      {/* Search / selected */}
      <div className="p-3 space-y-2">
        {selectedCustomer ? (
          <div className="flex items-center justify-between">
            <div className="min-w-0 flex-1">
              <div className="flex items-center gap-1.5">
                <p className="text-sm font-medium text-foreground truncate">{selectedCustomer.name}</p>
                {selectedCustomer.last_age_verified_at && (
                  <Badge variant="secondary" className="text-[9px] gap-0.5 bg-success/10 text-success border-success/20 shrink-0">
                    <ShieldCheck className="h-2.5 w-2.5" /> ID✓
                  </Badge>
                )}
              </div>
              <p className="text-[10px] text-muted-foreground">{selectedCustomer.customer_number} · {selectedCustomer.phone}</p>
              {discountBadges.length > 0 && (
                <div className="mt-1 flex flex-wrap gap-1">
                  {discountBadges.map((b) => (
                    <Badge key={b} variant="outline" className="h-5 border-accent/30 px-1 py-0 text-[8px] text-accent">
                      {b}
                    </Badge>
                  ))}
                </div>
              )}
            </div>
            <div className="flex flex-col items-end gap-1 shrink-0">
              <div className="flex gap-1">
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  className="h-7 gap-1 px-2 text-[10px]"
                  onClick={() => setDiscountDialogOpen(true)}
                >
                  <BadgePercent className="h-3 w-3" />
                  Discount eligibility
                </Button>
                <Button variant="ghost" size="sm" className="h-7 text-xs shrink-0" onClick={() => onSelectCustomer(null)}>
                  Clear
                </Button>
              </div>
            </div>
          </div>
        ) : (
          <div className="flex gap-1.5">
            <div className="relative flex-1">
              <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
              <Input
                value={custSearch}
                onChange={(e) => setCustSearch(e.target.value)}
                placeholder="Customer # or name..."
                className="pl-8 h-8 text-xs bg-background"
              />
            </div>

            {/* Scan ID button */}
            <Button
              variant="outline"
              size="sm"
              className="h-8 px-2"
              title="Scan Driver's Licence"
              onClick={() => { dismissAgeBlock(); setScannerOpen(true); }}
            >
              <ScanLine className="h-3.5 w-3.5" />
            </Button>

            <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
              <DialogTrigger asChild>
                <Button variant="outline" size="sm" className="h-8 px-2">
                  <UserPlus className="h-3.5 w-3.5" />
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-sm">
                <DialogHeader>
                  <DialogTitle>New Customer</DialogTitle>
                </DialogHeader>
                <div className="space-y-3 pt-2">
                  {scannedDL && (
                    <div className="rounded-md bg-success/10 border border-success/20 px-3 py-2 flex items-center gap-2">
                      <ShieldCheck className="h-4 w-4 text-success shrink-0" />
                      <p className="text-xs text-success font-medium">Age verified — {scannedDL.age} years old</p>
                    </div>
                  )}
                  <div>
                    <Label className="text-xs">Name</Label>
                    <Input value={newName} onChange={(e) => setNewName(e.target.value)} className="mt-1" />
                  </div>
                  <div>
                    <Label className="text-xs">Phone</Label>
                    <Input value={newPhone} onChange={(e) => setNewPhone(e.target.value)} className="mt-1" />
                  </div>
                  <Button onClick={handleCreate} className="w-full" disabled={createCustomer.isPending}>
                    Create Customer
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        )}

        {/* Search results dropdown */}
        {!selectedCustomer && searchResults.length > 0 && (
          <div className="rounded-md border border-border bg-popover shadow-md">
            {searchResults.map((c) => (
              <button
                key={c.id}
                onClick={() => { onSelectCustomer(c); setCustSearch(""); }}
                className="w-full text-left px-3 py-2 text-xs hover:bg-muted/50 transition-colors flex justify-between items-center"
              >
                <span className="font-medium text-foreground">{c.name}</span>
                <div className="flex items-center gap-1.5">
                  {c.last_age_verified_at && (
                    <ShieldCheck className="h-3 w-3 text-success" />
                  )}
                  <span className="text-muted-foreground">{c.customer_number}</span>
                </div>
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Favorites & Recommendations */}
      {selectedCustomer && favorites.length > 0 && (
        <div className="px-3 pb-3">
          <Separator className="mb-2" />
          <p className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wider mb-1.5 flex items-center gap-1">
            <Star className="h-3 w-3" /> Favorites (last 3 months)
          </p>
          <ScrollArea className="max-h-24">
            <div className="space-y-1">
              {favorites.map((f) => {
                const product = productMap.get(f.product_id);
                const inStock = isSellable(product);
                return (
                  <button
                    key={f.product_id}
                    type="button"
                    disabled={!inStock}
                    onClick={() => product && onAddToCart(product)}
                    aria-label={`Add favorite ${f.name} to cart`}
                    className="flex w-full items-center justify-between text-left text-xs rounded-md px-1.5 py-1 -mx-1.5 hover:bg-accent/10 focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-accent disabled:cursor-not-allowed disabled:opacity-60"
                    title={inStock ? `Add ${f.name} to cart` : `${f.name} is out of stock`}
                  >
                    <span className="truncate text-accent">
                      {f.name}
                    </span>
                    <div className="flex items-center gap-1.5 shrink-0">
                      <span className="text-muted-foreground">×{f.count}</span>
                      {inStock ? (
                        <Badge variant="secondary" className="text-[9px] gap-0.5 bg-success/10 text-success border-success/20">
                          <CheckCircle2 className="h-2.5 w-2.5" /> In Stock
                        </Badge>
                      ) : (
                        <Badge variant="secondary" className="text-[9px] gap-0.5 bg-destructive/10 text-destructive border-destructive/20">
                          <Clock className="h-2.5 w-2.5" /> Out
                        </Badge>
                      )}
                    </div>
                  </button>
                );
              })}
            </div>
          </ScrollArea>

          {recommendations.length > 0 && (
            <>
              <p className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wider mt-2 mb-1.5 flex items-center gap-1">
                <Package className="h-3 w-3" /> Recommended
              </p>
              <div className="space-y-1">
                {recommendations.map((r) => {
                  const inStock = isSellable(r);
                  return (
                    <button
                      key={r.id}
                      type="button"
                      disabled={!inStock}
                      onClick={() => onAddToCart(r)}
                      aria-label={`Add recommended ${r.name} to cart`}
                      className="flex w-full items-center justify-between text-left text-xs rounded-md px-1.5 py-1 -mx-1.5 hover:bg-accent/10 focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-accent disabled:cursor-not-allowed disabled:opacity-60"
                      title={inStock ? `Add ${r.name} to cart` : `${r.name} is out of stock`}
                    >
                      <span className="truncate text-accent">
                        {r.name}
                      </span>
                      <span className="text-accent text-[10px]">{r.type}</span>
                    </button>
                  );
                })}
              </div>
            </>
          )}

          <p className="text-[10px] text-muted-foreground mt-2">{recentOrders.length} orders in last 3 months</p>
        </div>
      )}

      {/* Driver's Licence Scanner */}
      <BarcodeScanner
        open={scannerOpen}
        onOpenChange={setScannerOpen}
        onScan={handleDLScan}
        title="Scan Driver's Licence"
        formats={DL_FORMATS}
      />

      <Dialog open={discountDialogOpen} onOpenChange={setDiscountDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Discount eligibility</DialogTitle>
          </DialogHeader>
          <p className="text-xs text-muted-foreground">
            POS applies ticket discounts only after ID verification. Senior pricing also applies when date of birth shows 65+
            (once verified).
          </p>
          <div className="grid gap-3 pt-2">
            {(
              [
                ["is_employee", "Employee discount (25%) — requires Manager Override at POS"],
                ["is_senior", "Senior discount flag"],
                ["is_military", "Military discount (20%)"],
                ["is_police", "Police discount (20%)"],
                ["is_fire", "Fire discount (20%)"],
              ] as const
            ).map(([key, help]) => (
              <div key={key} className="flex items-start gap-2">
                <Checkbox
                  id={`disc-${key}`}
                  checked={discountForm[key]}
                  onCheckedChange={(c) =>
                    setDiscountForm((prev) => ({ ...prev, [key]: c === true }))
                  }
                  className="mt-0.5"
                />
                <div className="min-w-0">
                  <Label htmlFor={`disc-${key}`} className="text-sm font-medium leading-tight cursor-pointer">
                    {key === "is_employee"
                      ? "Employee"
                      : key === "is_senior"
                        ? "Senior"
                        : key === "is_military"
                          ? "Military"
                          : key === "is_police"
                            ? "Police"
                            : "Fire"}
                  </Label>
                  <p className="text-[10px] text-muted-foreground">{help}</p>
                </div>
              </div>
            ))}
            <div className="space-y-1.5">
              <Label htmlFor="disc-note">Verification / notes</Label>
              <Textarea
                id="disc-note"
                placeholder="e.g. Military ID verified 2026-05-01"
                className="min-h-[72px] text-xs"
                value={discountForm.service_discount_note}
                onChange={(e) =>
                  setDiscountForm((prev) => ({ ...prev, service_discount_note: e.target.value }))
                }
              />
            </div>
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <Button type="button" variant="outline" size="sm" onClick={() => setDiscountDialogOpen(false)}>
              Cancel
            </Button>
            <Button
              type="button"
              size="sm"
              disabled={updateDiscountProfile.isPending || !selectedCustomer}
              onClick={() => {
                if (!selectedCustomer) return;
                void (async () => {
                  try {
                    const updated = await updateDiscountProfile.mutateAsync({
                      id: selectedCustomer.id,
                      is_employee: discountForm.is_employee,
                      is_senior: discountForm.is_senior,
                      is_military: discountForm.is_military,
                      is_police: discountForm.is_police,
                      is_fire: discountForm.is_fire,
                      service_discount_note: discountForm.service_discount_note.trim() || null,
                    });
                    onSelectCustomer(updated);
                    toast.success("Discount eligibility saved.");
                    setDiscountDialogOpen(false);
                  } catch {
                    toast.error("Could not save discount eligibility.");
                  }
                })();
              }}
            >
              Save
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};
