import { useMemo } from "react";
import { AlertTriangle, Leaf, FlaskConical } from "lucide-react";
import { cn } from "@/lib/utils";
import type { CartItem } from "@/pages/PointOfSale";
import { computeDailyLimits, FLOWER_LIMIT_GRAMS, CONCENTRATE_LIMIT_GRAMS } from "@/lib/dailyLimits";

interface DailyLimitTrackerProps {
  cart: CartItem[];
}

export const DailyLimitTracker = ({ cart }: DailyLimitTrackerProps) => {
  const { flowerGrams, concentrateGrams, flowerPct, concentratePct, isOverLimit } = useMemo(
    () => computeDailyLimits(cart),
    [cart],
  );

  if (cart.length === 0) return null;

  return (
    <div className={cn(
      "mx-4 mb-3 rounded-xl border-2 p-4 space-y-3 transition-colors",
      isOverLimit
        ? "border-destructive/40 bg-destructive/5"
        : "border-border bg-muted/20",
    )}>
      <p className="text-[11px] font-bold uppercase tracking-[0.15em] text-muted-foreground">
        Daily Limits
      </p>

      <LimitBar
        icon={<Leaf className="h-3.5 w-3.5" strokeWidth={2.5} />}
        label="Flower"
        grams={flowerGrams}
        limit={FLOWER_LIMIT_GRAMS}
        pct={flowerPct}
      />
      <LimitBar
        icon={<FlaskConical className="h-3.5 w-3.5" strokeWidth={2.5} />}
        label="Concentrate"
        grams={concentrateGrams}
        limit={CONCENTRATE_LIMIT_GRAMS}
        pct={concentratePct}
      />

      {isOverLimit && (
        <div className="flex items-center gap-2 pt-1">
          <AlertTriangle className="h-4 w-4 text-destructive shrink-0" strokeWidth={2.5} />
          <p className="text-xs font-bold text-destructive">
            Limit exceeded — remove items to proceed
          </p>
        </div>
      )}
    </div>
  );
};

const LimitBar = ({
  icon,
  label,
  grams,
  limit,
  pct,
}: {
  icon: React.ReactNode;
  label: string;
  grams: number;
  limit: number;
  pct: number;
}) => {
  const over = pct > 100;
  const barWidth = Math.min(pct, 100);

  return (
    <div className="space-y-1.5">
      <div className="flex items-center justify-between text-xs">
        <span className={cn(
          "flex items-center gap-1.5 font-bold",
          over ? "text-destructive" : "text-foreground",
        )}>
          {icon} {label}
        </span>
        <span className={cn(
          "tabular-nums font-bold",
          over ? "text-destructive" : "text-muted-foreground",
        )}>
          {grams.toFixed(1)}g / {limit}g
        </span>
      </div>
      <div className="h-2 rounded-full bg-muted overflow-hidden">
        <div
          className={cn(
            "h-full rounded-full transition-all duration-300",
            over ? "bg-destructive" : pct >= 80 ? "bg-warning" : "bg-success",
          )}
          style={{ width: `${barWidth}%` }}
        />
      </div>
    </div>
  );
};
