import { useState } from "react";
import { BadgePercent } from "lucide-react";
import { Button } from "@/components/ui/button";
import { DiscountDialog } from "@/components/pos/DiscountDialog";
import type { UseManagerOverride } from "@/hooks/useManagerOverride";
import type { Customer } from "@/hooks/useCustomers";
import type { CartPricingResult, TicketPromotionSelection } from "@/lib/discounts/types";
import type { PosDiscountPermissions } from "@/hooks/usePosDiscountPermissions";

interface Props {
  customer: Customer | null;
  ticket: TicketPromotionSelection;
  onTicketChange: (t: TicketPromotionSelection) => void;
  previewPricing: CartPricingResult;
  managerOverride: UseManagerOverride;
  permissions: PosDiscountPermissions;
  employeePricingOk: boolean;
  disabled?: boolean;
}

export function DiscountButton({
  customer,
  ticket,
  onTicketChange,
  previewPricing,
  managerOverride,
  permissions,
  employeePricingOk,
  disabled,
}: Props) {
  const [open, setOpen] = useState(false);

  return (
    <>
      <Button
        type="button"
        variant="outline"
        size="sm"
        className="w-full gap-2"
        disabled={disabled}
        onClick={() => setOpen(true)}
        data-testid="pos-discounts-button"
      >
        <BadgePercent className="h-3.5 w-3.5" />
        Discounts
      </Button>
      <DiscountDialog
        open={open}
        onOpenChange={setOpen}
        customer={customer}
        ticket={ticket}
        onTicketChange={onTicketChange}
        previewPricing={previewPricing}
        managerOverride={managerOverride}
        permissions={permissions}
        employeePricingOk={employeePricingOk}
      />
    </>
  );
}
