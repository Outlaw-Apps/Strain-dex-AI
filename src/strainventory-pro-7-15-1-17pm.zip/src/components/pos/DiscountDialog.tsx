import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { ScrollArea } from "@/components/ui/scroll-area";
import { ManagerOverrideButton } from "@/components/ui/ManagerOverrideButton";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { CUSTOMER_PERCENT_DEFINITIONS, BOGO_DEFINITION_ID } from "@/lib/discounts/builtins";
import type { CartPricingResult, TicketPromotionSelection } from "@/lib/discounts/types";
import { isAgeVerified, isSeniorEligible } from "@/lib/discounts/eligibility";
import { isCustomerDiscountEligible } from "@/lib/discounts/discountEngine";
import type { Customer } from "@/hooks/useCustomers";
import type { UseManagerOverride } from "@/hooks/useManagerOverride";
import type { PosDiscountPermissions } from "@/hooks/usePosDiscountPermissions";
import { AppliedDiscountList } from "@/components/pos/AppliedDiscountList";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

interface DiscountDialogProps {
  open: boolean;
  onOpenChange: (o: boolean) => void;
  customer: Customer | null;
  ticket: TicketPromotionSelection;
  onTicketChange: (t: TicketPromotionSelection) => void;
  previewPricing: CartPricingResult;
  managerOverride: UseManagerOverride;
  permissions: PosDiscountPermissions;
  /** Same flag passed into `calculateCartPricing` for employee governance */
  employeePricingOk: boolean;
  referenceTime?: Date;
}

function roleAllowsCustomerDiscount(
  defId: string,
  permissions: PosDiscountPermissions,
  managerOverrideActive: boolean,
): boolean {
  if (defId === "cust-employee") {
    return permissions.applyEmployeeDiscountWithoutOverride || managerOverrideActive;
  }
  return permissions.applyStandardDiscount;
}

export function DiscountDialog({
  open,
  onOpenChange,
  customer,
  ticket,
  onTicketChange,
  previewPricing,
  managerOverride,
  permissions,
  employeePricingOk,
  referenceTime = new Date(),
}: DiscountDialogProps) {
  const customerVerified = Boolean(customer && isAgeVerified(customer));
  const seniorHint = customer && isSeniorEligible(customer, referenceTime);
  const disabledReason = customerVerified ? null : "Verify customer first.";

  const bogoPreview = previewPricing.appliedDiscounts.find((d) => d.definitionId === BOGO_DEFINITION_ID);

  const showManagerOverride =
    managerOverride.canOverride && permissions.overrideDiscountRules;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent
        className="flex max-h-[85vh] flex-col sm:max-w-md"
        data-testid="pos-discounts-dialog"
      >
        <DialogHeader className="space-y-1">
          <div className="flex items-start justify-between gap-2">
            <DialogTitle>Discounts & promotions</DialogTitle>
            {showManagerOverride && (
              <ManagerOverrideButton override={managerOverride} className="shrink-0" />
            )}
          </div>
          <p className="text-xs text-muted-foreground">
            Choose one ticket-level discount or a BOGO pattern. Sale and clearance still price from each
            product row.
          </p>
          {permissions.loading && (
            <p className="text-[10px] text-muted-foreground">Loading permissions…</p>
          )}
        </DialogHeader>

        <ScrollArea className="min-h-[200px] flex-1 pr-2">
          <div className="space-y-4 pb-4">
            <section>
              <h3 className="mb-2 text-xs font-semibold text-foreground">Auto pricing</h3>
              <p className="mb-2 text-[10px] text-muted-foreground">
                Sale and clearance windows read from catalog fields and apply when items are in the cart.
              </p>
              <AppliedDiscountList
                applied={previewPricing.appliedDiscounts.filter((a) => a.automated)}
                emptyLabel="No automatic markdowns on this cart."
              />
            </section>

            <Separator />

            <section>
              <h3 className="mb-2 text-xs font-semibold text-foreground">Customer discounts</h3>
              {!customerVerified && (
                <p className="mb-2 text-[10px] text-destructive">{disabledReason}</p>
              )}
              {customerVerified && seniorHint && (
                <Badge variant="secondary" className="mb-2 bg-accent/15 text-accent text-[9px]">
                  Senior eligible
                </Badge>
              )}
              <div className="grid grid-cols-2 gap-2">
                {CUSTOMER_PERCENT_DEFINITIONS.map((def) => {
                  const roleOk = roleAllowsCustomerDiscount(
                    def.id,
                    permissions,
                    managerOverride.overrideActive,
                  );
                  const eligible =
                    customerVerified &&
                    roleOk &&
                    isCustomerDiscountEligible(customer!, def.id, referenceTime, employeePricingOk);
                  const selected = ticket.kind === "customer" && ticket.definitionId === def.id;
                  const needsOverride =
                    def.id === "cust-employee" &&
                    !permissions.applyEmployeeDiscountWithoutOverride &&
                    !managerOverride.overrideActive;
                  return (
                    <Button
                      key={def.id}
                      size="sm"
                      variant={selected ? "gold" : "outline"}
                      disabled={permissions.loading || !eligible}
                      title={
                        !customerVerified
                          ? "Verify customer first"
                          : !roleOk
                            ? "Not permitted for your role"
                            : needsOverride
                              ? "Lead role or Manager Override required for employee pricing"
                              : undefined
                      }
                      className={cn(
                        "flex h-auto flex-col items-start gap-0.5 py-2",
                        !eligible && "opacity-50",
                      )}
                      onClick={() => onTicketChange({ kind: "customer", definitionId: def.id })}
                    >
                      <span className="text-xs font-medium">{def.name}</span>
                      <span className="text-[10px] text-muted-foreground tabular-nums">
                        {def.percentOff}% off eligible items
                      </span>
                    </Button>
                  );
                })}
              </div>
            </section>

            <Separator />

            <section>
              <h3 className="mb-2 text-xs font-semibold text-foreground">BOGO · same SKU</h3>
              {!permissions.loading && !permissions.applyBogoDiscount && (
                <Alert variant="destructive" className="mb-2 py-2">
                  <AlertDescription className="text-[10px]">
                    Your role cannot apply BOGO promotions.
                  </AlertDescription>
                </Alert>
              )}
              <p className="mb-2 text-[10px] text-muted-foreground">
                The cheaper unit in each pair is credited. Clearance SKUs skip BOGO per policy.
              </p>
              <div className="grid grid-cols-2 gap-2">
                <Button
                  size="sm"
                  variant={ticket.kind === "bogo" && ticket.mode === "buy1_get1_free" ? "gold" : "outline"}
                  disabled={permissions.loading || !permissions.applyBogoDiscount}
                  onClick={() => onTicketChange({ kind: "bogo", mode: "buy1_get1_free" })}
                >
                  Buy 1 get 1 free
                </Button>
                <Button
                  size="sm"
                  variant={ticket.kind === "bogo" && ticket.mode === "buy1_get1_half" ? "gold" : "outline"}
                  disabled={permissions.loading || !permissions.applyBogoDiscount}
                  onClick={() => onTicketChange({ kind: "bogo", mode: "buy1_get1_half" })}
                >
                  Second item half off
                </Button>
              </div>
              {bogoPreview && (
                <p className="mt-2 text-[10px] text-muted-foreground tabular-nums">
                  Estimated BOGO credit: −${bogoPreview.amountOff.toFixed(2)}
                </p>
              )}
            </section>

            <Separator />

            <section>
              <h3 className="mb-2 text-xs font-semibold">Live summary</h3>
              <AppliedDiscountList applied={previewPricing.appliedDiscounts} emptyLabel="No discounts yet." />
            </section>
          </div>
        </ScrollArea>

        <div className="flex justify-between border-t border-border pt-2">
          <Button variant="ghost" size="sm" onClick={() => onTicketChange({ kind: "none" })}>
            Clear ticket promos
          </Button>
          <Button size="sm" variant="gold" onClick={() => onOpenChange(false)}>
            Done
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
