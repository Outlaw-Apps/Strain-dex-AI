import { memo, useEffect, useMemo, useState } from "react";
import { motion } from "framer-motion";
import { Search, Loader2, PackageX, Minus, Plus, ScanLine, Pencil, Eye, Package } from "lucide-react";
import { Link } from "react-router-dom";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { useQueryClient } from "@tanstack/react-query";
import { BarcodeScanner } from "@/components/ui/BarcodeScanner";
import type { ScanResult } from "@/hooks/useBarcodeScanner";
import type { Product } from "@/hooks/useProducts";
import { formatDisplayNumber } from "@/lib/posPricing";
import { resolveProductPricing } from "@/lib/discounts/productPrice";
import { useRecentPosProducts } from "@/hooks/useRecentPosProducts";
import { ProductQuickLookup } from "./ProductQuickLookup";

interface Props {
  products: Product[];
  isLoading: boolean;
  search: string;
  onSearchChange: (v: string) => void;
  onAddToCart: (p: Product) => void;
}

const LOW_STOCK_THRESHOLD = 10;

const InlineQtyEditor = ({ product }: { product: Product }) => {
  const qc = useQueryClient();
  const qty = Number(product.quantity) || 0;
  const [updating, setUpdating] = useState(false);
  const [value, setValue] = useState(formatDisplayNumber(qty));

  useEffect(() => {
    setValue(formatDisplayNumber(qty));
  }, [qty]);

  const saveQty = async (nextValue: string) => {
    const parsed = Number.parseFloat(nextValue);
    if (!Number.isFinite(parsed) || parsed < 0) {
      toast.error("Enter a valid stock quantity");
      setValue(formatDisplayNumber(qty));
      return;
    }

    const newQty = Math.round(parsed * 100) / 100;
    setUpdating(true);
    const { error } = await supabase
      .from("products")
      .update({ quantity: newQty, in_stock: newQty > 0, updated_at: new Date().toISOString() })
      .eq("id", product.id);
    setUpdating(false);
    if (error) {
      toast.error("Failed to update stock");
      setValue(formatDisplayNumber(qty));
      return;
    }
    setValue(formatDisplayNumber(newQty));
    qc.invalidateQueries({ queryKey: ["products"] });
  };

  const updateQty = async (e: React.MouseEvent, delta: number) => {
    e.stopPropagation();
    await saveQty(String(Math.max(0, Math.round((qty + delta) * 100) / 100)));
  };

  const isOut = qty <= 0 || !product.in_stock;
  const isLow = !isOut && qty <= LOW_STOCK_THRESHOLD;

  return (
    <div
      className="flex items-center gap-1"
      onClick={(e) => e.stopPropagation()}
      onKeyDown={(e) => e.stopPropagation()}
    >
      <button
        aria-label={`Decrease ${product.name} stock`}
        onClick={(e) => void updateQty(e, -1)}
        disabled={updating || qty <= 0}
        className="h-5 w-5 rounded bg-muted flex items-center justify-center text-muted-foreground hover:text-foreground transition-colors disabled:opacity-40"
      >
        <Minus className="h-2.5 w-2.5" />
      </button>
      <Input
        type="number"
        min="0"
        step="0.01"
        value={value}
        onChange={(e) => setValue(e.target.value)}
        onBlur={() => void saveQty(value)}
        onKeyDown={(e) => {
          if (e.key === "Enter") {
            void saveQty(value);
          }
          if (e.key === "Escape") {
            setValue(formatDisplayNumber(qty));
          }
        }}
        className={cn(
          "h-6 w-16 px-1 text-center text-[10px] tabular-nums",
          isOut && "text-destructive",
          isLow && !isOut && "text-warning",
          !isOut && !isLow && "text-muted-foreground",
        )}
      />
      <button
        aria-label={`Increase ${product.name} stock`}
        onClick={(e) => void updateQty(e, 1)}
        disabled={updating}
        className="h-5 w-5 rounded bg-muted flex items-center justify-center text-muted-foreground hover:text-foreground transition-colors disabled:opacity-40"
      >
        <Plus className="h-2.5 w-2.5" />
      </button>
    </div>
  );
};

export const ProductGrid = ({ products, isLoading, search, onSearchChange, onAddToCart }: Props) => {
  const [scannerOpen, setScannerOpen] = useState(false);
  const [lookupOpen, setLookupOpen] = useState(false);
  const { recents, pushRecent } = useRecentPosProducts();

  const handleAddToCart = (product: Product) => {
    onAddToCart(product);
    pushRecent({ id: product.id, name: product.name, brand: product.brand, sku: product.sku });
  };

  const handleQuickPick = (product: Product) => {
    const qty = Number(product.quantity) || 0;
    if (!product.in_stock || qty <= 0) {
      toast.error(`${product.name} is out of stock`);
      return;
    }
    handleAddToCart(product);
    onSearchChange("");
    setLookupOpen(false);
  };

  const handleProductScan = (result: ScanResult) => {
    const rawScan = result.text.trim();
    const normalize = (value: string) =>
      value
        .trim()
        .split("\0").join("")
        .replace(/[\r\n\t]/g, "")
        .replace(/\s+/g, "")
        .toUpperCase();

    const normalizedScan = normalize(rawScan);
    const found = products.find((product) => normalize(product.sku ?? "") === normalizedScan);
    if (found) {
      if (!found.in_stock || Number(found.quantity) <= 0) {
        toast.error(`${found.name} is out of stock`);
      } else {
        handleAddToCart(found);
      }
    } else {
      onSearchChange(rawScan);
      toast.info(`No product with SKU "${rawScan}" found. Showing search results.`);
    }
  };

  return (
    <div className="flex-1 flex flex-col border-r-2 border-border overflow-hidden bg-background">
      <div className="p-4 sm:p-5 border-b-2 border-border bg-gradient-to-r from-card to-accent/[0.03]">
        <div className="flex items-center gap-3 mb-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl gold-gradient ring-1 ring-border/60">
            <Package className="h-5 w-5 text-accent-foreground" strokeWidth={2.5} />
          </div>
          <div>
            <h1 className="text-lg font-bold text-foreground tracking-tight">Point of Sale</h1>
            <p className="text-[11px] text-muted-foreground font-medium">{products.length} published products available</p>
          </div>
        </div>
        <div className="flex gap-2.5">
          <div className="relative flex-1">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              value={search}
              onChange={(e) => {
                onSearchChange(e.target.value);
                setLookupOpen(true);
              }}
              onFocus={() => setLookupOpen(true)}
              placeholder="Search SKU, strain, brand, or product name…"
              aria-label="Fast product lookup"
              autoComplete="off"
              className="pl-11 h-11 bg-card text-sm font-medium border-2 border-border focus-visible:border-accent focus-visible:ring-accent/20"
            />
            <ProductQuickLookup
              products={products}
              recents={recents}
              query={search}
              open={lookupOpen}
              onSelect={handleQuickPick}
              onClose={() => setLookupOpen(false)}
            />
          </div>
          <Button
            variant="outline"
            size="icon"
            className="h-11 w-11 border-2 border-border"
            title="Scan product barcode"
            onClick={() => setScannerOpen(true)}
          >
            <ScanLine className="h-5 w-5" strokeWidth={2} />
          </Button>
        </div>
      </div>

      <ScrollArea className="flex-1 p-4">
        {isLoading ? (
          <div className="flex items-center justify-center py-16">
            <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
          </div>
        ) : (
          <ProductGridGrouped products={products} onAddToCart={handleAddToCart} />
        )}
      </ScrollArea>

      <BarcodeScanner
        open={scannerOpen}
        onOpenChange={setScannerOpen}
        onScan={handleProductScan}
        title="Scan Product Barcode"
      />
    </div>
  );
};

interface GroupedProps {
  products: Product[];
  onAddToCart: (p: Product) => void;
}

const ProductGridGrouped = ({ products, onAddToCart }: GroupedProps) => {
  const groups = useMemo(() => {
    const map = new Map<string, Product[]>();
    for (const p of products) {
      const key = (p.type || "Other").toString();
      if (!map.has(key)) map.set(key, []);
      map.get(key)!.push(p);
    }
    const sorted = Array.from(map.entries())
      .map(([type, items]) => ({
        type,
        items: items.slice().sort((a, b) => a.name.localeCompare(b.name)),
      }))
      .sort((a, b) => a.type.localeCompare(b.type));
    return sorted;
  }, [products]);

  if (products.length === 0) {
    return (
      <div className="text-center py-12 text-sm text-muted-foreground">
        No published products found.
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {groups.map(({ type, items }) => (
        <section key={type} aria-labelledby={`pos-group-${type}`}>
          <div className="sticky top-0 z-10 -mx-4 px-4 py-2 bg-background/95 backdrop-blur border-b-2 border-border flex items-center gap-2.5">
            <div className="h-2 w-2 rounded-full bg-accent" />
            <h2 id={`pos-group-${type}`} className="text-xs font-bold uppercase tracking-[0.15em] text-foreground">
              {type}
            </h2>
            <Badge variant="secondary" className="text-[10px] font-bold tabular-nums">{items.length}</Badge>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 2xl:grid-cols-6 gap-3 mt-3">
            {items.map((product) => (
              <ProductCard key={product.id} product={product} onAddToCart={onAddToCart} />
            ))}
          </div>
        </section>
      ))}
    </div>
  );
};

const ProductCardImpl = ({ product, onAddToCart }: { product: Product; onAddToCart: (p: Product) => void }) => {
  const img = product.images?.find((image) => image.primary) || product.images?.[0];
  const price = Number(product.price) || 0;
  const slice = resolveProductPricing(product, new Date());
  const shelfPpg = slice.effectivePpg;
  const qty = Number(product.quantity) || 0;
  const isOut = qty <= 0 || !product.in_stock;
  const promo = slice.clearance ? "clearance" : slice.sale ? "sale" : null;

  return (
    <motion.div whileHover={isOut ? {} : { scale: 1.02 }} whileTap={isOut ? {} : { scale: 0.98 }}>
      <Card
        role={isOut ? undefined : "button"}
        tabIndex={isOut ? -1 : 0}
        aria-disabled={isOut}
        aria-label={`Add ${product.name} to cart`}
        className={cn(
          "min-h-[132px] overflow-hidden transition-all duration-200 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-success focus-visible:ring-offset-2",
          isOut
            ? "opacity-50 cursor-not-allowed border-2 border-border/40"
            : "cursor-pointer border-2 border-border shadow-soft hover:shadow-elevated hover:border-success/40",
        )}
        onClick={() => {
          if (!isOut) onAddToCart(product);
        }}
        onKeyDown={(event) => {
          if (isOut || (event.key !== "Enter" && event.key !== " ")) return;
          event.preventDefault();
          onAddToCart(product);
        }}
      >
        <div className="aspect-[4/3] bg-gradient-to-br from-accent/10 to-emerald/10 flex items-center justify-center relative p-2">
          {img ? (
            <img
              src={img.url}
              alt={img.alt}
              loading="lazy"
              decoding="async"
              className="max-h-full max-w-full object-contain"
            />
          ) : (
            <span className="text-[10px] font-medium text-muted-foreground">No image</span>
          )}
          {isOut && (
            <div className="absolute inset-0 bg-background/60 flex items-center justify-center">
              <Badge variant="secondary" className="text-[11px] gap-1 bg-destructive/15 text-destructive border-destructive/25 font-bold px-2 py-1">
                <PackageX className="h-3.5 w-3.5" /> Out of Stock
              </Badge>
            </div>
          )}
          {/* Quick action overlay */}
          <div
            className="absolute top-2 right-2 flex gap-1.5 opacity-0 group-hover:opacity-100 focus-within:opacity-100"
            onClick={(e) => e.stopPropagation()}
          >
            <Link
              to={`/catalog/${product.id}`}
              aria-label={`View ${product.name}`}
              className="h-7 w-7 rounded-lg bg-background/90 border border-border flex items-center justify-center text-muted-foreground hover:text-foreground shadow-sm"
            >
              <Eye className="h-3.5 w-3.5" strokeWidth={2.5} />
            </Link>
            <Link
              to={`/catalog/${product.id}?edit=1`}
              aria-label={`Edit ${product.name}`}
              className="h-7 w-7 rounded-lg bg-background/90 border border-border flex items-center justify-center text-muted-foreground hover:text-foreground shadow-sm"
            >
              <Pencil className="h-3.5 w-3.5" strokeWidth={2.5} />
            </Link>
          </div>
        </div>
        <CardContent className="p-2.5">
          <p className="text-sm font-bold text-foreground truncate leading-tight">{product.name}</p>
          <p className="text-[11px] text-muted-foreground font-medium truncate">{product.brand}</p>
          {promo && (
            <div className="mt-1.5 flex flex-wrap gap-1">
              <Badge
                variant="secondary"
                className={
                  promo === "clearance"
                    ? "h-5 border border-destructive/30 bg-destructive/15 px-1.5 text-[9px] text-destructive font-bold"
                    : "h-5 border border-accent/30 bg-accent/10 px-1.5 text-[9px] text-accent font-bold"
                }
              >
                {promo === "clearance" ? "Clearance" : "Sale"}
              </Badge>
              {product.sale_label && promo === "sale" && (
                <span className="text-[9px] text-muted-foreground truncate font-medium">{product.sale_label}</span>
              )}
            </div>
          )}
          <div className="flex justify-between items-center gap-1 mt-2">
            <span className="text-sm font-bold text-accent tabular-nums">
              {shelfPpg <= 0 && price <= 0 ? (
                "-"
              ) : promo ? (
                <span className="tabular-nums">
                  {slice.listPpg > shelfPpg && (
                    <span className="mr-1 text-[11px] font-medium text-muted-foreground line-through">
                      ${price.toFixed(2)}
                    </span>
                  )}
                  ${shelfPpg.toFixed(2)}/g
                </span>
              ) : price > 0 ? (
                `$${price.toFixed(2)}/g`
              ) : (
                "-"
              )}
            </span>
            <Badge variant="secondary" className="text-[10px] font-bold capitalize">
              {product.type}
            </Badge>
          </div>
          <div className="flex justify-between items-center mt-1.5 gap-1">
            {product.thc && (
              <p className="text-[11px] text-accent/80 font-semibold truncate">THC: {product.thc}</p>
            )}
            <div className="ml-auto">
              <InlineQtyEditor product={product} />
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
};

// Memoize so cart-state changes in the parent don't re-render every tile.
// Products come from react-query so references are stable across renders.
const ProductCard = memo(ProductCardImpl, (prev, next) => {
  const a = prev.product;
  const b = next.product;
  return (
    a === b ||
    (a.id === b.id &&
      a.updated_at === b.updated_at &&
      a.quantity === b.quantity &&
      a.in_stock === b.in_stock &&
      a.price === b.price &&
      a.sale_label === b.sale_label)
  );
});
