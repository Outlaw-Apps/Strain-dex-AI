// Fast POS product lookup: SKU/name/strain/brand fuzzy match with keyboard
// navigation and recent items. Renders as a floating dropdown below the
// search input; the parent controls the search string and can add products
// straight to cart.
import { memo, useEffect, useMemo, useRef, useState } from "react";
import { Clock, PackageX, Search, Sparkles } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import type { Product } from "@/hooks/useProducts";
import type { RecentPosProduct } from "@/hooks/useRecentPosProducts";

interface Props {
  products: Product[];
  recents: RecentPosProduct[];
  query: string;
  open: boolean;
  onSelect: (product: Product) => void;
  onClose: () => void;
}

interface Ranked {
  product: Product;
  score: number;
  matchedField: "sku" | "name" | "strain" | "brand" | "type";
}

const norm = (s: string | null | undefined) => (s ?? "").toLowerCase().trim();

/**
 * Ranks a product against the query. Higher = better.
 * - Exact SKU / name match: 1000 / 900
 * - SKU starts-with: 800
 * - Name / strain starts-with: 700 / 650
 * - Any substring: 100 + (1 / position)
 */
function rank(product: Product, q: string): Ranked | null {
  const name = norm(product.name);
  const sku = norm(product.sku);
  const strain = norm(product.strain);
  const brand = norm(product.brand);
  const type = norm(product.type);

  if (sku && sku === q) return { product, score: 1000, matchedField: "sku" };
  if (name === q) return { product, score: 900, matchedField: "name" };
  if (sku && sku.startsWith(q)) return { product, score: 800, matchedField: "sku" };
  if (name.startsWith(q)) return { product, score: 700, matchedField: "name" };
  if (strain && strain.startsWith(q)) return { product, score: 650, matchedField: "strain" };
  if (brand && brand.startsWith(q)) return { product, score: 500, matchedField: "brand" };

  const buckets: Array<[string, Ranked["matchedField"], number]> = [
    [name, "name", 300],
    [strain, "strain", 250],
    [sku, "sku", 220],
    [brand, "brand", 180],
    [type, "type", 100],
  ];
  for (const [hay, field, base] of buckets) {
    if (!hay) continue;
    const idx = hay.indexOf(q);
    if (idx >= 0) return { product, score: base - Math.min(idx, base - 10), matchedField: field };
  }
  return null;
}

export const ProductQuickLookup = memo(function ProductQuickLookup({
  products,
  recents,
  query,
  open,
  onSelect,
  onClose,
}: Props) {
  const [activeIdx, setActiveIdx] = useState(0);
  const containerRef = useRef<HTMLDivElement | null>(null);

  const trimmed = query.trim().toLowerCase();

  const suggestions = useMemo<Ranked[]>(() => {
    if (!trimmed) return [];
    return products
      .map((p) => rank(p, trimmed))
      .filter((r): r is Ranked => r !== null)
      .sort((a, b) => b.score - a.score)
      .slice(0, 8);
  }, [products, trimmed]);

  // Hydrate recents against the live product list so stock/price is current.
  const recentHydrated = useMemo(() => {
    if (trimmed) return [];
    const byId = new Map(products.map((p) => [p.id, p]));
    return recents
      .map((r) => byId.get(r.id))
      .filter((p): p is Product => Boolean(p))
      .slice(0, 6);
  }, [products, recents, trimmed]);

  const flatItems: Product[] = trimmed
    ? suggestions.map((s) => s.product)
    : recentHydrated;

  // Reset active index whenever list changes.
  useEffect(() => {
    setActiveIdx(0);
  }, [trimmed, flatItems.length]);

  // Keyboard navigation, mounted at window level while open so the search
  // input keeps focus.
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (!flatItems.length) {
        if (e.key === "Escape") onClose();
        return;
      }
      if (e.key === "ArrowDown") {
        e.preventDefault();
        setActiveIdx((i) => (i + 1) % flatItems.length);
      } else if (e.key === "ArrowUp") {
        e.preventDefault();
        setActiveIdx((i) => (i - 1 + flatItems.length) % flatItems.length);
      } else if (e.key === "Enter") {
        const target = flatItems[activeIdx];
        if (target) {
          e.preventDefault();
          onSelect(target);
        }
      } else if (e.key === "Escape") {
        onClose();
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, flatItems, activeIdx, onSelect, onClose]);

  // Click-away dismiss.
  useEffect(() => {
    if (!open) return;
    const onClick = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        onClose();
      }
    };
    // Delay so the same click that opened the dropdown doesn't close it.
    const t = window.setTimeout(() => document.addEventListener("mousedown", onClick), 0);
    return () => {
      window.clearTimeout(t);
      document.removeEventListener("mousedown", onClick);
    };
  }, [open, onClose]);

  if (!open) return null;

  const heading = trimmed ? "Smart suggestions" : "Recent items";
  const HeadingIcon = trimmed ? Sparkles : Clock;
  const hint = trimmed
    ? `${flatItems.length} match${flatItems.length === 1 ? "" : "es"} • ↑↓ to move, Enter to add`
    : recentHydrated.length
      ? "Products you've rung up recently"
      : "";

  return (
    <div
      ref={containerRef}
      className="absolute left-0 right-0 top-full z-30 mt-1 rounded-lg border-2 border-border bg-popover shadow-elevated overflow-hidden"
      role="listbox"
      aria-label="Product quick lookup"
    >
      <div className="flex items-center justify-between gap-2 border-b border-border/60 bg-muted/40 px-3 py-2">
        <div className="flex items-center gap-2">
          <HeadingIcon className="h-3.5 w-3.5 text-accent" />
          <span className="text-[10px] font-bold uppercase tracking-[0.15em] text-foreground">
            {heading}
          </span>
        </div>
        {hint && <span className="text-[10px] font-medium text-muted-foreground">{hint}</span>}
      </div>

      {flatItems.length === 0 ? (
        <div className="flex items-center gap-2 px-3 py-6 text-xs text-muted-foreground">
          <Search className="h-3.5 w-3.5" />
          {trimmed ? `No products match "${query}".` : "No recent items yet."}
        </div>
      ) : (
        <ul className="max-h-80 overflow-y-auto">
          {flatItems.map((product, i) => {
            const qty = Number(product.quantity) || 0;
            const isOut = qty <= 0 || !product.in_stock;
            const match = trimmed ? suggestions[i]?.matchedField : null;
            return (
              <li key={product.id}>
                <button
                  type="button"
                  role="option"
                  aria-selected={i === activeIdx}
                  disabled={isOut}
                  onMouseEnter={() => setActiveIdx(i)}
                  onClick={() => onSelect(product)}
                  className={cn(
                    "flex w-full items-center gap-3 px-3 py-2 text-left transition-colors",
                    i === activeIdx && !isOut
                      ? "bg-accent/10 text-foreground"
                      : "hover:bg-muted/50",
                    isOut && "opacity-50 cursor-not-allowed",
                  )}
                >
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2">
                      <span className="truncate text-sm font-semibold text-foreground">
                        {product.name}
                      </span>
                      {match && (
                        <Badge
                          variant="secondary"
                          className="h-4 px-1.5 text-[9px] font-bold uppercase tracking-wider"
                        >
                          {match}
                        </Badge>
                      )}
                    </div>
                    <div className="flex items-center gap-2 text-[11px] text-muted-foreground">
                      {product.brand && <span className="truncate">{product.brand}</span>}
                      {product.sku && (
                        <span className="tabular-nums font-medium">· SKU {product.sku}</span>
                      )}
                      {product.strain && <span className="truncate">· {product.strain}</span>}
                    </div>
                  </div>
                  <div className="flex flex-col items-end gap-0.5 shrink-0">
                    <span className="text-sm font-bold text-accent tabular-nums">
                      {Number(product.price) > 0 ? `$${Number(product.price).toFixed(2)}` : "—"}
                    </span>
                    {isOut ? (
                      <span className="flex items-center gap-1 text-[10px] font-bold text-destructive">
                        <PackageX className="h-3 w-3" /> Out
                      </span>
                    ) : (
                      <span className="text-[10px] font-medium text-muted-foreground tabular-nums">
                        {qty} in stock
                      </span>
                    )}
                  </div>
                </button>
              </li>
            );
          })}
        </ul>
      )}
    </div>
  );
});
