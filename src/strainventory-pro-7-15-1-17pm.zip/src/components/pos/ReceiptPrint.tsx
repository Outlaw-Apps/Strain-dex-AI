import { useEffect, useState, type CSSProperties } from "react";
import { createPortal } from "react-dom";
import { formatDisplayNumber } from "@/lib/posPricing";
import { usePrinterSettings } from "@/hooks/usePosLocalSettings";



export interface ReceiptLineItem {
  name: string;
  weight: string;
  qty: number;
  unitPrice: number;
  total: number;
}

export interface ReceiptData {
  transactionId: string;
  dateISO: string;
  storeName?: string;
  items: ReceiptLineItem[];
  subtotal: number;
  discountTotal: number;
  tax: number;
  total: number;
  paymentMethod: string;
  customerName?: string | null;
  cashierName?: string | null;
}

const money = (n: number) => `$${(Number(n) || 0).toFixed(2)}`;

/**
 * Hidden receipt — only rendered in the print layer via @media print rules in index.css.
 * Sized for an 80mm thermal printer (~72mm printable area).
 */
export const ReceiptPrint = ({ data }: { data: ReceiptData | null }) => {
  const [mounted, setMounted] = useState(false);
  const { widthMm, fontScale, paperSize } = usePrinterSettings();
  useEffect(() => setMounted(true), []);
  if (!data || !mounted || typeof document === "undefined") return null;
  const date = new Date(data.dateISO);
  const dateStr = date.toLocaleString();
  const store = data.storeName || "Strainventory";

  const printableWidthMm = paperSize === "thermal" ? widthMm : paperSize === "a4" ? 190 : 200;
  const styleVars = {
    ["--receipt-width" as string]: `${printableWidthMm}mm`,
    ["--receipt-font-scale" as string]: String(fontScale),
    ["--receipt-paper-size" as string]:
      paperSize === "thermal" ? `${Math.max(widthMm + 4, 58)}mm auto` : paperSize === "a4" ? "A4" : "Letter",
  } as CSSProperties;

  return createPortal(

    <div id="print-receipt-root" className="print-only-receipt" style={styleVars}>

      <div className="receipt">
        <div className="receipt-header">
          <div className="store-name">{store}</div>
          <div className="receipt-sub">Licensed Cannabis Retailer</div>
          <div className="receipt-sub">{dateStr}</div>
          <div className="receipt-sub">Txn #{data.transactionId}</div>
          {data.customerName ? <div className="receipt-sub">Customer: {data.customerName}</div> : null}
          {data.cashierName ? <div className="receipt-sub">Cashier: {data.cashierName}</div> : null}
        </div>

        <div className="dashed" />

        <div className="items">
          {data.items.map((item, idx) => (
            <div key={idx} className="item-row">
              <div className="item-name">{item.name}</div>
              <div className="item-line">
                <span>
                  {formatDisplayNumber(item.qty)} × {item.weight} @ {money(item.unitPrice)}
                </span>
                <span className="num">{money(item.total)}</span>
              </div>
            </div>
          ))}
        </div>

        <div className="dashed" />

        <div className="totals">
          <div className="total-row">
            <span>Subtotal</span>
            <span className="num">{money(data.subtotal)}</span>
          </div>
          {data.discountTotal > 0 ? (
            <div className="total-row">
              <span>Discounts</span>
              <span className="num">-{money(data.discountTotal)}</span>
            </div>
          ) : null}
          <div className="total-row">
            <span>Tax</span>
            <span className="num">{money(data.tax)}</span>
          </div>
          <div className="dashed" />
          <div className="total-row grand">
            <span>TOTAL</span>
            <span className="num">{money(data.total)}</span>
          </div>
          <div className="total-row">
            <span>Paid ({data.paymentMethod})</span>
            <span className="num">{money(data.total)}</span>
          </div>
        </div>

        <div className="dashed" />

        <div className="receipt-footer">
          <div>Thank you for shopping with us!</div>
          <div>Keep out of reach of children & pets.</div>
          <div>For use only by adults 21+.</div>
          <div className="receipt-sub">strainventory.com</div>
        </div>
      </div>
    </div>,
    document.body,
  );
};

