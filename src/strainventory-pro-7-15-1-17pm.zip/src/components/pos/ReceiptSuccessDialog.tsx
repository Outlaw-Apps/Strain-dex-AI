import { useEffect } from "react";
import { Printer, CheckCircle2 } from "lucide-react";
import { Dialog, DialogContent, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { VisuallyHidden } from "@radix-ui/react-visually-hidden";
import type { ReceiptData } from "./ReceiptPrint";

interface Props {
  open: boolean;
  data: ReceiptData | null;
  autoPrint: boolean;
  onClose: () => void;
}

export const ReceiptSuccessDialog = ({ open, data, autoPrint, onClose }: Props) => {
  // Auto-print when toggle is enabled
  useEffect(() => {
    if (!open || !data || !autoPrint) return;
    const t = setTimeout(() => {
      try {
        window.print();
      } catch {
        /* ignore */
      }
    }, 250);
    return () => clearTimeout(t);
  }, [open, data, autoPrint]);

  if (!data) return null;

  return (
    <Dialog open={open} onOpenChange={(o) => { if (!o) onClose(); }}>
      <DialogContent className="max-w-sm border-2 border-emerald-500/40 bg-card p-0 overflow-hidden no-print">
        <VisuallyHidden>
          <DialogTitle>Transaction Complete</DialogTitle>
          <DialogDescription>Print or close receipt</DialogDescription>
        </VisuallyHidden>
        <div className="p-6 flex flex-col items-center text-center">
          <div className="h-16 w-16 rounded-full bg-emerald-500 flex items-center justify-center ring-4 ring-emerald-400/40 mb-4">
            <CheckCircle2 className="h-9 w-9 text-white" strokeWidth={2.5} />
          </div>
          <h2 className="font-serif text-2xl font-extrabold text-foreground">Transaction Complete</h2>
          <p className="text-sm text-muted-foreground mt-1">Txn #{data.transactionId}</p>
          <p className="mt-4 text-4xl font-extrabold tabular-nums">${data.total.toFixed(2)}</p>
          <p className="text-xs text-muted-foreground mt-0.5">Paid via {data.paymentMethod}</p>

          <div className="mt-6 flex gap-2 w-full">
            <Button variant="outline" size="sm" className="flex-1 h-10" onClick={onClose}>
              Close
            </Button>
            <Button
              variant="gold"
              size="sm"
              className="flex-1 h-10 gap-1.5"
              onClick={() => window.print()}
            >
              <Printer className="h-4 w-4" strokeWidth={2.5} />
              Print Receipt
            </Button>
          </div>
          {autoPrint ? (
            <p className="mt-3 text-[11px] text-muted-foreground">Auto-print enabled — opening print dialog…</p>
          ) : null}
        </div>
      </DialogContent>
    </Dialog>
  );
};
