import { motion } from "framer-motion";
import { ArrowRight, ImageIcon, Loader2, RotateCcw, Sparkles, Vault } from "lucide-react";
import { Button } from "@/components/ui/button";

interface Props {
  submitting: boolean;
  missingRequired: boolean;
  canSearch: boolean;
  onClear: () => void;
  onFindImages: () => void;
  onGenerateAIDraft: () => void;
  onSubmit: () => void;
}

export default function IntakeActions({
  submitting,
  missingRequired,
  canSearch,
  onClear,
  onFindImages,
  onGenerateAIDraft,
  onSubmit,
}: Props) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3, delay: 0.32 }}
      className="flex flex-col sm:flex-row items-center justify-between gap-4 mt-8"
    >
      <div className="flex items-center gap-3 w-full sm:w-auto">
        <Button
          variant="outline"
          className="gap-2 w-full sm:w-auto"
          onClick={onClear}
          disabled={submitting}
        >
          <RotateCcw className="h-4 w-4" />
          Clear Form
        </Button>
      </div>

      <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2 sm:gap-3 w-full sm:w-auto sm:flex-wrap sm:justify-end">
        <Button variant="outline" className="gap-2" disabled={!canSearch} onClick={onFindImages}>
          <ImageIcon className="h-4 w-4" />
          Find Images
        </Button>
        <Button variant="gold" className="gap-2" disabled={!canSearch} onClick={onGenerateAIDraft}>
          <Sparkles className="h-4 w-4" />
          Generate AI Draft
          <ArrowRight className="h-4 w-4" />
        </Button>
        <Button
          variant="emerald"
          size="lg"
          className="gap-2"
          disabled={missingRequired || submitting}
          onClick={onSubmit}
        >
          {submitting ? <Loader2 className="h-4 w-4 animate-spin" /> : <Vault className="h-4 w-4" />}
          Add to Vault
        </Button>
      </div>
    </motion.div>
  );
}
