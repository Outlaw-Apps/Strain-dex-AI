import { AnimatePresence, motion } from "framer-motion";
import { Leaf, Loader2, Wand2 } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { cardMotion } from "./cardMotion";
import type { IntakeForm } from "@/lib/productIntake/types";

interface Props {
  form: IntakeForm;
  set: <K extends keyof IntakeForm>(key: K, value: IntakeForm[K]) => void;
  generatingProfile: boolean;
  onAutoGenerate: () => void;
}

export default function IntakeCannabisProfileCard({ form, set, generatingProfile, onAutoGenerate }: Props) {
  return (
    <motion.div {...cardMotion(0.19)}>
      <Card className="h-full border-2 border-border bg-card shadow-elevated rounded-2xl">
        <CardHeader className="pb-4">
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2 text-base">
              <Leaf className="h-4 w-4 text-accent" />
              Cannabis Profile
            </CardTitle>
            <Button
              variant="outline"
              size="sm"
              className="gap-1.5 text-xs"
              disabled={generatingProfile || (!form.name.trim() && !form.brand.trim())}
              onClick={onAutoGenerate}
            >
              {generatingProfile ? (
                <Loader2 className="h-3.5 w-3.5 animate-spin" />
              ) : (
                <Wand2 className="h-3.5 w-3.5" />
              )}
              {generatingProfile ? "Updating..." : "AI Fill Details"}
            </Button>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <Label htmlFor="pi-thc">THC %</Label>
              <Input
                id="pi-thc"
                type="number"
                min="0"
                max="100"
                step="0.1"
                placeholder="e.g. 24.5"
                className="bg-background"
                value={form.thc}
                onChange={(e) => set("thc", e.target.value)}
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="pi-cbd">CBD %</Label>
              <Input
                id="pi-cbd"
                type="number"
                min="0"
                max="100"
                step="0.1"
                placeholder="e.g. 0.8"
                className="bg-background"
                value={form.cbd}
                onChange={(e) => set("cbd", e.target.value)}
              />
            </div>
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="pi-flavor">Flavor Profile</Label>
            <Input
              id="pi-flavor"
              placeholder="e.g. Sweet, Berry, Citrus"
              className="bg-background"
              value={form.flavorProfile}
              onChange={(e) => set("flavorProfile", e.target.value)}
            />
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="pi-aroma">Aroma Profile</Label>
            <Input
              id="pi-aroma"
              placeholder="e.g. Earthy, Pine, Diesel"
              className="bg-background"
              value={form.aromaProfile}
              onChange={(e) => set("aromaProfile", e.target.value)}
            />
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="pi-notes">
              Vendor Notes / Context <span className="text-muted-foreground font-normal">(optional)</span>
            </Label>
            <Textarea
              id="pi-notes"
              placeholder="Paste vendor descriptions, COA info, terpene profiles..."
              className="bg-background min-h-[80px] resize-y"
              value={form.notes}
              onChange={(e) => set("notes", e.target.value)}
            />
            <p className="text-xs text-muted-foreground">
              AI can fill THC, CBD, aroma, flavor, and supporting notes from the details you enter here.
            </p>
          </div>

          <AnimatePresence>
            {generatingProfile && (
              <motion.p
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: "auto" }}
                exit={{ opacity: 0, height: 0 }}
                className="text-xs text-muted-foreground italic"
              >
                Strain Vinny is analyzing your product...
              </motion.p>
            )}
          </AnimatePresence>
        </CardContent>
      </Card>
    </motion.div>
  );
}
