import { motion } from "framer-motion";
import { FlaskConical } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { PRODUCT_TYPES, type ProductType } from "@/lib/constants";
import {
  LIMIT_CATEGORIES,
  STRAIN_TYPES,
  type IntakeForm,
  type LimitCategory,
  type StrainType,
} from "@/lib/productIntake/types";
import { cardMotion } from "./cardMotion";

interface Props {
  form: IntakeForm;
  set: <K extends keyof IntakeForm>(key: K, value: IntakeForm[K]) => void;
}

export default function IntakeClassificationCard({ form, set }: Props) {
  return (
    <motion.div {...cardMotion(0.12)}>
      <Card className="h-full border-2 border-border bg-card shadow-elevated rounded-2xl">
        <CardHeader className="pb-4">
          <CardTitle className="flex items-center gap-2 text-base">
            <FlaskConical className="h-4 w-4 text-accent" />
            Classification
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-1.5">
            <Label>
              Strain Type <span className="text-destructive">*</span>
            </Label>
            <Select
              value={form.strainType}
              onValueChange={(value) => set("strainType", value as StrainType)}
            >
              <SelectTrigger className="bg-background">
                <SelectValue placeholder="Select strain type" />
              </SelectTrigger>
              <SelectContent>
                {STRAIN_TYPES.map((strainType) => (
                  <SelectItem key={strainType} value={strainType}>
                    {strainType}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-1.5">
            <Label>
              Limit Category <span className="text-destructive">*</span>
            </Label>
            <Select
              value={form.limitCategory}
              onValueChange={(value) => set("limitCategory", value as LimitCategory)}
            >
              <SelectTrigger className="bg-background">
                <SelectValue placeholder="Select limit category" />
              </SelectTrigger>
              <SelectContent>
                {LIMIT_CATEGORIES.map((category) => (
                  <SelectItem key={category} value={category}>
                    {category}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-1.5">
            <Label>
              Product Type <span className="text-destructive">*</span>
            </Label>
            <Select
              value={form.productType}
              onValueChange={(value) => set("productType", value as ProductType)}
            >
              <SelectTrigger className="bg-background">
                <SelectValue placeholder="Select product type" />
              </SelectTrigger>
              <SelectContent>
                {PRODUCT_TYPES.map((productType) => (
                  <SelectItem key={productType} value={productType}>
                    {productType}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="pi-genetics">Genetics / Lineage</Label>
            <Input
              id="pi-genetics"
              placeholder="e.g. Blueberry x Haze"
              className="bg-background"
              value={form.genetics}
              onChange={(e) => set("genetics", e.target.value)}
            />
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="pi-vendor">
              Vendor <span className="text-muted-foreground font-normal">(optional)</span>
            </Label>
            <Input
              id="pi-vendor"
              placeholder="e.g. GreenLine Dist."
              className="bg-background"
              value={form.vendor}
              onChange={(e) => set("vendor", e.target.value)}
            />
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}
