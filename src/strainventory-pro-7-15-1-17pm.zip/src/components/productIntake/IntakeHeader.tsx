import { motion } from "framer-motion";
import { Download, Package } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ManagerOverrideButton } from "@/components/ui/ManagerOverrideButton";
import type { useManagerOverride } from "@/hooks/useManagerOverride";

interface IntakeHeaderProps {
  hasAnyContent: boolean;
  onDownload: () => void;
  managerOverride: ReturnType<typeof useManagerOverride>;
}

export default function IntakeHeader({ hasAnyContent, onDownload, managerOverride }: IntakeHeaderProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: -8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4 }}
      className="mb-8"
    >
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="h-12 w-12 rounded-2xl gold-gradient flex items-center justify-center shadow-gold shrink-0">
            <Package className="h-6 w-6 text-background" />
          </div>
          <div>
            <h1 className="text-display text-3xl sm:text-4xl font-semibold tracking-tight text-foreground flex items-center gap-3">
              Product Intake
              <span className="h-2 w-2 rounded-full bg-success animate-pulse" aria-hidden />
            </h1>
            <p className="text-muted-foreground text-sm mt-1">
              Add a new batch to your dispensary vault. Strain Vinny can fill the key details,
              generate a draft, and help you find images.
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            className="gap-2 border-2"
            disabled={!hasAnyContent}
            onClick={onDownload}
          >
            <Download className="h-4 w-4" />
            Download Draft Report
          </Button>
          <ManagerOverrideButton override={managerOverride} />
        </div>
      </div>
    </motion.div>
  );
}
