import { motion } from "framer-motion";
import { Package, ScanLine } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { cardMotion } from "./cardMotion";
import type { IntakeForm } from "@/lib/productIntake/types";

interface Props {
  form: IntakeForm;
  set: <K extends keyof IntakeForm>(key: K, value: IntakeForm[K]) => void;
  onOpenScanner: () => void;
}

export default function IntakeIdentityCard({ form, set, onOpenScanner }: Props) {
  return (
    <motion.div {...cardMotion(0.05)}>
      <Card className="h-full border-2 border-border bg-card shadow-elevated rounded-2xl">
        <CardHeader className="pb-4">
          <CardTitle className="flex items-center gap-2 text-base">
            <Package className="h-4 w-4 text-accent" />
            Identity
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-1.5">
            <Label htmlFor="pi-name">
              Product Name <span className="text-destructive">*</span>
            </Label>
            <Input
              id="pi-name"
              placeholder="e.g. Blue Dream Pre-Roll"
              className="bg-background"
              value={form.name}
              onChange={(e) => set("name", e.target.value)}
            />
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="pi-brand">
              Brand / Cultivator <span className="text-destructive">*</span>
            </Label>
            <Input
              id="pi-brand"
              placeholder="e.g. Pacific Stone"
              className="bg-background"
              value={form.brand}
              onChange={(e) => set("brand", e.target.value)}
            />
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="pi-strain">Strain</Label>
            <Input
              id="pi-strain"
              placeholder="e.g. Blue Dream"
              className="bg-background"
              value={form.strain}
              onChange={(e) => set("strain", e.target.value)}
            />
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="pi-batch">
              Batch Number <span className="text-destructive">*</span>
            </Label>
            <Input
              id="pi-batch"
              placeholder="e.g. BN-20260404-001"
              className="bg-background"
              value={form.batchNumber}
              onChange={(e) => set("batchNumber", e.target.value)}
            />
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="pi-sku">
              SKU <span className="text-muted-foreground font-normal">(optional)</span>
            </Label>
            <div className="flex gap-2">
              <Input
                id="pi-sku"
                placeholder="e.g. PS-BD-35"
                className="bg-background flex-1"
                value={form.sku}
                onChange={(e) => set("sku", e.target.value)}
              />
              <Button
                variant="outline"
                size="icon"
                title="Scan SKU barcode"
                aria-label="Scan SKU barcode"
                onClick={onOpenScanner}
              >
                <ScanLine className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}
