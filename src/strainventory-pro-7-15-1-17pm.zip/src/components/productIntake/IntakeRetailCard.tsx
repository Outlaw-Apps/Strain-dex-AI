import { motion } from "framer-motion";
import { DollarSign } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { cardMotion } from "./cardMotion";
import type { IntakeForm } from "@/lib/productIntake/types";

interface Props {
  form: IntakeForm;
  set: <K extends keyof IntakeForm>(key: K, value: IntakeForm[K]) => void;
}

export default function IntakeRetailCard({ form, set }: Props) {
  return (
    <motion.div {...cardMotion(0.23)}>
      <Card className="h-full border-2 border-border bg-card shadow-elevated rounded-2xl">
        <CardHeader className="pb-4">
          <CardTitle className="flex items-center gap-2 text-base">
            <DollarSign className="h-4 w-4 text-accent" />
            Retail &amp; promotions
          </CardTitle>
          <p className="text-xs text-muted-foreground">
            Optional at intake — you can also set pricing from the catalog. Clearance beats sale and list price at checkout.
          </p>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-1.5">
            <Label htmlFor="pi-list-price">Base list price ($ / g)</Label>
            <Input
              id="pi-list-price"
              type="number"
              min="0"
              step="0.01"
              placeholder="e.g. 12.00"
              className="bg-background tabular-nums"
              value={form.listPricePerGram}
              onChange={(e) => set("listPricePerGram", e.target.value)}
            />
          </div>

          <div className="space-y-2 rounded-lg border border-border/60 bg-muted/20 p-3">
            <p className="text-xs font-medium text-foreground">Sale window</p>
            <div className="space-y-1.5">
              <Label htmlFor="pi-sale-price">Sale $ / g</Label>
              <Input
                id="pi-sale-price"
                type="number"
                min="0"
                step="0.01"
                className="bg-background tabular-nums"
                value={form.salePricePerGram}
                onChange={(e) => set("salePricePerGram", e.target.value)}
              />
            </div>
            <div className="gap-3 grid grid-cols-1 sm:grid-cols-2">
              <div className="space-y-1.5">
                <Label htmlFor="pi-sale-start">Starts</Label>
                <Input
                  id="pi-sale-start"
                  type="datetime-local"
                  className="bg-background"
                  value={form.saleStartsLocal}
                  onChange={(e) => set("saleStartsLocal", e.target.value)}
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="pi-sale-end">Ends</Label>
                <Input
                  id="pi-sale-end"
                  type="datetime-local"
                  className="bg-background"
                  value={form.saleEndsLocal}
                  onChange={(e) => set("saleEndsLocal", e.target.value)}
                />
              </div>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="pi-sale-label">Shelf label</Label>
              <Input
                id="pi-sale-label"
                placeholder="e.g. Flash Friday"
                className="bg-background"
                value={form.saleLabel}
                onChange={(e) => set("saleLabel", e.target.value)}
              />
            </div>
          </div>

          <div className="space-y-3 rounded-lg border border-destructive/25 bg-destructive/5 p-3">
            <div className="flex items-start gap-2">
              <Checkbox
                id="pi-clearance"
                checked={form.clearanceActive}
                onCheckedChange={(c) => set("clearanceActive", c === true)}
              />
              <div className="space-y-0.5">
                <Label htmlFor="pi-clearance" className="cursor-pointer font-medium leading-snug">
                  Clearance markdown
                </Label>
                <p className="text-[10px] text-muted-foreground">
                  Overrides sale and base list. Requires a clearance price unless Manager Override is on.
                </p>
              </div>
            </div>
            {form.clearanceActive && (
              <>
                <div className="space-y-1.5">
                  <Label htmlFor="pi-clearance-price">
                    Clearance $ / g <span className="text-destructive">*</span>
                  </Label>
                  <Input
                    id="pi-clearance-price"
                    type="number"
                    min="0"
                    step="0.01"
                    className="bg-background tabular-nums"
                    value={form.clearancePricePerGram}
                    onChange={(e) => set("clearancePricePerGram", e.target.value)}
                  />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="pi-clearance-reason">Reason</Label>
                  <Input
                    id="pi-clearance-reason"
                    placeholder="e.g. Batch aging"
                    className="bg-background"
                    value={form.clearanceReason}
                    onChange={(e) => set("clearanceReason", e.target.value)}
                  />
                </div>
              </>
            )}
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}
