import { useEffect, useMemo, useRef, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import {
  Loader2,
  KeyRound,
  UserCog,
  Check,
  AlertCircle,
  ImagePlus,
  Trash2,
  User as UserIcon,
} from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/context/AuthContext";
import { useQueryClient } from "@tanstack/react-query";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { cn } from "@/lib/utils";

export const AccountSecurityPanel = () => {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const [originalName, setOriginalName] = useState("");
  const [fullName, setFullName] = useState("");
  const [loadingProfile, setLoadingProfile] = useState(true);
  const [savingName, setSavingName] = useState(false);
  const [confirmOpen, setConfirmOpen] = useState(false);

  const [avatarUrl, setAvatarUrl] = useState<string | null>(null);
  const [uploadingAvatar, setUploadingAvatar] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [savingPassword, setSavingPassword] = useState(false);

  const trimmedName = fullName.trim();
  const nameValidation = useMemo(() => {
    if (loadingProfile) return { ok: false, message: "" };
    if (trimmedName.length === 0)
      return { ok: false, message: "Display name is required." };
    if (trimmedName.length < 2)
      return { ok: false, message: "Use at least 2 characters." };
    if (trimmedName.length > 60)
      return { ok: false, message: "Keep it under 60 characters." };
    if (!/^[\p{L}\p{N}][\p{L}\p{N}\s'.\-_]*$/u.test(trimmedName))
      return {
        ok: false,
        message: "Letters, numbers, spaces, apostrophes, hyphens, periods only.",
      };
    return { ok: true, message: "Looks good." };
  }, [trimmedName, loadingProfile]);

  const isDirty = trimmedName !== originalName.trim();

  useEffect(() => {
    if (!user) return;
    let cancelled = false;
    (async () => {
      const { data, error } = await supabase
        .from("profiles")
        .select("full_name, avatar_url")
        .eq("id", user.id)
        .maybeSingle();
      if (!cancelled) {
        if (!error && data) {
          const value = data.full_name ?? "";
          setFullName(value);
          setOriginalName(value);
          setAvatarUrl(data.avatar_url ?? null);
        }
        setLoadingProfile(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [user]);

  const handleSaveName = async () => {
    if (!user || !nameValidation.ok) return;
    setSavingName(true);
    try {
      const { error } = await supabase
        .from("profiles")
        .update({ full_name: trimmedName })
        .eq("id", user.id);
      if (error) throw error;
      await supabase.auth.updateUser({ data: { full_name: trimmedName } });
      setOriginalName(trimmedName);
      setConfirmOpen(false);
      toast.success("Display name updated.");
      queryClient.invalidateQueries({ queryKey: ["profiles"] });
      queryClient.invalidateQueries({ queryKey: ["my-profile", user.id] });
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Could not update name.");
    } finally {
      setSavingName(false);
    }
  };

  const handleAvatarFile = async (file: File) => {
    if (!user) return;
    if (!file.type.startsWith("image/")) {
      toast.error("Please choose an image file.");
      return;
    }
    if (file.size > 5 * 1024 * 1024) {
      toast.error("Image must be under 5 MB.");
      return;
    }
    setUploadingAvatar(true);
    try {
      const ext = file.name.split(".").pop()?.toLowerCase() || "png";
      const path = `${user.id}/avatar-${Date.now()}.${ext}`;
      const { error: uploadError } = await supabase.storage
        .from("avatars")
        .upload(path, file, { upsert: true, contentType: file.type });
      if (uploadError) throw uploadError;
      const { data: signed, error: signedError } = await supabase.storage
        .from("avatars")
        .createSignedUrl(path, 60 * 60 * 24 * 365 * 5);
      if (signedError) throw signedError;
      const url = signed?.signedUrl ?? "";
      const { error: updateError } = await supabase
        .from("profiles")
        .update({ avatar_url: url })
        .eq("id", user.id);
      if (updateError) throw updateError;
      await supabase.auth.updateUser({ data: { avatar_url: url } });
      setAvatarUrl(url);
      queryClient.invalidateQueries({ queryKey: ["profiles"] });
      queryClient.invalidateQueries({ queryKey: ["my-profile", user.id] });
      toast.success("Profile picture updated.");
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Could not upload avatar.");
    } finally {
      setUploadingAvatar(false);
      if (fileInputRef.current) fileInputRef.current.value = "";
    }
  };

  const handleRemoveAvatar = async () => {
    if (!user) return;
    setUploadingAvatar(true);
    try {
      const { error } = await supabase
        .from("profiles")
        .update({ avatar_url: "" })
        .eq("id", user.id);
      if (error) throw error;
      await supabase.auth.updateUser({ data: { avatar_url: null } });
      setAvatarUrl(null);
      queryClient.invalidateQueries({ queryKey: ["profiles"] });
      queryClient.invalidateQueries({ queryKey: ["my-profile", user.id] });
      toast.success("Profile picture removed.");
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Could not remove avatar.");
    } finally {
      setUploadingAvatar(false);
    }
  };

  const handleChangePassword = async () => {
    if (!user?.email) {
      toast.error("No email on this account — password change unavailable.");
      return;
    }
    if (newPassword.length < 8) {
      toast.error("New password must be at least 8 characters.");
      return;
    }
    if (newPassword !== confirmPassword) {
      toast.error("New password and confirmation do not match.");
      return;
    }
    setSavingPassword(true);
    try {
      // Reverify current password
      const { error: signInError } = await supabase.auth.signInWithPassword({
        email: user.email,
        password: currentPassword,
      });
      if (signInError) {
        toast.error("Current password is incorrect.");
        return;
      }
      const { error } = await supabase.auth.updateUser({ password: newPassword });
      if (error) throw error;
      toast.success("Password updated.");
      setCurrentPassword("");
      setNewPassword("");
      setConfirmPassword("");
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Could not update password.");
    } finally {
      setSavingPassword(false);
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      <Card className="border-2 border-border bg-card shadow-elevated rounded-2xl lg:col-span-2">
        <CardHeader className="pb-3">
          <CardTitle className="text-base flex items-center gap-2">
            <ImagePlus className="h-4 w-4 text-accent" />
            Profile Picture
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center gap-5">
            <div className="relative h-20 w-20 shrink-0 overflow-hidden rounded-full border-2 border-accent/40 bg-muted flex items-center justify-center">
              {avatarUrl ? (
                <img
                  src={avatarUrl}
                  alt="Your avatar"
                  className="h-full w-full object-cover"
                />
              ) : (
                <UserIcon className="h-8 w-8 text-muted-foreground" />
              )}
              {uploadingAvatar && (
                <div className="absolute inset-0 flex items-center justify-center bg-background/70 backdrop-blur-sm">
                  <Loader2 className="h-5 w-5 animate-spin text-accent" />
                </div>
              )}
            </div>
            <div className="flex-1 min-w-0 space-y-2">
              <p className="text-sm text-muted-foreground">
                PNG or JPG, up to 5 MB. Square images look best.
              </p>
              <div className="flex flex-wrap items-center gap-2">
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={(e) => {
                    const f = e.target.files?.[0];
                    if (f) void handleAvatarFile(f);
                  }}
                />
                <Button
                  variant="gold"
                  size="sm"
                  onClick={() => fileInputRef.current?.click()}
                  disabled={uploadingAvatar}
                  className="gap-2"
                >
                  <ImagePlus className="h-3.5 w-3.5" />
                  {avatarUrl ? "Change picture" : "Upload picture"}
                </Button>
                {avatarUrl && (
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={handleRemoveAvatar}
                    disabled={uploadingAvatar}
                    className="gap-2 text-destructive hover:text-destructive"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                    Remove
                  </Button>
                )}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card className="border-2 border-border bg-card shadow-elevated rounded-2xl">
        <CardHeader className="pb-3">
          <CardTitle className="text-base flex items-center gap-2">
            <UserCog className="h-4 w-4 text-accent" />
            Display Name
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="full-name">Full name</Label>
            <div className="relative">
              <Input
                id="full-name"
                value={fullName}
                maxLength={60}
                disabled={loadingProfile}
                onChange={(e) => setFullName(e.target.value)}
                placeholder="Your display name"
                aria-invalid={!nameValidation.ok && isDirty}
                aria-describedby="full-name-help"
                className={cn(
                  "pr-9",
                  isDirty && !nameValidation.ok && "border-destructive focus-visible:ring-destructive/50",
                  isDirty && nameValidation.ok && "border-emerald-500/60",
                )}
                onKeyDown={(e) => {
                  if (e.key === "Enter" && isDirty && nameValidation.ok) {
                    e.preventDefault();
                    setConfirmOpen(true);
                  }
                }}
              />
              {isDirty && (
                <span className="absolute right-3 top-1/2 -translate-y-1/2">
                  {nameValidation.ok ? (
                    <Check className="h-4 w-4 text-emerald-500" />
                  ) : (
                    <AlertCircle className="h-4 w-4 text-destructive" />
                  )}
                </span>
              )}
            </div>
            <div className="flex items-center justify-between gap-2">
              <p
                id="full-name-help"
                className={cn(
                  "text-xs",
                  isDirty && !nameValidation.ok
                    ? "text-destructive"
                    : isDirty && nameValidation.ok
                      ? "text-emerald-500"
                      : "text-muted-foreground",
                )}
              >
                {isDirty
                  ? nameValidation.message
                  : "Shown in the sidebar, schedule, and team messages."}
              </p>
              <span className="text-[10px] text-muted-foreground tabular-nums">
                {trimmedName.length}/60
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <Button
              variant="gold"
              onClick={() => setConfirmOpen(true)}
              disabled={loadingProfile || !isDirty || !nameValidation.ok || savingName}
              className="gap-2"
            >
              Save changes
            </Button>
            {isDirty && (
              <Button
                variant="ghost"
                onClick={() => setFullName(originalName)}
                disabled={savingName}
              >
                Cancel
              </Button>
            )}
          </div>
        </CardContent>
      </Card>

      <AlertDialog open={confirmOpen} onOpenChange={(open) => !savingName && setConfirmOpen(open)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Update your display name?</AlertDialogTitle>
            <AlertDialogDescription asChild>
              <div className="space-y-2">
                <p>This is what teammates and customers will see across the app.</p>
                <div className="rounded-md border border-border bg-muted/40 p-3 text-sm">
                  <div className="flex items-center justify-between gap-3">
                    <span className="text-xs uppercase tracking-wider text-muted-foreground">From</span>
                    <span className="font-medium text-foreground truncate">{originalName || "—"}</span>
                  </div>
                  <div className="mt-1 flex items-center justify-between gap-3">
                    <span className="text-xs uppercase tracking-wider text-muted-foreground">To</span>
                    <span className="font-semibold text-accent truncate">{trimmedName}</span>
                  </div>
                </div>
              </div>
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={savingName}>Keep current</AlertDialogCancel>
            <AlertDialogAction
              onClick={(e) => {
                e.preventDefault();
                void handleSaveName();
              }}
              disabled={savingName}
              className="gap-2"
            >
              {savingName && <Loader2 className="h-3.5 w-3.5 animate-spin" />}
              Confirm change
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>


      <Card className="border-2 border-border bg-card shadow-elevated rounded-2xl">
        <CardHeader className="pb-3">
          <CardTitle className="text-base flex items-center gap-2">
            <KeyRound className="h-4 w-4 text-accent" />
            Change Password
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {!user?.email ? (
            <p className="text-sm text-muted-foreground">
              This account uses ID + PIN. Ask an administrator to reset your PIN
              from the User Accounts panel.
            </p>
          ) : (
            <>
              <div className="space-y-2">
                <Label htmlFor="current-password">Current password</Label>
                <Input
                  id="current-password"
                  type="password"
                  autoComplete="current-password"
                  value={currentPassword}
                  onChange={(e) => setCurrentPassword(e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="new-password">New password</Label>
                <Input
                  id="new-password"
                  type="password"
                  autoComplete="new-password"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="confirm-password">Confirm new password</Label>
                <Input
                  id="confirm-password"
                  type="password"
                  autoComplete="new-password"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                />
              </div>
              <Button
                variant="gold"
                onClick={handleChangePassword}
                disabled={
                  savingPassword ||
                  !currentPassword ||
                  !newPassword ||
                  !confirmPassword
                }
                className="gap-2"
              >
                {savingPassword && <Loader2 className="h-3.5 w-3.5 animate-spin" />}
                Update password
              </Button>
              <p className="text-xs text-muted-foreground">
                Use at least 8 characters. You'll stay signed in on this device.
              </p>
            </>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default AccountSecurityPanel;
