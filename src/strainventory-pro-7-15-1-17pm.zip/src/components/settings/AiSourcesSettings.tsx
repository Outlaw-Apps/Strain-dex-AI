import { useState } from "react";
import { motion } from "framer-motion";
import { Globe, Plus, Trash2, ShieldCheck, ShieldX, Loader2 } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  type AiSearchDomain,
  type AiSearchDomainMode,
  normalizeDomainInput,
  useAiSearchDomains,
} from "@/hooks/useAiSearchDomains";

interface DomainListProps {
  title: string;
  description: string;
  domains: AiSearchDomain[];
  emptyMessage: string;
  icon: React.ReactNode;
  accent: "success" | "destructive";
  onToggle: (id: string, enabled: boolean) => void;
  onDelete: (id: string) => void;
}

const DomainList = ({
  title,
  description,
  domains,
  emptyMessage,
  icon,
  accent,
  onToggle,
  onDelete,
}: DomainListProps) => (
  <Card className="shadow-soft">
    <CardHeader className="pb-3">
      <CardTitle className="text-base flex items-center gap-2">
        <span className={accent === "success" ? "text-success" : "text-destructive"}>
          {icon}
        </span>
        {title}
        <Badge variant="secondary" className="text-[9px]">
          {domains.length}
        </Badge>
      </CardTitle>
      <p className="text-xs text-muted-foreground mt-1">{description}</p>
    </CardHeader>
    <CardContent className="space-y-2">
      {domains.length === 0 ? (
        <p className="text-xs text-muted-foreground py-4 text-center">{emptyMessage}</p>
      ) : (
        domains.map((d) => (
          <div
            key={d.id}
            className="flex items-center gap-2 px-3 py-2 rounded-md border border-border/50 bg-muted/20"
          >
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-foreground truncate">{d.domain}</p>
              {d.label && (
                <p className="text-[10px] text-muted-foreground truncate">{d.label}</p>
              )}
            </div>
            <Switch
              checked={d.enabled}
              onCheckedChange={(v) => onToggle(d.id, v)}
              aria-label={`Toggle ${d.domain}`}
            />
            <Button
              size="icon"
              variant="ghost"
              className="h-7 w-7"
              onClick={() => onDelete(d.id)}
              aria-label={`Remove ${d.domain}`}
            >
              <Trash2 className="h-3.5 w-3.5 text-destructive" />
            </Button>
          </div>
        ))
      )}
    </CardContent>
  </Card>
);

export const AiSourcesSettings = () => {
  const {
    allowDomains,
    blockDomains,
    isLoading,
    addDomain,
    addDomainPending,
    toggleEnabled,
    deleteDomain,
  } = useAiSearchDomains();

  const [newDomain, setNewDomain] = useState("");
  const [newLabel, setNewLabel] = useState("");
  const [newMode, setNewMode] = useState<AiSearchDomainMode>("allow");

  const handleAdd = async () => {
    const normalized = normalizeDomainInput(newDomain, newMode);
    if (!normalized) return;
    await addDomain({ domain: normalized, mode: newMode, label: newLabel });
    setNewDomain("");
    setNewLabel("");
  };

  const enabledAllowCount = allowDomains.filter((d) => d.enabled).length;
  const noActiveAllowlist = enabledAllowCount === 0;

  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-6"
    >
      <Card className="shadow-soft">
        <CardHeader className="pb-3">
          <CardTitle className="text-base flex items-center gap-2">
            <Globe className="h-4 w-4 text-accent" />
            AI Research Sources
          </CardTitle>
          <p className="text-xs text-muted-foreground mt-1">
            Control which websites the AI may search for strain research and product
            descriptions. Allow entries restrict the AI to specific sites; block entries
            remove URLs even when their host is allowed (e.g.{" "}
            <code className="text-[10px]">leafly.com/menu</code> blocks Leafly menu pages
            while still allowing the rest of leafly.com). Changes apply on the next AI
            draft or assistant request.
          </p>
        </CardHeader>
        <CardContent className="space-y-4">
          {noActiveAllowlist && (
            <Alert>
              <AlertDescription className="text-xs">
                No allow entries are active. The AI may search any site that is not
                explicitly blocked. Add at least one allow domain to enforce strict
                allowlist mode.
              </AlertDescription>
            </Alert>
          )}

          <div className="grid grid-cols-1 md:grid-cols-[1fr_1fr_140px_auto] gap-2 items-end">
            <div>
              <Label className="text-xs">Domain</Label>
              <Input
                placeholder="leafly.com or leafly.com/menu"
                value={newDomain}
                onChange={(e) => setNewDomain(e.target.value)}
                disabled={addDomainPending}
              />
            </div>
            <div>
              <Label className="text-xs">Label (optional)</Label>
              <Input
                placeholder="e.g. Leafly menu pages"
                value={newLabel}
                onChange={(e) => setNewLabel(e.target.value)}
                disabled={addDomainPending}
              />
            </div>
            <div>
              <Label className="text-xs">Mode</Label>
              <Select
                value={newMode}
                onValueChange={(v) => setNewMode(v as AiSearchDomainMode)}
                disabled={addDomainPending}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="allow">Allow</SelectItem>
                  <SelectItem value="block">Block</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <Button
              variant="gold"
              onClick={handleAdd}
              disabled={addDomainPending || !newDomain.trim()}
              className="gap-1.5"
            >
              {addDomainPending ? (
                <Loader2 className="h-3.5 w-3.5 animate-spin" />
              ) : (
                <Plus className="h-3.5 w-3.5" />
              )}
              Add
            </Button>
          </div>
        </CardContent>
      </Card>

      {isLoading ? (
        <div className="flex items-center justify-center py-8 text-muted-foreground">
          <Loader2 className="h-4 w-4 animate-spin mr-2" />
          Loading domains...
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <DomainList
            title="Allowed Domains"
            description="When any allow entry is enabled the AI may only visit listed hosts."
            domains={allowDomains}
            emptyMessage="No allow entries. The AI is free to use any non-blocked site."
            icon={<ShieldCheck className="h-4 w-4" />}
            accent="success"
            onToggle={(id, enabled) => toggleEnabled({ id, enabled })}
            onDelete={(id) => deleteDomain(id)}
          />
          <DomainList
            title="Blocked Domains"
            description="Block entries always win. Use a path (e.g. leafly.com/menu) to scope the block."
            domains={blockDomains}
            emptyMessage="No block entries."
            icon={<ShieldX className="h-4 w-4" />}
            accent="destructive"
            onToggle={(id, enabled) => toggleEnabled({ id, enabled })}
            onDelete={(id) => deleteDomain(id)}
          />
        </div>
      )}
    </motion.div>
  );
};
