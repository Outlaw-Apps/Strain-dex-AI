import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { Check, Palette, RotateCcw, Type } from "lucide-react";
import {
  ACCENT_PRESETS,
  AccentPresetId,
  FONT_FAMILIES,
  FONT_SCALES,
  FontFamilyId,
  FontScaleId,
} from "@/lib/appearance";
import { useAppearanceSettings } from "@/hooks/useAppearanceSettings";
import { cn } from "@/lib/utils";

export function AppearanceSettingsPanel() {
  const { settings, update, reset } = useAppearanceSettings();

  return (
    <Card>
      <CardHeader className="flex flex-row items-start justify-between gap-3">
        <div>
          <CardTitle className="flex items-center gap-2 text-base">
            <Palette className="h-4 w-4" aria-hidden /> Appearance
          </CardTitle>
          <CardDescription>
            Personalize accent color, brightness, contrast and typography. Saved on this device.
          </CardDescription>
        </div>
        <Button
          variant="ghost"
          size="sm"
          onClick={reset}
          className="gap-1.5"
          aria-label="Reset appearance to defaults"
        >
          <RotateCcw className="h-3.5 w-3.5" /> Reset
        </Button>
      </CardHeader>

      <CardContent className="space-y-8">
        {/* Accent presets */}
        <section aria-labelledby="accent-heading" className="space-y-3">
          <h3 id="accent-heading" className="text-sm font-semibold">
            Accent color
          </h3>
          <div
            role="radiogroup"
            aria-label="Accent color preset"
            className="grid grid-cols-4 gap-3 sm:grid-cols-8"
          >
            {(Object.keys(ACCENT_PRESETS) as AccentPresetId[]).map((id) => {
              const preset = ACCENT_PRESETS[id];
              const active = settings.accent === id;
              return (
                <button
                  key={id}
                  type="button"
                  role="radio"
                  aria-checked={active}
                  aria-label={preset.label}
                  onClick={() => update({ accent: id })}
                  className={cn(
                    "group relative flex aspect-square items-center justify-center rounded-xl border-2 transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2",
                    active
                      ? "border-foreground scale-105 shadow-md"
                      : "border-border hover:scale-105 hover:border-foreground/40",
                  )}
                  style={{ backgroundColor: preset.swatch }}
                >
                  {active && (
                    <Check className="h-5 w-5 text-white drop-shadow" strokeWidth={3} />
                  )}
                  <span className="sr-only">{preset.label}</span>
                </button>
              );
            })}
          </div>
        </section>

        {/* Brightness + Contrast */}
        <section aria-labelledby="display-heading" className="space-y-5">
          <h3 id="display-heading" className="text-sm font-semibold">
            Display adjustments
          </h3>

          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <Label htmlFor="brightness-slider">Brightness</Label>
              <span className="text-sm tabular-nums text-muted-foreground">
                {settings.brightness}%
              </span>
            </div>
            <Slider
              id="brightness-slider"
              min={80}
              max={120}
              step={1}
              value={[settings.brightness]}
              onValueChange={([v]) => update({ brightness: v })}
              aria-label="Screen brightness"
            />
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <Label htmlFor="contrast-slider">Contrast</Label>
              <span className="text-sm tabular-nums text-muted-foreground">
                {settings.contrast}%
              </span>
            </div>
            <Slider
              id="contrast-slider"
              min={80}
              max={120}
              step={1}
              value={[settings.contrast]}
              onValueChange={([v]) => update({ contrast: v })}
              aria-label="Screen contrast"
            />
          </div>
        </section>

        {/* Font family */}
        <section aria-labelledby="font-heading" className="space-y-3">
          <h3
            id="font-heading"
            className="flex items-center gap-2 text-sm font-semibold"
          >
            <Type className="h-4 w-4" aria-hidden /> Typography
          </h3>

          <div
            role="radiogroup"
            aria-label="Body font family"
            className="grid grid-cols-1 gap-2 sm:grid-cols-2"
          >
            {(Object.keys(FONT_FAMILIES) as FontFamilyId[]).map((id) => {
              const f = FONT_FAMILIES[id];
              const active = settings.fontFamily === id;
              return (
                <button
                  key={id}
                  type="button"
                  role="radio"
                  aria-checked={active}
                  onClick={() => update({ fontFamily: id })}
                  className={cn(
                    "flex flex-col items-start gap-1 rounded-lg border-2 p-3 text-left transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring",
                    active
                      ? "border-foreground bg-accent/10"
                      : "border-border hover:border-foreground/30",
                  )}
                  style={{ fontFamily: f.stack }}
                >
                  <span className="text-sm font-semibold">{f.label}</span>
                  <span className="text-xs text-muted-foreground">
                    The quick brown fox jumps over the lazy dog.
                  </span>
                </button>
              );
            })}
          </div>

          <div className="space-y-2 pt-2">
            <Label>Size scale</Label>
            <div
              role="radiogroup"
              aria-label="Font size scale"
              className="grid grid-cols-3 gap-2"
            >
              {(Object.keys(FONT_SCALES) as FontScaleId[]).map((id) => {
                const s = FONT_SCALES[id];
                const active = settings.fontScale === id;
                return (
                  <button
                    key={id}
                    type="button"
                    role="radio"
                    aria-checked={active}
                    onClick={() => update({ fontScale: id })}
                    className={cn(
                      "rounded-lg border-2 px-3 py-2 text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring",
                      active
                        ? "border-foreground bg-accent/10"
                        : "border-border hover:border-foreground/30",
                    )}
                  >
                    {s.label}
                  </button>
                );
              })}
            </div>
          </div>
        </section>
      </CardContent>
    </Card>
  );
}

export default AppearanceSettingsPanel;
