import { useEffect, useRef, useState } from "react";
import { motion } from "framer-motion";
import { Image as ImageIcon, Loader2, Upload, Trash2 } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useBusinessSettings } from "@/hooks/useBusinessSettings";

const BRANDING_BUCKET = "product-images";
const BRANDING_PREFIX = "branding";

export const BrandingSettings = () => {
  const { settings, isLoading, updateSettings } = useBusinessSettings();
  const [name, setName] = useState("");
  const [logoUrl, setLogoUrl] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (settings) {
      setName(settings.business_name ?? "");
      setLogoUrl(settings.logo_url ?? null);
    }
  }, [settings]);

  const handleSave = async () => {
    setSaving(true);
    try {
      await updateSettings({
        business_name: name.trim() || null,
        logo_url: logoUrl,
      });
    } finally {
      setSaving(false);
    }
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 2 * 1024 * 1024) {
      toast.error("Logo must be smaller than 2MB.");
      return;
    }
    setUploading(true);
    try {
      const ext = file.name.split(".").pop() || "png";
      const path = `${BRANDING_PREFIX}/logo-${Date.now()}.${ext}`;
      const { error } = await supabase.storage
        .from(BRANDING_BUCKET)
        .upload(path, file, { cacheControl: "3600", upsert: true });
      if (error) throw error;
      const { data } = supabase.storage.from(BRANDING_BUCKET).getPublicUrl(path);
      setLogoUrl(data.publicUrl);
      await updateSettings({ logo_url: data.publicUrl });
    } catch (err) {
      console.error(err);
      toast.error(err instanceof Error ? err.message : "Failed to upload logo.");
    } finally {
      setUploading(false);
      if (fileRef.current) fileRef.current.value = "";
    }
  };

  const handleRemoveLogo = async () => {
    setLogoUrl(null);
    await updateSettings({ logo_url: null });
  };

  return (
    <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }}>
      <Card className="border-2 border-border bg-card shadow-elevated rounded-2xl">
        <CardHeader className="pb-3">
          <CardTitle className="text-base flex items-center gap-2">
            <ImageIcon className="h-4 w-4 text-accent" />
            Dispensary Branding
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="business-name" className="text-sm font-medium">
              Dispensary Name
            </Label>
            <Input
              id="business-name"
              placeholder="e.g. Green Leaf Co."
              value={name}
              onChange={(e) => setName(e.target.value)}
              disabled={isLoading}
              maxLength={60}
            />
            <p className="text-xs text-muted-foreground">
              Shown in the sidebar, headers, and printed receipts.
            </p>
          </div>

          <div className="space-y-2">
            <Label className="text-sm font-medium">Logo</Label>
            <div className="flex items-center gap-4">
              <div className="h-20 w-20 rounded-xl border-2 border-border bg-muted/30 flex items-center justify-center overflow-hidden shrink-0">
                {logoUrl ? (
                  <img
                    src={logoUrl}
                    alt="Dispensary logo"
                    className="h-full w-full object-cover"
                  />
                ) : (
                  <ImageIcon className="h-7 w-7 text-muted-foreground/50" />
                )}
              </div>
              <div className="flex flex-col gap-2">
                <input
                  ref={fileRef}
                  type="file"
                  accept="image/png,image/jpeg,image/webp,image/svg+xml"
                  className="hidden"
                  onChange={handleFileChange}
                />
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => fileRef.current?.click()}
                  disabled={uploading}
                  className="gap-2"
                >
                  {uploading ? (
                    <Loader2 className="h-3.5 w-3.5 animate-spin" />
                  ) : (
                    <Upload className="h-3.5 w-3.5" />
                  )}
                  {logoUrl ? "Replace Logo" : "Upload Logo"}
                </Button>
                {logoUrl && (
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={handleRemoveLogo}
                    className="gap-2 text-destructive hover:text-destructive"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                    Remove
                  </Button>
                )}
              </div>
            </div>
            <p className="text-xs text-muted-foreground">
              PNG, JPG, WebP, or SVG. Max 2MB. Square images look best.
            </p>
          </div>

          <div className="pt-2 flex justify-end">
            <Button
              variant="gold"
              size="sm"
              onClick={handleSave}
              disabled={saving || isLoading}
              className="gap-1.5 border-2 border-accent shadow-gold font-semibold"
            >
              {saving && <Loader2 className="h-3.5 w-3.5 animate-spin" />}
              Save Branding
            </Button>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
};
