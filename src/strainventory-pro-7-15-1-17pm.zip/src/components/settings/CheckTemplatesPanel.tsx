import { useState } from "react";
import { motion } from "framer-motion";
import { Plus, Pencil, Trash2, Star, Loader2, Banknote, AlertTriangle, Eye } from "lucide-react";
import { toast } from "sonner";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  useCheckTemplates, useCreateCheckTemplate, useDeleteCheckTemplate, useUpdateCheckTemplate,
} from "@/hooks/useCheckTemplates";
import {
  DEFAULT_CHECK_LAYOUT, type CheckStockMode, type CheckTemplate,
} from "@/lib/payroll/checkTemplates.types";
import { buildChecksPdf } from "@/lib/payroll/checkPdf";

interface FormState {
  name: string;
  bank_name: string;
  bank_address: string;
  account_holder: string;
  account_holder_address: string;
  routing_number: string;
  account_number: string;
  fractional_routing: string;
  next_check_number: number;
  signature_label: string;
  memo_default: string;
  stock_mode: CheckStockMode;
  is_default: boolean;
  is_active: boolean;
}

const emptyForm: FormState = {
  name: "",
  bank_name: "",
  bank_address: "",
  account_holder: "",
  account_holder_address: "",
  routing_number: "",
  account_number: "",
  fractional_routing: "",
  next_check_number: 1001,
  signature_label: "Authorized Signature",
  memo_default: "",
  stock_mode: "preprinted",
  is_default: false,
  is_active: true,
};

function maskAccount(acct: string) {
  if (!acct) return "";
  return acct.length <= 4 ? acct : `••••${acct.slice(-4)}`;
}

export function CheckTemplatesPanel() {
  const { data: templates = [], isLoading } = useCheckTemplates();
  const create = useCreateCheckTemplate();
  const update = useUpdateCheckTemplate();
  const del = useDeleteCheckTemplate();

  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<CheckTemplate | null>(null);
  const [form, setForm] = useState<FormState>(emptyForm);
  const [confirmDelete, setConfirmDelete] = useState<CheckTemplate | null>(null);

  const openNew = () => {
    setEditing(null);
    setForm(emptyForm);
    setOpen(true);
  };

  const openEdit = (t: CheckTemplate) => {
    setEditing(t);
    setForm({
      name: t.name,
      bank_name: t.bank_name,
      bank_address: t.bank_address ?? "",
      account_holder: t.account_holder,
      account_holder_address: t.account_holder_address ?? "",
      routing_number: t.routing_number,
      account_number: t.account_number,
      fractional_routing: t.fractional_routing ?? "",
      next_check_number: t.next_check_number,
      signature_label: t.signature_label,
      memo_default: t.memo_default ?? "",
      stock_mode: t.stock_mode,
      is_default: t.is_default,
      is_active: t.is_active,
    });
    setOpen(true);
  };

  const validate = (): string | null => {
    if (!form.name.trim()) return "Template name is required.";
    if (!form.bank_name.trim()) return "Bank name is required.";
    if (!form.account_holder.trim()) return "Account holder is required.";
    if (!/^\d{9}$/.test(form.routing_number)) return "Routing number must be exactly 9 digits.";
    if (!/^\d{4,17}$/.test(form.account_number)) return "Account number must be 4-17 digits.";
    if (form.next_check_number < 1) return "Next check number must be a positive integer.";
    return null;
  };

  const submit = async () => {
    const err = validate();
    if (err) { toast.error(err); return; }
    const payload = {
      name: form.name.trim(),
      bank_name: form.bank_name.trim(),
      bank_address: form.bank_address.trim() || null,
      account_holder: form.account_holder.trim(),
      account_holder_address: form.account_holder_address.trim() || null,
      routing_number: form.routing_number.trim(),
      account_number: form.account_number.trim(),
      fractional_routing: form.fractional_routing.trim() || null,
      next_check_number: form.next_check_number,
      signature_label: form.signature_label.trim() || "Authorized Signature",
      memo_default: form.memo_default.trim() || null,
      stock_mode: form.stock_mode,
      is_default: form.is_default,
      is_active: form.is_active,
      layout: editing?.layout ?? DEFAULT_CHECK_LAYOUT,
    };
    try {
      if (editing) {
        await update.mutateAsync({ id: editing.id, ...payload });
        toast.success("Check template updated.");
      } else {
        await create.mutateAsync(payload);
        toast.success("Check template created.");
      }
      setOpen(false);
    } catch (e) {
      toast.error("Failed to save check template.");
      console.error(e);
    }
  };

  const preview = (t: CheckTemplate) => {
    try {
      const bytes = buildChecksPdf({
        template: t,
        checks: [{
          payee_name: "Sample Employee",
          amount: 1234.56,
          memo: "Preview only — not for negotiation",
          check_number: t.next_check_number,
          date: new Date(),
        }],
      });
      const blob = new Blob([bytes as BlobPart], { type: "application/pdf" });
      const url = URL.createObjectURL(blob);
      window.open(url, "_blank");
      window.setTimeout(() => URL.revokeObjectURL(url), 10_000);
    } catch (e) {
      toast.error("Could not build preview.");
      console.error(e);
    }
  };

  return (
    <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }}>
      <Card className="border-2 border-border bg-card shadow-elevated rounded-2xl">
        <CardHeader className="flex flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-xl gold-gradient flex items-center justify-center shadow-gold">
              <Banknote className="h-5 w-5 text-accent-foreground" />
            </div>
            <div>
              <CardTitle className="text-lg">Bank Check Templates</CardTitle>
              <p className="text-xs text-muted-foreground mt-0.5">
                MICR-ready templates used when printing payroll paychecks.
              </p>
            </div>
          </div>
          <Button size="sm" variant="gold" onClick={openNew} className="gap-1.5">
            <Plus className="h-4 w-4" /> New Template
          </Button>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex items-start gap-2 rounded-lg border border-warning/40 bg-warning/10 p-3 text-xs">
            <AlertTriangle className="h-4 w-4 text-warning shrink-0 mt-0.5" />
            <p className="text-muted-foreground leading-relaxed">
              For bank clearing, the MICR line must be printed with a licensed <strong>MICR E-13B</strong> font
              using magnetic toner. Use <em>Pre-printed stock</em> mode for standard business check paper,
              or <em>Blank stock</em> mode when your printer is configured with MICR E-13B.
            </p>
          </div>

          {isLoading ? (
            <div className="flex items-center justify-center py-8 text-muted-foreground">
              <Loader2 className="h-5 w-5 animate-spin mr-2" /> Loading templates…
            </div>
          ) : templates.length === 0 ? (
            <div className="text-center py-8 text-sm text-muted-foreground">
              No check templates yet. Create one to start printing paychecks.
            </div>
          ) : (
            <ul className="space-y-2">
              {templates.map((t) => (
                <li
                  key={t.id}
                  className="flex flex-col sm:flex-row sm:items-center gap-3 rounded-xl border border-border bg-background/50 p-3"
                >
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <p className="text-sm font-semibold text-foreground truncate">{t.name}</p>
                      {t.is_default && (
                        <Badge variant="secondary" className="gap-1 text-[10px]">
                          <Star className="h-3 w-3" /> Default
                        </Badge>
                      )}
                      <Badge variant="outline" className="text-[10px] uppercase tracking-wider">
                        {t.stock_mode === "preprinted" ? "Pre-printed" : "Blank stock"}
                      </Badge>
                      {!t.is_active && (
                        <Badge variant="destructive" className="text-[10px]">Inactive</Badge>
                      )}
                    </div>
                    <p className="text-xs text-muted-foreground mt-0.5 truncate">
                      {t.bank_name} • Routing {t.routing_number} • Acct {maskAccount(t.account_number)} • Next #{t.next_check_number}
                    </p>
                  </div>
                  <div className="flex items-center gap-1.5 shrink-0">
                    <Button size="sm" variant="ghost" onClick={() => preview(t)} className="gap-1.5">
                      <Eye className="h-3.5 w-3.5" /> Preview
                    </Button>
                    <Button size="sm" variant="outline" onClick={() => openEdit(t)} className="gap-1.5">
                      <Pencil className="h-3.5 w-3.5" /> Edit
                    </Button>
                    <Button
                      size="sm"
                      variant="ghost"
                      className="text-destructive hover:text-destructive gap-1.5"
                      onClick={() => setConfirmDelete(t)}
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </Button>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </CardContent>
      </Card>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editing ? "Edit Check Template" : "New Check Template"}</DialogTitle>
            <DialogDescription>
              Bank routing and account numbers are stored securely and visible only to admins.
            </DialogDescription>
          </DialogHeader>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="sm:col-span-2">
              <Label>Template Name <span className="text-destructive">*</span></Label>
              <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })}
                placeholder="Primary Payroll Checks" />
            </div>

            <div>
              <Label>Bank Name <span className="text-destructive">*</span></Label>
              <Input value={form.bank_name} onChange={(e) => setForm({ ...form, bank_name: e.target.value })} />
            </div>
            <div>
              <Label>Bank Address</Label>
              <Input value={form.bank_address} onChange={(e) => setForm({ ...form, bank_address: e.target.value })} />
            </div>

            <div>
              <Label>Account Holder <span className="text-destructive">*</span></Label>
              <Input value={form.account_holder} onChange={(e) => setForm({ ...form, account_holder: e.target.value })} />
            </div>
            <div>
              <Label>Account Holder Address</Label>
              <Input value={form.account_holder_address}
                onChange={(e) => setForm({ ...form, account_holder_address: e.target.value })} />
            </div>

            <div>
              <Label>Routing Number (9 digits) <span className="text-destructive">*</span></Label>
              <Input inputMode="numeric" maxLength={9}
                value={form.routing_number}
                onChange={(e) => setForm({ ...form, routing_number: e.target.value.replace(/\D/g, "") })} />
            </div>
            <div>
              <Label>Account Number <span className="text-destructive">*</span></Label>
              <Input inputMode="numeric"
                value={form.account_number}
                onChange={(e) => setForm({ ...form, account_number: e.target.value.replace(/\D/g, "") })} />
            </div>

            <div>
              <Label>Fractional Routing (optional)</Label>
              <Input value={form.fractional_routing}
                onChange={(e) => setForm({ ...form, fractional_routing: e.target.value })}
                placeholder="12-3456/7890" />
            </div>
            <div>
              <Label>Next Check Number <span className="text-destructive">*</span></Label>
              <Input type="number" min={1} value={form.next_check_number}
                onChange={(e) => setForm({ ...form, next_check_number: Number(e.target.value) || 1 })} />
            </div>

            <div>
              <Label>Check Stock Mode</Label>
              <Select value={form.stock_mode}
                onValueChange={(v) => setForm({ ...form, stock_mode: v as CheckStockMode })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="preprinted">Pre-printed stock (recommended)</SelectItem>
                  <SelectItem value="blank">Blank stock (requires MICR font)</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Signature Label</Label>
              <Input value={form.signature_label}
                onChange={(e) => setForm({ ...form, signature_label: e.target.value })} />
            </div>

            <div className="sm:col-span-2">
              <Label>Default Memo</Label>
              <Textarea rows={2} value={form.memo_default}
                onChange={(e) => setForm({ ...form, memo_default: e.target.value })}
                placeholder="Payroll — %period%" />
            </div>

            <div className="flex items-center justify-between rounded-lg border border-border p-3">
              <div>
                <p className="text-sm font-medium">Default template</p>
                <p className="text-xs text-muted-foreground">Auto-selected when printing checks.</p>
              </div>
              <Switch checked={form.is_default}
                onCheckedChange={(v) => setForm({ ...form, is_default: v })} />
            </div>
            <div className="flex items-center justify-between rounded-lg border border-border p-3">
              <div>
                <p className="text-sm font-medium">Active</p>
                <p className="text-xs text-muted-foreground">Inactive templates are hidden from selection.</p>
              </div>
              <Switch checked={form.is_active}
                onCheckedChange={(v) => setForm({ ...form, is_active: v })} />
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
            <Button variant="gold" onClick={submit} disabled={create.isPending || update.isPending}>
              {(create.isPending || update.isPending) && <Loader2 className="h-4 w-4 animate-spin mr-1.5" />}
              {editing ? "Save Changes" : "Create Template"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!confirmDelete} onOpenChange={(o) => !o && setConfirmDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete check template?</AlertDialogTitle>
            <AlertDialogDescription>
              This removes the "{confirmDelete?.name}" template. Any check numbers already printed
              are unaffected. This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              onClick={async () => {
                if (!confirmDelete) return;
                try {
                  await del.mutateAsync(confirmDelete.id);
                  toast.success("Template deleted.");
                } catch (e) {
                  toast.error("Failed to delete template.");
                  console.error(e);
                }
                setConfirmDelete(null);
              }}
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </motion.div>
  );
}

export default CheckTemplatesPanel;
