import { useEffect, useState } from "react";
import { Loader2, Mail, Save, RotateCcw } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";

interface EmailTemplate {
  id: string;
  template_name: string;
  display_name: string;
  subject: string;
  body_html: string;
  description: string | null;
  variables: string[];
  enabled: boolean;
}

export const EmailTemplatesSettings = () => {
  const [templates, setTemplates] = useState<EmailTemplate[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState<string | null>(null);
  const [drafts, setDrafts] = useState<Record<string, Partial<EmailTemplate>>>({});

  const load = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from("email_templates" as never)
      .select("*")
      .order("display_name");
    if (error) {
      toast.error("Failed to load email templates");
      setLoading(false);
      return;
    }
    const rows = (data as unknown as EmailTemplate[]) ?? [];
    setTemplates(rows);
    setDrafts({});
    setLoading(false);
  };

  useEffect(() => {
    load();
  }, []);

  const getValue = <K extends keyof EmailTemplate>(t: EmailTemplate, key: K): EmailTemplate[K] => {
    const draft = drafts[t.id]?.[key];
    return (draft ?? t[key]) as EmailTemplate[K];
  };

  const setField = <K extends keyof EmailTemplate>(id: string, key: K, value: EmailTemplate[K]) => {
    setDrafts((prev) => ({ ...prev, [id]: { ...prev[id], [key]: value } }));
  };

  const isDirty = (id: string) => Boolean(drafts[id] && Object.keys(drafts[id]).length > 0);

  const save = async (t: EmailTemplate) => {
    const patch = drafts[t.id];
    if (!patch) return;
    setSaving(t.id);
    const { error } = await supabase
      .from("email_templates" as never)
      .update(patch as never)
      .eq("id", t.id);
    setSaving(null);
    if (error) {
      toast.error("Save failed: " + error.message);
      return;
    }
    toast.success(`${t.display_name} saved`);
    await load();
  };

  const reset = (id: string) => {
    setDrafts((prev) => {
      const next = { ...prev };
      delete next[id];
      return next;
    });
  };

  if (loading) {
    return (
      <Card className="border-2 border-border bg-card shadow-elevated rounded-2xl">
        <CardContent className="py-12 flex items-center justify-center text-muted-foreground">
          <Loader2 className="h-5 w-5 animate-spin mr-2" /> Loading templates…
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="border-2 border-border bg-card shadow-elevated rounded-2xl">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-base">
          <Mail className="h-4 w-4 text-accent" />
          Email Templates
        </CardTitle>
        <p className="text-xs text-muted-foreground">
          Edit the subject and body of reusable transactional emails. Use{" "}
          <code className="px-1 rounded bg-muted">{"{{variable}}"}</code> to interpolate values
          sent from the app.
        </p>
      </CardHeader>
      <CardContent>
        {templates.length === 0 ? (
          <p className="text-sm text-muted-foreground py-6 text-center">
            No templates configured yet.
          </p>
        ) : (
          <Tabs defaultValue={templates[0].template_name} className="space-y-4">
            <TabsList className="flex-wrap h-auto gap-1 bg-muted/40 p-1 border border-border rounded-lg">
              {templates.map((t) => (
                <TabsTrigger key={t.id} value={t.template_name} className="text-xs">
                  {t.display_name}
                  {isDirty(t.id) && <span className="ml-1 h-1.5 w-1.5 rounded-full bg-accent inline-block" />}
                </TabsTrigger>
              ))}
            </TabsList>

            {templates.map((t) => (
              <TabsContent key={t.id} value={t.template_name} className="space-y-4">
                <div className="flex items-center justify-between flex-wrap gap-2">
                  <div>
                    <p className="text-sm font-semibold">{t.display_name}</p>
                    {t.description && (
                      <p className="text-xs text-muted-foreground">{t.description}</p>
                    )}
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="flex items-center gap-2">
                      <Label className="text-xs text-muted-foreground">Enabled</Label>
                      <Switch
                        checked={getValue(t, "enabled") as boolean}
                        onCheckedChange={(v) => setField(t.id, "enabled", v)}
                      />
                    </div>
                  </div>
                </div>

                {t.variables?.length > 0 && (
                  <div className="flex flex-wrap items-center gap-1.5">
                    <span className="text-[11px] text-muted-foreground">Available variables:</span>
                    {t.variables.map((v) => (
                      <Badge key={v} variant="outline" className="text-[10px] font-mono">
                        {`{{${v}}}`}
                      </Badge>
                    ))}
                  </div>
                )}

                <div className="space-y-2">
                  <Label className="text-xs">Subject</Label>
                  <Input
                    value={getValue(t, "subject") as string}
                    onChange={(e) => setField(t.id, "subject", e.target.value)}
                    placeholder="Email subject"
                  />
                </div>

                <div className="space-y-2">
                  <Label className="text-xs">Body (HTML)</Label>
                  <Textarea
                    value={getValue(t, "body_html") as string}
                    onChange={(e) => setField(t.id, "body_html", e.target.value)}
                    placeholder="<h1>Hello</h1>"
                    rows={10}
                    className="font-mono text-xs"
                  />
                </div>

                <div className="flex justify-end gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    disabled={!isDirty(t.id) || saving === t.id}
                    onClick={() => reset(t.id)}
                  >
                    <RotateCcw className="h-3.5 w-3.5 mr-1" /> Reset
                  </Button>
                  <Button
                    variant="gold"
                    size="sm"
                    disabled={!isDirty(t.id) || saving === t.id}
                    onClick={() => save(t)}
                  >
                    {saving === t.id ? (
                      <Loader2 className="h-3.5 w-3.5 mr-1 animate-spin" />
                    ) : (
                      <Save className="h-3.5 w-3.5 mr-1" />
                    )}
                    Save changes
                  </Button>
                </div>
              </TabsContent>
            ))}
          </Tabs>
        )}
      </CardContent>
    </Card>
  );
};
