import { useState, useEffect, useMemo, useCallback } from "react";
import { motion } from "framer-motion";
import {
  LogIn,
  LogOut,
  Clock,
  Timer,
  CalendarDays,
  Loader2,
  User,
  Pencil,
  Trash2,
  Save,
  X,
  AlertTriangle,
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Separator } from "@/components/ui/separator";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { toast } from "sonner";
import {
  useActiveShift,
  useTimeEntries,
  useClockIn,
  useClockOut,
  type TimeEntry,
} from "@/hooks/useTimeEntries";
import { useGeofence, type GeofenceCheckKind } from "@/hooks/useGeofence";
import { useUserRoles } from "@/hooks/useUserRoles";
import { useProfileMap } from "@/hooks/useProfiles";
import { useQueryClient } from "@tanstack/react-query";
import { Link } from "react-router-dom";
import { useAuth } from "@/context/AuthContext";
import { supabase } from "@/integrations/supabase/client";

// cspell:ignore nums

/** Convert an ISO timestamp to a `datetime-local` input value in the user's local timezone. */
function toLocalDatetimeString(iso: string): string {
  const d = new Date(iso);
  const pad = (n: number) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

function formatDuration(start: string, end?: string | null) {
  const ms = (end ? new Date(end).getTime() : Date.now()) - new Date(start).getTime();
  const hrs = Math.floor(ms / 3_600_000);
  const mins = Math.floor((ms % 3_600_000) / 60_000);
  const secs = Math.floor((ms % 60_000) / 1000);
  if (hrs > 0) return `${hrs}h ${mins}m`;
  if (mins > 0) return `${mins}m ${secs}s`;
  return `${secs}s`;
}

function formatTime(iso: string) {
  return new Date(iso).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
}

function formatDate(iso: string) {
  return new Date(iso).toLocaleDateString([], { month: "short", day: "numeric" });
}

export const EmployeeTimeClock = () => {
  const { user, session, loading: authLoading } = useAuth();
  const { isAdmin } = useUserRoles();
  const { data: activeShift, isLoading: loadingActive } = useActiveShift();
  const { data: entries = [], isLoading: loadingEntries } = useTimeEntries(isAdmin);
  const clockIn = useClockIn();
  const clockOut = useClockOut();
  const profileMap = useProfileMap();
  const queryClient = useQueryClient();
  const { isInsideFence, geofenceEnabled, isLoading: geofenceSettingsLoading } = useGeofence();

  const [elapsed, setElapsed] = useState("");
  const [geofenceChecking, setGeofenceChecking] = useState(false);
  const [geofenceError, setGeofenceError] = useState<string | null>(null);
  const [geofenceErrorKind, setGeofenceErrorKind] = useState<GeofenceCheckKind | null>(null);

  const [editingEntryId, setEditingEntryId] = useState<string | null>(null);
  const [editClockIn, setEditClockIn] = useState("");
  const [editClockOut, setEditClockOut] = useState("");
  const [savingEdit, setSavingEdit] = useState(false);

  const startEdit = useCallback((entry: TimeEntry) => {
    setEditingEntryId(entry.id);
    setEditClockIn(toLocalDatetimeString(entry.clock_in));
    setEditClockOut(entry.clock_out ? toLocalDatetimeString(entry.clock_out) : "");
  }, []);

  const cancelEdit = useCallback(() => {
    setEditingEntryId(null);
    setEditClockIn("");
    setEditClockOut("");
  }, []);

  const saveEdit = useCallback(async () => {
    if (!editingEntryId) return;
    setSavingEdit(true);
    try {
      const updates = {
        clock_in: new Date(editClockIn).toISOString(),
        clock_out: editClockOut ? new Date(editClockOut).toISOString() : null,
      };
      const { error } = await supabase.from("time_entries").update(updates).eq("id", editingEntryId);
      if (error) throw error;
      toast.success("Time entry updated");
      cancelEdit();
      queryClient.invalidateQueries({ queryKey: ["time-entries"] });
    } catch {
      toast.error("Failed to update entry");
    } finally {
      setSavingEdit(false);
    }
  }, [editingEntryId, editClockIn, editClockOut, cancelEdit, queryClient]);

  const deleteEntry = useCallback(
    async (entryId: string) => {
      if (!confirm("Delete this time entry?")) return;
      try {
        const { error } = await supabase.from("time_entries").delete().eq("id", entryId);
        if (error) throw error;
        toast.success("Time entry deleted");
        queryClient.invalidateQueries({ queryKey: ["time-entries"] });
      } catch {
        toast.error("Failed to delete entry");
      }
    },
    [queryClient],
  );

  useEffect(() => {
    if (!activeShift) {
      setElapsed("");
      return;
    }
    const tick = () => setElapsed(formatDuration(activeShift.clock_in));
    tick();
    const id = setInterval(tick, 1000);
    return () => clearInterval(id);
  }, [activeShift]);

  const handleClockIn = async () => {
    setGeofenceError(null);
    setGeofenceErrorKind(null);

    if (!geofenceEnabled && !geofenceSettingsLoading) {
      await doClockIn();
      return;
    }

    setGeofenceChecking(true);
    try {
      const result = await isInsideFence();
      switch (result.kind) {
        case "disabled":
          await doClockIn();
          return;
        case "inside":
          if (result.fixSource === "ip") {
            toast.info(
              "Clocked in using approximate IP location (GPS unavailable on this device).",
            );
          }
          await doClockIn();
          return;
        case "loading":
          setGeofenceErrorKind("unavailable");
          setGeofenceError(
            "Settings are still loading. Please wait a moment and try again.",
          );
          toast.error("Settings loading");
          return;
        case "outside":
          setGeofenceErrorKind("outside");
          setGeofenceError(
            `You are ${result.distanceMeters}m from the dispensary (allowed within ${result.effectiveRadiusMeters}m). Please move closer.`,
          );
          toast.error("Outside geofence");
          return;
        case "permission_denied":
          setGeofenceErrorKind("permission_denied");
          setGeofenceError(
            "Location permission was denied. Enable location for this app and try again.",
          );
          toast.error("Location permission denied");
          return;
        case "timeout":
          setGeofenceErrorKind("timeout");
          setGeofenceError(
            "Location lookup timed out. Check your signal and try again.",
          );
          toast.error("Location timed out");
          return;
        case "unsupported":
          setGeofenceErrorKind("unsupported");
          setGeofenceError(
            "This device does not support location services.",
          );
          toast.error("Device unsupported");
          return;
        case "misconfigured":
          setGeofenceErrorKind("misconfigured");
          setGeofenceError(
            "Geofence is on but no dispensary location is set. Ask an admin to set it in Settings.",
          );
          toast.error("Geofence not configured");
          return;
        case "unavailable":
        default:
          setGeofenceErrorKind("unavailable");
          setGeofenceError(
            "Could not determine your location. Try again or ask a manager to override.",
          );
          toast.error("Location unavailable");
          return;
      }
    } finally {
      setGeofenceChecking(false);
    }
  };

  const handleManagerOverrideClockIn = async () => {
    setGeofenceError(null);
    setGeofenceErrorKind(null);
    const succeeded = await doClockIn();
    if (succeeded) {
      toast.warning("Manager override used to bypass geofence.");
    }
  };

  const doClockIn = async (): Promise<boolean> => {
    try {
      await clockIn.mutateAsync();
      toast.success("Clocked in! Have a great shift.");
      return true;
    } catch {
      toast.error("Failed to clock in");
      return false;
    }
  };

  const canOverrideGeofence =
    isAdmin &&
    geofenceErrorKind !== null &&
    geofenceErrorKind !== "disabled" &&
    geofenceErrorKind !== "inside";

  const handleClockOut = async () => {
    if (!activeShift) return;
    try {
      await clockOut.mutateAsync(activeShift.id);
      toast.success("Clocked out. Good work!");
    } catch {
      toast.error("Failed to clock out");
    }
  };

  const weeklyHours = useMemo(() => {
    const now = new Date();
    const startOfWeek = new Date(now);
    startOfWeek.setDate(now.getDate() - now.getDay());
    startOfWeek.setHours(0, 0, 0, 0);
    let totalMs = 0;
    for (const e of entries) {
      if (new Date(e.clock_in) >= startOfWeek) {
        const end = e.clock_out ? new Date(e.clock_out).getTime() : Date.now();
        totalMs += end - new Date(e.clock_in).getTime();
      }
    }
    return (totalMs / 3_600_000).toFixed(1);
  }, [entries]);

  const grouped = useMemo(() => {
    const map = new Map<string, TimeEntry[]>();
    for (const e of entries) {
      const key = formatDate(e.clock_in);
      if (!map.has(key)) map.set(key, []);
      map.get(key)!.push(e);
    }
    return Array.from(map.entries());
  }, [entries]);

  const isClocking = clockIn.isPending || clockOut.isPending || geofenceChecking;
  const getEmployeeName = (userId: string) => profileMap.get(userId) || userId.slice(0, 8);

  let clockStatusContent;
  if (loadingActive) {
    clockStatusContent = (
      <div className="flex items-center gap-2 text-muted-foreground">
        <Loader2 className="h-4 w-4 animate-spin" />
        <span className="text-sm">Loading...</span>
      </div>
    );
  } else if (activeShift) {
    clockStatusContent = (
      <div>
        <div className="flex items-center gap-2 mb-1">
          <div className="h-2.5 w-2.5 rounded-full bg-success animate-pulse" />
          <span className="text-sm font-medium text-foreground">Currently Clocked In</span>
        </div>
        <p className="text-xs text-muted-foreground">Since {formatTime(activeShift.clock_in)}</p>
        <p className="text-2xl font-semibold text-accent tabular-nums mt-1">{elapsed}</p>
      </div>
    );
  } else {
    clockStatusContent = (
      <div>
        <div className="flex items-center gap-2 mb-1">
          <div className="h-2.5 w-2.5 rounded-full bg-muted-foreground/40" />
          <span className="text-sm font-medium text-foreground">Not Clocked In</span>
        </div>
        <p className="text-xs text-muted-foreground">Tap to start your shift</p>
      </div>
    );
  }

  if (authLoading) {
    return (
      <div className="space-y-6">
        <Card className="shadow-soft">
          <CardContent className="flex items-center justify-center gap-2 py-12 text-muted-foreground">
            <Loader2 className="h-5 w-5 animate-spin" />
            <span className="text-sm">Checking your session…</span>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (!session || !user) {
    return (
      <div className="space-y-6">
        <Alert>
          <LogIn className="h-4 w-4" />
          <AlertDescription>
            <p className="mb-3">You must be signed in with an active session to use the time clock.</p>
            <Button variant="gold" size="sm" asChild>
              <Link to="/auth">Sign in</Link>
            </Button>
          </AlertDescription>
        </Alert>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }}>
        <Card className="shadow-soft">
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2">
              <Timer className="h-4 w-4 text-accent" />
              Time Clock
            </CardTitle>
          </CardHeader>
          <CardContent>
            {geofenceError && (
              <Alert variant="destructive" className="mb-4">
                <AlertTriangle className="h-4 w-4" />
                <AlertDescription className="flex flex-col gap-2">
                  <span>{geofenceError}</span>
                  {canOverrideGeofence && (
                    <Button
                      size="sm"
                      variant="outline"
                      className="self-start gap-1.5 h-7 text-xs"
                      onClick={handleManagerOverrideClockIn}
                      disabled={isClocking}
                    >
                      <LogIn className="h-3 w-3" />
                      Manager Override: Clock In Anyway
                    </Button>
                  )}
                </AlertDescription>
              </Alert>
            )}

            <div className="flex items-center gap-4">
              <div className="flex-1">{clockStatusContent}</div>

              {activeShift ? (
                <Button
                  variant="destructive"
                  size="lg"
                  className="gap-2 px-6"
                  onClick={handleClockOut}
                  disabled={isClocking}
                >
                  {isClocking && <Loader2 className="h-4 w-4 animate-spin" />}
                  <LogOut className="h-4 w-4" />
                  Clock Out
                </Button>
              ) : (
                <Button
                  variant="gold"
                  size="lg"
                  className="gap-2 px-6"
                  onClick={handleClockIn}
                  disabled={isClocking}
                >
                  {isClocking && <Loader2 className="h-4 w-4 animate-spin" />}
                  <LogIn className="h-4 w-4" />
                  Clock In
                </Button>
              )}
            </div>

            <Separator className="my-4" />
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <CalendarDays className="h-3.5 w-3.5" />
                <span>This Week</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-sm font-semibold text-foreground tabular-nums">{weeklyHours} hrs</span>
                {Number(weeklyHours) >= 40 && (
                  <Badge
                    variant="secondary"
                    className="text-[9px] bg-warning/15 text-warning border-warning/20"
                  >
                    OT Alert
                  </Badge>
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
      >
        <Card className="shadow-soft">
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2">
              <Clock className="h-4 w-4 text-accent" />
              Recent Shifts
              {isAdmin && (
                <Badge variant="secondary" className="text-[9px] ml-1">
                  All Staff
                </Badge>
              )}
            </CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            {loadingEntries ? (
              <div className="flex items-center justify-center py-8">
                <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" />
              </div>
            ) : grouped.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                <Clock className="h-6 w-6 mx-auto mb-2 opacity-30" />
                <p className="text-sm">No shifts recorded yet</p>
              </div>
            ) : (
              <ScrollArea className="max-h-80">
                <div className="divide-y divide-border/50">
                  {grouped.map(([date, dayEntries]) => (
                    <div key={date} className="px-4 py-3">
                      <p className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wider mb-2">
                        {date}
                      </p>
                      <div className="space-y-2">
                        {dayEntries.map((e) =>
                          editingEntryId === e.id ? (
                            <div key={e.id} className="flex flex-col gap-1.5 text-xs p-2 rounded-md bg-muted/20">
                              <div className="flex items-center gap-2 flex-wrap">
                                {isAdmin && (
                                  <span className="text-foreground font-medium text-[10px]">
                                    {getEmployeeName(e.user_id)}
                                  </span>
                                )}
                              </div>
                              <div className="grid grid-cols-2 gap-2">
                                <div>
                                  <label className="text-[10px] text-muted-foreground">Clock In</label>
                                  <Input
                                    type="datetime-local"
                                    value={editClockIn}
                                    onChange={(ev) => setEditClockIn(ev.target.value)}
                                    className="h-7 text-xs"
                                  />
                                </div>
                                <div>
                                  <label className="text-[10px] text-muted-foreground">Clock Out</label>
                                  <Input
                                    type="datetime-local"
                                    value={editClockOut}
                                    onChange={(ev) => setEditClockOut(ev.target.value)}
                                    className="h-7 text-xs"
                                  />
                                </div>
                              </div>
                              <div className="flex gap-1.5 justify-end">
                                <Button
                                  size="sm"
                                  variant="outline"
                                  className="h-6 text-[10px] gap-1 px-2"
                                  onClick={cancelEdit}
                                  disabled={savingEdit}
                                >
                                  <X className="h-3 w-3" /> Cancel
                                </Button>
                                <Button
                                  size="sm"
                                  variant="gold"
                                  className="h-6 text-[10px] gap-1 px-2"
                                  onClick={saveEdit}
                                  disabled={savingEdit}
                                >
                                  {savingEdit ? (
                                    <Loader2 className="h-3 w-3 animate-spin" />
                                  ) : (
                                    <Save className="h-3 w-3" />
                                  )}
                                  Save
                                </Button>
                              </div>
                            </div>
                          ) : (
                            <div key={e.id} className="flex items-center justify-between gap-2 py-1">
                              <div className="flex items-center gap-2 min-w-0">
                                {isAdmin && (
                                  <div className="flex items-center gap-1.5 shrink-0">
                                    <div className="h-5 w-5 rounded-full bg-accent/15 flex items-center justify-center">
                                      <User className="h-3 w-3 text-accent" />
                                    </div>
                                    <span className="text-foreground font-medium max-w-[100px] truncate">
                                      {getEmployeeName(e.user_id)}
                                    </span>
                                    <span className="text-muted-foreground">·</span>
                                  </div>
                                )}
                                <div className="min-w-0">
                                  <span className="text-foreground font-medium">{formatTime(e.clock_in)}</span>
                                  <span className="text-muted-foreground mx-1">→</span>
                                  <span className="text-foreground font-medium">
                                    {e.clock_out ? formatTime(e.clock_out) : "—"}
                                  </span>
                                </div>
                              </div>
                              <div className="flex items-center gap-2 shrink-0">
                                <span className="text-muted-foreground tabular-nums">
                                  {e.clock_out ? formatDuration(e.clock_in, e.clock_out) : "Active"}
                                </span>
                                {!e.clock_out && (
                                  <div className="h-1.5 w-1.5 rounded-full bg-success animate-pulse" />
                                )}
                                {isAdmin && (
                                  <div className="flex items-center gap-0.5 ml-1">
                                    <Button
                                      size="icon"
                                      variant="ghost"
                                      className="h-5 w-5"
                                      title="Edit entry (manager override)"
                                      onClick={() => startEdit(e)}
                                    >
                                      <Pencil className="h-3 w-3 text-muted-foreground" />
                                    </Button>
                                    <Button
                                      size="icon"
                                      variant="ghost"
                                      className="h-5 w-5"
                                      title="Delete entry (manager override)"
                                      onClick={() => deleteEntry(e.id)}
                                    >
                                      <Trash2 className="h-3 w-3 text-destructive" />
                                    </Button>
                                  </div>
                                )}
                              </div>
                            </div>
                          ),
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </ScrollArea>
            )}
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
};
