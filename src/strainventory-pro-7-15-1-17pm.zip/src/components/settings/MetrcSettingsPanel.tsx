import { useState } from "react";
import { motion } from "framer-motion";
import {
  Activity,
  CheckCircle2,
  Database,
  Link2,
  Loader2,
  RefreshCw,
  Shield,
  Tag,
  TestTube,
  XCircle,
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useMetrcSettings } from "@/hooks/useMetrcSettings";
import { useProducts } from "@/hooks/useProducts";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

export const MetrcSettingsPanel = () => {
  const {
    settings,
    isLoading,
    syncLog,
    packageLinks,
    linksLoading,
    updateSettings,
    testConnection,
    pullPackages,
    linkPackageToProduct,
    isBusy,
  } = useMetrcSettings();

  const { data: products } = useProducts();

  const [licenseNumber, setLicenseNumber] = useState(settings?.license_number ?? "");
  const [facilityName, setFacilityName] = useState(settings?.facility_name ?? "");
  const [enabled, setEnabled] = useState(settings?.enabled ?? false);
  const [autoSync, setAutoSync] = useState(settings?.auto_sync_sales ?? false);

  const handleSave = async () => {
    await updateSettings({
      license_number: licenseNumber || null,
      facility_name: facilityName || null,
      enabled,
      auto_sync_sales: autoSync,
    });
  };

  const handleTest = async () => {
    await testConnection();
  };

  const handlePull = async () => {
    await pullPackages();
  };

  return (
    <div className="space-y-6">
      {/* Configuration Card */}
      <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.05 }}>
        <Card className="shadow-soft">
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2">
              <Shield className="h-4 w-4 text-accent" />
              Metrc Sandbox Configuration
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label className="text-xs">License Number</Label>
                <Input
                  placeholder="e.g. C10-0000123-LIC"
                  value={licenseNumber}
                  onChange={(e) => setLicenseNumber(e.target.value)}
                  disabled={isBusy}
                  className="bg-background font-mono text-sm"
                />
                <p className="text-[10px] text-muted-foreground">
                  Your California facility license number
                </p>
              </div>
              <div className="space-y-2">
                <Label className="text-xs">Facility Name</Label>
                <Input
                  placeholder="Dispensary Name"
                  value={facilityName}
                  onChange={(e) => setFacilityName(e.target.value)}
                  disabled={isBusy}
                  className="bg-background text-sm"
                />
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-6 pt-1">
              <div className="flex items-center gap-2">
                <Switch
                  checked={enabled}
                  onCheckedChange={setEnabled}
                  disabled={isBusy}
                />
                <Label className="text-sm cursor-pointer" onClick={() => setEnabled(!enabled)}>
                  Enable Metrc sync
                </Label>
              </div>
              <div className="flex items-center gap-2">
                <Switch
                  checked={autoSync}
                  onCheckedChange={setAutoSync}
                  disabled={isBusy || !enabled}
                />
                <Label className="text-sm cursor-pointer" onClick={() => setAutoSync(!autoSync)}>
                  Auto-post sales receipts
                </Label>
              </div>
            </div>

            <div className="flex items-center gap-2 pt-2">
              <Button
                variant="gold"
                size="sm"
                onClick={handleSave}
                disabled={isBusy}
                className="gap-1.5"
              >
                {isBusy && <Loader2 className="h-3.5 w-3.5 animate-spin" />}
                Save Configuration
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={handleTest}
                disabled={isBusy || !enabled}
                className="gap-1.5"
              >
                <TestTube className="h-3.5 w-3.5" />
                Test Connection
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={handlePull}
                disabled={isBusy || !enabled}
                className="gap-1.5"
              >
                <RefreshCw className="h-3.5 w-3.5" />
                Pull Active Packages
              </Button>
            </div>

            {settings?.last_sync_at && (
              <p className="text-[10px] text-muted-foreground">
                Last sync: {new Date(settings.last_sync_at).toLocaleString()}
              </p>
            )}
          </CardContent>
        </Card>
      </motion.div>

      {/* Package Links Card */}
      <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}>
        <Card className="shadow-soft">
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2">
              <Database className="h-4 w-4 text-accent" />
              Package Links
              <Badge variant="outline" className="ml-1 text-[10px]">
                {packageLinks?.length ?? 0}
              </Badge>
            </CardTitle>
          </CardHeader>
          <CardContent>
            {linksLoading ? (
              <div className="flex items-center gap-2 text-sm text-muted-foreground py-4">
                <Loader2 className="h-4 w-4 animate-spin" />
                Loading packages…
              </div>
            ) : packageLinks && packageLinks.length > 0 ? (
              <ScrollArea className="h-72">
                <div className="space-y-2">
                  {packageLinks.map((link) => (
                    <div
                      key={link.id}
                      className="flex items-center justify-between rounded-lg border border-border bg-background/60 px-3 py-2"
                    >
                      <div className="flex items-center gap-2 min-w-0">
                        <Tag className="h-3.5 w-3.5 text-muted-foreground shrink-0" />
                        <div className="min-w-0">
                          <div className="text-xs font-medium truncate">{link.metrc_tag}</div>
                          <div className="text-[10px] text-muted-foreground truncate">
                            {link.item_name || link.package_name}
                            {link.quantity && link.unit_of_measure
                              ? ` · ${link.quantity} ${link.unit_of_measure}`
                              : ""}
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center gap-2 shrink-0">
                        {link.product_id ? (
                          <Badge variant="outline" className="text-[10px] gap-1">
                            <Link2 className="h-3 w-3" />
                            Linked
                          </Badge>
                        ) : (
                          <Badge variant="secondary" className="text-[10px]">
                            Unlinked
                          </Badge>
                        )}
                        <Select
                          value={link.product_id ?? ""}
                          onValueChange={(val) =>
                            linkPackageToProduct({ metrcTag: link.metrc_tag, productId: val })
                          }
                        >
                          <SelectTrigger className="h-7 w-40 text-xs">
                            <SelectValue placeholder="Link to product…" />
                          </SelectTrigger>
                          <SelectContent>
                            {products?.map((p) => (
                              <SelectItem key={p.id} value={p.id} className="text-xs">
                                {p.name}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                  ))}
                </div>
              </ScrollArea>
            ) : (
              <div className="text-sm text-muted-foreground py-6 text-center">
                No packages pulled yet. Click "Pull Active Packages" to fetch from Metrc.
              </div>
            )}
          </CardContent>
        </Card>
      </motion.div>

      {/* Sync Log Card */}
      <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.15 }}>
        <Card className="shadow-soft">
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2">
              <Activity className="h-4 w-4 text-accent" />
              Sync Log
            </CardTitle>
          </CardHeader>
          <CardContent>
            {syncLog && syncLog.length > 0 ? (
              <ScrollArea className="h-64">
                <div className="space-y-2">
                  {syncLog.map((entry) => (
                    <div
                      key={entry.id}
                      className="flex items-start gap-2 rounded-lg border border-border bg-background/60 px-3 py-2"
                    >
                      {entry.status === "success" ? (
                        <CheckCircle2 className="h-3.5 w-3.5 text-emerald-500 mt-0.5 shrink-0" />
                      ) : (
                        <XCircle className="h-3.5 w-3.5 text-destructive mt-0.5 shrink-0" />
                      )}
                      <div className="min-w-0">
                        <div className="text-xs font-medium truncate">{entry.operation}</div>
                        <div className="text-[10px] text-muted-foreground">
                          {entry.status} · {new Date(entry.created_at).toLocaleString()}
                        </div>
                        {entry.details && (
                          <pre className="text-[9px] text-muted-foreground mt-1 max-h-20 overflow-auto bg-muted/30 rounded p-1">
                            {JSON.stringify(entry.details, null, 2)}
                          </pre>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </ScrollArea>
            ) : (
              <div className="text-sm text-muted-foreground py-6 text-center">
                No sync activity yet.
              </div>
            )}
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
};
