import { useState, type ReactNode } from "react";
import { useQuery, useQueryClient, useMutation } from "@tanstack/react-query";
import { motion } from "framer-motion";
import {
  CheckCircle2,
  XCircle,
  Loader2,
  Mail,
  Phone,
  Calendar,
  BadgeCheck,
  AlertCircle,
  UserPlus,
} from "lucide-react";
import { toast } from "sonner";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/context/AuthContext";
import { EDGE_FUNCTIONS, ENV } from "@/lib/constants";
import { SHORT_ID_PATTERN, PIN_PATTERN } from "@/lib/pinAuth";

interface EmployeeRow {
  id: string;
  full_name: string;
  date_of_birth: string;
  phone: string;
  email: string;
  emergency_contact: string;
  role: string;
  badge_number: string;
  live_scan_status: string;
  mmic_number: string | null;
  status: string;
  assigned_role: string;
  created_at: string;
  approved_at: string | null;
  rejected_at: string | null;
  rejection_reason: string | null;
  user_id: string | null;
}

export const PendingEmployeesPanel = () => {
  const queryClient = useQueryClient();
  const { session } = useAuth();

  const [filter, setFilter] = useState<"pending_review" | "approved" | "rejected">(
    "pending_review",
  );
  const [rejectTarget, setRejectTarget] = useState<EmployeeRow | null>(null);
  const [rejectReason, setRejectReason] = useState("");
  const [approveTarget, setApproveTarget] = useState<EmployeeRow | null>(null);
  const [approveShortId, setApproveShortId] = useState("");
  const [approvePin, setApprovePin] = useState("");
  const [approving, setApproving] = useState(false);

  const {
    data: employees = [],
    isLoading,
    error,
  } = useQuery({
    queryKey: ["employees", filter],
    queryFn: async (): Promise<EmployeeRow[]> => {
      const { data, error } = await supabase
        .from("employees")
        .select("*")
        .eq("status", filter)
        .order("created_at", { ascending: false });
      if (error) throw error;
      return (data ?? []) as unknown as EmployeeRow[];
    },
  });

  const rejectMutation = useMutation({
    mutationFn: async ({ id, reason }: { id: string; reason: string }) => {
      const { error } = await supabase
        .from("employees")
        .update({
          status: "rejected",
          rejected_at: new Date().toISOString(),
          rejection_reason: reason || null,
          approved_at: null,
          approved_by: null,
        } as never)
        .eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["employees"] });
      toast.success("Employee rejected.");
      setRejectTarget(null);
      setRejectReason("");
    },
    onError: (err: Error) => toast.error(err.message || "Failed to reject."),
  });

  const approveWithoutLogin = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase
        .from("employees")
        .update({
          status: "approved",
          approved_at: new Date().toISOString(),
          approved_by: session?.user?.id ?? null,
          rejected_at: null,
          rejection_reason: null,
        } as never)
        .eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["employees"] });
      toast.success("Employee approved.");
    },
    onError: (err: Error) => toast.error(err.message || "Failed to approve."),
  });

  const handleApproveWithLogin = async () => {
    if (!approveTarget) return;
    if (!session?.access_token) {
      toast.error("You must be signed in.");
      return;
    }
    const shortId = approveShortId.trim().toUpperCase();
    const pin = approvePin.trim();
    if (!SHORT_ID_PATTERN.test(shortId)) {
      toast.error("Short ID must be 3-10 letters or digits.");
      return;
    }
    if (!PIN_PATTERN.test(pin)) {
      toast.error("PIN must be 4-6 digits.");
      return;
    }

    setApproving(true);
    try {
      const res = await fetch(EDGE_FUNCTIONS.PROVISION_PIN_USER, {
        method: "POST",
        headers: {
          apikey: ENV.SUPABASE_PUBLISHABLE_KEY,
          Authorization: `Bearer ${session.access_token}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          action: "provision",
          short_id: shortId,
          pin,
          display_name: approveTarget.full_name,
          role: approveTarget.assigned_role || "staff",
          employee_id: approveTarget.id,
        }),
      });
      const json = (await res.json().catch(() => ({}))) as {
        error?: string;
        code?: string;
        success?: boolean;
        existing?: { display_name?: string | null; short_id?: string };
      };
      if (!res.ok || !json.success) {
        if (json.code === "short_id_taken" && json.existing) {
          throw new Error(
            `Short ID "${json.existing.short_id ?? shortId}" is already assigned${
              json.existing.display_name ? ` to ${json.existing.display_name}` : ""
            }. Pick a different short ID.`,
          );
        }
        if (json.code === "auth_user_orphaned") {
          throw new Error(
            `A login account already exists for "${shortId}" but has no credential record. Pick a different short ID or contact an administrator.`,
          );
        }
        throw new Error(json.error || "Failed to create login.");
      }
      toast.success(`Approved & login created (${shortId}).`);
      queryClient.invalidateQueries({ queryKey: ["employees"] });
      queryClient.invalidateQueries({ queryKey: ["user-credentials"] });
      setApproveTarget(null);
      setApproveShortId("");
      setApprovePin("");
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Failed to create login.");
    } finally {
      setApproving(false);
    }
  };

  let employeeContent: ReactNode;

  if (isLoading) {
    employeeContent = (
      <div className="flex items-center justify-center py-10 text-muted-foreground">
        <Loader2 className="mr-2 h-5 w-5 animate-spin" />
        Loading employees...
      </div>
    );
  } else if (error) {
    employeeContent = (
      <div className="flex items-center gap-2 rounded-md border border-destructive/30 p-3 text-sm text-destructive">
        <AlertCircle className="h-4 w-4" />
        {error.message}
      </div>
    );
  } else if (employees.length === 0) {
    employeeContent = (
      <p className="py-6 text-center text-sm text-muted-foreground">
        No employees in this status.
      </p>
    );
  } else {
    employeeContent = (
      <div className="space-y-2">
        {employees.map((emp) => (
          <Card key={emp.id} className="border-border p-3">
            <div className="flex flex-wrap items-start justify-between gap-3">
              <div className="min-w-[220px] flex-1 space-y-1">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="text-sm font-semibold">{emp.full_name}</span>
                  <Badge variant="secondary" className="text-[10px]">
                    {emp.role}
                  </Badge>
                  <Badge variant="outline" className="text-[10px]">
                    Badge #{emp.badge_number}
                  </Badge>
                  <Badge
                    variant={
                      emp.live_scan_status === "cleared" ? "default" : "secondary"
                    }
                    className="text-[10px] capitalize"
                  >
                    Live Scan: {emp.live_scan_status}
                  </Badge>
                </div>
                <div className="flex flex-wrap items-center gap-3 text-xs text-muted-foreground">
                  <span className="flex items-center gap-1">
                    <Mail className="h-3 w-3" /> {emp.email}
                  </span>
                  <span className="flex items-center gap-1">
                    <Phone className="h-3 w-3" /> {emp.phone}
                  </span>
                  <span className="flex items-center gap-1">
                    <Calendar className="h-3 w-3" /> DOB {emp.date_of_birth}
                  </span>
                </div>
                {emp.rejection_reason && (
                  <p className="text-[11px] text-destructive">
                    Rejected: {emp.rejection_reason}
                  </p>
                )}
                {emp.user_id && (
                  <p className="text-[11px] text-success">
                    Linked to login account.
                  </p>
                )}
              </div>

              {filter === "pending_review" && (
                <div className="flex shrink-0 flex-wrap gap-2">
                  <Button
                    size="sm"
                    onClick={() => {
                      setApproveTarget(emp);
                      setApproveShortId("");
                      setApprovePin("");
                    }}
                    className="gap-1"
                  >
                    <UserPlus className="h-3 w-3" />
                    Approve
                  </Button>
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => {
                      setRejectTarget(emp);
                      setRejectReason("");
                    }}
                    className="gap-1 text-destructive hover:text-destructive"
                  >
                    <XCircle className="h-3 w-3" />
                    Reject
                  </Button>
                </div>
              )}
            </div>
          </Card>
        ))}
      </div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-4"
    >
      <Card className="shadow-soft">
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-base">
            <BadgeCheck className="h-4 w-4 text-accent" />
            Employee Review
          </CardTitle>
          <p className="mt-1 text-xs text-muted-foreground">
            Approve or reject employees submitted through onboarding. Approving
            can also create their short-ID + PIN login in one step.
          </p>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex gap-2">
            {(["pending_review", "approved", "rejected"] as const).map((f) => (
              <Button
                key={f}
                size="sm"
                variant={filter === f ? "default" : "outline"}
                onClick={() => setFilter(f)}
                className="capitalize"
              >
                {f.replace("_", " ")}
              </Button>
            ))}
          </div>

          {employeeContent}
        </CardContent>
      </Card>

      <Dialog
        open={!!rejectTarget}
        onOpenChange={(open) => {
          if (!open) {
            setRejectTarget(null);
            setRejectReason("");
          }
        }}
      >
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Reject employee</DialogTitle>
            <DialogDescription>
              {rejectTarget?.full_name
                ? `This marks ${rejectTarget.full_name} as rejected. Their record is retained for audit.`
                : ""}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-2">
            <Label className="text-xs">Reason (optional)</Label>
            <Textarea
              value={rejectReason}
              onChange={(e) => setRejectReason(e.target.value)}
              placeholder="e.g. Live Scan not cleared, background check failed..."
              rows={3}
            />
          </div>
          <DialogFooter>
            <Button
              variant="ghost"
              onClick={() => {
                setRejectTarget(null);
                setRejectReason("");
              }}
            >
              Cancel
            </Button>
            <Button
              variant="destructive"
              disabled={rejectMutation.isPending}
              onClick={() =>
                rejectTarget &&
                rejectMutation.mutate({
                  id: rejectTarget.id,
                  reason: rejectReason.trim(),
                })
              }
            >
              {rejectMutation.isPending ? (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              ) : null}
              Reject
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog
        open={!!approveTarget}
        onOpenChange={(open) => {
          if (!open) {
            setApproveTarget(null);
            setApproveShortId("");
            setApprovePin("");
          }
        }}
      >
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Approve employee</DialogTitle>
            <DialogDescription>
              Assign a business-friendly short ID and 4-6 digit PIN.{" "}
              {approveTarget?.full_name
                ? `${approveTarget.full_name} will use these to clock in.`
                : ""}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-3">
            <div>
              <Label className="text-xs">Short ID</Label>
              <Input
                value={approveShortId}
                onChange={(e) =>
                  setApproveShortId(e.target.value.replace(/[^A-Za-z0-9]/g, ""))
                }
                placeholder="e.g. DW01"
                maxLength={10}
                autoCapitalize="characters"
              />
              <p className="mt-1 text-[10px] text-muted-foreground">
                3-10 letters or digits. Shown to the employee on the sign-in
                screen.
              </p>
            </div>
            <div>
              <Label className="text-xs">PIN</Label>
              <Input
                value={approvePin}
                onChange={(e) => setApprovePin(e.target.value.replace(/\D/g, ""))}
                placeholder="e.g. 1234"
                maxLength={6}
                inputMode="numeric"
              />
              <p className="mt-1 text-[10px] text-muted-foreground">
                4-6 digits. Share this with the employee securely.
              </p>
            </div>
          </div>
          <DialogFooter className="flex-col gap-2 sm:flex-row sm:justify-between">
            <Button
              variant="ghost"
              size="sm"
              disabled={approveWithoutLogin.isPending || approving}
              onClick={() => {
                if (!approveTarget) return;
                approveWithoutLogin.mutate(approveTarget.id, {
                  onSuccess: () => {
                    setApproveTarget(null);
                    setApproveShortId("");
                    setApprovePin("");
                  },
                });
              }}
              className="text-muted-foreground"
            >
              Approve without login
            </Button>
            <div className="flex gap-2">
              <Button
                variant="ghost"
                onClick={() => {
                  setApproveTarget(null);
                  setApproveShortId("");
                  setApprovePin("");
                }}
              >
                Cancel
              </Button>
              <Button onClick={handleApproveWithLogin} disabled={approving}>
                {approving ? (
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                ) : (
                  <CheckCircle2 className="mr-2 h-4 w-4" />
                )}
                Approve & create login
              </Button>
            </div>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </motion.div>
  );
};
