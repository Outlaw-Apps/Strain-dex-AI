import { ScanLine, Printer, RotateCcw } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  useScannerSettings,
  usePrinterSettings,
  type PaperSize,
} from "@/hooks/usePosLocalSettings";
import { toast } from "sonner";

export const ScannerPrinterSettingsPanel = () => {
  const scanner = useScannerSettings();
  const printer = usePrinterSettings();

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      {/* Scanner Timing */}
      <Card className="border-2">
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-base">
            <ScanLine className="h-4 w-4 text-primary" />
            Scanner Calibration
          </CardTitle>
          <p className="text-xs text-muted-foreground">
            Tune timings for USB / Bluetooth wedge scanners. Camera scanning is unaffected.
          </p>
        </CardHeader>
        <CardContent className="space-y-5">
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <Label className="text-sm font-semibold">Wedge tolerance</Label>
              <span className="text-xs tabular-nums text-muted-foreground">
                {scanner.wedgeIntervalMs} ms
              </span>
            </div>
            <Slider
              min={20}
              max={250}
              step={5}
              value={[scanner.wedgeIntervalMs]}
              onValueChange={(v) => scanner.setWedgeIntervalMs(v[0] ?? 80)}
            />
            <p className="text-[11px] text-muted-foreground">
              Max ms between keystrokes treated as a scanner burst. Raise for slow scanners,
              lower if real typing is being captured.
            </p>
          </div>

          <div className="space-y-2">
            <Label className="text-sm font-semibold">Burst threshold (min chars)</Label>
            <Input
              type="number"
              min={2}
              max={64}
              value={scanner.wedgeMinLength}
              onChange={(e) => scanner.setWedgeMinLength(Number(e.target.value) || 4)}
              className="h-9"
            />
            <p className="text-[11px] text-muted-foreground">
              Minimum characters before Enter is treated as a scan. Default 4.
            </p>
          </div>

          <Button variant="outline" size="sm" onClick={() => { scanner.resetDefaults(); toast.success("Scanner timings reset"); }}>
            <RotateCcw className="h-3.5 w-3.5 mr-1.5" />
            Reset defaults
          </Button>
        </CardContent>
      </Card>

      {/* Printer Settings */}
      <Card className="border-2">
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-base">
            <Printer className="h-4 w-4 text-primary" />
            Receipt Printer
          </CardTitle>
          <p className="text-xs text-muted-foreground">
            Configure paper size, printable width, and font scale before printing.
          </p>
        </CardHeader>
        <CardContent className="space-y-5">
          <div className="space-y-2">
            <Label className="text-sm font-semibold">Paper size</Label>
            <Select value={printer.paperSize} onValueChange={(v) => printer.setPaperSize(v as PaperSize)}>
              <SelectTrigger className="h-9"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="thermal">Thermal roll (58 / 72 / 80 mm)</SelectItem>
                <SelectItem value="a4">A4</SelectItem>
                <SelectItem value="letter">US Letter</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {printer.paperSize === "thermal" ? (
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label className="text-sm font-semibold">Receipt width</Label>
                <span className="text-xs tabular-nums text-muted-foreground">{printer.widthMm} mm</span>
              </div>
              <Slider
                min={48}
                max={110}
                step={1}
                value={[printer.widthMm]}
                onValueChange={(v) => printer.setWidthMm(v[0] ?? 72)}
              />
              <p className="text-[11px] text-muted-foreground">
                Printable width. Use 48 mm for 58 mm rolls, 72 mm for 80 mm rolls.
              </p>
            </div>
          ) : null}

          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <Label className="text-sm font-semibold">Font scale</Label>
              <span className="text-xs tabular-nums text-muted-foreground">{printer.fontScale.toFixed(2)}×</span>
            </div>
            <Slider
              min={0.7}
              max={1.6}
              step={0.05}
              value={[printer.fontScale]}
              onValueChange={(v) => printer.setFontScale(v[0] ?? 1)}
            />
          </div>

          <div className="flex gap-2">
            <Button variant="outline" size="sm" onClick={() => { printer.resetDefaults(); toast.success("Printer settings reset"); }}>
              <RotateCcw className="h-3.5 w-3.5 mr-1.5" />
              Reset defaults
            </Button>
            <Button variant="secondary" size="sm" onClick={() => window.print()}>
              <Printer className="h-3.5 w-3.5 mr-1.5" />
              Test print
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};
