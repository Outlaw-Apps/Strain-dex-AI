import { useEffect, useMemo, useState } from "react";
import { CalendarClock, Loader2, Send, Trash2, Plus, X } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { isoToDatetimeLocalValue, datetimeLocalValueToIso } from "@/lib/datetimeLocal";

interface ScheduledRow {
  id: string;
  message_id: string;
  template_name: string;
  recipient_email: string;
  scheduled_at: string;
  status: "pending" | "dispatched" | "cancelled" | "failed";
  dispatched_at: string | null;
  error_message: string | null;
  created_at: string;
}

interface TemplateRow {
  template_name: string;
  display_name: string;
  enabled: boolean;
}

const statusVariant: Record<ScheduledRow["status"], "default" | "secondary" | "destructive" | "outline"> = {
  pending: "secondary",
  dispatched: "default",
  cancelled: "outline",
  failed: "destructive",
};

export const ScheduledEmailsPanel = () => {
  const [rows, setRows] = useState<ScheduledRow[]>([]);
  const [templates, setTemplates] = useState<TemplateRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [showForm, setShowForm] = useState(false);

  const [draft, setDraft] = useState({
    templateName: "",
    recipientEmail: "",
    scheduledAt: isoToDatetimeLocalValue(new Date(Date.now() + 60 * 60 * 1000).toISOString()),
    templateData: "",
  });

  const load = async () => {
    setLoading(true);
    const [r, t] = await Promise.all([
      supabase
        .from("scheduled_emails" as never)
        .select("*")
        .order("scheduled_at", { ascending: true })
        .limit(100),
      supabase
        .from("email_templates" as never)
        .select("template_name, display_name, enabled")
        .order("display_name"),
    ]);
    if (r.error) toast.error("Failed to load scheduled emails");
    else setRows(((r.data as unknown) as ScheduledRow[]) ?? []);
    if (!t.error) setTemplates(((t.data as unknown) as TemplateRow[]) ?? []);
    setLoading(false);
  };

  useEffect(() => {
    load();
  }, []);

  const enabledTemplates = useMemo(() => templates.filter((t) => t.enabled !== false), [templates]);

  const cancel = async (row: ScheduledRow) => {
    if (row.status !== "pending") return;
    const { error } = await supabase
      .from("scheduled_emails" as never)
      .update({ status: "cancelled" } as never)
      .eq("id", row.id);
    if (error) {
      toast.error("Cancel failed: " + error.message);
      return;
    }
    toast.success("Scheduled email cancelled");
    await load();
  };

  const remove = async (row: ScheduledRow) => {
    const { error } = await supabase
      .from("scheduled_emails" as never)
      .delete()
      .eq("id", row.id);
    if (error) {
      toast.error("Delete failed: " + error.message);
      return;
    }
    await load();
  };

  const submit = async () => {
    const iso = datetimeLocalValueToIso(draft.scheduledAt);
    if (!draft.templateName) return toast.error("Pick a template");
    if (!draft.recipientEmail) return toast.error("Recipient email required");
    if (!iso) return toast.error("Pick a valid send time");
    if (new Date(iso).getTime() - Date.now() <= 30_000) {
      return toast.error("Pick a time at least 30 seconds in the future");
    }

    let templateData: Record<string, unknown> | undefined;
    if (draft.templateData.trim()) {
      try {
        templateData = JSON.parse(draft.templateData);
      } catch {
        return toast.error("Template data must be valid JSON");
      }
    }

    setSubmitting(true);
    const { data, error } = await supabase.functions.invoke("send-transactional-email", {
      body: {
        templateName: draft.templateName,
        recipientEmail: draft.recipientEmail,
        scheduledAt: iso,
        templateData,
      },
    });
    setSubmitting(false);

    if (error || (data && (data as { error?: string }).error)) {
      const msg = error?.message || (data as { error?: string })?.error || "Schedule failed";
      toast.error(msg);
      return;
    }
    toast.success("Email scheduled");
    setShowForm(false);
    setDraft((d) => ({ ...d, recipientEmail: "", templateData: "" }));
    await load();
  };

  return (
    <Card className="border-2 border-border bg-card shadow-elevated rounded-2xl">
      <CardHeader className="flex flex-row items-start justify-between gap-3">
        <div>
          <CardTitle className="flex items-center gap-2 text-base">
            <CalendarClock className="h-4 w-4 text-accent" />
            Scheduled Emails
          </CardTitle>
          <p className="text-xs text-muted-foreground mt-1">
            Queue welcome notes or notifications for a specific time. The dispatcher checks every minute.
          </p>
        </div>
        <Button
          size="sm"
          variant={showForm ? "outline" : "gold"}
          onClick={() => setShowForm((s) => !s)}
        >
          {showForm ? (
            <>
              <X className="h-3.5 w-3.5 mr-1" /> Close
            </>
          ) : (
            <>
              <Plus className="h-3.5 w-3.5 mr-1" /> Schedule new
            </>
          )}
        </Button>
      </CardHeader>
      <CardContent className="space-y-5">
        {showForm && (
          <div className="grid gap-3 p-4 border-2 border-dashed border-border rounded-xl">
            <div className="grid sm:grid-cols-2 gap-3">
              <div className="space-y-1">
                <Label className="text-xs">Template</Label>
                <Select
                  value={draft.templateName}
                  onValueChange={(v) => setDraft((d) => ({ ...d, templateName: v }))}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Choose template…" />
                  </SelectTrigger>
                  <SelectContent>
                    {enabledTemplates.map((t) => (
                      <SelectItem key={t.template_name} value={t.template_name}>
                        {t.display_name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1">
                <Label className="text-xs">Recipient email</Label>
                <Input
                  type="email"
                  value={draft.recipientEmail}
                  onChange={(e) => setDraft((d) => ({ ...d, recipientEmail: e.target.value }))}
                  placeholder="user@example.com"
                />
              </div>
              <div className="space-y-1">
                <Label className="text-xs">Send at</Label>
                <Input
                  type="datetime-local"
                  value={draft.scheduledAt}
                  onChange={(e) => setDraft((d) => ({ ...d, scheduledAt: e.target.value }))}
                />
              </div>
              <div className="space-y-1 sm:col-span-2">
                <Label className="text-xs">Template data (JSON, optional)</Label>
                <Textarea
                  value={draft.templateData}
                  onChange={(e) => setDraft((d) => ({ ...d, templateData: e.target.value }))}
                  placeholder='{"name":"Jane"}'
                  rows={3}
                  className="font-mono text-xs"
                />
              </div>
            </div>
            <div className="flex justify-end">
              <Button variant="gold" size="sm" onClick={submit} disabled={submitting}>
                {submitting ? (
                  <Loader2 className="h-3.5 w-3.5 mr-1 animate-spin" />
                ) : (
                  <Send className="h-3.5 w-3.5 mr-1" />
                )}
                Schedule send
              </Button>
            </div>
          </div>
        )}

        {loading ? (
          <div className="py-8 flex items-center justify-center text-muted-foreground">
            <Loader2 className="h-5 w-5 animate-spin mr-2" /> Loading…
          </div>
        ) : rows.length === 0 ? (
          <p className="text-sm text-muted-foreground py-6 text-center">
            No scheduled emails yet.
          </p>
        ) : (
          <div className="border border-border rounded-lg divide-y divide-border">
            {rows.map((row) => {
              const when = new Date(row.scheduled_at);
              return (
                <div
                  key={row.id}
                  className="flex items-center justify-between gap-3 p-3 text-sm"
                >
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-medium truncate">{row.recipient_email}</span>
                      <Badge variant="outline" className="text-[10px]">
                        {row.template_name}
                      </Badge>
                      <Badge variant={statusVariant[row.status]} className="text-[10px] capitalize">
                        {row.status}
                      </Badge>
                    </div>
                    <p className="text-xs text-muted-foreground mt-0.5">
                      {when.toLocaleString()}
                      {row.error_message && (
                        <span className="text-destructive ml-2">· {row.error_message}</span>
                      )}
                    </p>
                  </div>
                  <div className="flex items-center gap-1">
                    {row.status === "pending" && (
                      <Button size="sm" variant="outline" onClick={() => cancel(row)}>
                        Cancel
                      </Button>
                    )}
                    <Button
                      size="icon"
                      variant="ghost"
                      onClick={() => remove(row)}
                      title="Delete"
                    >
                      <Trash2 className="h-4 w-4 text-muted-foreground" />
                    </Button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </CardContent>
    </Card>
  );
};
