import { useState } from "react";
import { useQuery, useQueryClient, useMutation } from "@tanstack/react-query";
import { motion } from "framer-motion";
import {
  KeyRound,
  Loader2,
  Plus,
  Trash2,
  RefreshCw,
  AlertCircle,
} from "lucide-react";
import { toast } from "sonner";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { useAuth } from "@/context/AuthContext";
import { EDGE_FUNCTIONS, ENV } from "@/lib/constants";
import { SHORT_ID_PATTERN, PIN_PATTERN } from "@/lib/pinAuth";

interface CredentialRow {
  id: string;
  user_id: string;
  short_id: string;
  display_name: string | null;
  created_at: string;
  updated_at: string;
}

export const UserAccountsPanel = () => {
  const queryClient = useQueryClient();
  const { session } = useAuth();

  const [createOpen, setCreateOpen] = useState(false);
  const [shortId, setShortId] = useState("");
  const [pin, setPin] = useState("");
  const [displayName, setDisplayName] = useState("");
  const [role, setRole] = useState<"staff" | "reviewer" | "admin">("staff");
  const [submitting, setSubmitting] = useState(false);

  const [resetTarget, setResetTarget] = useState<CredentialRow | null>(null);
  const [resetPin, setResetPin] = useState("");
  const [resetting, setResetting] = useState(false);

  const {
    data: credentials = [],
    isLoading,
    error,
  } = useQuery({
    queryKey: ["user-credentials"],
    queryFn: async (): Promise<CredentialRow[]> => {
      if (!session?.access_token) return [];
      const res = await fetch(EDGE_FUNCTIONS.PROVISION_PIN_USER, {
        method: "GET",
        headers: {
          apikey: ENV.SUPABASE_PUBLISHABLE_KEY,
          Authorization: `Bearer ${session.access_token}`,
        },
      });
      const json = (await res.json().catch(() => ({}))) as {
        credentials?: CredentialRow[];
        error?: string;
      };
      if (!res.ok) throw new Error(json.error || "Failed to load users.");
      return json.credentials ?? [];
    },
    enabled: !!session?.access_token,
  });

  const deleteMutation = useMutation({
    mutationFn: async (userId: string) => {
      if (!session?.access_token) throw new Error("Not signed in.");
      const res = await fetch(EDGE_FUNCTIONS.PROVISION_PIN_USER, {
        method: "POST",
        headers: {
          apikey: ENV.SUPABASE_PUBLISHABLE_KEY,
          Authorization: `Bearer ${session.access_token}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ action: "delete", user_id: userId }),
      });
      const json = (await res.json().catch(() => ({}))) as {
        error?: string;
      };
      if (!res.ok) throw new Error(json.error || "Failed to delete user.");
    },
    onSuccess: () => {
      toast.success("User removed.");
      queryClient.invalidateQueries({ queryKey: ["user-credentials"] });
    },
    onError: (err: Error) => toast.error(err.message),
  });

  const handleCreate = async () => {
    const cleanShortId = shortId.trim().toUpperCase();
    const cleanPin = pin.trim();
    if (!SHORT_ID_PATTERN.test(cleanShortId)) {
      toast.error("Short ID must be 3-10 letters or digits.");
      return;
    }
    if (!PIN_PATTERN.test(cleanPin)) {
      toast.error("PIN must be 4-6 digits.");
      return;
    }
    if (!session?.access_token) {
      toast.error("Not signed in.");
      return;
    }

    setSubmitting(true);
    try {
      const res = await fetch(EDGE_FUNCTIONS.PROVISION_PIN_USER, {
        method: "POST",
        headers: {
          apikey: ENV.SUPABASE_PUBLISHABLE_KEY,
          Authorization: `Bearer ${session.access_token}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          action: "provision",
          short_id: cleanShortId,
          pin: cleanPin,
          display_name: displayName.trim() || null,
          role,
        }),
      });
      const json = (await res.json().catch(() => ({}))) as {
        success?: boolean;
        error?: string;
      };
      if (!res.ok || !json.success) {
        throw new Error(json.error || "Failed to create user.");
      }
      toast.success(`Account created: ${cleanShortId}`);
      setCreateOpen(false);
      setShortId("");
      setPin("");
      setDisplayName("");
      setRole("staff");
      queryClient.invalidateQueries({ queryKey: ["user-credentials"] });
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Failed to create user.");
    } finally {
      setSubmitting(false);
    }
  };

  const handleResetPin = async () => {
    if (!resetTarget) return;
    const cleanPin = resetPin.trim();
    if (!PIN_PATTERN.test(cleanPin)) {
      toast.error("PIN must be 4-6 digits.");
      return;
    }
    if (!session?.access_token) {
      toast.error("Not signed in.");
      return;
    }

    setResetting(true);
    try {
      const res = await fetch(EDGE_FUNCTIONS.PROVISION_PIN_USER, {
        method: "POST",
        headers: {
          apikey: ENV.SUPABASE_PUBLISHABLE_KEY,
          Authorization: `Bearer ${session.access_token}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          action: "update_pin",
          user_id: resetTarget.user_id,
          pin: cleanPin,
        }),
      });
      const json = (await res.json().catch(() => ({}))) as {
        success?: boolean;
        error?: string;
      };
      if (!res.ok || !json.success) {
        throw new Error(json.error || "Failed to reset PIN.");
      }
      toast.success(`PIN reset for ${resetTarget.short_id}.`);
      setResetTarget(null);
      setResetPin("");
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Failed to reset PIN.");
    } finally {
      setResetting(false);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-4"
    >
      <Card className="shadow-soft">
        <CardHeader className="pb-3 flex flex-row items-center justify-between">
          <div>
            <CardTitle className="text-base flex items-center gap-2">
              <KeyRound className="h-4 w-4 text-accent" />
              User Accounts (Short ID + PIN)
            </CardTitle>
            <p className="text-xs text-muted-foreground mt-1">
              Create business-friendly logins: a short memorable ID and a 4-6
              digit PIN. Staff sign in with these instead of email/password.
            </p>
          </div>
          <Button size="sm" onClick={() => setCreateOpen(true)} className="gap-1">
            <Plus className="h-3 w-3" /> New account
          </Button>
        </CardHeader>
        <CardContent className="space-y-2">
          {isLoading ? (
            <div className="flex items-center justify-center py-10 text-muted-foreground">
              <Loader2 className="h-5 w-5 animate-spin mr-2" />
              Loading users...
            </div>
          ) : error ? (
            <div className="flex items-center gap-2 text-destructive text-sm p-3 border border-destructive/30 rounded-md">
              <AlertCircle className="h-4 w-4" />
              {(error as Error).message}
            </div>
          ) : credentials.length === 0 ? (
            <p className="text-sm text-muted-foreground py-6 text-center">
              No short-ID accounts yet. Create one to let staff sign in with a
              PIN.
            </p>
          ) : (
            credentials.map((c) => (
              <div
                key={c.id}
                className="flex items-center justify-between gap-3 border rounded-md p-2"
              >
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <Badge variant="outline" className="font-mono text-xs">
                      {c.short_id}
                    </Badge>
                    {c.display_name && (
                      <span className="text-sm font-medium truncate">
                        {c.display_name}
                      </span>
                    )}
                  </div>
                  <p className="text-[10px] text-muted-foreground">
                    Created {new Date(c.created_at).toLocaleDateString()}
                  </p>
                </div>
                <div className="flex gap-2 shrink-0">
                  <Button
                    size="sm"
                    variant="ghost"
                    className="gap-1"
                    onClick={() => {
                      setResetTarget(c);
                      setResetPin("");
                    }}
                  >
                    <RefreshCw className="h-3 w-3" /> Reset PIN
                  </Button>
                  <Button
                    size="sm"
                    variant="ghost"
                    className="gap-1 text-destructive hover:text-destructive"
                    disabled={deleteMutation.isPending}
                    onClick={() => {
                      if (
                        confirm(
                          `Remove ${c.short_id}? The user will no longer be able to sign in.`,
                        )
                      ) {
                        deleteMutation.mutate(c.user_id);
                      }
                    }}
                  >
                    <Trash2 className="h-3 w-3" /> Remove
                  </Button>
                </div>
              </div>
            ))
          )}
        </CardContent>
      </Card>

      {/* Create dialog */}
      <Dialog open={createOpen} onOpenChange={setCreateOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Create a short-ID account</DialogTitle>
            <DialogDescription>
              Staff will sign in with the short ID + PIN combination. No email
              required.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-3">
            <div>
              <Label className="text-xs">Short ID</Label>
              <Input
                value={shortId}
                onChange={(e) =>
                  setShortId(e.target.value.replace(/[^A-Za-z0-9]/g, ""))
                }
                placeholder="e.g. DW01"
                maxLength={10}
              />
              <p className="text-[10px] text-muted-foreground mt-1">
                3-10 letters or digits. Must be unique.
              </p>
            </div>
            <div>
              <Label className="text-xs">PIN</Label>
              <Input
                value={pin}
                onChange={(e) => setPin(e.target.value.replace(/\D/g, ""))}
                placeholder="e.g. 1234"
                maxLength={6}
                inputMode="numeric"
              />
              <p className="text-[10px] text-muted-foreground mt-1">
                4-6 digits.
              </p>
            </div>
            <div>
              <Label className="text-xs">Display name (optional)</Label>
              <Input
                value={displayName}
                onChange={(e) => setDisplayName(e.target.value)}
                placeholder="e.g. Dee Womack"
              />
            </div>
            <div>
              <Label className="text-xs">Role</Label>
              <Select
                value={role}
                onValueChange={(v) =>
                  setRole(v as "staff" | "reviewer" | "admin")
                }
              >
                <SelectTrigger className="w-full">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="staff">Staff</SelectItem>
                  <SelectItem value="reviewer">Reviewer</SelectItem>
                  <SelectItem value="admin">Admin</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setCreateOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleCreate} disabled={submitting}>
              {submitting ? (
                <Loader2 className="h-4 w-4 animate-spin mr-2" />
              ) : (
                <Plus className="h-4 w-4 mr-2" />
              )}
              Create account
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Reset PIN dialog */}
      <Dialog
        open={!!resetTarget}
        onOpenChange={(open) => {
          if (!open) {
            setResetTarget(null);
            setResetPin("");
          }
        }}
      >
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              Reset PIN{resetTarget ? ` for ${resetTarget.short_id}` : ""}
            </DialogTitle>
            <DialogDescription>
              Set a new 4-6 digit PIN. Share it with the user securely.
            </DialogDescription>
          </DialogHeader>
          <div>
            <Label className="text-xs">New PIN</Label>
            <Input
              value={resetPin}
              onChange={(e) => setResetPin(e.target.value.replace(/\D/g, ""))}
              placeholder="e.g. 5678"
              maxLength={6}
              inputMode="numeric"
            />
          </div>
          <DialogFooter>
            <Button
              variant="ghost"
              onClick={() => {
                setResetTarget(null);
                setResetPin("");
              }}
            >
              Cancel
            </Button>
            <Button onClick={handleResetPin} disabled={resetting}>
              {resetting ? (
                <Loader2 className="h-4 w-4 animate-spin mr-2" />
              ) : (
                <RefreshCw className="h-4 w-4 mr-2" />
              )}
              Reset PIN
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </motion.div>
  );
};
