import { WebsiteConfigCard } from "./website/WebsiteConfigCard";
import { ProductMappingCard } from "./website/ProductMappingCard";
import { PublishQueueCard } from "./website/PublishQueueCard";

export const WebsiteIntegrationPanel = () => (
  <div className="space-y-6">
    <WebsiteConfigCard />
    <ProductMappingCard />
    <PublishQueueCard />
  </div>
);
