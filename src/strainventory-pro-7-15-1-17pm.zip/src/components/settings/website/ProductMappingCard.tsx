import { useMemo, useState } from "react";
import { motion } from "framer-motion";
import { GripVertical, Package, RefreshCw, Trash2, X } from "lucide-react";
import {
  DndContext,
  DragOverlay,
  PointerSensor,
  useDraggable,
  useDroppable,
  useSensor,
  useSensors,
  type DragEndEvent,
  type DragStartEvent,
} from "@dnd-kit/core";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { toast } from "sonner";
import { useProducts } from "@/hooks/useProducts";
import {
  useWebsiteMappings,
  type WebsiteProductMapping,
} from "@/hooks/useWebsiteIntegration";
import { slugify } from "./slugify";

type ProductLite = {
  id: string;
  name: string;
  brand?: string | null;
  sku?: string | null;
};

const ProductCard = ({
  product,
  mapping,
  dragging,
}: {
  product: ProductLite;
  mapping?: WebsiteProductMapping;
  dragging?: boolean;
}) => (
  <div
    className={`flex items-center gap-2 rounded-lg border border-border bg-background/80 px-3 py-2 ${
      dragging ? "shadow-elegant ring-1 ring-accent" : "shadow-soft"
    }`}
  >
    <GripVertical className="h-3.5 w-3.5 text-muted-foreground shrink-0" />
    <div className="min-w-0 flex-1">
      <div className="text-xs font-medium truncate">{product.name}</div>
      <div className="text-[10px] text-muted-foreground truncate">
        {product.brand || "—"} · SKU {product.sku || "—"}
      </div>
    </div>
    {mapping && (
      <Badge
        variant={mapping.status === "synced" ? "outline" : "secondary"}
        className="text-[10px]"
      >
        {mapping.status}
      </Badge>
    )}
  </div>
);

const DraggableProduct = ({
  product,
  mapping,
}: {
  product: ProductLite;
  mapping?: WebsiteProductMapping;
}) => {
  const { attributes, listeners, setNodeRef, isDragging } = useDraggable({
    id: product.id,
    data: { product },
  });
  return (
    <div
      ref={setNodeRef}
      {...attributes}
      {...listeners}
      className={`cursor-grab active:cursor-grabbing ${isDragging ? "opacity-40" : ""}`}
    >
      <ProductCard product={product} mapping={mapping} />
    </div>
  );
};

const DropColumn = ({
  id,
  title,
  count,
  children,
  hint,
}: {
  id: string;
  title: string;
  count: number;
  children: React.ReactNode;
  hint: string;
}) => {
  const { setNodeRef, isOver } = useDroppable({ id });
  return (
    <div
      ref={setNodeRef}
      className={`rounded-lg border-2 border-dashed transition-colors ${
        isOver ? "border-accent bg-accent/5" : "border-border bg-background/40"
      }`}
    >
      <div className="flex items-center justify-between px-3 py-2 border-b border-border">
        <div className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
          {title}
        </div>
        <Badge variant="outline" className="text-[10px]">
          {count}
        </Badge>
      </div>
      <ScrollArea className="h-80">
        <div className="p-2 space-y-2 min-h-full">
          {count === 0 ? (
            <div className="text-[11px] text-muted-foreground text-center py-12 px-3">
              {hint}
            </div>
          ) : (
            children
          )}
        </div>
      </ScrollArea>
    </div>
  );
};

export const ProductMappingCard = () => {
  const { data: products } = useProducts();
  const { mappings, upsertMapping, removeMapping } = useWebsiteMappings();
  const [activeProduct, setActiveProduct] = useState<ProductLite | null>(null);

  const mappingByProduct = useMemo(
    () => new Map(mappings.map((m) => [m.productId, m])),
    [mappings],
  );

  const { unmapped, mapped } = useMemo(() => {
    const list = (products ?? []) as ProductLite[];
    const u: ProductLite[] = [];
    const m: ProductLite[] = [];
    list.forEach((p) => (mappingByProduct.has(p.id) ? m.push(p) : u.push(p)));
    return { unmapped: u, mapped: m };
  }, [products, mappingByProduct]);

  const sensors = useSensors(
    useSensor(PointerSensor, { activationConstraint: { distance: 4 } }),
  );

  const handleDragStart = (e: DragStartEvent) => {
    const p = e.active.data.current?.product as ProductLite | undefined;
    if (p) setActiveProduct(p);
  };

  const handleDragEnd = (e: DragEndEvent) => {
    setActiveProduct(null);
    const product = e.active.data.current?.product as ProductLite | undefined;
    const target = e.over?.id;
    if (!product || !target) return;

    if (target === "mapped" && !mappingByProduct.has(product.id)) {
      upsertMapping({
        productId: product.id,
        externalId: product.sku || product.id,
        slug: slugify(product.name),
        lastSyncedAt: null,
        status: "pending",
      });
      toast.success(`Mapped "${product.name}" to storefront.`);
    } else if (target === "unmapped" && mappingByProduct.has(product.id)) {
      removeMapping(product.id);
      toast.success(`Removed "${product.name}" from storefront.`);
    }
  };

  const handleAutoMap = () => {
    if (unmapped.length === 0) {
      toast.error("Everything is already mapped.");
      return;
    }
    unmapped.forEach((p) =>
      upsertMapping({
        productId: p.id,
        externalId: p.sku || p.id,
        slug: slugify(p.name),
        lastSyncedAt: null,
        status: "pending",
      }),
    );
    toast.success(`Auto-mapped ${unmapped.length} product(s).`);
  };

  const handleClear = () => {
    mapped.forEach((p) => removeMapping(p.id));
    toast.success("Cleared all mappings.");
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.08 }}
    >
      <Card className="shadow-soft">
        <CardHeader className="pb-3 flex flex-row items-center justify-between">
          <CardTitle className="text-base flex items-center gap-2">
            <Package className="h-4 w-4 text-accent" />
            Product Sync Mapping
            <Badge variant="outline" className="ml-1 text-[10px]">
              {mapped.length}/{(products ?? []).length}
            </Badge>
          </CardTitle>
          <div className="flex items-center gap-2">
            {mapped.length > 0 && (
              <Button
                variant="ghost"
                size="sm"
                onClick={handleClear}
                className="gap-1.5 text-muted-foreground"
              >
                <Trash2 className="h-3.5 w-3.5" />
                Clear
              </Button>
            )}
            <Button
              variant="outline"
              size="sm"
              onClick={handleAutoMap}
              className="gap-1.5"
            >
              <RefreshCw className="h-3.5 w-3.5" />
              Auto-map all
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <p className="text-[11px] text-muted-foreground mb-3">
            Drag a product into <span className="font-medium">Storefront</span>{" "}
            to publish it, or back to <span className="font-medium">Catalog</span>{" "}
            to unmap.
          </p>
          {(products ?? []).length === 0 ? (
            <div className="text-sm text-muted-foreground py-6 text-center">
              No products yet. Add products in the catalog to map them.
            </div>
          ) : (
            <DndContext
              sensors={sensors}
              onDragStart={handleDragStart}
              onDragEnd={handleDragEnd}
              onDragCancel={() => setActiveProduct(null)}
            >
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <DropColumn
                  id="unmapped"
                  title="Catalog (unmapped)"
                  count={unmapped.length}
                  hint="Drop here to remove from the storefront."
                >
                  {unmapped.map((p) => (
                    <DraggableProduct key={p.id} product={p} />
                  ))}
                </DropColumn>
                <DropColumn
                  id="mapped"
                  title="Storefront"
                  count={mapped.length}
                  hint="Drop products here to publish to your website menu."
                >
                  {mapped.map((p) => (
                    <DraggableProduct
                      key={p.id}
                      product={p}
                      mapping={mappingByProduct.get(p.id)}
                    />
                  ))}
                </DropColumn>
              </div>
              <DragOverlay>
                {activeProduct && (
                  <div className="w-[320px] opacity-90">
                    <ProductCard
                      product={activeProduct}
                      mapping={mappingByProduct.get(activeProduct.id)}
                      dragging
                    />
                  </div>
                )}
              </DragOverlay>
            </DndContext>
          )}
        </CardContent>
      </Card>
    </motion.div>
  );
};

// keep X icon referenced for tree-shake stability
void X;
