import { Trash2 } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import type { WebsiteProductMapping } from "@/hooks/useWebsiteIntegration";
import { slugify } from "./slugify";

interface ProductMappingRowProps {
  product: { id: string; name: string; brand?: string | null; sku?: string | null };
  mapping?: WebsiteProductMapping;
  onUpsert: (m: WebsiteProductMapping) => void;
  onRemove: (productId: string) => void;
}

export const ProductMappingRow = ({
  product: p,
  mapping: m,
  onUpsert,
  onRemove,
}: ProductMappingRowProps) => (
  <div className="flex items-center gap-2 rounded-lg border border-border bg-background/60 px-3 py-2">
    <div className="min-w-0 flex-1">
      <div className="text-xs font-medium truncate">{p.name}</div>
      <div className="text-[10px] text-muted-foreground truncate">
        {p.brand} · SKU {p.sku || "—"}
      </div>
    </div>
    <Input
      placeholder="external-id"
      value={m?.externalId ?? ""}
      onChange={(e) =>
        onUpsert({
          productId: p.id,
          externalId: e.target.value,
          slug: m?.slug ?? slugify(p.name),
          lastSyncedAt: m?.lastSyncedAt ?? null,
          status: m?.status ?? "unmapped",
        })
      }
      className="h-7 w-32 text-xs font-mono bg-background"
    />
    <Input
      placeholder="url-slug"
      value={m?.slug ?? ""}
      onChange={(e) =>
        onUpsert({
          productId: p.id,
          externalId: m?.externalId ?? (p.sku || p.id),
          slug: e.target.value,
          lastSyncedAt: m?.lastSyncedAt ?? null,
          status: m?.status ?? "unmapped",
        })
      }
      className="h-7 w-36 text-xs font-mono bg-background"
    />
    {m ? (
      <>
        <Badge
          variant={m.status === "synced" ? "outline" : "secondary"}
          className="text-[10px]"
        >
          {m.status}
        </Badge>
        <Button
          variant="ghost"
          size="icon"
          className="h-7 w-7"
          onClick={() => onRemove(p.id)}
        >
          <Trash2 className="h-3.5 w-3.5 text-muted-foreground" />
        </Button>
      </>
    ) : (
      <Badge variant="secondary" className="text-[10px]">
        unmapped
      </Badge>
    )}
  </div>
);
