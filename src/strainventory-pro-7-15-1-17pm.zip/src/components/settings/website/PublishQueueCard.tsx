import { motion } from "framer-motion";
import { Sparkles, Trash2 } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useWebsitePublishQueue } from "@/hooks/useWebsiteIntegration";

export const PublishQueueCard = () => {
  const { queue, clearQueue } = useWebsitePublishQueue();

  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.12 }}
    >
      <Card className="shadow-soft">
        <CardHeader className="pb-3 flex flex-row items-center justify-between">
          <CardTitle className="text-base flex items-center gap-2">
            <Sparkles className="h-4 w-4 text-accent" />
            Publish Queue
            <Badge variant="outline" className="ml-1 text-[10px]">
              {queue.length}
            </Badge>
          </CardTitle>
          {queue.length > 0 && (
            <Button variant="outline" size="sm" onClick={clearQueue} className="gap-1.5">
              <Trash2 className="h-3.5 w-3.5" />
              Clear
            </Button>
          )}
        </CardHeader>
        <CardContent>
          {queue.length > 0 ? (
            <ScrollArea className="h-60">
              <div className="space-y-2">
                {queue.map((evt) => (
                  <div
                    key={evt.id}
                    className="flex items-start gap-2 rounded-lg border border-border bg-background/60 px-3 py-2"
                  >
                    <Badge variant="secondary" className="text-[10px] uppercase">
                      {evt.action}
                    </Badge>
                    <div className="min-w-0 flex-1">
                      <div className="text-xs font-mono truncate">{evt.productId}</div>
                      <div className="text-[10px] text-muted-foreground">
                        {evt.status} · {new Date(evt.queuedAt).toLocaleString()}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </ScrollArea>
          ) : (
            <div className="text-sm text-muted-foreground py-6 text-center">
              No publish events queued. Product updates will appear here when sync
              is enabled.
            </div>
          )}
        </CardContent>
      </Card>
    </motion.div>
  );
};
