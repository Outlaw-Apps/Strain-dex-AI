import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { Globe, Link2, Plug } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { toast } from "sonner";
import {
  getWebsiteConfig,
  setWebsiteConfig,
} from "@/hooks/useWebsiteIntegration";

export const WebsiteConfigCard = () => {
  const initial = getWebsiteConfig();
  const [provider, setProvider] = useState(initial.provider);
  const [storeUrl, setStoreUrl] = useState(initial.storeUrl);
  const [apiKey, setApiKey] = useState(initial.apiKey);
  const [syncMenu, setSyncMenu] = useState(initial.syncMenu);
  const [syncInventory, setSyncInventory] = useState(initial.syncInventory);
  const [testing, setTesting] = useState(false);

  useEffect(() => {
    setWebsiteConfig({ provider, storeUrl, apiKey, syncMenu, syncInventory });
  }, [provider, storeUrl, apiKey, syncMenu, syncInventory]);

  const handleSave = () => {
    setWebsiteConfig({ provider, storeUrl, apiKey, syncMenu, syncInventory });
    toast.success("Website integration settings saved.");
  };

  const handleTestConnection = async () => {
    if (provider === "none") {
      toast.error("Pick a storefront provider first.");
      return;
    }
    if (!storeUrl.trim()) {
      toast.error("Enter your storefront URL before testing.");
      return;
    }
    let target: URL;
    try {
      target = new URL(storeUrl.trim());
    } catch {
      toast.error("Storefront URL is not a valid URL.");
      return;
    }
    setTesting(true);
    const started = performance.now();
    try {
      // Cross-origin ping — `no-cors` always resolves opaque; treat resolution
      // as "the host is reachable from this browser" which is the most we can
      // verify without a backend proxy.
      await fetch(target.toString(), { method: "HEAD", mode: "no-cors", cache: "no-store" });
      const ms = Math.round(performance.now() - started);
      toast.success(`Reached ${target.host} in ${ms} ms.`);
    } catch (err) {
      toast.error(`Could not reach ${target.host}: ${(err as Error).message}`);
    } finally {
      setTesting(false);
    }
  };

  return (
    <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }}>
      <Card className="shadow-soft">
        <CardHeader className="pb-3">
          <CardTitle className="text-base flex items-center gap-2">
            <Globe className="h-4 w-4 text-accent" />
            Dispensary Website Integration
            <Badge variant="outline" className="ml-2 text-[10px]">
              Placeholder
            </Badge>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-5">
          <p className="text-xs text-muted-foreground">
            Wire up a public-facing dispensary storefront. Mappings and the
            publish queue are stored locally until a live provider is connected.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label className="text-xs">Storefront Provider</Label>
              <Select value={provider} onValueChange={setProvider}>
                <SelectTrigger className="bg-background text-sm">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">Not connected</SelectItem>
                  <SelectItem value="dutchie">Dutchie</SelectItem>
                  <SelectItem value="weedmaps">Weedmaps</SelectItem>
                  <SelectItem value="leafly">Leafly</SelectItem>
                  <SelectItem value="jane">I Heart Jane</SelectItem>
                  <SelectItem value="custom">Custom / Shopify</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label className="text-xs">Storefront URL</Label>
              <Input
                placeholder="https://yourdispensary.com"
                value={storeUrl}
                onChange={(e) => setStoreUrl(e.target.value)}
                className="bg-background text-sm"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label className="text-xs">API Key / Token</Label>
            <Input
              type="password"
              placeholder="Paste your provider API key"
              value={apiKey}
              onChange={(e) => setApiKey(e.target.value)}
              className="bg-background font-mono text-sm"
            />
            <p className="text-[10px] text-muted-foreground">
              Stored locally for now. Move to a backend secret before going live.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-6">
            <div className="flex items-center gap-2">
              <Switch
                checked={syncMenu}
                onCheckedChange={setSyncMenu}
                disabled={provider === "none"}
              />
              <Label className="text-sm">Push catalog to website menu</Label>
            </div>
            <div className="flex items-center gap-2">
              <Switch
                checked={syncInventory}
                onCheckedChange={setSyncInventory}
                disabled={provider === "none"}
              />
              <Label className="text-sm">Sync inventory in real time</Label>
            </div>
          </div>

          <div className="flex items-center gap-2 pt-2">
            <Button variant="gold" size="sm" onClick={handleSave} className="gap-1.5">
              <Plug className="h-3.5 w-3.5" />
              Save Configuration
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={handleTestConnection}
              disabled={testing || provider === "none" || !storeUrl.trim()}
              className="gap-1.5"
            >
              <Link2 className="h-3.5 w-3.5" />
              {testing ? "Testing…" : "Test Connection"}
            </Button>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
};
