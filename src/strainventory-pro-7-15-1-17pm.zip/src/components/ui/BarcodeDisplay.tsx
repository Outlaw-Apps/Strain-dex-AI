/**
 * BarcodeDisplay — renders a Code128 barcode using JsBarcode.
 * Used for product labels and employee badge barcodes.
 */

import { useEffect, useRef } from "react";
import JsBarcode from "jsbarcode";

interface BarcodePrintProps {
  value: string;
  label?: string;
  /** Barcode format — defaults to CODE128 */
  format?: string;
  width?: number;
  height?: number;
  className?: string;
}

export const BarcodeDisplay = ({
  value,
  label,
  format = "CODE128",
  width = 2,
  height = 60,
  className,
}: BarcodePrintProps) => {
  const svgRef = useRef<SVGSVGElement>(null);

  useEffect(() => {
    if (!svgRef.current || !value) return;
    try {
      JsBarcode(svgRef.current, value, {
        format,
        width,
        height,
        displayValue: true,
        text: label ?? value,
        fontSize: 11,
        margin: 8,
        background: "transparent",
      });
    } catch {
      // Invalid value for the chosen format — clear previous render
      if (svgRef.current) {
        svgRef.current.innerHTML = "";
      }
    }
  }, [value, label, format, width, height]);

  if (!value) return null;

  return <svg ref={svgRef} className={className} />;
};
