/**
 * BarcodeScanner component — modal overlay with camera viewfinder.
 *
 * Supports hybrid mode: camera (via @zxing/browser) and hardware wedge.
 * Falls back to manual entry when camera is unavailable.
 */

import { useEffect, useRef, useState, useCallback, useMemo } from "react";
import { BarcodeFormat } from "@zxing/library";
import { Camera, CameraOff, Keyboard, ScanLine, X, CheckCircle2, AlertCircle } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { cn } from "@/lib/utils";
import { useBarcodeScanner, type ScanResult } from "@/hooks/useBarcodeScanner";

type ScanMode = "camera" | "wedge" | "manual";

export interface BarcodeScannerProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onScan: (result: ScanResult) => void;
  /** Label shown in the dialog title, e.g. "Scan Driver's Licence" */
  title?: string;
  /** Restrict accepted barcode formats; defaults to all */
  formats?: BarcodeFormat[];
  /** Whether to enable the hardware-wedge mode at all (default: true) */
  allowWedge?: boolean;
}

export const BarcodeScanner = ({
  open,
  onOpenChange,
  onScan,
  title = "Scan Barcode",
  formats,
  allowWedge = true,
}: BarcodeScannerProps) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [mode, setMode] = useState<ScanMode>("camera");
  const [manualValue, setManualValue] = useState("");
  const [flashResult, setFlashResult] = useState<"success" | "error" | null>(null);
  const handledRef = useRef(false);

  const { startCamera, stopCamera, startWedge, stopWedge, isCameraScanning, isWedgeActive, error } =
    useBarcodeScanner((result: ScanResult) => {
      if (handledRef.current) return;
      handledRef.current = true;
      stopCamera();
      stopWedge();
      setFlashResult("success");
      setTimeout(() => {
        setFlashResult(null);
        onScan(result);
        onOpenChange(false);
      }, 600);
    });

  // Reset handled guard when dialog opens
  useEffect(() => {
    if (open) {
      handledRef.current = false;
    }
  }, [open]);

  // Stabilise format array identity so useEffect doesn't re-fire every render
  const formatsKey = formats ? formats.join(",") : "";
  // eslint-disable-next-line react-hooks/exhaustive-deps
  const stableFormats = useMemo(() => formats, [formatsKey]);

  // Start / stop based on open state and mode
  useEffect(() => {
    if (!open) {
      stopCamera();
      stopWedge();
      return;
    }

    if (mode === "camera" && videoRef.current) {
      // Delay lets the Dialog animation finish and the video element mount
      // before we request camera access.  The hook now also waits for
      // `loadeddata` internally, so this mainly avoids a getUserMedia race.
      const timer = setTimeout(() => {
        if (videoRef.current) {
          startCamera(videoRef.current, stableFormats);
        }
      }, 300);
      return () => {
        clearTimeout(timer);
        stopCamera();
        stopWedge();
      };
    } else if (mode === "wedge" && allowWedge) {
      startWedge();
    }

    return () => {
      stopCamera();
      stopWedge();
    };
  }, [open, mode, allowWedge, stableFormats, startCamera, stopCamera, startWedge, stopWedge]);

  const switchMode = (next: ScanMode) => {
    stopCamera();
    stopWedge();
    setMode(next);
  };

  const handleManualSubmit = () => {
    if (!manualValue.trim() || handledRef.current) return;
    handledRef.current = true;
    stopCamera();
    stopWedge();
    const result: ScanResult = { text: manualValue.trim(), format: "MANUAL" };
    setFlashResult("success");
    setManualValue("");
    setTimeout(() => {
      setFlashResult(null);
      onScan(result);
      onOpenChange(false);
    }, 600);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="w-[calc(100vw-2rem)] max-w-md p-0 overflow-hidden">
        <DialogHeader className="px-4 pt-4 pb-2">
          <div className="flex items-center justify-between">
            <DialogTitle className="text-base flex items-center gap-2">
              <ScanLine className="h-4 w-4 text-accent" />
              {title}
            </DialogTitle>
            <button
              type="button"
              aria-label="Close scanner"
              onClick={() => onOpenChange(false)}
              className="text-muted-foreground hover:text-foreground transition-colors"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        </DialogHeader>

        {/* Mode tabs */}
        <div className="flex border-b border-border">
          <ModeTab active={mode === "camera"} onClick={() => switchMode("camera")}>
            <Camera className="h-3.5 w-3.5" /> Camera
          </ModeTab>
          {allowWedge && (
            <ModeTab active={mode === "wedge"} onClick={() => switchMode("wedge")}>
              <Keyboard className="h-3.5 w-3.5" /> Scanner
            </ModeTab>
          )}
          <ModeTab active={mode === "manual"} onClick={() => switchMode("manual")}>
            Manual
          </ModeTab>
        </div>

        {/* Camera viewfinder */}
        {mode === "camera" && (
          <div className="relative bg-black" style={{ aspectRatio: "4/3" }}>
            <video ref={videoRef} className="w-full h-full object-cover" muted playsInline />

            {/* Animated scan line */}
            {isCameraScanning && !flashResult && (
              <div className="absolute inset-0 pointer-events-none">
                <div className="absolute left-4 right-4 top-1/2 h-0.5 bg-accent/80 animate-scan-line" />
                {/* Corner brackets */}
                <div className="absolute top-6 left-6 w-8 h-8 border-l-2 border-t-2 border-accent rounded-tl" />
                <div className="absolute top-6 right-6 w-8 h-8 border-r-2 border-t-2 border-accent rounded-tr" />
                <div className="absolute bottom-6 left-6 w-8 h-8 border-l-2 border-b-2 border-accent rounded-bl" />
                <div className="absolute bottom-6 right-6 w-8 h-8 border-r-2 border-b-2 border-accent rounded-br" />
              </div>
            )}

            {/* Flash overlay on result */}
            {flashResult === "success" && (
              <div className="absolute inset-0 bg-success/30 flex items-center justify-center">
                <CheckCircle2 className="h-16 w-16 text-success" />
              </div>
            )}

            {/* Error overlay */}
            {error && (
              <div className="absolute inset-0 bg-background/80 flex flex-col items-center justify-center gap-3 p-4 text-center">
                <CameraOff className="h-10 w-10 text-muted-foreground" />
                <p className="text-sm text-muted-foreground">{error}</p>
                <Button size="sm" variant="outline" onClick={() => switchMode("manual")}>
                  Enter Manually
                </Button>
              </div>
            )}
          </div>
        )}

        {/* Wedge mode instructions */}
        {mode === "wedge" && (
          <div className="px-6 py-10 flex flex-col items-center gap-4 text-center">
            <div
              className={cn(
                "rounded-full p-5 transition-colors",
                isWedgeActive ? "bg-accent/10 text-accent" : "bg-muted text-muted-foreground",
              )}
            >
              <ScanLine className="h-10 w-10" />
            </div>
            <div>
              <p className="text-sm font-medium text-foreground">Hardware Scanner Ready</p>
              <p className="text-xs text-muted-foreground mt-1">
                Point your barcode scanner at the barcode and press the trigger.
              </p>
            </div>
            {isWedgeActive && (
              <div className="flex items-center gap-1.5 text-xs text-success">
                <div className="h-2 w-2 rounded-full bg-success animate-pulse" />
                Listening for scanner input…
              </div>
            )}
          </div>
        )}

        {/* Manual entry */}
        {mode === "manual" && (
          <div className="px-4 py-5 space-y-3">
            <div className="flex items-center gap-2 text-sm text-muted-foreground mb-1">
              <AlertCircle className="h-4 w-4" />
              Enter the barcode value manually
            </div>
            <div>
              <Label className="text-xs">Barcode / ID Number</Label>
              <Input
                autoFocus
                value={manualValue}
                onChange={(e) => setManualValue(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && handleManualSubmit()}
                placeholder="Type or paste barcode…"
                className="mt-1"
              />
            </div>
            <Button className="w-full" onClick={handleManualSubmit} disabled={!manualValue.trim()}>
              Confirm
            </Button>
          </div>
        )}

        <div className="px-4 pb-4 pt-2">
          <p className="text-[10px] text-muted-foreground text-center">
            {formats && formats.length > 0
              ? `Accepted formats: ${formats.map((f) => BarcodeFormat[f]).join(", ")}`
              : "All barcode formats accepted"}
          </p>
        </div>
      </DialogContent>
    </Dialog>
  );
};

const ModeTab = ({
  active,
  onClick,
  children,
}: {
  active: boolean;
  onClick: () => void;
  children: React.ReactNode;
}) => (
  <button
    type="button"
    onClick={onClick}
    className={cn(
      "flex-1 flex items-center justify-center gap-1.5 py-2 text-xs font-medium transition-colors",
      active
        ? "border-b-2 border-accent text-accent"
        : "text-muted-foreground hover:text-foreground",
    )}
  >
    {children}
  </button>
);
