/**
 * ManagerOverrideButton — renders a toggle button for admin users to
 * bypass mandatory form-field validation on the current page.
 *
 * Only visible to admin users. Shows a clear visual indicator when active.
 */

import { ShieldAlert, ShieldOff } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { cn } from "@/lib/utils";
import type { UseManagerOverride } from "@/hooks/useManagerOverride";

interface ManagerOverrideButtonProps {
  override: UseManagerOverride;
  /** Optional compact mode — just the icon badge */
  compact?: boolean;
  className?: string;
}

export const ManagerOverrideButton = ({
  override,
  compact = false,
  className,
}: ManagerOverrideButtonProps) => {
  if (!override.canOverride) return null;

  if (compact) {
    return (
      <Tooltip>
        <TooltipTrigger asChild>
          <Button
            type="button"
            variant={override.overrideActive ? "destructive" : "outline"}
            size="icon"
            className={cn("h-8 w-8", className)}
            onClick={override.toggleOverride}
          >
            {override.overrideActive ? (
              <ShieldOff className="h-4 w-4" />
            ) : (
              <ShieldAlert className="h-4 w-4" />
            )}
          </Button>
        </TooltipTrigger>
        <TooltipContent>
          {override.overrideActive
            ? "Override active — click to restore validation"
            : "Manager Override — bypass required fields"}
        </TooltipContent>
      </Tooltip>
    );
  }

  return (
    <Button
      type="button"
      variant={override.overrideActive ? "destructive" : "outline"}
      size="sm"
      className={cn("gap-2 text-xs", className)}
      onClick={override.toggleOverride}
    >
      {override.overrideActive ? (
        <ShieldOff className="h-3.5 w-3.5" />
      ) : (
        <ShieldAlert className="h-3.5 w-3.5" />
      )}
      {override.overrideActive ? "Override Active" : "Manager Override"}
      {override.overrideActive && (
        <Badge variant="secondary" className="ml-1 text-[9px] bg-destructive/20 text-destructive-foreground border-none">
          ON
        </Badge>
      )}
    </Button>
  );
};
