import { createContext, useContext, useMemo, useState, type ReactNode } from "react";
import { useAuth } from "@/context/AuthContext";
import {
  useMessengerNotifications as useMessengerNotificationsHook,
} from "@/hooks/useMessengerNotifications";
import type { ConversationMessageRow } from "@/hooks/useMessages";

interface MessengerNotificationsContextValue {
  unreadCount: number;
  latestMessage: ConversationMessageRow | null;
  clearNotifications: () => void;
  /**
   * Currently-open conversation id. Set by the Messages page on mount /
   * conversation selection. Used by the underlying hook for in-app
   * suppression when the window is focused.
   */
  activeChannelId: string | null;
  setActiveChannelId: (id: string | null) => void;
}

const MessengerNotificationsContext =
  createContext<MessengerNotificationsContextValue | null>(null);

export function MessengerNotificationsProvider({ children }: { children: ReactNode }) {
  const { user } = useAuth();
  const [activeChannelId, setActiveChannelId] = useState<string | null>(null);

  const { unreadCount, latestMessage, clearNotifications } = useMessengerNotificationsHook({
    channelId: activeChannelId,
    userId: user?.id ?? null,
  });

  const value = useMemo<MessengerNotificationsContextValue>(
    () => ({
      unreadCount,
      latestMessage,
      clearNotifications,
      activeChannelId,
      setActiveChannelId,
    }),
    [unreadCount, latestMessage, clearNotifications, activeChannelId],
  );

  return (
    <MessengerNotificationsContext.Provider value={value}>
      {children}
    </MessengerNotificationsContext.Provider>
  );
}

export function useMessengerNotificationsContext(): MessengerNotificationsContextValue {
  const ctx = useContext(MessengerNotificationsContext);
  if (!ctx) {
    // Safe fallback so consumers don't crash if used outside the provider
    // (e.g. in tests). All operations become no-ops in that case.
    return {
      unreadCount: 0,
      latestMessage: null,
      clearNotifications: () => undefined,
      activeChannelId: null,
      setActiveChannelId: () => undefined,
    };
  }
  return ctx;
}
