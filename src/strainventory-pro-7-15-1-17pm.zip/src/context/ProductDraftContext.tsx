import React, { createContext, useContext, useState, useCallback, useEffect, useMemo } from "react";
import { clearStoredDraft, loadStoredDraft, saveStoredDraft } from "@/lib/productDraftStorage";
import type { ProductImage, ProductSearchDraft } from "@/types/catalog";

// ---------- types ----------
export type ProductIntake = ProductSearchDraft;

export type ConfidenceLevel = "verified" | "matched" | "inferred" | "review";

export interface DraftField {
  label: string;
  value: string;
  confidence: ConfidenceLevel;
}

export interface DraftSection {
  title: string;
  icon: string; // icon key for lookup
  confidence: ConfidenceLevel;
  fields: { label: string; value: string }[];
}

export interface DraftSourceCitation {
  source: string;
  domain: string;
  url: string;
  title: string;
  snippet?: string;
}

export interface SelectedImage {
  id: string;
  url: string;
  alt: string;
  quality: string;
  source: string;
}

export interface GeneratedDraft {
  overallConfidence: number;
  sections: DraftSection[];
  descriptionShort: string;
  descriptionLong: string;
  sources?: DraftSourceCitation[];
}

export interface ProductDraft {
  catalogId: string | null;
  intake: ProductIntake;
  draft: GeneratedDraft | null;
  primaryImage: SelectedImage | null;
  alternateImages: SelectedImage[];
  imageSearchResults: ProductImageSearchResult[];
  status: "intake" | "drafted" | "images_selected" | "reviewed" | "published";
}

export interface ProductImageSearchResult extends ProductImage {
  id: string;
  quality: string;
  source: string;
  verificationConfidence?: number;
}

const emptyIntake: ProductIntake = {
  brand: "",
  strain: "",
  productType: "",
  packageSize: "",
  sku: "",
  vendor: "",
  notes: "",
};

const defaultDraft: ProductDraft = {
  catalogId: null,
  intake: emptyIntake,
  draft: null,
  primaryImage: null,
  alternateImages: [],
  imageSearchResults: [],
  status: "intake",
};

// ---------- context ----------
interface ProductDraftContextType {
  product: ProductDraft;
  setCatalogId: (catalogId: string | null) => void;
  setIntake: (intake: ProductIntake) => void;
  setDraft: (draft: GeneratedDraft) => void;
  setPrimaryImage: (img: SelectedImage | null) => void;
  setAlternateImages: (imgs: SelectedImage[]) => void;
  setImageSearchResults: (imgs: ProductImageSearchResult[]) => void;
  setStatus: (status: ProductDraft["status"]) => void;
  resetDraft: () => void;
}

const ProductDraftContext = createContext<ProductDraftContextType | null>(null);

export const ProductDraftProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [product, setProduct] = useState<ProductDraft>(() => loadStoredDraft() ?? defaultDraft);

  useEffect(() => {
    saveStoredDraft(product);
  }, [product]);

  const setCatalogId = useCallback((catalogId: string | null) => {
    setProduct((prev) => ({ ...prev, catalogId }));
  }, []);

  const setIntake = useCallback((intake: ProductIntake) => {
    setProduct((prev) => ({ ...prev, intake, status: "intake" }));
  }, []);

  const setDraft = useCallback((draft: GeneratedDraft) => {
    setProduct((prev) => ({ ...prev, draft, status: "drafted" }));
  }, []);

  const setPrimaryImage = useCallback((img: SelectedImage | null) => {
    setProduct((prev) => ({ ...prev, primaryImage: img }));
  }, []);

  const setAlternateImages = useCallback((imgs: SelectedImage[]) => {
    setProduct((prev) => ({ ...prev, alternateImages: imgs }));
  }, []);

  const setImageSearchResults = useCallback((imgs: ProductImageSearchResult[]) => {
    setProduct((prev) => ({ ...prev, imageSearchResults: imgs }));
  }, []);

  const setStatus = useCallback((status: ProductDraft["status"]) => {
    setProduct((prev) => ({ ...prev, status }));
  }, []);

  const resetDraft = useCallback(() => {
    clearStoredDraft();
    setProduct(defaultDraft);
  }, []);

  const value = useMemo(
    () => ({
      product,
      setCatalogId,
      setIntake,
      setDraft,
      setPrimaryImage,
      setAlternateImages,
      setImageSearchResults,
      setStatus,
      resetDraft,
    }),
    [product, setCatalogId, setIntake, setDraft, setPrimaryImage, setAlternateImages, setImageSearchResults, setStatus, resetDraft]
  );

  return (
    <ProductDraftContext.Provider value={value}>
      {children}
    </ProductDraftContext.Provider>
  );
};

export const useProductDraft = () => {
  const ctx = useContext(ProductDraftContext);
  if (!ctx) throw new Error("useProductDraft must be used inside ProductDraftProvider");
  return ctx;
};
