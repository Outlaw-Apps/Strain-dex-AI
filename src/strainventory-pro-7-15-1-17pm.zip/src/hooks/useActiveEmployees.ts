import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export const useActiveEmployees = () => {
  return useQuery({
    queryKey: ["active-employees"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("time_entries")
        .select("user_id, clock_in")
        .is("clock_out", null);

      if (error) throw error;

      return (data ?? []).map((entry) => ({
        user_id: entry.user_id,
        clock_in: entry.clock_in,
      }));
    },
    refetchInterval: 30_000,
  });
};