import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";

export type AiSearchDomainMode = "allow" | "block";

export interface AiSearchDomain {
  id: string;
  domain: string;
  mode: AiSearchDomainMode;
  label: string | null;
  enabled: boolean;
  created_at: string;
  updated_at: string;
}

export interface NewAiSearchDomain {
  domain: string;
  mode: AiSearchDomainMode;
  label?: string;
}

const QUERY_KEY = ["ai-search-domains"] as const;

/**
 * Normalize a user-entered domain into the storage form.
 *  - Lowercase, strip scheme + leading "www.".
 *  - For allow entries the path is dropped (allowlist gates which sites the AI may visit).
 *  - For block entries an optional path prefix is preserved (e.g. leafly.com/menu).
 */
export const normalizeDomainInput = (
  raw: string,
  mode: AiSearchDomainMode,
): string => {
  const cleaned = raw
    .trim()
    .toLowerCase()
    .replace(/^https?:\/\//, "")
    .replace(/^www\./, "")
    .replace(/\/+$/, "");
  if (!cleaned) return "";
  if (mode === "allow") {
    const slash = cleaned.indexOf("/");
    return slash === -1 ? cleaned : cleaned.slice(0, slash);
  }
  return cleaned;
};

export const useAiSearchDomains = () => {
  const queryClient = useQueryClient();

  const { data: domains = [], isLoading } = useQuery({
    queryKey: QUERY_KEY,
    queryFn: async (): Promise<AiSearchDomain[]> => {
      const { data, error } = await supabase
        .from("ai_search_domains")
        .select("*")
        .order("mode", { ascending: true })
        .order("domain", { ascending: true });
      if (error) throw error;
      return (data ?? []) as AiSearchDomain[];
    },
  });

  const invalidate = () => queryClient.invalidateQueries({ queryKey: QUERY_KEY });

  const addDomain = useMutation({
    mutationFn: async (input: NewAiSearchDomain) => {
      const domain = normalizeDomainInput(input.domain, input.mode);
      if (!domain) throw new Error("Domain cannot be empty");
      const { error } = await supabase.from("ai_search_domains").insert({
        domain,
        mode: input.mode,
        label: input.label?.trim() || null,
        enabled: true,
      });
      if (error) throw error;
    },
    onSuccess: () => {
      invalidate();
      toast.success("Domain added");
    },
    onError: (error: Error) => toast.error(error.message || "Failed to add domain"),
  });

  const toggleEnabled = useMutation({
    mutationFn: async ({ id, enabled }: { id: string; enabled: boolean }) => {
      const { error } = await supabase
        .from("ai_search_domains")
        .update({ enabled })
        .eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => invalidate(),
    onError: () => toast.error("Failed to update domain"),
  });

  const deleteDomain = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase
        .from("ai_search_domains")
        .delete()
        .eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      invalidate();
      toast.success("Domain removed");
    },
    onError: () => toast.error("Failed to remove domain"),
  });

  const allowDomains = domains.filter((d) => d.mode === "allow");
  const blockDomains = domains.filter((d) => d.mode === "block");

  return {
    domains,
    allowDomains,
    blockDomains,
    isLoading,
    addDomain: addDomain.mutateAsync,
    addDomainPending: addDomain.isPending,
    toggleEnabled: toggleEnabled.mutateAsync,
    deleteDomain: deleteDomain.mutateAsync,
  };
};
