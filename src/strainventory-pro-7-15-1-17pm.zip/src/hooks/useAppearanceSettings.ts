import { useCallback, useEffect, useState } from "react";
import {
  AppearanceSettings,
  DEFAULT_APPEARANCE,
  applyAppearance,
  emitAppearanceChange,
  loadAppearance,
  onAppearanceChange,
  saveAppearance,
} from "@/lib/appearance";

export function useAppearanceSettings() {
  const [settings, setSettings] = useState<AppearanceSettings>(() => loadAppearance());

  useEffect(() => {
    return onAppearanceChange((next) => setSettings(next));
  }, []);

  const update = useCallback((patch: Partial<AppearanceSettings>) => {
    setSettings((prev) => {
      const next = { ...prev, ...patch };
      saveAppearance(next);
      applyAppearance(next);
      emitAppearanceChange(next);
      return next;
    });
  }, []);

  const reset = useCallback(() => {
    saveAppearance(DEFAULT_APPEARANCE);
    applyAppearance(DEFAULT_APPEARANCE);
    emitAppearanceChange(DEFAULT_APPEARANCE);
    setSettings(DEFAULT_APPEARANCE);
  }, []);

  return { settings, update, reset };
}
