/**
 * useBarcodeScanner — hybrid barcode scanner hook.
 *
 * Supports two modes that can be active simultaneously:
 *  - "camera" : uses @zxing/browser to read from the device camera (supports
 *               Code128, EAN-13, QR, PDF417, and many more).
 *  - "wedge"  : listens for rapid keystrokes that end with Enter, which is
 *               how USB / Bluetooth hardware barcode scanners present data.
 *
 * Usage:
 *   const { startCamera, stopCamera, startWedge, stopWedge,
 *           lastResult, isScanning, error } = useBarcodeScanner(onResult);
 */

import { useState, useRef, useCallback, useEffect } from "react";
import { BrowserMultiFormatReader, type IScannerControls } from "@zxing/browser";
import { DecodeHintType, BarcodeFormat } from "@zxing/library";
import {
  getScannerWedgeIntervalMs,
  getScannerWedgeMinLength,
} from "@/hooks/usePosLocalSettings";

export type ScanResult = {
  text: string;
  /** Raw ZXing format name, e.g. "PDF_417", "CODE_128", "QR_CODE" */
  format: string;
};

interface UseBarcodeScanner {
  /** Start camera scanning using the given video element ref. */
  startCamera: (videoEl: HTMLVideoElement, formats?: BarcodeFormat[]) => Promise<void>;
  stopCamera: () => void;
  /** Start listening for hardware wedge scanner input. */
  startWedge: () => void;
  stopWedge: () => void;
  lastResult: ScanResult | null;
  isCameraScanning: boolean;
  isWedgeActive: boolean;
  error: string | null;
  clearResult: () => void;
}

// Wedge timing thresholds are configurable from Settings → Preferences and
// read at handler invocation time so calibration changes apply without reload.


/** Minimum ms between two accepted scan results (debounce). */
const SCAN_DEBOUNCE_MS = 1200;

/** Maximum number of automatic camera restart attempts. */
const MAX_CAMERA_RETRIES = 2;

/** Delay (ms) before retrying camera acquisition after a failure. */
const CAMERA_RETRY_DELAY_MS = 500;

export function useBarcodeScanner(
  onResult: (result: ScanResult) => void,
): UseBarcodeScanner {
  const [lastResult, setLastResult] = useState<ScanResult | null>(null);
  const [isCameraScanning, setIsCameraScanning] = useState(false);
  const [isWedgeActive, setIsWedgeActive] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Keep latest onResult in a ref so startCamera/startWedge identities stay
  // stable across renders — otherwise the consumer's useEffect tears the
  // camera down and re-opens it on every render (visible as a flash/blink
  // and a scanner that almost never decodes).
  const onResultRef = useRef(onResult);
  useEffect(() => {
    onResultRef.current = onResult;
  }, [onResult]);

  const controlsRef = useRef<IScannerControls | null>(null);
  const readerRef = useRef<BrowserMultiFormatReader | null>(null);
  const videoElRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);

  /** Timestamp of the last accepted scan — used for debouncing. */
  const lastScanTimeRef = useRef<number>(0);
  /** The last accepted barcode text — used to suppress duplicate reads. */
  const lastScanTextRef = useRef<string>("");

  /** Track retry count to avoid infinite loops. */
  const retryCountRef = useRef<number>(0);
  /** Set when the hook is unmounting so we don't start new work. */
  const unmountedRef = useRef(false);
  /** Set by stopCamera() to cancel pending retry timeouts. */
  const stoppedRef = useRef(false);

  // Wedge state
  const wedgeBufferRef = useRef<string>("");
  const wedgeLastTimeRef = useRef<number>(0);
  const wedgeListenerRef = useRef<((e: KeyboardEvent) => void) | null>(null);

  // ── Helpers ──────────────────────────────────────────────────────────
  const releaseStream = useCallback(() => {
    try {
      controlsRef.current?.stop();
    } catch {
      // ignore — controls may already be stopped
    }
    controlsRef.current = null;
    readerRef.current = null;

    const stream = streamRef.current ?? (videoElRef.current?.srcObject as MediaStream | null);
    if (stream) {
      stream.getTracks().forEach((t) => {
        try { t.stop(); } catch { /* */ }
      });
    }
    if (videoElRef.current) {
      videoElRef.current.srcObject = null;
    }
    streamRef.current = null;
  }, []);

  // ──────────────────────────────────────────────────────────────────────
  // Camera scanning
  // ──────────────────────────────────────────────────────────────────────
  const startCamera = useCallback(
    async (videoEl: HTMLVideoElement, formats?: BarcodeFormat[]) => {
      if (unmountedRef.current) return;
      stoppedRef.current = false; // Clear stop signal for new session
      setError(null);

      // Ensure any previous session is fully torn down first
      releaseStream();

      try {
        const hints = new Map<DecodeHintType, unknown>();
        if (formats && formats.length > 0) {
          hints.set(DecodeHintType.POSSIBLE_FORMATS, formats);
        }
        hints.set(DecodeHintType.TRY_HARDER, true);

        // Throttle between failed decode attempts to reduce main-thread load
        const reader = new BrowserMultiFormatReader(hints, {
          delayBetweenScanAttempts: 150,
        });

        readerRef.current = reader;

        // Try progressive camera constraints with graceful fallback
        const constraintTiers: MediaStreamConstraints[] = [
          {
            video: {
              facingMode: { ideal: "environment" },
              width: { ideal: 1920 },
              height: { ideal: 1080 },
              frameRate: { ideal: 30, min: 15 },
            },
          },
          {
            video: {
              facingMode: { ideal: "environment" },
              width: { ideal: 1280 },
              height: { ideal: 720 },
            },
          },
          { video: { facingMode: "environment" } },
          { video: true },
        ];

        let stream: MediaStream | null = null;
        for (const constraints of constraintTiers) {
          if (unmountedRef.current) return;
          try {
            stream = await navigator.mediaDevices.getUserMedia(constraints);
            break;
          } catch {
            // try next tier
          }
        }

        if (!stream) {
          throw new Error("Camera unavailable — all resolution tiers failed.");
        }

        if (unmountedRef.current) {
          stream.getTracks().forEach((t) => t.stop());
          return;
        }

        streamRef.current = stream;
        videoElRef.current = videoEl;
        videoEl.srcObject = stream;

        // Request autofocus on the camera track when available
        const videoTrack = stream.getVideoTracks()[0];
        if (videoTrack) {
          try {
            const capabilities = videoTrack.getCapabilities?.();
            if (capabilities && "focusMode" in capabilities) {
              const modes = (capabilities as Record<string, unknown>).focusMode;
              if (Array.isArray(modes) && modes.includes("continuous")) {
                await videoTrack.applyConstraints({
                  advanced: [{ focusMode: "continuous" } as MediaTrackConstraintSet],
                });
              }
            }
          } catch {
            // Focus hints are best-effort; not all devices support them.
          }
        }

        // Wait for the video element to be ready before starting decode
        await new Promise<void>((resolve, reject) => {
          let settled = false;
          let safetyTimeoutId: ReturnType<typeof setTimeout> | undefined;

          const settle = (ok: boolean, err?: Error) => {
            if (settled) return;
            settled = true;
            if (safetyTimeoutId !== undefined) {
              clearTimeout(safetyTimeoutId);
            }
            videoEl.removeEventListener("loadeddata", onReady);
            if (ok) {
              resolve();
            } else {
              reject(err ?? new Error("Video playback failed."));
            }
          };

          const onReady = () => {
            settle(true);
          };

          if (videoEl.readyState >= 2) {
            settle(true);
          } else {
            videoEl.addEventListener("loadeddata", onReady);
            safetyTimeoutId = setTimeout(() => {
              settle(false, new Error("Video element did not become ready in time."));
            }, 5000);
          }

          videoEl.play().catch((e) => {
            settle(false, e instanceof Error ? e : new Error(String(e)));
          });
        });

        if (unmountedRef.current) {
          releaseStream();
          return;
        }

        const controls = await reader.decodeFromStream(
          stream,
          videoEl,
          (result, err) => {
            if (result) {
              const text = result.getText();
              const now = Date.now();

              // Debounce: ignore duplicate / rapid-fire reads
              if (
                text === lastScanTextRef.current &&
                now - lastScanTimeRef.current < SCAN_DEBOUNCE_MS
              ) {
                return;
              }

              // Ignore empty or very short (likely hallucinated) results
              if (!text || text.length < 2) {
                return;
              }

              lastScanTimeRef.current = now;
              lastScanTextRef.current = text;

              const sr: ScanResult = {
                text,
                format: result.getBarcodeFormat().toString(),
              };
              setLastResult(sr);
              onResultRef.current(sr);
            } else if (err && err.name !== "NotFoundException") {
              // Only log non-trivial errors; NotFoundException is expected for
              // frames that simply don't contain a barcode.
              console.warn("[BarcodeScanner] camera decode note:", err.message);
            }
          },
        );

        controlsRef.current = controls;
        retryCountRef.current = 0; // Reset retry counter on success
        setIsCameraScanning(true);

        // Monitor the stream for unexpected track-ended events and auto-retry
        const handleTrackEnded = () => {
          videoTrack?.removeEventListener("ended", handleTrackEnded);
          if (unmountedRef.current || stoppedRef.current) return;
          if (retryCountRef.current < MAX_CAMERA_RETRIES) {
            retryCountRef.current += 1;
            releaseStream();
            setIsCameraScanning(false);
            setTimeout(() => {
              if (!unmountedRef.current && !stoppedRef.current && videoElRef.current) {
                startCamera(videoElRef.current, formats);
              }
            }, CAMERA_RETRY_DELAY_MS);
          } else {
            releaseStream();
            setIsCameraScanning(false);
            setError("Camera stream ended unexpectedly. Please reopen the scanner.");
          }
        };
        videoTrack?.addEventListener("ended", handleTrackEnded);
      } catch (e) {
        releaseStream();
        // Auto-retry on transient failures (not permission errors)
        const isPermissionError =
          e instanceof Error && e.message.includes("Permission");
        if (!isPermissionError && retryCountRef.current < MAX_CAMERA_RETRIES) {
          retryCountRef.current += 1;
          setIsCameraScanning(false);
          setTimeout(() => {
            if (!unmountedRef.current && !stoppedRef.current) {
              startCamera(videoEl, formats);
            }
          }, CAMERA_RETRY_DELAY_MS);
          return;
        }

        const msg =
          e instanceof Error
            ? isPermissionError
              ? "Camera permission denied. Please allow camera access and try again."
              : e.message
            : "Camera unavailable";
        setError(msg);
        setIsCameraScanning(false);
      }
    },
    [releaseStream],
  );

  const stopCamera = useCallback(() => {
    stoppedRef.current = true;
    releaseStream();
    retryCountRef.current = 0;
    setIsCameraScanning(false);
  }, [releaseStream]);

  // ──────────────────────────────────────────────────────────────────────
  // Hardware wedge scanning
  // ──────────────────────────────────────────────────────────────────────
  const startWedge = useCallback(() => {
    if (wedgeListenerRef.current) return; // already active

    const handler = (e: KeyboardEvent) => {
      const now = Date.now();
      const wedgeIntervalMs = getScannerWedgeIntervalMs();
      const wedgeMinLength = getScannerWedgeMinLength();

      const target = e.target as HTMLElement | null;
      const isEditable =
        !!target &&
        (target.tagName === "INPUT" ||
          target.tagName === "TEXTAREA" ||
          target.isContentEditable);

      if (e.key === "Enter") {
        const buf = wedgeBufferRef.current;
        wedgeBufferRef.current = "";
        if (buf.length >= wedgeMinLength) {
          const isDuplicateWithinWindow =
            buf === lastScanTextRef.current &&
            now - lastScanTimeRef.current < SCAN_DEBOUNCE_MS;
          if (isDuplicateWithinWindow) {
            e.preventDefault();
            return;
          }
          lastScanTimeRef.current = now;
          lastScanTextRef.current = buf;

          const sr: ScanResult = { text: buf, format: "HARDWARE_WEDGE" };
          setLastResult(sr);
          onResultRef.current(sr);
          // Prevent the Enter from submitting a form
          e.preventDefault();
        }
        return;
      }


      // Measure time since last key to distinguish scanner input from typing
      const elapsed = now - wedgeLastTimeRef.current;
      wedgeLastTimeRef.current = now;

      // If there was a long pause and we already had buffered chars, discard
      // the old buffer and treat this key as the start of a new sequence.
      if (elapsed >= wedgeIntervalMs && wedgeBufferRef.current.length > 0) {
        wedgeBufferRef.current = "";
      }

      // Always consider the current key as part of the (new or existing) buffer,
      // so we don't drop the first character of a scan.
      if (e.key.length === 1 && wedgeBufferRef.current.length < 256) {
        wedgeBufferRef.current += e.key;
        // Suppress the keystroke from leaking into focused inputs once we've
        // detected a fast burst (likely a real hardware scan in progress).
        if (isEditable && wedgeBufferRef.current.length >= 2) {
          e.preventDefault();
        }
      }
    };


    document.addEventListener("keydown", handler, true);
    wedgeListenerRef.current = handler;
    setIsWedgeActive(true);
  }, []);

  const stopWedge = useCallback(() => {
    if (wedgeListenerRef.current) {
      document.removeEventListener("keydown", wedgeListenerRef.current, true);
      wedgeListenerRef.current = null;
    }
    wedgeBufferRef.current = "";
    setIsWedgeActive(false);
  }, []);

  // Clean up on unmount
  useEffect(() => {
    unmountedRef.current = false;
    return () => {
      unmountedRef.current = true;
      try { controlsRef.current?.stop(); } catch { /* */ }
      controlsRef.current = null;
      readerRef.current = null;
      const stream = streamRef.current ?? (videoElRef.current?.srcObject as MediaStream | null);
      if (stream) {
        stream.getTracks().forEach((t) => {
          try { t.stop(); } catch { /* */ }
        });
      }
      if (videoElRef.current) {
        videoElRef.current.srcObject = null;
      }
      streamRef.current = null;
      if (wedgeListenerRef.current) {
        document.removeEventListener("keydown", wedgeListenerRef.current, true);
      }
    };
  }, []);

  const clearResult = useCallback(() => {
    setLastResult(null);
    lastScanTextRef.current = "";
    lastScanTimeRef.current = 0;
  }, []);

  return {
    startCamera,
    stopCamera,
    startWedge,
    stopWedge,
    lastResult,
    isCameraScanning,
    isWedgeActive,
    error,
    clearResult,
  };
}
