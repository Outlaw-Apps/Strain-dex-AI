import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

const SETTINGS_ID = "00000000-0000-0000-0000-000000000001";

export type BusinessSettings = {
  id: string;
  geofence_enabled: boolean;
  geofence_lat: number | null;
  geofence_lng: number | null;
  geofence_radius_meters: number;
  business_name: string | null;
  logo_url: string | null;
  updated_at: string;
};

export const useBusinessSettings = () => {
  const queryClient = useQueryClient();

  const { data: settings, isLoading } = useQuery({
    queryKey: ["business-settings"],
    queryFn: async (): Promise<BusinessSettings> => {
      const { data, error } = await supabase
        .from("business_settings")
        .select("*")
        .eq("id", SETTINGS_ID)
        .single();

      if (error) throw error;
      return data;
    },
  });

  const updateSettings = useMutation({
    mutationFn: async (updates: Partial<BusinessSettings>) => {
      const { error } = await supabase
        .from("business_settings")
        .update(updates)
        .eq("id", SETTINGS_ID);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["business-settings"] });
      toast.success("Settings saved successfully");
    },
    onError: () => toast.error("Failed to save settings"),
  });

  return { settings, isLoading, updateSettings: updateSettings.mutateAsync };
};