import { useMutation } from "@tanstack/react-query";
import type { CatalogImageCandidate, CatalogImageSearchInput } from "@/lib/catalogImages";
import { rankCatalogImages } from "@/lib/catalogImages";
import { EDGE_FUNCTIONS, ENV } from "@/lib/constants";
import { supabase } from "@/integrations/supabase/client";

export const useCatalogImageSearch = () =>
  useMutation({
    mutationFn: async (input: CatalogImageSearchInput) => {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session?.access_token) {
        throw new Error("Sign in required to search for product images.");
      }
      let response: Response;
      try {
        response = await fetch(EDGE_FUNCTIONS.FETCH_PRODUCT_IMAGES, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            apikey: ENV.SUPABASE_PUBLISHABLE_KEY,
            Authorization: `Bearer ${session.access_token}`,
          },
          body: JSON.stringify(input),
        });
      } catch (error) {
        const message = error instanceof Error ? error.message : String(error);
        throw new Error(
          `Image search service could not be reached. Confirm the fetch-product-images function is deployed and your Supabase URL is configured. (${message})`,
        );
      }

      const payload: unknown = await response.json().catch(() => ({}));
      if (!response.ok) {
        const payloadObj = payload as Record<string, unknown>;
        const message =
          typeof payloadObj?.error === "string"
            ? payloadObj.error
            : `Image search failed with status ${response.status}`;
        throw new Error(message);
      }

      const payloadObj = payload as Record<string, unknown>;
      const images = (payloadObj?.images ?? []) as CatalogImageCandidate[];

      // Log search warnings from the edge function (e.g. partial failures)
      if (typeof payloadObj?.warning === "string") {
        console.warn("[ImageSearch] server warning:", payloadObj.warning);
      }

      return rankCatalogImages(images, input);
    },
  });
