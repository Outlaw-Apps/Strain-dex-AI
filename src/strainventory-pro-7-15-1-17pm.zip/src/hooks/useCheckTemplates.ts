import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import type { CheckTemplate } from "@/lib/payroll/checkTemplates.types";

/* eslint-disable @typescript-eslint/no-explicit-any */
const tbl = () => (supabase as any).from("check_templates");

const KEY = ["check-templates"] as const;

export function useCheckTemplates() {
  return useQuery({
    queryKey: KEY,
    queryFn: async () => {
      const { data, error } = await tbl()
        .select("*")
        .order("is_default", { ascending: false })
        .order("created_at", { ascending: false });
      if (error) throw error;
      return (data ?? []) as CheckTemplate[];
    },
    staleTime: 30_000,
  });
}

export function useCreateCheckTemplate() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (input: Partial<CheckTemplate>) => {
      const { data: { user } } = await supabase.auth.getUser();
      const payload = { ...input, created_by: user?.id ?? null };
      const { data, error } = await tbl().insert(payload).select().single();
      if (error) throw error;
      return data as CheckTemplate;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: KEY }),
  });
}

export function useUpdateCheckTemplate() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async ({ id, ...rest }: Partial<CheckTemplate> & { id: string }) => {
      const { data, error } = await tbl().update(rest).eq("id", id).select().single();
      if (error) throw error;
      return data as CheckTemplate;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: KEY }),
  });
}

export function useDeleteCheckTemplate() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (id: string) => {
      const { error } = await tbl().delete().eq("id", id);
      if (error) throw error;
      return id;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: KEY }),
  });
}

export function useIncrementCheckNumber() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async ({ id, by }: { id: string; by: number }) => {
      const { data: cur, error: readErr } = await tbl()
        .select("next_check_number")
        .eq("id", id)
        .single();
      if (readErr) throw readErr;
      const next = ((cur as { next_check_number: number }).next_check_number ?? 1001) + by;
      const { error } = await tbl().update({ next_check_number: next }).eq("id", id);
      if (error) throw error;
      return next;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: KEY }),
  });
}
