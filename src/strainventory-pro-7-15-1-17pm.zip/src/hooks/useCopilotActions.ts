import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/context/AuthContext";
import type { CopilotActionRecord } from "@/lib/copilot/types";

export function useCopilotActions(sessionId?: string | null, limit = 30) {
  const { user } = useAuth();
  const [actions, setActions] = useState<CopilotActionRecord[]>([]);

  useEffect(() => {
    if (!user) return;
    let cancelled = false;

    async function load() {
      let q = supabase
        .from("copilot_actions")
        .select("*")
        .order("created_at", { ascending: false })
        .limit(limit);
      if (sessionId) q = q.eq("session_id", sessionId);
      else q = q.eq("user_id", user!.id);
      const { data } = await q;
      if (!cancelled && data) setActions(data as CopilotActionRecord[]);
    }
    load();

    const channel = supabase
      .channel(`copilot_actions_${sessionId ?? user.id}`)
      .on(
        "postgres_changes",
        {
          event: "*",
          schema: "public",
          table: "copilot_actions",
          filter: sessionId ? `session_id=eq.${sessionId}` : `user_id=eq.${user.id}`,
        },
        () => load(),
      )
      .subscribe();
    return () => {
      cancelled = true;
      supabase.removeChannel(channel);
    };
  }, [user, sessionId, limit]);

  return actions;
}
