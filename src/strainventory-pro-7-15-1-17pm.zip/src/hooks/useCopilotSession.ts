import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/context/AuthContext";
import type { CopilotSessionRecord } from "@/lib/copilot/types";

export function useCopilotSession(threadId?: string | null) {
  const { user } = useAuth();
  const [session, setSession] = useState<CopilotSessionRecord | null>(null);

  useEffect(() => {
    let cancelled = false;
    async function ensure() {
      if (!user) return;
      // Reuse an active session on this thread, else create one.
      const { data: existing } = await supabase
        .from("copilot_sessions")
        .select("*")
        .eq("user_id", user.id)
        .eq("status", "active")
        .maybeSingle();
      if (cancelled) return;
      if (existing) {
        setSession(existing as CopilotSessionRecord);
        return;
      }
      const { data: created } = await supabase
        .from("copilot_sessions")
        .insert({
          user_id: user.id,
          thread_id: threadId ?? null,
          context: {},
        })
        .select()
        .single();
      if (!cancelled && created) setSession(created as CopilotSessionRecord);
    }
    ensure();
    return () => {
      cancelled = true;
    };
  }, [user, threadId]);

  return session;
}
