import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export interface Customer {
  id: string;
  customer_number: string;
  name: string;
  email: string;
  phone: string;
  notes: string;
  license_number: string | null;
  date_of_birth: string | null;
  last_age_verified_at: string | null;
  is_employee?: boolean;
  is_senior?: boolean;
  is_military?: boolean;
  is_police?: boolean;
  is_fire?: boolean;
  service_discount_note?: string | null;
  created_at: string;
  updated_at: string;
}

export const useCustomers = () =>
  useQuery({
    queryKey: ["customers"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("customers")
        .select("*")
        .order("created_at", { ascending: false });
      if (error) throw error;
      return (data ?? []) as Customer[];
    },
    staleTime: 60_000,
  });

export const useCustomerSearch = (query: string) =>
  useQuery({
    queryKey: ["customers", "search", query],
    queryFn: async () => {
      if (!query || query.length < 2) return [];
      const { data, error } = await supabase
        .from("customers")
        .select("*")
        .or(`customer_number.ilike.%${query}%,name.ilike.%${query}%,phone.ilike.%${query}%,license_number.ilike.%${query}%`)
        .limit(10);
      if (error) throw error;
      return (data ?? []) as Customer[];
    },
    enabled: query.length >= 2,
    staleTime: 10_000,
  });

export const useCreateCustomer = () => {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (c: {
      name: string;
      phone: string;
      email?: string;
      license_number?: string;
      date_of_birth?: string;
      last_age_verified_at?: string;
      is_employee?: boolean;
      is_senior?: boolean;
      is_military?: boolean;
      is_police?: boolean;
      is_fire?: boolean;
      service_discount_note?: string;
    }) => {
      const num = `C-${Date.now().toString(36).toUpperCase()}`;
      const { data, error } = await supabase
        .from("customers")
        .insert({
          customer_number: num,
          name: c.name,
          phone: c.phone,
          email: c.email ?? "",
          license_number: c.license_number ?? null,
          date_of_birth: c.date_of_birth ?? null,
          last_age_verified_at: c.last_age_verified_at ?? null,
          is_employee: c.is_employee ?? false,
          is_senior: c.is_senior ?? false,
          is_military: c.is_military ?? false,
          is_police: c.is_police ?? false,
          is_fire: c.is_fire ?? false,
          service_discount_note: c.service_discount_note ?? null,
        })
        .select()
        .single();
      if (error) throw error;
      return data as Customer;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["customers"] }),
  });
};

export const useUpdateCustomerDiscountProfile = () => {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (input: {
      id: string;
      is_employee: boolean;
      is_senior: boolean;
      is_military: boolean;
      is_police: boolean;
      is_fire: boolean;
      service_discount_note: string | null;
    }) => {
      const { id, ...flags } = input;
      const { data, error } = await supabase
        .from("customers")
        .update({
          ...flags,
          updated_at: new Date().toISOString(),
        })
        .eq("id", id)
        .select()
        .single();
      if (error) throw error;
      return data as Customer;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["customers"] });
    },
  });
};

export const useCustomerByLicense = (licenseNumber: string | null) =>
  useQuery({
    queryKey: ["customers", "license", licenseNumber],
    queryFn: async () => {
      if (!licenseNumber) return null;
      const { data, error } = await supabase
        .from("customers")
        .select("*")
        .eq("license_number", licenseNumber)
        .maybeSingle();
      if (error) throw error;
      return data as Customer | null;
    },
    enabled: !!licenseNumber,
    staleTime: 30_000,
  });
