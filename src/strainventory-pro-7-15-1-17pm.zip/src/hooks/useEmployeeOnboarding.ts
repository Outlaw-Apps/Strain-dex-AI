import { useCallback, useRef, useState } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/context/AuthContext";
import { useManagerOverride } from "@/hooks/useManagerOverride";
import {
  calculateAge,
  initialOnboardingFormData,
  ONBOARDING_MIME_TO_EXT,
  ROLE_TO_APP_ROLE,
  type FieldError,
  type OnboardingFormData,
} from "@/components/onboarding/types";

const TOTAL_STEPS = 3;

export function useEmployeeOnboarding() {
  const { user } = useAuth();
  const managerOverride = useManagerOverride();
  const [currentStep, setCurrentStep] = useState(0);
  const [formData, setFormData] = useState<OnboardingFormData>(initialOnboardingFormData);
  const [errors, setErrors] = useState<FieldError[]>([]);
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [createdEmployeeId, setCreatedEmployeeId] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const updateField = useCallback(
    <K extends keyof OnboardingFormData>(field: K, value: OnboardingFormData[K]) => {
      setFormData((prev) => ({ ...prev, [field]: value }));
      setErrors((prev) => prev.filter((e) => e.field !== field));
    },
    [],
  );

  const getError = useCallback(
    (field: string) => errors.find((e) => e.field === field)?.message,
    [errors],
  );

  const validateStep = useCallback(
    (step: number): boolean => {
      const newErrors: FieldError[] = [];

      if (step === 0) {
        // Compliance check — never skippable.
        if (formData.dateOfBirth) {
          const age = calculateAge(formData.dateOfBirth);
          if (age < 21) {
            newErrors.push({ field: "dateOfBirth", message: "Employee must be 21 or older (California cannabis law)" });
            toast.error("Employee must be at least 21 years old to work at a California dispensary.");
          }
        } else {
          newErrors.push({ field: "dateOfBirth", message: "Date of birth is required" });
        }

        if (!managerOverride.overrideActive) {
          if (!formData.fullName.trim()) newErrors.push({ field: "fullName", message: "Full name is required" });
          if (!formData.phone.trim()) newErrors.push({ field: "phone", message: "Phone number is required" });
          if (!formData.email.trim()) {
            newErrors.push({ field: "email", message: "Email is required" });
          } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
            newErrors.push({ field: "email", message: "Enter a valid email address" });
          }
          if (!formData.emergencyContact.trim()) newErrors.push({ field: "emergencyContact", message: "Emergency contact is required" });
        }
      }

      if (step === 1 && !managerOverride.overrideActive) {
        if (!formData.role) newErrors.push({ field: "role", message: "Role selection is required" });
        if (!formData.badgeNumber.trim()) newErrors.push({ field: "badgeNumber", message: "Badge number is required" });
        if (!formData.liveScanStatus) newErrors.push({ field: "liveScanStatus", message: "Live Scan status is required" });
      }

      if (step === 2 && !managerOverride.overrideActive) {
        if (!formData.governmentIdFile) newErrors.push({ field: "governmentIdFile", message: "Government ID upload is required" });
        if (!formData.sopAcknowledged) newErrors.push({ field: "sopAcknowledged", message: "SOP & Handbook acknowledgment is required" });
      }

      setErrors(newErrors);
      if (newErrors.length > 0 && step !== 0) {
        toast.error("Please complete all required fields before continuing.");
      }
      return newErrors.length === 0;
    },
    [formData, managerOverride.overrideActive],
  );

  const handleNext = useCallback(() => {
    if (validateStep(currentStep)) {
      setCurrentStep((prev) => Math.min(prev + 1, TOTAL_STEPS - 1));
    }
  }, [currentStep, validateStep]);

  const handleBack = useCallback(() => {
    setErrors([]);
    setCurrentStep((prev) => Math.max(prev - 1, 0));
  }, []);

  const handleFileChange = useCallback(
    (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      if (!file) return;

      const maxSize = 10 * 1024 * 1024;
      if (file.size > maxSize) {
        toast.error("File size must be under 10 MB.");
        e.target.value = "";
        updateField("governmentIdFile", null);
        return;
      }
      const validTypes = ["image/jpeg", "image/png", "image/webp", "application/pdf"];
      if (!validTypes.includes(file.type)) {
        toast.error("Accepted formats: JPEG, PNG, WebP, or PDF.");
        e.target.value = "";
        updateField("governmentIdFile", null);
        return;
      }
      updateField("governmentIdFile", file);
    },
    [updateField],
  );

  const resetForm = useCallback(() => {
    setFormData(initialOnboardingFormData);
    setCurrentStep(0);
    setSubmitted(false);
    setCreatedEmployeeId(null);
    setErrors([]);
  }, []);

  const handleSubmit = useCallback(async () => {
    if (!validateStep(2)) return;
    if (!user) {
      toast.error("You must be signed in to submit.");
      return;
    }

    setSubmitting(true);

    try {
      let governmentIdUrl: string | null = null;

      if (formData.governmentIdFile) {
        const fileNameParts = formData.governmentIdFile.name.split(".");
        const nameExt =
          fileNameParts.length > 1 ? fileNameParts[fileNameParts.length - 1].toLowerCase() : "";
        const ext = nameExt || ONBOARDING_MIME_TO_EXT[formData.governmentIdFile.type] || "bin";
        const filePath = `${user.id}/${Date.now()}-gov-id.${ext}`;
        const { error: uploadError } = await supabase.storage
          .from("employee-documents")
          .upload(filePath, formData.governmentIdFile, {
            contentType: formData.governmentIdFile.type,
          });

        if (uploadError) {
          throw new Error(`Document upload failed: ${uploadError.message}`);
        }

        governmentIdUrl = filePath;
      }

      const assignedRole = ROLE_TO_APP_ROLE[formData.role] || "staff";

      const { data: inserted, error: insertError } = await supabase
        .from("employees")
        .insert({
          full_name: formData.fullName.trim(),
          date_of_birth: formData.dateOfBirth,
          phone: formData.phone.trim(),
          email: formData.email.trim().toLowerCase(),
          emergency_contact: formData.emergencyContact.trim(),
          role: formData.role,
          badge_number: formData.badgeNumber.trim(),
          live_scan_status: formData.liveScanStatus,
          mmic_number: formData.mmicNumber.trim() || null,
          government_id_url: governmentIdUrl,
          sop_handbook_acknowledged: formData.sopAcknowledged,
          status: "pending_review",
          assigned_role: assignedRole,
          created_by: user.id,
        })
        .select("id")
        .single();

      if (insertError || !inserted) {
        throw new Error(insertError?.message ?? "Insert failed");
      }

      // Auto-generate the default onboarding checklist for this employee.
      const { error: rpcError } = await supabase.rpc(
        "generate_default_onboarding_checklist",
        { _employee_id: inserted.id, _role: assignedRole },
      );
      if (rpcError) {
        // Non-fatal — record still created; surface a soft warning.
        console.warn("checklist generation failed", rpcError);
      }

      setCreatedEmployeeId(inserted.id);
      setSubmitted(true);
      toast.success("Employee onboarding record submitted for review!");
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : "Submission failed.";
      toast.error(msg);
    } finally {
      setSubmitting(false);
    }
  }, [formData, user, validateStep]);

  return {
    currentStep,
    formData,
    submitting,
    submitted,
    createdEmployeeId,
    fileInputRef,
    managerOverride,
    totalSteps: TOTAL_STEPS,
    updateField,
    getError,
    handleNext,
    handleBack,
    handleFileChange,
    handleSubmit,
    resetForm,
  };
}
