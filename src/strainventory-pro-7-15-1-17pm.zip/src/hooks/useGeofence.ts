import { useBusinessSettings, type BusinessSettings } from "./useBusinessSettings";

const EARTH_RADIUS_M = 6371000;

// Cap on how much GPS accuracy slop we will forgive. Desktop devices using
// WiFi-based geolocation routinely report 200-500m of error; this buffer lets
// them clock in without making the geofence meaningless on mobile (which
// usually reports <50m and so gets little to no buffer).
const MAX_ACCURACY_BUFFER_M = 400;

// When the browser/Electron GPS path fails (desktop Chromium without a Google
// API key returns POSITION_UNAVAILABLE), we fall back to IP-based geolocation.
// IP lookups are city-level (2-20 km accuracy), so we treat them with a much
// larger bounded buffer. Admins who need tight geofences on mobile are
// unaffected; the OS-provided GPS path still runs first.
const IP_FALLBACK_MAX_BUFFER_M = 20000;
const IP_GEOLOCATION_ENDPOINT = "https://ipapi.co/json/";
const IP_GEOLOCATION_TIMEOUT_MS = 6000;

const haversineDistance = (
  lat1: number,
  lon1: number,
  lat2: number,
  lon2: number,
): number => {
  const toRad = (x: number) => (x * Math.PI) / 180;
  const dLat = toRad(lat2 - lat1);
  const dLon = toRad(lon2 - lon1);
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(toRad(lat1)) *
      Math.cos(toRad(lat2)) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return EARTH_RADIUS_M * c;
};

export type GeofenceCheckKind =
  | "loading"
  | "disabled"
  | "inside"
  | "outside"
  | "permission_denied"
  | "unavailable"
  | "timeout"
  | "unsupported"
  | "misconfigured";

export type GeofenceFixSource = "gps" | "ip" | "none";

export interface GeofenceCheckResult {
  kind: GeofenceCheckKind;
  inside: boolean;
  distanceMeters: number;
  accuracyMeters: number;
  effectiveRadiusMeters: number;
  settings: BusinessSettings | null;
  message?: string;
  /**
   * Where the fix came from. "gps" means a browser/device geolocation reading,
   * "ip" means the city-level IP fallback, and "none" means no fix was obtained
   * (e.g. permission denied or settings still loading).
   */
  fixSource?: GeofenceFixSource;
}

export const computeEffectiveRadius = (
  configuredRadius: number,
  accuracyMeters: number,
  source: GeofenceFixSource = "gps",
): number => {
  const cap =
    source === "ip" ? IP_FALLBACK_MAX_BUFFER_M : MAX_ACCURACY_BUFFER_M;
  const buffer = Math.min(Math.max(accuracyMeters, 0), cap);
  return configuredRadius + buffer;
};

const getCurrentPosition = () =>
  new Promise<GeolocationPosition>((resolve, reject) => {
    navigator.geolocation.getCurrentPosition(resolve, reject, {
      enableHighAccuracy: true,
      timeout: 10000,
      maximumAge: 60000,
    });
  });

const mapPositionError = (error: GeolocationPositionError): GeofenceCheckKind => {
  if (error.code === error.PERMISSION_DENIED) return "permission_denied";
  if (error.code === error.POSITION_UNAVAILABLE) return "unavailable";
  if (error.code === error.TIMEOUT) return "timeout";
  return "unavailable";
};

interface IpFix {
  latitude: number;
  longitude: number;
  /** IP fixes don't report true accuracy; treat as ~10km as a rough default. */
  accuracy: number;
}

/**
 * IP-based fallback used when the OS/browser geolocation path returns nothing
 * usable. Accuracy is city-level, so `computeEffectiveRadius` widens the
 * buffer automatically when this source is in play.
 *
 * Exported for unit testing.
 */
export const fetchIpGeolocation = async (
  fetchImpl: typeof fetch = fetch,
): Promise<IpFix | null> => {
  const controller =
    typeof AbortController !== "undefined" ? new AbortController() : null;
  const timer = controller
    ? setTimeout(() => controller.abort(), IP_GEOLOCATION_TIMEOUT_MS)
    : null;
  try {
    const response = await fetchImpl(IP_GEOLOCATION_ENDPOINT, {
      signal: controller?.signal,
      headers: { Accept: "application/json" },
    });
    if (!response.ok) return null;
    const body = (await response.json().catch(() => null)) as
      | { latitude?: number; longitude?: number }
      | null;
    if (
      !body ||
      typeof body.latitude !== "number" ||
      typeof body.longitude !== "number" ||
      Number.isNaN(body.latitude) ||
      Number.isNaN(body.longitude)
    ) {
      return null;
    }
    return {
      latitude: body.latitude,
      longitude: body.longitude,
      accuracy: 10000,
    };
  } catch {
    return null;
  } finally {
    if (timer) clearTimeout(timer);
  }
};

export const useGeofence = () => {
  const { settings, isLoading } = useBusinessSettings();

  const isInsideFence = async (): Promise<GeofenceCheckResult> => {
    if (isLoading || !settings) {
      return {
        kind: "loading",
        inside: false,
        distanceMeters: 0,
        accuracyMeters: 0,
        effectiveRadiusMeters: 0,
        settings: null,
        message: "Business settings are still loading.",
      };
    }

    if (!settings.geofence_enabled) {
      return {
        kind: "disabled",
        inside: true,
        distanceMeters: 0,
        accuracyMeters: 0,
        effectiveRadiusMeters: 0,
        settings: settings,
      };
    }

    if (settings.geofence_lat == null || settings.geofence_lng == null) {
      return {
        kind: "misconfigured",
        inside: false,
        distanceMeters: 0,
        accuracyMeters: 0,
        effectiveRadiusMeters: settings.geofence_radius_meters,
        settings,
        message: "Geofence is enabled but no dispensary coordinates are set.",
      };
    }

    const hasBrowserGeolocation =
      typeof navigator !== "undefined" && "geolocation" in navigator;

    let latitude: number | null = null;
    let longitude: number | null = null;
    let accuracy = 0;
    let fixSource: GeofenceFixSource = "none";
    let gpsErrorKind: GeofenceCheckKind | null = null;
    let gpsErrorMessage: string | undefined;

    if (hasBrowserGeolocation) {
      try {
        const position = await getCurrentPosition();
        latitude = position.coords.latitude;
        longitude = position.coords.longitude;
        accuracy = position.coords.accuracy ?? 0;
        fixSource = "gps";
      } catch (error) {
        const positionError = error as GeolocationPositionError;
        gpsErrorKind = mapPositionError(positionError);
        gpsErrorMessage = positionError?.message;
      }
    } else {
      gpsErrorKind = "unsupported";
    }

    // Fall back to IP-based geolocation when GPS is unavailable but NOT when
    // the user explicitly denied permission — denying permission is a signal
    // they do not want to be located, and silently succeeding would be
    // surprising and user-hostile.
    if (latitude == null || longitude == null) {
      if (gpsErrorKind === "permission_denied") {
        return {
          kind: "permission_denied",
          inside: false,
          distanceMeters: 0,
          accuracyMeters: 0,
          effectiveRadiusMeters: settings.geofence_radius_meters,
          settings,
          message: gpsErrorMessage,
          fixSource: "none",
        };
      }

      const ipFix = await fetchIpGeolocation();
      if (ipFix) {
        latitude = ipFix.latitude;
        longitude = ipFix.longitude;
        accuracy = ipFix.accuracy;
        fixSource = "ip";
      }
    }

    if (latitude == null || longitude == null) {
      const kind = gpsErrorKind ?? "unavailable";
      return {
        kind,
        inside: false,
        distanceMeters: 0,
        accuracyMeters: 0,
        effectiveRadiusMeters: settings.geofence_radius_meters,
        settings,
        message:
          gpsErrorMessage ??
          "Could not determine your location from GPS or IP lookup.",
        fixSource: "none",
      };
    }

    const distance = haversineDistance(
      settings.geofence_lat,
      settings.geofence_lng,
      latitude,
      longitude,
    );
    const effectiveRadius = computeEffectiveRadius(
      settings.geofence_radius_meters,
      accuracy,
      fixSource,
    );
    const inside = distance <= effectiveRadius;

    return {
      kind: inside ? "inside" : "outside",
      inside,
      distanceMeters: Math.round(distance),
      accuracyMeters: Math.round(accuracy),
      effectiveRadiusMeters: Math.round(effectiveRadius),
      settings,
      fixSource,
    };
  };

  return {
    isInsideFence,
    isLoading,
    geofenceEnabled: settings?.geofence_enabled ?? false,
  };
};
