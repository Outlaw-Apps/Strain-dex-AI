/* eslint-disable @typescript-eslint/no-explicit-any -- label_templates table is not yet in generated Supabase types */
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/context/AuthContext";

export interface LabelTemplateConfig {
  mode: "barcode" | "qr";
  size: "small" | "medium" | "large" | "shelf" | "custom";
  customWidthIn?: number;
  customHeightIn?: number;
  copies: number;
  showPrice: boolean;
  showSubtitle: boolean;
  showBrand: boolean;
  showStrain: boolean;
  showThc?: boolean;
  showCbd?: boolean;
  showSku?: boolean;
  showStrainType?: boolean;
  showDescription?: boolean;
  showTerpenes?: boolean;
  autoFit?: boolean;
  titleFontSize: number;
  subtitleFontSize: number;
  priceFontSize: number;
  fontWeight: "normal" | "bold";
  fontFamily: "sans" | "serif" | "mono";
  barcodeFormat: string;
  qrErrorLevel: "L" | "M" | "Q" | "H";
}

export interface LabelTemplate {
  id: string;
  user_id: string;
  name: string;
  description: string | null;
  config: LabelTemplateConfig;
  is_shared: boolean;
  created_at: string;
  updated_at: string;
}

const KEY = ["label_templates"];

export function useLabelTemplates() {
  return useQuery({
    queryKey: KEY,
    queryFn: async () => {
      const { data, error } = await (supabase as any)
        .from("label_templates")
        .select("*")
        .order("updated_at", { ascending: false });
      if (error) throw error;
      return (data ?? []) as LabelTemplate[];
    },
  });
}

export function useSaveLabelTemplate() {
  const qc = useQueryClient();
  const { user } = useAuth();
  return useMutation({
    mutationFn: async (input: {
      id?: string;
      name: string;
      description?: string;
      config: LabelTemplateConfig;
      is_shared?: boolean;
    }) => {
      if (!user) throw new Error("Not signed in");
      if (input.id) {
        const { data, error } = await (supabase as any)
          .from("label_templates")
          .update({
            name: input.name,
            description: input.description ?? null,
            config: input.config,
            is_shared: input.is_shared ?? true,
          })
          .eq("id", input.id)
          .select()
          .single();
        if (error) throw error;
        return data as LabelTemplate;
      }
      const { data, error } = await (supabase as any)
        .from("label_templates")
        .insert({
          user_id: user.id,
          name: input.name,
          description: input.description ?? null,
          config: input.config,
          is_shared: input.is_shared ?? true,
        })
        .select()
        .single();
      if (error) throw error;
      return data as LabelTemplate;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: KEY }),
  });
}

export function useDeleteLabelTemplate() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (id: string) => {
      const { error } = await (supabase as any)
        .from("label_templates")
        .delete()
        .eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: KEY }),
  });
}
