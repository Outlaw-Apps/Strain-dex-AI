/**
 * useManagerOverride — lets admin users bypass mandatory form-field validation.
 *
 * When `overrideActive` is true the consumer should treat all mandatory (`*`)
 * fields as optional so the form can be submitted with incomplete data.
 *
 * Usage:
 *   const { overrideActive, toggleOverride, canOverride } = useManagerOverride();
 *
 *   // In validation:
 *   if (!overrideActive && !form.name.trim()) { ... }
 */

import { useState, useCallback, useMemo } from "react";
import { useUserRoles } from "@/hooks/useUserRoles";
import { toast } from "sonner";

export interface UseManagerOverride {
  /** Whether the current user has the admin role required to override. */
  canOverride: boolean;
  /** Whether override mode is currently engaged. */
  overrideActive: boolean;
  /** Toggle override on/off. Shows a toast when toggled. */
  toggleOverride: () => void;
  /** Activate override mode (idempotent). */
  activateOverride: () => void;
  /** Deactivate override mode (idempotent). */
  deactivateOverride: () => void;
}

export const useManagerOverride = (): UseManagerOverride => {
  const { isAdmin } = useUserRoles();
  const [overrideActive, setOverrideActive] = useState(false);

  const toggleOverride = useCallback(() => {
    if (!isAdmin) {
      toast.error("Manager override requires admin privileges.");
      return;
    }
    setOverrideActive((prev) => {
      const next = !prev;
      toast[next ? "warning" : "info"](
        next
          ? "Manager Override ON — required fields may be skipped."
          : "Manager Override OFF — standard validation restored.",
      );
      return next;
    });
  }, [isAdmin]);

  const activateOverride = useCallback(() => {
    if (!isAdmin) return;
    if (!overrideActive) {
      setOverrideActive(true);
      toast.warning("Manager Override ON — required fields may be skipped.");
    }
  }, [isAdmin, overrideActive]);

  const deactivateOverride = useCallback(() => {
    if (overrideActive) {
      setOverrideActive(false);
      toast.info("Manager Override OFF — standard validation restored.");
    }
  }, [overrideActive]);

  return useMemo(
    () => ({ canOverride: isAdmin, overrideActive, toggleOverride, activateOverride, deactivateOverride }),
    [isAdmin, overrideActive, toggleOverride, activateOverride, deactivateOverride],
  );
};
