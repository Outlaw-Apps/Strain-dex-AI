import { useCallback, useEffect, useMemo } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import type { RealtimeChannel } from "@supabase/supabase-js";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/context/AuthContext";

const db = supabase;

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export interface ConversationRow {
  id: string;
  is_group: boolean;
  title: string | null;
  created_by: string | null;
  created_at: string;
  last_message_at: string;
  last_message_preview: string | null;
  last_sender_id: string | null;
}

export interface ConversationMemberRow {
  conversation_id: string;
  user_id: string;
  joined_at: string;
  last_read_at: string;
}

export interface ConversationMessageRow {
  id: string;
  conversation_id: string;
  sender_id: string;
  body: string | null;
  image_url: string | null;
  attachment_path: string | null;
  created_at: string;
}

const MESSAGE_COLUMNS = "id, conversation_id, sender_id, body, image_url, attachment_path, created_at";
const ATTACHMENT_BUCKET = "message-attachments";
const MAX_ATTACHMENT_BYTES = 8 * 1024 * 1024; // 8 MB
const ALLOWED_IMAGE_TYPES = new Set(["image/jpeg", "image/png", "image/webp", "image/gif", "image/heic"]);

const errorMessage = (error: unknown) => {
  if (error instanceof Error) return error.message;
  if (error && typeof error === "object" && "message" in error) {
    const maybeMessage = (error as { message?: unknown }).message;
    if (typeof maybeMessage === "string") return maybeMessage;
  }
  return String(error);
};

const isMissingAttachmentBucketError = (error: unknown) => {
  const message = errorMessage(error).toLowerCase();
  return message.includes("bucket not found") || message.includes("bucket_not_found");
};

const ensureMessageAttachmentBucket = async () => {
  const { error } = await db.functions.invoke("cleanup-message-attachments", {
    body: { mode: "ensure" },
  });
  if (error) throw error;
};

export interface ConversationSummary {
  conversation: ConversationRow;
  otherUserId: string | null;
  lastReadAt: string | null;
  unreadCount: number;
}

// ---------------------------------------------------------------------------
// Query keys
// ---------------------------------------------------------------------------

const conversationsKey = (userId: string | undefined) =>
  ["conversations", userId] as const;

const messagesKey = (conversationId: string) =>
  ["conversation-messages", conversationId] as const;

// ---------------------------------------------------------------------------
// useConversations — list of the current user's DMs with unread counts
// ---------------------------------------------------------------------------

export const useConversations = () => {
  const { user } = useAuth();
  const userId = user?.id;
  const queryClient = useQueryClient();

  const query = useQuery({
    queryKey: conversationsKey(userId),
    enabled: !!userId,
    queryFn: async (): Promise<ConversationSummary[]> => {
      if (!userId) return [];

      // RLS scopes this to conversations the current user is a member of.
      const { data: memberships, error: memberError } = await db
        .from("conversation_members")
        .select("conversation_id, user_id, last_read_at");
      if (memberError) throw memberError;

      if (!memberships || memberships.length === 0) return [];

      const conversationIds = Array.from(
        new Set(memberships.map((m) => m.conversation_id)),
      );

      const { data: conversations, error: convError } = await db
        .from("conversations")
        .select("*")
        .in("id", conversationIds);
      if (convError) throw convError;

      // Build per-conversation-member index so we can compute "other user"
      // (for DMs) and keep track of our own last_read_at in one pass.
      const membersByConvo = new Map<string, ConversationMemberRow[]>();
      for (const m of memberships as ConversationMemberRow[]) {
        const list = membersByConvo.get(m.conversation_id) ?? [];
        list.push(m);
        membersByConvo.set(m.conversation_id, list);
      }

      // One RPC call returns unread counts for every conversation the user
      // is a member of. Replaces the N+1 per-conversation COUNT(*) loop.
      // Unread counts are non-essential — if the RPC fails we still want to
      // show the conversation list, just without badges.
      const { data: unreadRows, error: unreadError } = await db.rpc(
        "get_unread_conversation_counts",
      );
      const unreadByConvo = new Map<string, number>();
      if (unreadError) {
        console.warn(
          "get_unread_conversation_counts failed; defaulting unread counts to 0:",
          unreadError.message,
        );
      } else {
        for (const row of (unreadRows ?? []) as {
          conversation_id: string;
          unread_count: number;
        }[]) {
          unreadByConvo.set(row.conversation_id, Number(row.unread_count) || 0);
        }
      }

      const summaries: ConversationSummary[] = [];
      for (const conv of (conversations ?? []) as ConversationRow[]) {
        const members = membersByConvo.get(conv.id) ?? [];
        const mine = members.find((m) => m.user_id === userId);
        const other = members.find((m) => m.user_id !== userId);
        summaries.push({
          conversation: conv,
          otherUserId: other?.user_id ?? null,
          lastReadAt: mine?.last_read_at ?? null,
          unreadCount: unreadByConvo.get(conv.id) ?? 0,
        });
      }

      summaries.sort((a, b) =>
        b.conversation.last_message_at.localeCompare(
          a.conversation.last_message_at,
        ),
      );

      return summaries;
    },
  });

  // Realtime: when any message is inserted in a conversation we're a member
  // of, invalidate the conversation list so last-message + unread counts
  // refresh. A single channel keyed on the user id is sufficient.
  useEffect(() => {
    if (!userId) return;
    const channel: RealtimeChannel = supabase
      .channel(`conversations-${userId}`)
      .on(
        "postgres_changes",
        {
          event: "INSERT",
          schema: "public",
          table: "conversation_messages",
        },
        () => {
          queryClient.invalidateQueries({
            queryKey: conversationsKey(userId),
          });
        },
      )
      .on(
        "postgres_changes",
        {
          event: "UPDATE",
          schema: "public",
          table: "conversations",
        },
        () => {
          queryClient.invalidateQueries({
            queryKey: conversationsKey(userId),
          });
        },
      )
      .subscribe();

    return () => {
      void supabase.removeChannel(channel);
    };
  }, [userId, queryClient]);

  return query;
};

// ---------------------------------------------------------------------------
// useMessages — ordered messages for a single conversation, with realtime
// ---------------------------------------------------------------------------

export const useMessages = (conversationId: string | null) => {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const userId = user?.id;

  const query = useQuery({
    queryKey: conversationId
      ? messagesKey(conversationId)
      : ["conversation-messages", "none"],
    enabled: !!conversationId,
    queryFn: async (): Promise<ConversationMessageRow[]> => {
      if (!conversationId) return [];
      const { data, error } = await db
        .from("conversation_messages")
        .select(MESSAGE_COLUMNS)
        .eq("conversation_id", conversationId)
        .order("created_at", { ascending: true })
        .limit(500);
      if (error) throw error;
      const rows = (data ?? []) as ConversationMessageRow[];

      // Re-sign attachment URLs from the durable `attachment_path` so images
      // keep working past the original 7-day signed-URL expiration. We batch
      // the call to avoid N round-trips when a thread has many photos.
      const paths = Array.from(
        new Set(
          rows
            .map((r) => r.attachment_path)
            .filter((p): p is string => typeof p === "string" && p.length > 0),
        ),
      );
      if (paths.length > 0) {
        const { data: signed, error: signError } = await db.storage
          .from(ATTACHMENT_BUCKET)
          .createSignedUrls(paths, 60 * 60 * 24 * 7);
        if (!signError && signed) {
          const urlByPath = new Map<string, string>();
          for (const entry of signed) {
            if (entry.path && entry.signedUrl) urlByPath.set(entry.path, entry.signedUrl);
          }
          return rows.map((r) =>
            r.attachment_path && urlByPath.has(r.attachment_path)
              ? { ...r, image_url: urlByPath.get(r.attachment_path) ?? r.image_url }
              : r,
          );
        }
      }
      return rows;
    },
  });

  useEffect(() => {
    if (!conversationId) return;
    const channel: RealtimeChannel = supabase
      .channel(`messages-${conversationId}`)
      .on(
        "postgres_changes",
        {
          event: "INSERT",
          schema: "public",
          table: "conversation_messages",
          filter: `conversation_id=eq.${conversationId}`,
        },
        (payload) => {
          const row = payload.new as ConversationMessageRow;
          queryClient.setQueryData<ConversationMessageRow[]>(
            messagesKey(conversationId),
            (prev) => {
              if (!prev) return [row];
              if (prev.some((m) => m.id === row.id)) return prev;
              return [...prev, row];
            },
          );
        },
      )
      .on(
        "postgres_changes",
        {
          event: "DELETE",
          schema: "public",
          table: "conversation_messages",
          filter: `conversation_id=eq.${conversationId}`,
        },
        (payload) => {
          const row = payload.old as ConversationMessageRow;
          queryClient.setQueryData<ConversationMessageRow[]>(
            messagesKey(conversationId),
            (prev) => prev?.filter((message) => message.id !== row.id) ?? [],
          );
        },
      )
      .subscribe();

    return () => {
      void supabase.removeChannel(channel);
    };
  }, [conversationId, queryClient]);

  const sendMutation = useMutation({
    mutationFn: async (body: string) => {
      if (!conversationId) throw new Error("No active conversation.");
      if (!userId) throw new Error("You must be signed in to send messages.");
      const trimmed = body.trim();
      if (!trimmed) throw new Error("Message cannot be empty.");
      if (trimmed.length > 4000) {
        throw new Error("Message must be 4000 characters or fewer.");
      }
      const { data, error } = await db
        .from("conversation_messages")
        .insert({
          conversation_id: conversationId,
          sender_id: userId,
          body: trimmed,
        })
        .select(MESSAGE_COLUMNS)
        .single();
      if (error) throw error;
      return data as ConversationMessageRow;
    },
    onSuccess: (inserted) => {
      if (!conversationId) return;
      queryClient.setQueryData<ConversationMessageRow[]>(
        messagesKey(conversationId),
        (prev) => {
          if (!prev) return [inserted];
          if (prev.some((m) => m.id === inserted.id)) return prev;
          return [...prev, inserted];
        },
      );
      queryClient.invalidateQueries({ queryKey: conversationsKey(userId) });
    },
  });

  const sendImageMutation = useMutation({
    mutationFn: async ({ file, caption }: { file: File; caption?: string }) => {
      if (!conversationId) throw new Error("No active conversation.");
      if (!userId) throw new Error("You must be signed in to send pictures.");
      if (!ALLOWED_IMAGE_TYPES.has(file.type)) {
        throw new Error("Unsupported image type. Use JPG, PNG, WEBP, GIF, or HEIC.");
      }
      if (file.size > MAX_ATTACHMENT_BYTES) {
        throw new Error("Image is too large. Max 8 MB.");
      }
      const trimmedCaption = (caption ?? "").trim().slice(0, 4000) || null;

      const ext = file.name.split(".").pop()?.toLowerCase().replace(/[^a-z0-9]/g, "") || "jpg";
      const filename = `${Date.now()}-${Math.random().toString(36).slice(2, 8)}.${ext}`;
      const path = `${conversationId}/${userId}/${filename}`;

      const uploadAttachment = () => db.storage
        .from(ATTACHMENT_BUCKET)
        .upload(path, file, { contentType: file.type, cacheControl: "3600", upsert: false });

      let { error: uploadError } = await uploadAttachment();
      if (uploadError && isMissingAttachmentBucketError(uploadError)) {
        await ensureMessageAttachmentBucket();
        ({ error: uploadError } = await uploadAttachment());
      }
      if (uploadError) throw uploadError;

      // Signed URL valid for 7 days; we store it on the row so consumers can
      // render the image directly without re-signing on every load.
      const signAttachment = () => db.storage
        .from(ATTACHMENT_BUCKET)
        .createSignedUrl(path, 60 * 60 * 24 * 7);

      let { data: signed, error: signError } = await signAttachment();
      if (signError && isMissingAttachmentBucketError(signError)) {
        await ensureMessageAttachmentBucket();
        ({ data: signed, error: signError } = await signAttachment());
      }
      if (signError) throw signError;

      const { data, error } = await db
        .from("conversation_messages")
        .insert({
          conversation_id: conversationId,
          sender_id: userId,
          body: trimmedCaption,
          image_url: signed?.signedUrl ?? null,
          attachment_path: path,
        })
        .select(MESSAGE_COLUMNS)
        .single();
      if (error) {
        // Best-effort cleanup of orphaned upload
        await db.storage.from(ATTACHMENT_BUCKET).remove([path]).catch(() => undefined);
        throw error;
      }
      return data as ConversationMessageRow;
    },
    onSuccess: (inserted) => {
      if (!conversationId) return;
      queryClient.setQueryData<ConversationMessageRow[]>(
        messagesKey(conversationId),
        (prev) => {
          if (!prev) return [inserted];
          if (prev.some((m) => m.id === inserted.id)) return prev;
          return [...prev, inserted];
        },
      );
      queryClient.invalidateQueries({ queryKey: conversationsKey(userId) });
    },
  });


  const deleteMutation = useMutation({
    mutationFn: async (messageId: string) => {
      if (!conversationId) throw new Error("No active conversation.");
      if (!userId) throw new Error("You must be signed in to delete messages.");
      const { error } = await db
        .from("conversation_messages")
        .delete()
        .eq("id", messageId)
        .eq("conversation_id", conversationId)
        .eq("sender_id", userId);
      if (error) throw error;
      return messageId;
    },
    onSuccess: (deletedMessageId) => {
      if (!conversationId) return;
      queryClient.setQueryData<ConversationMessageRow[]>(
        messagesKey(conversationId),
        (prev) => prev?.filter((message) => message.id !== deletedMessageId) ?? [],
      );
      queryClient.invalidateQueries({ queryKey: conversationsKey(userId) });
    },
  });

  const deleteAllMineMutation = useMutation({
    mutationFn: async () => {
      if (!conversationId) throw new Error("No active conversation.");
      if (!userId) throw new Error("You must be signed in to delete messages.");
      const { error } = await db
        .from("conversation_messages")
        .delete()
        .eq("conversation_id", conversationId)
        .eq("sender_id", userId);
      if (error) throw error;
    },
    onSuccess: () => {
      if (!conversationId) return;
      queryClient.setQueryData<ConversationMessageRow[]>(
        messagesKey(conversationId),
        (prev) => prev?.filter((message) => message.sender_id !== userId) ?? [],
      );
      queryClient.invalidateQueries({ queryKey: conversationsKey(userId) });
    },
  });

  const markRead = useCallback(async () => {
    if (!conversationId) return;
    const { error } = await db.rpc("mark_conversation_read", {
      _conversation_id: conversationId,
    });
    if (error) {
      // Non-fatal: worst case unread count stays stale until next refresh.
      console.warn("mark_conversation_read failed:", error.message);
      return;
    }
    queryClient.invalidateQueries({ queryKey: conversationsKey(userId) });
  }, [conversationId, queryClient, userId]);

  return useMemo(
    () => ({
      ...query,
      sendMessage: sendMutation.mutateAsync,
      sendImage: sendImageMutation.mutateAsync,
      deleteMessage: deleteMutation.mutateAsync,
      deleteAllMine: deleteAllMineMutation.mutateAsync,
      sending: sendMutation.isPending,
      sendingImage: sendImageMutation.isPending,
      deleting: deleteMutation.isPending,
      deletingAll: deleteAllMineMutation.isPending,
      markRead,
    }),
    [
      query,
      sendMutation.mutateAsync,
      sendMutation.isPending,
      sendImageMutation.mutateAsync,
      sendImageMutation.isPending,
      deleteMutation.mutateAsync,
      deleteMutation.isPending,
      deleteAllMineMutation.mutateAsync,
      deleteAllMineMutation.isPending,
      markRead,
    ],
  );
};

// ---------------------------------------------------------------------------
// useStartDirectMessage — find-or-create a 1:1 DM with the given user
// ---------------------------------------------------------------------------

export const useStartDirectMessage = () => {
  const queryClient = useQueryClient();
  const { user } = useAuth();

  return useMutation({
    mutationFn: async (otherUserId: string): Promise<string> => {
      const { data, error } = await db.rpc("get_or_create_dm", {
        _other_user_id: otherUserId,
      });
      if (error) throw error;
      if (typeof data !== "string") {
        throw new Error("get_or_create_dm returned an unexpected value.");
      }
      queryClient.invalidateQueries({ queryKey: conversationsKey(user?.id) });
      return data;
    },
  });
};
