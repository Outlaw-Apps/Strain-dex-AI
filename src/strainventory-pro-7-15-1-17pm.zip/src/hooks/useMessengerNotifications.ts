import { useCallback, useEffect, useRef, useState } from "react";
import type { RealtimeChannel } from "@supabase/supabase-js";
import { supabase } from "@/integrations/supabase/client";
import type { ConversationMessageRow } from "@/hooks/useMessages";

const APP_TITLE = "StrainVentory";

interface UseMessengerNotificationsArgs {
  /**
   * Currently-open conversation id. When the window is focused AND the
   * incoming message arrives in this channel, notifications are suppressed.
   * Pass `null` if no conversation is open (e.g. user is on a different page).
   */
  channelId: string | null;
  /**
   * Current user id. Used to skip self-sent messages and scope the realtime
   * subscription. The hook is a no-op while userId is `null`.
   */
  userId: string | null;
}

interface UseMessengerNotificationsResult {
  unreadCount: number;
  latestMessage: ConversationMessageRow | null;
  clearNotifications: () => void;
}

/**
 * Subscribe to ALL conversation_messages INSERTs the current user can see and
 * surface a UI notification (badge count + sound + browser Notification +
 * document.title) for each new message. The hook tracks state internally —
 * call `clearNotifications()` when the user has acknowledged them
 * (e.g. opened the messages page).
 */
export function useMessengerNotifications({
  channelId,
  userId,
}: UseMessengerNotificationsArgs): UseMessengerNotificationsResult {
  const [unreadCount, setUnreadCount] = useState(0);
  const [latestMessage, setLatestMessage] = useState<ConversationMessageRow | null>(null);

  const channelIdRef = useRef(channelId);
  const audioCtxRef = useRef<AudioContext | null>(null);

  // Keep refs in sync so the realtime callback always sees latest state
  // without re-subscribing.
  useEffect(() => {
    channelIdRef.current = channelId;
  }, [channelId]);

  // Request browser-notification permission once, the first time the hook
  // mounts with a userId. We never re-prompt or block on the result.
  useEffect(() => {
    if (!userId) return;
    if (typeof Notification === "undefined") return;
    if (Notification.permission === "default") {
      try {
        void Notification.requestPermission().catch(() => {
          // Ignore permission-request failures; notifications are best-effort.
        });
      } catch {
        // Some environments can throw synchronously; silently ignore.
      }
    }
  }, [userId]);

  // Update document.title with unread count.
  useEffect(() => {
    if (typeof document === "undefined") return;
    const previous = document.title;
    document.title = unreadCount > 0 ? `(${unreadCount}) ${APP_TITLE}` : APP_TITLE;
    return () => {
      document.title = previous;
    };
  }, [unreadCount]);

  // Subscribe to all conversation_messages inserts visible to the user.
  // Supabase RLS already restricts the stream to conversations the user is a
  // member of, so we don't filter further server-side.
  useEffect(() => {
    if (!userId) return;
    const channel: RealtimeChannel = supabase
      .channel(`messenger-notifications-${userId}`)
      .on(
        "postgres_changes",
        {
          event: "INSERT",
          schema: "public",
          table: "conversation_messages",
        },
        (payload) => {
          const row = payload.new as ConversationMessageRow;
          if (!row || row.sender_id === userId) return;

          const isWindowFocused =
            typeof document !== "undefined" &&
            document.visibilityState === "visible" &&
            document.hasFocus();
          const isActiveChannel = channelIdRef.current === row.conversation_id;
          const suppress = isWindowFocused && isActiveChannel;

          setLatestMessage(row);

          if (suppress) return;

          setUnreadCount((n) => n + 1);
          playChime();
          showBrowserNotification(row);
        },
      )
      .subscribe();

    return () => {
      void supabase.removeChannel(channel);
    };
  }, [userId]);

  const clearNotifications = useCallback(() => {
    setUnreadCount(0);
  }, []);

  // Best-effort cleanup of the AudioContext on unmount.
  useEffect(() => {
    return () => {
      if (audioCtxRef.current) {
        void audioCtxRef.current.close().catch(() => undefined);
        audioCtxRef.current = null;
      }
    };
  }, []);

  return { unreadCount, latestMessage, clearNotifications };

  // ── helpers (closed over refs above) ──────────────────────────────────────

  function playChime() {
    if (typeof window === "undefined") return;
    try {
      const Ctor: typeof AudioContext | undefined =
        window.AudioContext ??
        (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
      if (!Ctor) return;
      const ctx = audioCtxRef.current ?? new Ctor();
      audioCtxRef.current = ctx;
      const now = ctx.currentTime;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = "sine";
      // Two-note chime: 880 → 1320 Hz.
      osc.frequency.setValueAtTime(880, now);
      osc.frequency.exponentialRampToValueAtTime(1320, now + 0.12);
      gain.gain.setValueAtTime(0.0001, now);
      gain.gain.exponentialRampToValueAtTime(0.08, now + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.25);
      osc.connect(gain).connect(ctx.destination);
      osc.start(now);
      osc.stop(now + 0.27);
    } catch {
      // Audio is decorative — never block the notification path on a failure.
    }
  }
}

function showBrowserNotification(row: ConversationMessageRow) {
  if (typeof Notification === "undefined") return;
  if (Notification.permission !== "granted") return;
  try {
    const text = (row.body ?? "").trim();
    const hasImage = !!row.image_url || !!row.attachment_path;
    const preview = text
      ? text.slice(0, 140)
      : hasImage
      ? "📷 Sent a photo"
      : "You have a new message.";
    new Notification("New message", {
      body: preview,
      tag: `convo-${row.conversation_id}`,
      icon: row.image_url ?? undefined,
    });
  } catch {
    // Some browsers throw on Notification construction in insecure contexts;
    // silently ignore.
  }
}
