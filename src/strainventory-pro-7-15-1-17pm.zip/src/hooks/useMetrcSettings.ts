import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

export type MetrcSettings = {
  id: string;
  license_number: string | null;
  facility_name: string | null;
  enabled: boolean;
  auto_sync_sales: boolean;
  last_sync_at: string | null;
  created_at: string;
  updated_at: string;
};

export type MetrcSyncLog = {
  id: string;
  operation: string;
  status: string;
  details: Record<string, unknown> | null;
  created_at: string;
};

export type MetrcPackageLink = {
  id: string;
  metrc_tag: string;
  product_id: string | null;
  package_name: string | null;
  quantity: number | null;
  unit_of_measure: string | null;
  item_name: string | null;
  created_at: string;
  updated_at: string;
};

export const useMetrcSettings = () => {
  const queryClient = useQueryClient();

  const { data: settings, isLoading } = useQuery({
    queryKey: ["metrc-settings"],
    queryFn: async (): Promise<MetrcSettings | null> => {
      const { data, error } = await supabase
        .from("metrc_settings")
        .select("*")
        .order("created_at", { ascending: false })
        .limit(1)
        .maybeSingle();

      if (error) throw error;
      return data;
    },
  });

  const { data: syncLog, isLoading: logLoading } = useQuery({
    queryKey: ["metrc-sync-log"],
    queryFn: async (): Promise<MetrcSyncLog[]> => {
      const { data, error } = await supabase
        .from("metrc_sync_log")
        .select("*")
        .order("created_at", { ascending: false })
        .limit(50);

      if (error) throw error;
      return (data ?? []) as MetrcSyncLog[];
    },
  });

  const { data: packageLinks, isLoading: linksLoading } = useQuery({
    queryKey: ["metrc-package-links"],
    queryFn: async (): Promise<MetrcPackageLink[]> => {
      const { data, error } = await supabase
        .from("metrc_package_links")
        .select("*, products(name, sku)")
        .order("created_at", { ascending: false });

      if (error) throw error;
      return (data ?? []) as MetrcPackageLink[];
    },
  });

  const updateSettings = useMutation({
    mutationFn: async (updates: Partial<MetrcSettings>) => {
      if (settings?.id) {
        const { error } = await supabase
          .from("metrc_settings")
          .update(updates)
          .eq("id", settings.id);
        if (error) throw error;
      } else {
        const { error } = await supabase
          .from("metrc_settings")
          .insert(updates);
        if (error) throw error;
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["metrc-settings"] });
      toast.success("Metrc settings saved");
    },
    onError: () => toast.error("Failed to save Metrc settings"),
  });

  const testConnection = useMutation({
    mutationFn: async () => {
      const { data: session } = await supabase.auth.getSession();
      const res = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/metrc-proxy`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${session.session?.access_token}`,
          },
          body: JSON.stringify({ endpoint: "/packages/v2/active", method: "GET" }),
        },
      );
      const json = await res.json();
      if (!res.ok) throw new Error(json.error || `HTTP ${res.status}`);
      return json;
    },
    onSuccess: (data) => {
      const count = Array.isArray(data.data) ? data.data.length : 0;
      toast.success(`Metrc connection OK — ${count} active packages found`);
      queryClient.invalidateQueries({ queryKey: ["metrc-sync-log"] });
    },
    onError: (err: Error) => toast.error(`Metrc connection failed: ${err.message}`),
  });

  const pullPackages = useMutation({
    mutationFn: async () => {
      const { data: session } = await supabase.auth.getSession();
      const res = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/metrc-proxy`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${session.session?.access_token}`,
          },
          body: JSON.stringify({ endpoint: "/packages/v2/active", method: "GET" }),
        },
      );
      const json = await res.json();
      if (!res.ok) throw new Error(json.error || `HTTP ${res.status}`);

      const packages: Array<{
        Label: string;
        PackageType: string;
        Quantity: number;
        UnitOfMeasureName: string;
        ProductName: string;
        ItemName: string;
      }> = json.data ?? [];

      // Upsert into metrc_package_links
      for (const pkg of packages) {
        await supabase.from("metrc_package_links").upsert(
          {
            metrc_tag: pkg.Label,
            package_name: pkg.PackageType,
            quantity: pkg.Quantity,
            unit_of_measure: pkg.UnitOfMeasureName,
            item_name: pkg.ItemName || pkg.ProductName,
          },
          { onConflict: "metrc_tag" },
        );
      }

      // Update last sync timestamp
      if (settings?.id) {
        await supabase
          .from("metrc_settings")
          .update({ last_sync_at: new Date().toISOString() })
          .eq("id", settings.id);
      }

      return packages.length;
    },
    onSuccess: (count) => {
      toast.success(`Pulled ${count} active packages from Metrc`);
      queryClient.invalidateQueries({ queryKey: ["metrc-package-links"] });
      queryClient.invalidateQueries({ queryKey: ["metrc-settings"] });
      queryClient.invalidateQueries({ queryKey: ["metrc-sync-log"] });
    },
    onError: (err: Error) => toast.error(`Failed to pull packages: ${err.message}`),
  });

  const linkPackageToProduct = useMutation({
    mutationFn: async ({ metrcTag, productId }: { metrcTag: string; productId: string }) => {
      const { error } = await supabase
        .from("metrc_package_links")
        .update({ product_id: productId })
        .eq("metrc_tag", metrcTag);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["metrc-package-links"] });
      toast.success("Package linked to product");
    },
    onError: () => toast.error("Failed to link package"),
  });

  const postSalesReceipt = useMutation({
    mutationFn: async (receipt: unknown) => {
      const { data: session } = await supabase.auth.getSession();
      const res = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/metrc-proxy`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${session.session?.access_token}`,
          },
          body: JSON.stringify({
            endpoint: "/sales/v2/receipts",
            method: "POST",
            body: receipt,
          }),
        },
      );
      const json = await res.json();
      if (!res.ok) throw new Error(json.error || `HTTP ${res.status}`);
      return json;
    },
    onSuccess: () => {
      toast.success("Sales receipt posted to Metrc");
      queryClient.invalidateQueries({ queryKey: ["metrc-sync-log"] });
    },
    onError: (err: Error) => toast.error(`Failed to post receipt: ${err.message}`),
  });

  return {
    settings,
    isLoading,
    syncLog,
    logLoading,
    packageLinks,
    linksLoading,
    updateSettings: updateSettings.mutateAsync,
    testConnection: testConnection.mutateAsync,
    pullPackages: pullPackages.mutateAsync,
    linkPackageToProduct: linkPackageToProduct.mutateAsync,
    postSalesReceipt: postSalesReceipt.mutateAsync,
    isBusy:
      updateSettings.isPending ||
      testConnection.isPending ||
      pullPackages.isPending ||
      linkPackageToProduct.isPending ||
      postSalesReceipt.isPending,
  };
};
