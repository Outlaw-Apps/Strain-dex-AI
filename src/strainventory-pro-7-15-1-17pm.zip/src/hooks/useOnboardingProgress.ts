import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

export interface OnboardingChecklistItem {
  id: string;
  checklist_id: string;
  key: string;
  label: string;
  category: string;
  required: boolean;
  status: string;
  due_date: string | null;
  completed_at: string | null;
  notes: string | null;
  sort_order: number;
}

export interface OnboardingChecklist {
  id: string;
  employee_id: string;
  template_key: string;
  status: string;
  progress_percent: number;
  notes: string | null;
  onboarding_checklist_items: OnboardingChecklistItem[];
}

export interface DocumentRequest {
  id: string;
  employee_id: string;
  doc_type: string;
  label: string;
  status: string;
  storage_path: string | null;
  file_name: string | null;
  file_size: number | null;
  file_mime: string | null;
  verified_at: string | null;
  verified_by: string | null;
  rejection_reason: string | null;
  notes: string | null;
  due_date: string | null;
  requested_at: string;
  completed_at: string | null;
}

export function useOnboardingProgress(employeeId: string | null | undefined) {
  return useQuery({
    queryKey: ["onboarding-progress", employeeId],
    enabled: !!employeeId,
    queryFn: async () => {
      const [checklistsRes, docsRes] = await Promise.all([
        supabase
          .from("onboarding_checklists")
          .select("*, onboarding_checklist_items(*)")
          .eq("employee_id", employeeId!)
          .order("created_at", { ascending: false }),
        supabase
          .from("document_requests")
          .select("*")
          .eq("employee_id", employeeId!)
          .order("created_at", { ascending: false }),
      ]);
      if (checklistsRes.error) throw checklistsRes.error;
      if (docsRes.error) throw docsRes.error;
      const checklists = (checklistsRes.data ?? []) as unknown as OnboardingChecklist[];
      // Sort items within each checklist
      for (const c of checklists) {
        c.onboarding_checklist_items?.sort((a, b) => a.sort_order - b.sort_order);
      }
      return {
        checklists,
        documents: (docsRes.data ?? []) as unknown as DocumentRequest[],
      };
    },
  });
}

export function useOnboardingMutations(employeeId: string) {
  const qc = useQueryClient();
  const invalidate = () =>
    qc.invalidateQueries({ queryKey: ["onboarding-progress", employeeId] });

  const generateChecklist = useMutation({
    mutationFn: async (role: string) => {
      const { data, error } = await supabase.rpc(
        "generate_default_onboarding_checklist",
        { _employee_id: employeeId, _role: role },
      );
      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      toast.success("Onboarding checklist created");
      invalidate();
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const toggleItem = useMutation({
    mutationFn: async (args: { id: string; completed: boolean }) => {
      const { error } = await supabase
        .from("onboarding_checklist_items")
        .update({
          status: args.completed ? "completed" : "pending",
          completed_at: args.completed ? new Date().toISOString() : null,
        } as never)
        .eq("id", args.id);
      if (error) throw error;
    },
    onSuccess: invalidate,
    onError: (e: Error) => toast.error(e.message),
  });

  const requestDocument = useMutation({
    mutationFn: async (args: { doc_type: string; label: string; notes?: string; due_date?: string }) => {
      const { error } = await supabase.from("document_requests").insert({
        employee_id: employeeId,
        doc_type: args.doc_type,
        label: args.label,
        notes: args.notes ?? null,
        due_date: args.due_date ?? null,
      });
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Document request sent");
      invalidate();
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const markDocument = useMutation({
    mutationFn: async (args: { id: string; status: string }) => {
      const { error } = await supabase
        .from("document_requests")
        .update({
          status: args.status,
          completed_at: args.status === "received" ? new Date().toISOString() : null,
        } as never)
        .eq("id", args.id);
      if (error) throw error;
    },
    onSuccess: invalidate,
    onError: (e: Error) => toast.error(e.message),
  });

  const uploadDocument = useMutation({
    mutationFn: async (args: { id: string; file: File }) => {
      const ext = args.file.name.split(".").pop()?.toLowerCase() || "bin";
      const path = `${employeeId}/${args.id}-${Date.now()}.${ext}`;
      const upload = await supabase.storage
        .from("employee-documents")
        .upload(path, args.file, { contentType: args.file.type, upsert: false });
      if (upload.error) throw upload.error;
      const { error } = await supabase
        .from("document_requests")
        .update({
          storage_path: path,
          file_name: args.file.name,
          file_size: args.file.size,
          file_mime: args.file.type,
          status: "submitted",
          completed_at: new Date().toISOString(),
        } as never)
        .eq("id", args.id);
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Document uploaded");
      invalidate();
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const verifyDocument = useMutation({
    mutationFn: async (id: string) => {
      const { data: { user } } = await supabase.auth.getUser();
      const { error } = await supabase
        .from("document_requests")
        .update({
          status: "verified",
          verified_at: new Date().toISOString(),
          verified_by: user?.id ?? null,
          rejection_reason: null,
        } as never)
        .eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Document verified");
      invalidate();
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const rejectDocument = useMutation({
    mutationFn: async (args: { id: string; reason: string }) => {
      const { data: { user } } = await supabase.auth.getUser();
      const { error } = await supabase
        .from("document_requests")
        .update({
          status: "rejected",
          rejection_reason: args.reason,
          verified_at: new Date().toISOString(),
          verified_by: user?.id ?? null,
        } as never)
        .eq("id", args.id);
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Document rejected");
      invalidate();
    },
    onError: (e: Error) => toast.error(e.message),
  });

  async function getSignedUrl(path: string): Promise<string | null> {
    const { data, error } = await supabase.storage
      .from("employee-documents")
      .createSignedUrl(path, 60 * 10);
    if (error) return null;
    return data?.signedUrl ?? null;
  }

  return {
    generateChecklist,
    toggleItem,
    requestDocument,
    markDocument,
    uploadDocument,
    verifyDocument,
    rejectDocument,
    getSignedUrl,
  };
}
