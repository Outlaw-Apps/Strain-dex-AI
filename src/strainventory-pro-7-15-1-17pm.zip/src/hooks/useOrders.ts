import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { insertPosAuditEvent } from "@/hooks/useShiftReports";
import { getWeightMultiplier } from "@/lib/posPricing";
import type { Json } from "@/integrations/supabase/types";

export interface OrderItem {
  id: string;
  order_id: string;
  product_id: string;
  product_name: string;
  weight: string;
  quantity: number;
  unit_price: number;
  total_price: number;
}

export interface Order {
  id: string;
  customer_id: string | null;
  payment_method: string;
  subtotal: number;
  tax: number;
  total: number;
  discount_total: number;
  discount_summary: string;
  discount_snapshot_json: Json;
  status: string;
  created_by: string | null;
  created_at: string;
  order_items?: OrderItem[];
}

interface CreateOrderInput {
  customer_id?: string | null;
  payment_method: string;
  subtotal: number;
  tax: number;
  total: number;
  discount_total: number;
  discount_summary: string;
  discount_snapshot_json: Json;
  discount_manager_override_used?: boolean;
  customer_name_override?: string | null;
  customer_age?: number | null;
  cashier_short_id?: string | null;
  items: {
    product_id: string;
    product_name: string;
    weight: string;
    quantity: number;
    unit_price: number;
    total_price: number;
    base_unit_price: number;
    discounted_unit_price: number;
    discount_amount: number;
    applied_discount_ids: string[];
  }[];
}

export const useCreateOrder = () => {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (input: CreateOrderInput) => {
      const { data: user } = await supabase.auth.getUser();
      const { data: order, error } = await supabase
        .from("orders")
        .insert({
          customer_id: input.customer_id ?? null,
          payment_method: input.payment_method,
          subtotal: input.subtotal,
          tax: input.tax,
          total: input.total,
          discount_total: input.discount_total,
          discount_summary: input.discount_summary,
          discount_snapshot_json: input.discount_snapshot_json ?? {},
          created_by: user.user?.id ?? null,
          customer_name_override: input.customer_name_override ?? null,
          customer_age: input.customer_age ?? null,
          cashier_short_id: input.cashier_short_id ?? null,
          cashier_verified_at: input.cashier_short_id ? new Date().toISOString() : null,
        })
        .select()
        .single();
      if (error) throw error;

      const items = input.items.map((i) => ({
        ...i,
        order_id: order.id,
        applied_discount_ids: i.applied_discount_ids as unknown as Json,
      }));
      const { error: itemsErr } = await supabase.from("order_items").insert(items);
      if (itemsErr) throw itemsErr;

      // Decrement product quantities
      for (const item of input.items) {
        const { data: prod } = await supabase
          .from("products")
          .select("quantity")
          .eq("id", item.product_id)
          .single();
        if (prod) {
          const soldQuantity = getWeightMultiplier(item.weight) * item.quantity;
          const newQty = Math.max(0, Number(prod.quantity) - soldQuantity);
          await supabase
            .from("products")
            .update({ quantity: newQty, in_stock: newQty > 0, updated_at: new Date().toISOString() })
            .eq("id", item.product_id);
        }
      }

      try {
        await insertPosAuditEvent("order_completed", {
          order_id: order.id,
          payment_method: input.payment_method,
          total: input.total,
          subtotal: input.subtotal,
          tax: input.tax,
          discount_total: input.discount_total,
          item_count: input.items.length,
        });
      } catch {
        // Non-fatal: sale already persisted; audit is supplementary
      }

      try {
        await supabase.from("order_discount_events").insert({
          order_id: order.id,
          created_by: user.user?.id ?? null,
          event_kind: "checkout",
          reason: input.discount_summary.slice(0, 500),
          manager_override: input.discount_manager_override_used ?? false,
          payload: (input.discount_snapshot_json ?? {}) as Json,
        });
      } catch {
        /* supplementary */
      }

      return order;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["orders"] });
      qc.invalidateQueries({ queryKey: ["customer-orders"] });
      qc.invalidateQueries({ queryKey: ["products"] });
      qc.invalidateQueries({ queryKey: ["orders-in-period"] });
      qc.invalidateQueries({ queryKey: ["pos-audit-events"] });
    },
  });
};

export const useCustomerOrders = (customerId: string | null) =>
  useQuery({
    queryKey: ["customer-orders", customerId],
    queryFn: async () => {
      if (!customerId) return [];
      const threeMonthsAgo = new Date();
      threeMonthsAgo.setMonth(threeMonthsAgo.getMonth() - 3);

      const { data, error } = await supabase
        .from("orders")
        .select("*, order_items(*)")
        .eq("customer_id", customerId)
        .gte("created_at", threeMonthsAgo.toISOString())
        .order("created_at", { ascending: false });
      if (error) throw error;
      return (data ?? []) as Order[];
    },
    enabled: !!customerId,
    staleTime: 30_000,
  });
