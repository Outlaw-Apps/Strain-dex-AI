import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export interface PayrollException {
  id: string;
  pay_period_id: string | null;
  employee_id: string | null;
  kind: string;
  severity: "info" | "warning" | "error" | string;
  message: string;
  details: Record<string, unknown>;
  status: "open" | "resolved" | "dismissed" | string;
  flagged_by: string | null;
  resolved_by: string | null;
  resolved_at: string | null;
  resolution_note: string | null;
  created_at: string;
  updated_at: string;
}

export const usePayrollExceptions = (payPeriodId?: string) =>
  useQuery({
    queryKey: ["payroll-exceptions", payPeriodId ?? "all"],
    queryFn: async () => {
      let q = supabase
        .from("payroll_exceptions")
        .select("*")
        .order("created_at", { ascending: false });
      if (payPeriodId) q = q.eq("pay_period_id", payPeriodId);
      const { data, error } = await q;
      if (error) throw error;
      return (data ?? []) as PayrollException[];
    },
    staleTime: 30_000,
  });

export const useResolvePayrollException = () => {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async ({ id, note }: { id: string; note?: string }) => {
      const { data: { user } } = await supabase.auth.getUser();
      const { data, error } = await supabase
        .from("payroll_exceptions")
        .update({
          status: "resolved",
          resolved_at: new Date().toISOString(),
          resolved_by: user?.id ?? null,
          resolution_note: note ?? null,
        })
        .eq("id", id)
        .select()
        .single();
      if (error) throw error;
      return data as PayrollException;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["payroll-exceptions"] });
    },
  });
};
