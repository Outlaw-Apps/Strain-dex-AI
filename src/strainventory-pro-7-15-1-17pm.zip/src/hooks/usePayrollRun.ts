import { useCallback, useMemo, useState } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useProfileMap } from "@/hooks/useProfiles";
import { usePayrollTimeEntries } from "@/hooks/useTimeEntries";
import {
  usePayrollProfiles,
  useCreatePayPeriod,
  useUpdatePayPeriod,
  useBulkInsertPayslips,
} from "@/lib/payroll/payroll.api";
import { calculatePayroll, payrollToCSV } from "@/lib/payroll/payroll.engine";
import { buildPayrollSummaryPdf, buildPayslipPacketPdf } from "@/lib/payroll/payrollPdf";
import { buildChecksPdf } from "@/lib/payroll/checkPdf";
import type { PayrollBreakdown } from "@/lib/payroll/payroll.types";
import type { CheckTemplate } from "@/lib/payroll/checkTemplates.types";
import { useIncrementCheckNumber } from "@/hooks/useCheckTemplates";

export type SavedRunStatus = "processed" | "paid";

const toLocalDate = (d: Date) =>
  `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;

function downloadBlobFile(blob: Blob, fileName: string) {
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = fileName;
  document.body.appendChild(link);
  link.click();
  link.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 1_000);
}

function downloadBytesAsFile(bytes: Uint8Array, fileName: string, mimeType: string) {
  downloadBlobFile(new Blob([bytes as BlobPart], { type: mimeType }), fileName);
}

function buildPayrollFileStem(startDate: string, endDate: string) {
  return `payroll-${startDate}-to-${endDate}`;
}

export function usePayrollRun() {
  const profileMap = useProfileMap();

  const today = new Date();
  const twoWeeksAgo = new Date(today);
  twoWeeksAgo.setDate(today.getDate() - 14);

  const [startDate, setStartDate] = useState(toLocalDate(twoWeeksAgo));
  const [endDate, setEndDate] = useState(toLocalDate(today));
  const [breakdowns, setBreakdowns] = useState<PayrollBreakdown[]>([]);
  const [isCalculating, setIsCalculating] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [isIssuing, setIsIssuing] = useState(false);
  const [isExportingSummaryPdf, setIsExportingSummaryPdf] = useState(false);
  const [calculated, setCalculated] = useState(false);
  const [savedRunId, setSavedRunId] = useState<string | null>(null);
  const [savedRunStatus, setSavedRunStatus] = useState<SavedRunStatus | null>(null);
  const [isPrintingChecks, setIsPrintingChecks] = useState(false);

  const { data: profiles = [], isLoading: loadingProfiles } = usePayrollProfiles();
  const { data: timeEntries = [], isLoading: loadingEntries } = usePayrollTimeEntries(startDate, endDate);
  const createPeriod = useCreatePayPeriod();
  const updatePeriod = useUpdatePayPeriod();
  const bulkInsert = useBulkInsertPayslips();
  const incrementCheckNumber = useIncrementCheckNumber();

  const activeProfiles = useMemo(() => profiles.filter((p) => p.is_active), [profiles]);

  const totals = useMemo(() => {
    let gross = 0, net = 0, ot = 0, dt = 0;
    for (const b of breakdowns) {
      gross += b.gross_pay;
      net += b.net_pay;
      ot += b.ot_hours;
      dt += b.doubletime_hours;
    }
    return { gross, net, ot, dt };
  }, [breakdowns]);

  const premiumHours = useMemo(() => totals.ot + totals.dt, [totals.dt, totals.ot]);
  const payrollFileStem = useMemo(() => buildPayrollFileStem(startDate, endDate), [endDate, startDate]);

  const pdfInput = useMemo(
    () => ({
      businessName: "StrainVentory",
      startDate,
      endDate,
      employeeNames: profileMap,
      breakdowns,
    }),
    [breakdowns, endDate, profileMap, startDate],
  );

  const resetPreview = useCallback(() => {
    setBreakdowns([]);
    setCalculated(false);
    setSavedRunId(null);
    setSavedRunStatus(null);
  }, []);

  const handleStartDateChange = useCallback((value: string) => {
    setStartDate(value);
    resetPreview();
  }, [resetPreview]);

  const handleEndDateChange = useCallback((value: string) => {
    setEndDate(value);
    resetPreview();
  }, [resetPreview]);

  const handleCalculate = useCallback(() => {
    if (activeProfiles.length === 0) {
      toast.error("No active employee payroll profiles found. Set up profiles in Admin Panel first.");
      return;
    }
    setIsCalculating(true);
    try {
      const periodStart = new Date(`${startDate}T00:00:00`);
      const periodEnd = new Date(`${endDate}T23:59:59`);
      const results = activeProfiles.map((profile) =>
        calculatePayroll(timeEntries, profile, periodStart, periodEnd),
      );
      setBreakdowns(results);
      setSavedRunId(null);
      setSavedRunStatus(null);
      setCalculated(true);
      toast.success(`Payroll calculated for ${results.length} employee(s).`);
    } catch (error) {
      toast.error("Failed to calculate payroll.");
      console.error(error);
    } finally {
      setIsCalculating(false);
    }
  }, [activeProfiles, endDate, startDate, timeEntries]);

  const persistPayrollRun = useCallback(async (targetStatus: SavedRunStatus) => {
    if (breakdowns.length === 0) {
      throw new Error("Calculate payroll before saving or issuing paychecks.");
    }

    if (savedRunId) {
      if (savedRunStatus === "paid") return { id: savedRunId, status: "paid" as const };
      if (savedRunStatus === targetStatus) return { id: savedRunId, status: targetStatus };

      const updatedPeriod = await updatePeriod.mutateAsync({
        id: savedRunId,
        status: targetStatus,
        total_wages: totals.gross,
        total_ot_hours: premiumHours,
      });
      const nextStatus: SavedRunStatus = updatedPeriod.status === "paid" ? "paid" : "processed";
      setSavedRunStatus(nextStatus);
      return { id: updatedPeriod.id, status: nextStatus };
    }

    let createdPeriodId: string | null = null;
    try {
      const period = await createPeriod.mutateAsync({ start_date: startDate, end_date: endDate });
      createdPeriodId = period.id;

      const payslipRows = breakdowns.map((b) => ({
        pay_period_id: period.id,
        employee_id: b.employee_id,
        regular_hours: b.regular_hours,
        ot_hours: b.ot_hours,
        doubletime_hours: b.doubletime_hours,
        gross_pay: b.gross_pay,
        deductions: b.deductions,
        net_pay: b.net_pay,
        pdf_url: null,
      }));

      await bulkInsert.mutateAsync(payslipRows);

      const updatedPeriod = await updatePeriod.mutateAsync({
        id: period.id,
        status: targetStatus,
        total_wages: totals.gross,
        total_ot_hours: premiumHours,
      });
      const nextStatus: SavedRunStatus = updatedPeriod.status === "paid" ? "paid" : "processed";
      setSavedRunId(updatedPeriod.id);
      setSavedRunStatus(nextStatus);
      return { id: updatedPeriod.id, status: nextStatus };
    } catch (error) {
      if (createdPeriodId) {
        await supabase.from("payslips").delete().eq("pay_period_id", createdPeriodId);
        await supabase.from("pay_periods").delete().eq("id", createdPeriodId);
      }
      throw error;
    }
  }, [
    breakdowns, bulkInsert, createPeriod, endDate, premiumHours,
    savedRunId, savedRunStatus, startDate, totals.gross, updatePeriod,
  ]);

  const handleProcess = useCallback(async () => {
    if (breakdowns.length === 0) return;
    setIsProcessing(true);
    try {
      const alreadySaved = Boolean(savedRunId);
      await persistPayrollRun("processed");
      toast.success(
        alreadySaved
          ? "Payroll is already saved for this preview."
          : "Payroll processed and saved. You can issue paychecks or export PDFs now.",
      );
    } catch (error) {
      toast.error("Failed to process payroll. Check console for details.");
      console.error(error);
    } finally {
      setIsProcessing(false);
    }
  }, [breakdowns.length, persistPayrollRun, savedRunId]);

  const handleExportCSV = useCallback(() => {
    if (breakdowns.length === 0) return;
    const csv = payrollToCSV(breakdowns, profileMap);
    downloadBlobFile(new Blob([csv], { type: "text/csv" }), `${payrollFileStem}.csv`);
    toast.success("CSV exported.");
  }, [breakdowns, payrollFileStem, profileMap]);

  const handleExportSummaryPdf = useCallback(() => {
    if (breakdowns.length === 0) return;
    setIsExportingSummaryPdf(true);
    try {
      const pdfBytes = buildPayrollSummaryPdf({ ...pdfInput, generatedAt: new Date() });
      downloadBytesAsFile(pdfBytes, `${payrollFileStem}-summary.pdf`, "application/pdf");
      toast.success("Payroll summary PDF exported.");
    } catch (error) {
      toast.error("Failed to export the payroll summary PDF.");
      console.error(error);
    } finally {
      setIsExportingSummaryPdf(false);
    }
  }, [breakdowns.length, payrollFileStem, pdfInput]);

  const handleIssuePaychecks = useCallback(async () => {
    if (breakdowns.length === 0) return;
    setIsIssuing(true);
    try {
      const alreadyPaid = savedRunStatus === "paid";
      const pdfBytes = buildPayslipPacketPdf({ ...pdfInput, generatedAt: new Date() });
      downloadBytesAsFile(pdfBytes, `${payrollFileStem}-paychecks.pdf`, "application/pdf");
      await persistPayrollRun("paid");
      toast.success(
        alreadyPaid
          ? "Paycheck packet exported again."
          : "Paychecks issued, marked paid, and exported as a PDF packet.",
      );
    } catch (error) {
      toast.error("Failed to issue paychecks. Check console for details.");
      console.error(error);
    } finally {
      setIsIssuing(false);
    }
  }, [breakdowns.length, payrollFileStem, pdfInput, persistPayrollRun, savedRunStatus]);

  const handlePrintChecks = useCallback(async (template: CheckTemplate) => {
    if (breakdowns.length === 0) return;
    setIsPrintingChecks(true);
    try {
      const payable = breakdowns.filter((b) => b.net_pay > 0);
      if (payable.length === 0) {
        toast.error("No employees have a positive net pay to print.");
        return;
      }
      const startNo = template.next_check_number;
      const now = new Date();
      const checks = payable.map((b, i) => ({
        payee_name: profileMap.get(b.employee_id) ?? b.employee_id.slice(0, 8),
        amount: b.net_pay,
        memo: `Payroll ${startDate} to ${endDate}`,
        check_number: startNo + i,
        date: now,
      }));
      const pdfBytes = buildChecksPdf({ template, checks });
      downloadBytesAsFile(pdfBytes, `${payrollFileStem}-checks-${startNo}.pdf`, "application/pdf");
      await incrementCheckNumber.mutateAsync({ id: template.id, by: payable.length });
      toast.success(`Printed ${payable.length} check(s) starting at #${startNo}.`);
    } catch (error) {
      toast.error("Failed to print checks. Check console for details.");
      console.error(error);
    } finally {
      setIsPrintingChecks(false);
    }
  }, [breakdowns, endDate, incrementCheckNumber, payrollFileStem, profileMap, startDate]);

  const isLoading = loadingProfiles || loadingEntries;
  const hasPreviewResults = calculated && breakdowns.length > 0;
  const issueButtonLabel = savedRunStatus === "paid" ? "Re-export Paychecks" : "Issue & Export Paychecks";

  return {
    profileMap,
    startDate, endDate,
    breakdowns, totals, premiumHours,
    isCalculating, isProcessing, isIssuing, isExportingSummaryPdf, isPrintingChecks,
    calculated, savedRunId, savedRunStatus,
    activeProfiles, isLoading, hasPreviewResults, issueButtonLabel,
    handleStartDateChange, handleEndDateChange,
    handleCalculate, handleProcess, handleExportCSV, handleExportSummaryPdf, handleIssuePaychecks,
    handlePrintChecks,
  };
}
