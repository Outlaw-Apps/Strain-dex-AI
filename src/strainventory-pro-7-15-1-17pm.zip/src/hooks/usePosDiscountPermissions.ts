import { useMemo } from "react";
import { useUserRoles, type AppRole } from "@/hooks/useUserRoles";

/**
 * POS discount RBAC — maps `app_role` (admin / staff / reviewer) to policy flags from DISCOUNTS.md.
 * Finer per-user grants can extend this later (e.g. dedicated permissions table).
 */
export interface PosDiscountPermissions {
  loading: boolean;
  /** apply_standard_discount — non-employee customer % (senior, military, police, fire) */
  applyStandardDiscount: boolean;
  /** apply_employee_discount without Manager Override (admin + reviewer) */
  applyEmployeeDiscountWithoutOverride: boolean;
  /** apply_bogo_discount */
  applyBogoDiscount: boolean;
  /** override_discount_rules — same gate as Manager Override (admin only in this app) */
  overrideDiscountRules: boolean;
}

export function derivePosDiscountPermissions(
  roles: AppRole[],
  loading: boolean,
): PosDiscountPermissions {
  if (loading) {
    return {
      loading: true,
      applyStandardDiscount: false,
      applyEmployeeDiscountWithoutOverride: false,
      applyBogoDiscount: false,
      overrideDiscountRules: false,
    };
  }

  const has = (r: AppRole) => roles.includes(r);
  const isAdmin = has("admin");
  const isReviewer = has("reviewer") || isAdmin;
  const staff = has("staff");
  const privileged = isAdmin || isReviewer;

  return {
    loading: false,
    applyStandardDiscount: privileged || staff,
    applyEmployeeDiscountWithoutOverride: privileged,
    applyBogoDiscount: privileged || staff,
    overrideDiscountRules: isAdmin,
  };
}

export const usePosDiscountPermissions = (): PosDiscountPermissions => {
  const { roles, loading } = useUserRoles();

  return useMemo(() => derivePosDiscountPermissions(roles, loading), [roles, loading]);
};
