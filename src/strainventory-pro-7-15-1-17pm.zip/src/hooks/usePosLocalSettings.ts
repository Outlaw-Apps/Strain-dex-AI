import { useCallback, useEffect, useState } from "react";

const AUTO_PRINT_KEY = "pos.autoPrintReceipts";

// ── Scanner timing ────────────────────────────────────────────────────────
export const SCANNER_WEDGE_INTERVAL_KEY = "pos.scanner.wedgeIntervalMs";
export const SCANNER_WEDGE_MIN_LENGTH_KEY = "pos.scanner.wedgeMinLength";
export const SCANNER_WEDGE_INTERVAL_DEFAULT = 80; // ms
export const SCANNER_WEDGE_MIN_LENGTH_DEFAULT = 4; // chars

// ── Printer / receipt settings ───────────────────────────────────────────
export const PRINTER_WIDTH_KEY = "pos.printer.widthMm"; // 58 | 72 | 80
export const PRINTER_FONT_SCALE_KEY = "pos.printer.fontScale"; // 0.8 – 1.4
export const PRINTER_PAPER_SIZE_KEY = "pos.printer.paperSize"; // "thermal" | "a4" | "letter"
export const PRINTER_WIDTH_DEFAULT = 72;
export const PRINTER_FONT_SCALE_DEFAULT = 1;
export const PRINTER_PAPER_SIZE_DEFAULT = "thermal" as const;

export type PaperSize = "thermal" | "a4" | "letter";

function readBool(key: string, fallback: boolean) {
  if (typeof window === "undefined") return fallback;
  try {
    const v = window.localStorage.getItem(key);
    if (v === null) return fallback;
    return v === "true";
  } catch {
    return fallback;
  }
}

function readNumber(key: string, fallback: number) {
  if (typeof window === "undefined") return fallback;
  try {
    const v = window.localStorage.getItem(key);
    if (v === null) return fallback;
    const n = Number(v);
    return Number.isFinite(n) ? n : fallback;
  } catch {
    return fallback;
  }
}

function readString<T extends string>(key: string, fallback: T): T {
  if (typeof window === "undefined") return fallback;
  try {
    const v = window.localStorage.getItem(key);
    return (v as T | null) ?? fallback;
  } catch {
    return fallback;
  }
}

export function useAutoPrintReceipts() {
  const [autoPrint, setAutoPrint] = useState<boolean>(() => readBool(AUTO_PRINT_KEY, false));

  useEffect(() => {
    const onStorage = (e: StorageEvent) => {
      if (e.key === AUTO_PRINT_KEY) setAutoPrint(e.newValue === "true");
    };
    window.addEventListener("storage", onStorage);
    return () => window.removeEventListener("storage", onStorage);
  }, []);

  const toggle = useCallback((next: boolean) => {
    setAutoPrint(next);
    try {
      window.localStorage.setItem(AUTO_PRINT_KEY, String(next));
    } catch {
      /* ignore */
    }
  }, []);

  return { autoPrint, setAutoPrint: toggle };
}

// ── Scanner timing getters (called from non-React code at runtime) ───────
export function getScannerWedgeIntervalMs(): number {
  return Math.max(20, Math.min(500, readNumber(SCANNER_WEDGE_INTERVAL_KEY, SCANNER_WEDGE_INTERVAL_DEFAULT)));
}

export function getScannerWedgeMinLength(): number {
  return Math.max(2, Math.min(64, readNumber(SCANNER_WEDGE_MIN_LENGTH_KEY, SCANNER_WEDGE_MIN_LENGTH_DEFAULT)));
}

export function useScannerSettings() {
  const [wedgeIntervalMs, setWedgeIntervalMsState] = useState<number>(() => getScannerWedgeIntervalMs());
  const [wedgeMinLength, setWedgeMinLengthState] = useState<number>(() => getScannerWedgeMinLength());

  useEffect(() => {
    const onStorage = (e: StorageEvent) => {
      if (e.key === SCANNER_WEDGE_INTERVAL_KEY) setWedgeIntervalMsState(getScannerWedgeIntervalMs());
      if (e.key === SCANNER_WEDGE_MIN_LENGTH_KEY) setWedgeMinLengthState(getScannerWedgeMinLength());
    };
    window.addEventListener("storage", onStorage);
    return () => window.removeEventListener("storage", onStorage);
  }, []);

  const setWedgeIntervalMs = useCallback((n: number) => {
    const clamped = Math.max(20, Math.min(500, Math.round(n)));
    setWedgeIntervalMsState(clamped);
    try { window.localStorage.setItem(SCANNER_WEDGE_INTERVAL_KEY, String(clamped)); } catch { /* */ }
  }, []);

  const setWedgeMinLength = useCallback((n: number) => {
    const clamped = Math.max(2, Math.min(64, Math.round(n)));
    setWedgeMinLengthState(clamped);
    try { window.localStorage.setItem(SCANNER_WEDGE_MIN_LENGTH_KEY, String(clamped)); } catch { /* */ }
  }, []);

  const resetDefaults = useCallback(() => {
    setWedgeIntervalMs(SCANNER_WEDGE_INTERVAL_DEFAULT);
    setWedgeMinLength(SCANNER_WEDGE_MIN_LENGTH_DEFAULT);
  }, [setWedgeIntervalMs, setWedgeMinLength]);

  return { wedgeIntervalMs, wedgeMinLength, setWedgeIntervalMs, setWedgeMinLength, resetDefaults };
}

// ── Printer settings ─────────────────────────────────────────────────────
export function usePrinterSettings() {
  const [widthMm, setWidthState] = useState<number>(() => readNumber(PRINTER_WIDTH_KEY, PRINTER_WIDTH_DEFAULT));
  const [fontScale, setFontScaleState] = useState<number>(() => readNumber(PRINTER_FONT_SCALE_KEY, PRINTER_FONT_SCALE_DEFAULT));
  const [paperSize, setPaperSizeState] = useState<PaperSize>(() => readString<PaperSize>(PRINTER_PAPER_SIZE_KEY, PRINTER_PAPER_SIZE_DEFAULT));

  useEffect(() => {
    const onStorage = (e: StorageEvent) => {
      if (e.key === PRINTER_WIDTH_KEY) setWidthState(readNumber(PRINTER_WIDTH_KEY, PRINTER_WIDTH_DEFAULT));
      if (e.key === PRINTER_FONT_SCALE_KEY) setFontScaleState(readNumber(PRINTER_FONT_SCALE_KEY, PRINTER_FONT_SCALE_DEFAULT));
      if (e.key === PRINTER_PAPER_SIZE_KEY) setPaperSizeState(readString<PaperSize>(PRINTER_PAPER_SIZE_KEY, PRINTER_PAPER_SIZE_DEFAULT));
    };
    window.addEventListener("storage", onStorage);
    return () => window.removeEventListener("storage", onStorage);
  }, []);

  const setWidthMm = useCallback((n: number) => {
    const clamped = Math.max(48, Math.min(110, Math.round(n)));
    setWidthState(clamped);
    try { window.localStorage.setItem(PRINTER_WIDTH_KEY, String(clamped)); } catch { /* */ }
  }, []);

  const setFontScale = useCallback((n: number) => {
    const clamped = Math.max(0.7, Math.min(1.6, Math.round(n * 100) / 100));
    setFontScaleState(clamped);
    try { window.localStorage.setItem(PRINTER_FONT_SCALE_KEY, String(clamped)); } catch { /* */ }
  }, []);

  const setPaperSize = useCallback((v: PaperSize) => {
    setPaperSizeState(v);
    try { window.localStorage.setItem(PRINTER_PAPER_SIZE_KEY, v); } catch { /* */ }
  }, []);

  const resetDefaults = useCallback(() => {
    setWidthMm(PRINTER_WIDTH_DEFAULT);
    setFontScale(PRINTER_FONT_SCALE_DEFAULT);
    setPaperSize(PRINTER_PAPER_SIZE_DEFAULT);
  }, [setWidthMm, setFontScale, setPaperSize]);

  return { widthMm, fontScale, paperSize, setWidthMm, setFontScale, setPaperSize, resetDefaults };
}
