import { useCallback, useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { EDGE_FUNCTIONS, ENV, type ProductType } from "@/lib/constants";
import { buildIntakeAiSuggestionsFromDraft } from "@/lib/aiDraftTools";
import {
  useProductDraft,
  type ProductIntake as DraftIntake,
} from "@/context/ProductDraftContext";
import { useManagerOverride } from "@/hooks/useManagerOverride";
import { datetimeLocalValueToIso } from "@/lib/datetimeLocal";
import {
  EMPTY_INTAKE_FORM,
  inferLimitCategory,
  isValidProductType,
  mergeDistinctLines,
  type IntakeForm,
  type LimitCategory,
} from "@/lib/productIntake/types";
import { buildDraftReportMarkdown, downloadMarkdown } from "@/lib/productIntake/draftReport";
import {
  extractDraftCandidate,
  extractErrorMessage,
  isGeneratedDraft,
} from "@/lib/productIntake/draftValidation";

function hasStoredIntake(intake: DraftIntake) {
  return [
    intake.brand,
    intake.strain,
    intake.productType,
    intake.sku,
    intake.vendor,
    intake.notes,
  ].some((value) => value.trim());
}

function buildFormPatchFromStoredIntake(intake: DraftIntake): Partial<IntakeForm> {
  const productType = isValidProductType(intake.productType) ? intake.productType : "";
  return {
    name: intake.strain || "",
    brand: intake.brand,
    strain: intake.strain,
    sku: intake.sku,
    vendor: intake.vendor,
    notes: intake.notes,
    productType,
    limitCategory: inferLimitCategory(productType),
  };
}

export function useProductIntake() {
  const navigate = useNavigate();
  const { product, resetDraft, setIntake, setDraft } = useProductDraft();
  const [form, setForm] = useState<IntakeForm>(EMPTY_INTAKE_FORM);
  const [submitting, setSubmitting] = useState(false);
  const [generatingProfile, setGeneratingProfile] = useState(false);
  const [skuScannerOpen, setSkuScannerOpen] = useState(false);
  const [draftSplashOpen, setDraftSplashOpen] = useState(false);
  const [draftProgress, setDraftProgress] = useState(0);
  const managerOverride = useManagerOverride();

  const set = useCallback(
    <K extends keyof IntakeForm>(key: K, value: IntakeForm[K]) =>
      setForm((prev) => ({ ...prev, [key]: value })),
    [],
  );

  useEffect(() => {
    if (!hasStoredIntake(product.intake)) return;
    setForm((prev) => {
      const next = { ...prev, ...buildFormPatchFromStoredIntake(product.intake) };
      return JSON.stringify(prev) === JSON.stringify(next) ? prev : next;
    });
  }, [product.intake]);

  useEffect(() => {
    if (!product.draft) return;
    const suggestions = buildIntakeAiSuggestionsFromDraft(product.draft);
    setForm((prev) => {
      const nextProductType =
        suggestions.productType && isValidProductType(suggestions.productType)
          ? (suggestions.productType as ProductType)
          : prev.productType;

      const next: IntakeForm = {
        ...prev,
        name: suggestions.name || prev.name || product.intake.strain || "",
        strain: suggestions.strain || prev.strain,
        productType: nextProductType || prev.productType,
        limitCategory:
          (prev.limitCategory ||
            inferLimitCategory(nextProductType || prev.productType)) as LimitCategory | "",
        vendor: suggestions.vendor || prev.vendor,
        thc: suggestions.thc || prev.thc,
        cbd: suggestions.cbd || prev.cbd,
        flavorProfile: suggestions.flavorProfile || prev.flavorProfile,
        aromaProfile: suggestions.aromaProfile || prev.aromaProfile,
        notes: mergeDistinctLines([
          prev.notes,
          suggestions.notes,
          product.draft!.descriptionShort,
          product.draft!.descriptionLong,
        ]),
      };
      return JSON.stringify(prev) === JSON.stringify(next) ? prev : next;
    });
  }, [product.draft, product.intake.strain]);

  const missingRequired = managerOverride.overrideActive
    ? false
    : !form.name.trim() ||
      !form.brand.trim() ||
      !form.batchNumber.trim() ||
      !form.strainType ||
      !form.limitCategory ||
      !form.productType;

  const buildIntakePayload = useCallback(
    () => ({
      brand: form.brand,
      strain: form.strain || form.name,
      productType: form.productType || form.limitCategory || "",
      packageSize: "",
      sku: form.sku,
      vendor: form.vendor,
      notes: form.notes,
    }),
    [form],
  );

  const handleSubmit = useCallback(async () => {
    if (missingRequired) {
      toast.error("Please fill all required fields before submitting.");
      return;
    }

    const listPrice = Number.parseFloat(form.listPricePerGram);
    const basePrice = Number.isFinite(listPrice) && listPrice >= 0 ? listPrice : 0;

    const saleRaw = form.salePricePerGram.trim();
    const salePriceNum = saleRaw ? Number.parseFloat(saleRaw) : NaN;
    const sale_price =
      saleRaw && Number.isFinite(salePriceNum) && salePriceNum >= 0 ? salePriceNum : null;

    let clearance_active = false;
    let clearance_price: number | null = null;
    if (form.clearanceActive) {
      const cp = Number.parseFloat(form.clearancePricePerGram);
      if (!Number.isFinite(cp) || cp < 0) {
        if (!managerOverride.overrideActive) {
          toast.error("Enter a valid clearance price per gram, or enable Manager Override.");
          return;
        }
      } else {
        clearance_active = true;
        clearance_price = cp;
      }
    }

    setSubmitting(true);
    try {
      const { error } = await supabase.from("products").insert({
        name: form.name.trim(),
        brand: form.brand.trim(),
        strain: form.strain.trim() || form.name.trim(),
        batch_number: form.batchNumber.trim(),
        sku: form.sku.trim(),
        strain_type: form.strainType || null,
        limit_category: form.limitCategory || null,
        product_type: form.productType || null,
        genetics: form.genetics.trim(),
        thc: form.thc.trim(),
        cbd: form.cbd.trim(),
        weight_grams: 0,
        taste: form.flavorProfile.trim(),
        aroma: form.aromaProfile.trim(),
        type: (form.productType || form.limitCategory || "Flower").toLowerCase(),
        status: "draft",
        price: basePrice,
        sale_price,
        sale_starts_at: datetimeLocalValueToIso(form.saleStartsLocal),
        sale_ends_at: datetimeLocalValueToIso(form.saleEndsLocal),
        sale_label: form.saleLabel.trim() || null,
        clearance_active,
        clearance_price,
        clearance_reason: form.clearanceReason.trim() || null,
      });
      if (error) throw error;
      toast.success(`Batch ${form.batchNumber} added to the Vault.`);
      setForm(EMPTY_INTAKE_FORM);
    } catch (error) {
      const message = error instanceof Error ? error.message : "Insert failed";
      toast.error(message);
    } finally {
      setSubmitting(false);
    }
  }, [form, managerOverride.overrideActive, missingRequired]);

  const handleAutoGenerateProfile = useCallback(async () => {
    if (!form.name.trim() && !form.brand.trim()) {
      toast.error("Enter at least a product name or brand to let AI fill the intake details.");
      return;
    }
    setGeneratingProfile(true);
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session?.access_token) {
        toast.error("Please sign in again to generate an AI profile.");
        return;
      }
      const response = await fetch(EDGE_FUNCTIONS.GENERATE_DRAFT, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          apikey: ENV.SUPABASE_PUBLISHABLE_KEY,
          Authorization: `Bearer ${session.access_token}`,
        },
        body: JSON.stringify(buildIntakePayload()),
      });
      const payload: unknown = await response.json().catch(() => ({}));
      if (!response.ok) {
        throw new Error(
          extractErrorMessage(payload, `Profile generation failed (${response.status})`),
        );
      }
      const draft = extractDraftCandidate(payload);
      if (!draft) throw new Error("No intake update data returned");

      const suggestions = buildIntakeAiSuggestionsFromDraft(draft);
      setForm((prev) => {
        const nextProductType =
          suggestions.productType && isValidProductType(suggestions.productType)
            ? (suggestions.productType as ProductType)
            : prev.productType;
        const nextLimitCategory =
          prev.limitCategory ||
          inferLimitCategory(nextProductType || suggestions.productType);
        return {
          ...prev,
          name: suggestions.name || prev.name,
          strain: suggestions.strain || prev.strain,
          productType: nextProductType,
          limitCategory: nextLimitCategory as LimitCategory | "",
          vendor: suggestions.vendor || prev.vendor,
          thc: suggestions.thc || prev.thc,
          cbd: suggestions.cbd || prev.cbd,
          flavorProfile: suggestions.flavorProfile || prev.flavorProfile,
          aromaProfile: suggestions.aromaProfile || prev.aromaProfile,
          notes: mergeDistinctLines([prev.notes, suggestions.notes]),
        };
      });
      toast.success("AI filled the relevant intake details. Review and adjust anything you want.");
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Auto-generation failed");
    } finally {
      setGeneratingProfile(false);
    }
  }, [buildIntakePayload, form.brand, form.name]);

  const handleGenerateAIDraft = useCallback(async () => {
    if (!form.name.trim() && !form.brand.trim()) {
      toast.error("Enter at least a product name or brand.");
      return;
    }
    const intakePayload = buildIntakePayload();
    resetDraft();
    setIntake(intakePayload);

    setDraftSplashOpen(true);
    setDraftProgress(0);
    const progressTimer = window.setInterval(() => {
      setDraftProgress((prev) => Math.min(prev + Math.random() * 12 + 6, 92));
    }, 250);

    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session?.access_token) {
        toast.error("Please sign in again to generate an AI draft.");
        return;
      }
      const response = await fetch(EDGE_FUNCTIONS.GENERATE_DRAFT, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          apikey: ENV.SUPABASE_PUBLISHABLE_KEY,
          Authorization: `Bearer ${session.access_token}`,
        },
        body: JSON.stringify(intakePayload),
      });
      const payload: unknown = await response.json().catch(() => ({}));
      if (!response.ok) {
        throw new Error(
          extractErrorMessage(payload, `Draft generation failed (${response.status})`),
        );
      }
      const newDraft = extractDraftCandidate(payload);
      if (!isGeneratedDraft(newDraft)) {
        throw new Error("Draft generation returned no content");
      }

      setDraft(newDraft);
      setDraftProgress(100);
      toast.success("AI draft ready — review and refine.");
      navigate("/review");
    } catch (error) {
      const message = error instanceof Error ? error.message : "Draft generation failed";
      toast.error(message);
    } finally {
      window.clearInterval(progressTimer);
      setDraftSplashOpen(false);
    }
  }, [buildIntakePayload, form.brand, form.name, navigate, resetDraft, setDraft, setIntake]);

  const handleFindImages = useCallback(() => {
    if (!form.name.trim() && !form.brand.trim()) {
      toast.error("Enter at least a product name or brand to search for images.");
      return;
    }
    resetDraft();
    setIntake(buildIntakePayload());
    navigate("/image-finder");
  }, [buildIntakePayload, form.brand, form.name, navigate, resetDraft, setIntake]);

  const handleDownloadDraftReport = useCallback(() => {
    const { content, filename } = buildDraftReportMarkdown(form, product.draft);
    downloadMarkdown(content, filename);
    toast.success("Draft report downloaded.");
  }, [form, product.draft]);

  const handleClearForm = useCallback(() => setForm(EMPTY_INTAKE_FORM), []);

  const hasAnyContent = Boolean(
    form.name.trim() || form.brand.trim() || form.strain.trim() || form.notes.trim(),
  );

  return {
    form,
    set,
    submitting,
    generatingProfile,
    skuScannerOpen,
    setSkuScannerOpen,
    draftSplashOpen,
    draftProgress,
    managerOverride,
    missingRequired,
    hasAnyContent,
    handleSubmit,
    handleAutoGenerateProfile,
    handleGenerateAIDraft,
    handleFindImages,
    handleDownloadDraftReport,
    handleClearForm,
  };
}
