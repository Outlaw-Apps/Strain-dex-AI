import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import type { Tables } from "@/integrations/supabase/types";
import type { ProductImage } from "@/types/catalog";

// The database row type for the `products` table.
type ProductRow = Tables<"products">;

// Application-level Product type — identical to the DB row except `images` is
// typed as `ProductImage[]` instead of `Json` so components can use it safely.
export interface Product extends Omit<ProductRow, "images"> {
  images: ProductImage[];
}

/** Parse a raw Supabase row into our typed Product, safely casting the images
 *  JSON field so we don't need unsafe double-casts elsewhere. */
function parseProduct(row: ProductRow): Product {
  let images: ProductImage[] = [];
  if (Array.isArray(row.images)) {
    images = (row.images as unknown[]).filter(
      (img): img is ProductImage =>
        typeof img === "object" && img !== null && "url" in img,
    );
  }
  return { ...row, images };
}

export const useProducts = () => {
  return useQuery({
    queryKey: ["products"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("products")
        .select("*")
        .order("updated_at", { ascending: false });
      if (error) throw error;
      return (data ?? []).map(parseProduct);
    },
    staleTime: 60_000,
    gcTime: 5 * 60_000,
  });
};

/** Mutation for inline stock adjustments. Keeps the Supabase call in one place
 *  and invalidates the products query on success so consumers stay in sync. */
export const useUpdateProductQuantity = () => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async ({ id, quantity }: { id: string; quantity: number }) => {
      const { error } = await supabase
        .from("products")
        .update({
          quantity,
          in_stock: quantity > 0,
          updated_at: new Date().toISOString(),
        })
        .eq("id", id);
      if (error) throw error;
      return quantity;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["products"] });
    },
  });
};

export const useProduct = (id: string | undefined) => {
  return useQuery({
    queryKey: ["products", id],
    queryFn: async () => {
      if (!id) throw new Error("No product ID");
      const { data, error } = await supabase
        .from("products")
        .select("*")
        .eq("id", id)
        .maybeSingle();
      if (error) throw error;
      return data ? parseProduct(data) : null;
    },
    enabled: !!id,
    staleTime: 60_000,
    gcTime: 5 * 60_000,
  });
};
