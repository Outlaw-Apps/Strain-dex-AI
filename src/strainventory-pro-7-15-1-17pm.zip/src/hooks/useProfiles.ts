import { useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export interface Profile {
  id: string;
  full_name: string;
  avatar_url: string;
}

/** Fetch all profiles (for admin views) */
export const useProfiles = () =>
  useQuery({
    queryKey: ["profiles"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("profiles")
        .select("id, full_name, avatar_url");
      if (error) throw error;
      return (data ?? []) as Profile[];
    },
    staleTime: 120_000,
  });

/** Build a Map<user_id, name> for lookups */
export const useProfileMap = () => {
  const { data: profiles = [] } = useProfiles();
  return useMemo(() => {
    const map = new Map<string, string>();
    for (const p of profiles) {
      map.set(p.id, p.full_name || "Unknown");
    }
    return map;
  }, [profiles]);
};
