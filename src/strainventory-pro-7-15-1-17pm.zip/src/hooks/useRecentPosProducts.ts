// Tracks the last N products added to the POS cart, persisted per-browser so
// budtenders see their frequent picks first on shift.
import { useCallback, useEffect, useState } from "react";

const STORAGE_KEY = "pos:recent-products:v1";
const MAX_RECENTS = 8;

export interface RecentPosProduct {
  id: string;
  name: string;
  brand?: string | null;
  sku?: string | null;
  addedAt: number;
}

function read(): RecentPosProduct[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    return parsed.filter((r): r is RecentPosProduct => !!r && typeof r.id === "string");
  } catch {
    return [];
  }
}

export function useRecentPosProducts() {
  const [recents, setRecents] = useState<RecentPosProduct[]>(() => read());

  // Sync across tabs.
  useEffect(() => {
    const onStorage = (e: StorageEvent) => {
      if (e.key === STORAGE_KEY) setRecents(read());
    };
    window.addEventListener("storage", onStorage);
    return () => window.removeEventListener("storage", onStorage);
  }, []);

  const pushRecent = useCallback(
    (product: { id: string; name: string; brand?: string | null; sku?: string | null }) => {
      setRecents((prev) => {
        const next: RecentPosProduct[] = [
          {
            id: product.id,
            name: product.name,
            brand: product.brand ?? null,
            sku: product.sku ?? null,
            addedAt: Date.now(),
          },
          ...prev.filter((r) => r.id !== product.id),
        ].slice(0, MAX_RECENTS);
        try {
          localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
        } catch {
          /* ignore quota */
        }
        return next;
      });
    },
    [],
  );

  const clearRecents = useCallback(() => {
    localStorage.removeItem(STORAGE_KEY);
    setRecents([]);
  }, []);

  return { recents, pushRecent, clearRecents };
}
