import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export type ApprovalStatus = "pending" | "approved" | "rejected";

export interface EmployeeShift {
  id: string;
  user_id: string;
  starts_at: string;
  ends_at: string;
  position: string | null;
  notes: string | null;
  status: string;
  published: boolean;
  approval_status: ApprovalStatus;
  approved_by: string | null;
  approved_at: string | null;
  rejection_reason: string | null;
  created_by: string | null;
  created_at: string;
  updated_at: string;
}

export interface ShiftInput {
  user_id: string;
  starts_at: string;
  ends_at: string;
  position?: string | null;
  notes?: string | null;
}

export const useShifts = (rangeStart: string, rangeEnd: string) =>
  useQuery({
    queryKey: ["employee-shifts", rangeStart, rangeEnd],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("employee_shifts")
        .select("*")
        .gte("starts_at", rangeStart)
        .lt("starts_at", rangeEnd)
        .order("starts_at", { ascending: true });
      if (error) throw error;
      return (data ?? []) as EmployeeShift[];
    },
    enabled: !!rangeStart && !!rangeEnd,
    staleTime: 15_000,
  });

export const usePendingShifts = () =>
  useQuery({
    queryKey: ["employee-shifts", "pending"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("employee_shifts")
        .select("*")
        .eq("approval_status", "pending")
        .order("starts_at", { ascending: true });
      if (error) throw error;
      return (data ?? []) as EmployeeShift[];
    },
    staleTime: 15_000,
  });

export const useMyUpcomingShifts = () =>
  useQuery({
    queryKey: ["employee-shifts", "mine", "upcoming"],
    queryFn: async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return [];
      const { data, error } = await supabase
        .from("employee_shifts")
        .select("*")
        .eq("user_id", user.id)
        .gte("ends_at", new Date().toISOString())
        .order("starts_at", { ascending: true })
        .limit(20);
      if (error) throw error;
      return (data ?? []) as EmployeeShift[];
    },
    staleTime: 30_000,
  });

export const useCreateShift = () => {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (input: ShiftInput) => {
      const { data: { user } } = await supabase.auth.getUser();
      const { data, error } = await supabase
        .from("employee_shifts")
        .insert({ ...input, created_by: user?.id ?? null, approval_status: "pending" })
        .select()
        .single();
      if (error) throw error;
      return data as EmployeeShift;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["employee-shifts"] }),
  });
};

export const useUpdateShift = () => {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async ({ id, resetApproval, ...patch }: Partial<ShiftInput> & { id: string; resetApproval?: boolean }) => {
      const update: Partial<EmployeeShift> = { ...patch };
      if (resetApproval) {
        update.approval_status = "pending";
        update.rejection_reason = null;
      }
      const { data, error } = await supabase
        .from("employee_shifts")
        .update(update)
        .eq("id", id)
        .select()
        .single();
      if (error) throw error;
      return data as EmployeeShift;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["employee-shifts"] }),
  });
};

export const useApproveShift = () => {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (id: string) => {
      const { data: { user } } = await supabase.auth.getUser();
      const { data, error } = await supabase
        .from("employee_shifts")
        .update({
          approval_status: "approved",
          approved_by: user?.id ?? null,
          approved_at: new Date().toISOString(),
          published: true,
          rejection_reason: null,
        })
        .eq("id", id)
        .select()
        .single();
      if (error) throw error;
      return data as EmployeeShift;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["employee-shifts"] }),
  });
};

export const useRejectShift = () => {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async ({ id, reason }: { id: string; reason: string }) => {
      const { data, error } = await supabase
        .from("employee_shifts")
        .update({
          approval_status: "rejected",
          rejection_reason: reason || null,
          published: false,
        })
        .eq("id", id)
        .select()
        .single();
      if (error) throw error;
      return data as EmployeeShift;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["employee-shifts"] }),
  });
};

export const useDeleteShift = () => {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("employee_shifts").delete().eq("id", id);
      if (error) throw error;
      return id;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["employee-shifts"] }),
  });
};
