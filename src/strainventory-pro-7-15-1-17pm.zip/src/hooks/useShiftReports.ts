import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import type { Json } from "@/integrations/supabase/types";
import type { OrderTotalRow } from "@/lib/shiftReconciliation";

export const insertPosAuditEvent = async (eventType: string, metadata: Record<string, unknown>) => {
  const { data: user } = await supabase.auth.getUser();
  const { error } = await supabase.from("pos_audit_events").insert({
    event_type: eventType,
    metadata: metadata as Json,
    created_by: user.user?.id ?? null,
  });
  if (error) throw error;
};

export const useOrdersInPeriod = (periodStart: string | null, periodEnd: string | null) =>
  useQuery({
    queryKey: ["orders-in-period", periodStart, periodEnd],
    queryFn: async () => {
      if (!periodStart || !periodEnd) return [] as OrderTotalRow[];
      const { data, error } = await supabase
        .from("orders")
        .select("payment_method,total")
        .gte("created_at", periodStart)
        .lte("created_at", periodEnd)
        .order("created_at", { ascending: true });
      if (error) throw error;
      return (data ?? []) as OrderTotalRow[];
    },
    enabled: !!periodStart && !!periodEnd,
    staleTime: 15_000,
  });

export const useRecentShiftReports = (limit = 20) =>
  useQuery({
    queryKey: ["shift-reports", limit],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("shift_reports")
        .select("*")
        .order("created_at", { ascending: false })
        .limit(limit);
      if (error) throw error;
      return data ?? [];
    },
    staleTime: 30_000,
  });

export const useRecentAuditEvents = (limit = 100) =>
  useQuery({
    queryKey: ["pos-audit-events", limit],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("pos_audit_events")
        .select("*")
        .order("created_at", { ascending: false })
        .limit(limit);
      if (error) throw error;
      return data ?? [];
    },
    staleTime: 15_000,
  });

export interface CreateShiftReportInput {
  period_start: string;
  period_end: string;
  order_count: number;
  total_sales: number;
  total_cash: number;
  total_card: number;
  total_other: number;
  opening_float: number | null;
  counted_cash: number | null;
  expected_cash: number | null;
  variance_notes: string;
  notes: string;
}

export const useCreateShiftReport = () => {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (input: CreateShiftReportInput) => {
      const { data: user } = await supabase.auth.getUser();
      const { data, error } = await supabase
        .from("shift_reports")
        .insert({
          period_start: input.period_start,
          period_end: input.period_end,
          closed_by: user.user?.id ?? null,
          order_count: input.order_count,
          total_sales: input.total_sales,
          total_cash: input.total_cash,
          total_card: input.total_card,
          total_other: input.total_other,
          opening_float: input.opening_float,
          counted_cash: input.counted_cash,
          expected_cash: input.expected_cash,
          variance_notes: input.variance_notes,
          notes: input.notes,
        })
        .select()
        .single();
      if (error) throw error;

      try {
        await insertPosAuditEvent("shift_closed", {
          shift_report_id: data.id,
          period_start: input.period_start,
          period_end: input.period_end,
          order_count: input.order_count,
          total_sales: input.total_sales,
        });
      } catch {
        // Non-fatal: shift report already persisted; audit is supplementary
      }

      return data;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["shift-reports"] });
      qc.invalidateQueries({ queryKey: ["pos-audit-events"] });
    },
  });
};
