import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export interface TimeEntry {
  id: string;
  user_id: string;
  clock_in: string;
  clock_out: string | null;
  notes: string;
  created_at: string;
}

/** Get the current user's active (open) shift — clock_out is null */
export const useActiveShift = () =>
  useQuery({
    queryKey: ["time-entries", "active"],
    queryFn: async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return null;
      const { data, error } = await supabase
        .from("time_entries")
        .select("*")
        .eq("user_id", user.id)
        .is("clock_out", null)
        .order("clock_in", { ascending: false })
        .limit(1)
        .maybeSingle();
      if (error) throw error;
      return data as TimeEntry | null;
    },
    refetchInterval: 30_000,
  });

/** Get recent time entries (last 14 days) for the current user, or all users if admin */
export const useTimeEntries = (allUsers = false) =>
  useQuery({
    queryKey: ["time-entries", "recent", allUsers],
    queryFn: async () => {
      const twoWeeksAgo = new Date();
      twoWeeksAgo.setDate(twoWeeksAgo.getDate() - 14);

      let q = supabase
        .from("time_entries")
        .select("*")
        .gte("clock_in", twoWeeksAgo.toISOString())
        .order("clock_in", { ascending: false });

      if (!allUsers) {
        const { data: { user } } = await supabase.auth.getUser();
        if (!user) return [];
        q = q.eq("user_id", user.id);
      }

      const { data, error } = await q.limit(100);
      if (error) throw error;
      return (data ?? []) as TimeEntry[];
    },
    staleTime: 30_000,
  });

/** Fetch ALL time entries within a date range for all users (payroll use).
 *  Paginates in 1000-row pages to bypass Supabase max_rows server limit. */
export const usePayrollTimeEntries = (startDate: string, endDate: string) =>
  useQuery({
    queryKey: ["time-entries", "payroll", startDate, endDate],
    queryFn: async () => {
      const start = new Date(startDate + "T00:00:00").toISOString();
      const end = new Date(endDate + "T23:59:59").toISOString();

      const PAGE_SIZE = 1000;
      let offset = 0;
      const all: TimeEntry[] = [];

      for (;;) {
        const { data, error } = await supabase
          .from("time_entries")
          .select("*")
          .gte("clock_in", start)
          .lte("clock_in", end)
          .order("clock_in", { ascending: false })
          .range(offset, offset + PAGE_SIZE - 1);
        if (error) throw error;
        const page = (data ?? []) as TimeEntry[];
        all.push(...page);
        if (page.length < PAGE_SIZE) break;
        offset += PAGE_SIZE;
      }

      return all;
    },
    enabled: !!startDate && !!endDate,
    staleTime: 30_000,
  });

export const useClockIn = () => {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("Not authenticated");
      const { data, error } = await supabase
        .from("time_entries")
        .insert({ user_id: user.id })
        .select()
        .single();
      if (error) throw error;
      return data as TimeEntry;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["time-entries"] });
    },
  });
};

export const useClockOut = () => {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (entryId: string) => {
      const { data, error } = await supabase
        .from("time_entries")
        .update({ clock_out: new Date().toISOString() })
        .eq("id", entryId)
        .select()
        .single();
      if (error) throw error;
      return data as TimeEntry;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["time-entries"] });
    },
  });
};
