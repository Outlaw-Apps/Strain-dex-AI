import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { startOfDay, endOfDay } from "date-fns";

export const useTodaysSales = () => {
  return useQuery({
    queryKey: ["todays-sales"],
    queryFn: async () => {
      const todayStart = startOfDay(new Date()).toISOString();
      const todayEnd = endOfDay(new Date()).toISOString();

      const { data, error } = await supabase
        .from("orders")
        .select("total, items:order_items(product_name, quantity, total_price)")
        .gte("created_at", todayStart)
        .lte("created_at", todayEnd);

      if (error) throw error;

      type OrderRow = NonNullable<typeof data>[number];
      type OrderItem = OrderRow["items"] extends (infer ItemType)[] | null ? ItemType : never;

      const revenue = data?.reduce((sum, o) => sum + Number(o.total || 0), 0) ?? 0;
      const orderCount = data?.length ?? 0;
      const avgTicket = orderCount ? revenue / orderCount : 0;

      // Top 3 strains sold today
      const strainMap = new Map<string, number>();
      data?.forEach((order) => {
        order.items?.forEach((item: OrderItem) => {
          const name = item.product_name || "Unknown";
          strainMap.set(name, (strainMap.get(name) || 0) + (item.quantity || 0));
        });
      });

      const topStrains = Array.from(strainMap.entries())
        .sort((a, b) => b[1] - a[1])
        .slice(0, 3)
        .map(([name, qty]) => ({ name, qty }));

      return { revenue, orderCount, avgTicket, topStrains };
    },
    refetchInterval: 60_000,
  });
};
