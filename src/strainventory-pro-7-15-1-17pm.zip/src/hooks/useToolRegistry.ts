import { useQuery } from "@tanstack/react-query";
import { fetchToolRegistry } from "@/lib/copilot/toolRegistry";

export function useToolRegistry() {
  return useQuery({
    queryKey: ["tool-registry"],
    queryFn: fetchToolRegistry,
    staleTime: 5 * 60_000,
  });
}
