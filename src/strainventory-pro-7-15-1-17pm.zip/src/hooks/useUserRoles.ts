import { useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/context/AuthContext";
import type { Database } from "@/integrations/supabase/types";

export type AppRole = Database["public"]["Enums"]["app_role"];

export const useUserRoles = () => {
  const { user } = useAuth();

  const { data: roles = [], isLoading: loading } = useQuery({
    queryKey: ["user-roles", user?.id],
    queryFn: async () => {
      if (!user) return [] as AppRole[];
      const { data, error } = await supabase.rpc("get_user_roles", { _user_id: user.id });
      if (error) throw error;
      return (data ?? []) as AppRole[];
    },
    enabled: !!user,
    staleTime: 5 * 60_000,
    gcTime: 10 * 60_000,
  });

  return useMemo(() => {
    const hasRole = (role: AppRole) => roles.includes(role);
    const isAdmin = hasRole("admin");
    const isReviewer = hasRole("reviewer") || isAdmin;
    const canPublish = isAdmin || hasRole("reviewer");
    const canEdit = true; // all roles can edit
    return { roles, loading, hasRole, isAdmin, isReviewer, canPublish, canEdit };
  }, [roles, loading]);
};
