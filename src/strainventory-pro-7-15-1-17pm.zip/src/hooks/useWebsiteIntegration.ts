// Placeholder publish workflow hook for the Website Integration.
// Wire this into product publish/update flows; it queues a sync event
// the WebsiteIntegrationPanel can later forward to the chosen provider
// (Dutchie, Weedmaps, Leafly, Jane, Shopify, etc.).

import { useCallback, useEffect, useState } from "react";

const MAPPING_KEY = "website-product-mappings";
const QUEUE_KEY = "website-publish-queue";
const CONFIG_KEY = "website-integration-config";

export type WebsiteProductMapping = {
  productId: string;
  externalId: string;
  slug: string;
  lastSyncedAt: string | null;
  status: "synced" | "pending" | "error" | "unmapped";
};

export type WebsitePublishEvent = {
  id: string;
  productId: string;
  action: "create" | "update" | "delete" | "stock";
  payload: Record<string, unknown>;
  queuedAt: string;
  status: "queued" | "sent" | "failed";
  error?: string;
};

export type WebsiteIntegrationConfig = {
  provider: string;
  storeUrl: string;
  apiKey: string;
  syncMenu: boolean;
  syncInventory: boolean;
};

const readJson = <T,>(key: string, fallback: T): T => {
  try {
    const raw = localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
};

const writeJson = (key: string, value: unknown) => {
  try {
    localStorage.setItem(key, JSON.stringify(value));
    window.dispatchEvent(new CustomEvent("website-integration-changed", { detail: { key } }));
  } catch {
    /* noop */
  }
};

export const getWebsiteConfig = (): WebsiteIntegrationConfig =>
  readJson<WebsiteIntegrationConfig>(CONFIG_KEY, {
    provider: "none",
    storeUrl: "",
    apiKey: "",
    syncMenu: false,
    syncInventory: false,
  });

export const setWebsiteConfig = (cfg: WebsiteIntegrationConfig) =>
  writeJson(CONFIG_KEY, cfg);

export const useWebsiteMappings = () => {
  const [mappings, setMappings] = useState<WebsiteProductMapping[]>(() =>
    readJson<WebsiteProductMapping[]>(MAPPING_KEY, []),
  );

  useEffect(() => {
    const onChange = (e: Event) => {
      const detail = (e as CustomEvent).detail as { key?: string } | undefined;
      if (!detail || detail.key === MAPPING_KEY) {
        setMappings(readJson<WebsiteProductMapping[]>(MAPPING_KEY, []));
      }
    };
    window.addEventListener("website-integration-changed", onChange);
    return () => window.removeEventListener("website-integration-changed", onChange);
  }, []);

  const upsertMapping = useCallback((m: WebsiteProductMapping) => {
    const next = readJson<WebsiteProductMapping[]>(MAPPING_KEY, []).filter(
      (x) => x.productId !== m.productId,
    );
    next.push(m);
    writeJson(MAPPING_KEY, next);
  }, []);

  const removeMapping = useCallback((productId: string) => {
    const next = readJson<WebsiteProductMapping[]>(MAPPING_KEY, []).filter(
      (x) => x.productId !== productId,
    );
    writeJson(MAPPING_KEY, next);
  }, []);

  const replaceMappings = useCallback((next: WebsiteProductMapping[]) => {
    writeJson(MAPPING_KEY, next);
  }, []);

  return { mappings, upsertMapping, removeMapping, replaceMappings };
};

/**
 * useWebsitePublish — call `publish` after a product is published, updated,
 * or stock changes. Until a live provider is wired in, events are queued in
 * localStorage so the WebsiteIntegrationPanel can show pending sync work.
 */
export const useWebsitePublish = () => {
  const publish = useCallback(
    async (
      action: WebsitePublishEvent["action"],
      productId: string,
      payload: Record<string, unknown> = {},
    ): Promise<WebsitePublishEvent> => {
      const config = getWebsiteConfig();
      const event: WebsitePublishEvent = {
        id: crypto.randomUUID(),
        productId,
        action,
        payload,
        queuedAt: new Date().toISOString(),
        status: "queued",
      };

      const queue = readJson<WebsitePublishEvent[]>(QUEUE_KEY, []);
      queue.unshift(event);
      writeJson(QUEUE_KEY, queue.slice(0, 100));

      // No live provider yet — events stay queued. When a real provider is
      // wired up, dispatch to its API here and update event.status.
      if (config.provider === "none" || !config.syncMenu) {
        return event;
      }

      // Placeholder for future provider dispatch.
      return event;
    },
    [],
  );

  return { publish };
};

export const useWebsitePublishQueue = () => {
  const [queue, setQueue] = useState<WebsitePublishEvent[]>(() =>
    readJson<WebsitePublishEvent[]>(QUEUE_KEY, []),
  );

  useEffect(() => {
    const onChange = (e: Event) => {
      const detail = (e as CustomEvent).detail as { key?: string } | undefined;
      if (!detail || detail.key === QUEUE_KEY) {
        setQueue(readJson<WebsitePublishEvent[]>(QUEUE_KEY, []));
      }
    };
    window.addEventListener("website-integration-changed", onChange);
    return () => window.removeEventListener("website-integration-changed", onChange);
  }, []);

  const clearQueue = useCallback(() => writeJson(QUEUE_KEY, []), []);

  return { queue, clearQueue };
};
