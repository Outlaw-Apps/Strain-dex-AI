import { useQuery } from "@tanstack/react-query";
import { addDays, endOfDay, startOfDay, startOfWeek, subWeeks } from "date-fns";
import { supabase } from "@/integrations/supabase/client";
import {
  buildWeeklyStrainPerformance,
  type WeeklyStrainOrder,
} from "@/lib/dashboardStrainPerformance";

const WEEK_STARTS_ON = 1;

function getDashboardWindow(now: Date) {
  const weekStart = startOfDay(startOfWeek(now, { weekStartsOn: WEEK_STARTS_ON }));
  return {
    queryStart: subWeeks(weekStart, 1).toISOString(),
    queryEnd: endOfDay(addDays(weekStart, 6)).toISOString(),
  };
}

export const useWeeklyStrainPerformance = () => {
  return useQuery({
    queryKey: ["weekly-strain-performance"],
    queryFn: async () => {
      const now = new Date();
      const { queryStart, queryEnd } = getDashboardWindow(now);

      const { data, error } = await supabase
        .from("orders")
        .select(`
          id,
          created_at,
          total,
          items:order_items(
            product_id,
            product_name,
            quantity,
            total_price,
            product:products(
              brand,
              strain_type,
              type,
              effects,
              thc,
              cbd,
              terpenes,
              quantity
            )
          )
        `)
        .gte("created_at", queryStart)
        .lte("created_at", queryEnd)
        .order("created_at", { ascending: true });

      if (error) throw error;

      return buildWeeklyStrainPerformance({
        orders: (data ?? []) as unknown as WeeklyStrainOrder[],
        now,
      });
    },
    refetchInterval: 60_000,
  });
};
