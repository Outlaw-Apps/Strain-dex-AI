export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.1"
  }
  public: {
    Tables: {
      ai_search_domains: {
        Row: {
          created_at: string
          domain: string
          enabled: boolean
          id: string
          label: string | null
          mode: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          domain: string
          enabled?: boolean
          id?: string
          label?: string | null
          mode: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          domain?: string
          enabled?: boolean
          id?: string
          label?: string | null
          mode?: string
          updated_at?: string
        }
        Relationships: []
      }
      announcement_broadcasts: {
        Row: {
          approval_action_id: string | null
          audience_role: string
          body: string
          created_at: string
          id: string
          requires_approval: boolean
          sender_id: string | null
          sent_at: string | null
          status: string
          title: string
          updated_at: string
        }
        Insert: {
          approval_action_id?: string | null
          audience_role?: string
          body: string
          created_at?: string
          id?: string
          requires_approval?: boolean
          sender_id?: string | null
          sent_at?: string | null
          status?: string
          title: string
          updated_at?: string
        }
        Update: {
          approval_action_id?: string | null
          audience_role?: string
          body?: string
          created_at?: string
          id?: string
          requires_approval?: boolean
          sender_id?: string | null
          sent_at?: string | null
          status?: string
          title?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "announcement_broadcasts_approval_action_id_fkey"
            columns: ["approval_action_id"]
            isOneToOne: false
            referencedRelation: "copilot_actions"
            referencedColumns: ["id"]
          },
        ]
      }
      approval_requests: {
        Row: {
          action_id: string
          approver_id: string | null
          created_at: string
          decided_at: string | null
          id: string
          reason: string | null
          requested_by: string
          status: string
          updated_at: string
        }
        Insert: {
          action_id: string
          approver_id?: string | null
          created_at?: string
          decided_at?: string | null
          id?: string
          reason?: string | null
          requested_by: string
          status?: string
          updated_at?: string
        }
        Update: {
          action_id?: string
          approver_id?: string | null
          created_at?: string
          decided_at?: string | null
          id?: string
          reason?: string | null
          requested_by?: string
          status?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "approval_requests_action_id_fkey"
            columns: ["action_id"]
            isOneToOne: false
            referencedRelation: "copilot_actions"
            referencedColumns: ["id"]
          },
        ]
      }
      assistant_action_logs: {
        Row: {
          confirmed_at: string | null
          created_at: string
          error: string | null
          executed_at: string | null
          execution_payload: Json
          id: string
          intent: string
          message_id: string | null
          proposed_changes: Json
          status: string
          summary: string
          thread_id: string | null
          user_id: string
        }
        Insert: {
          confirmed_at?: string | null
          created_at?: string
          error?: string | null
          executed_at?: string | null
          execution_payload?: Json
          id?: string
          intent: string
          message_id?: string | null
          proposed_changes?: Json
          status?: string
          summary: string
          thread_id?: string | null
          user_id: string
        }
        Update: {
          confirmed_at?: string | null
          created_at?: string
          error?: string | null
          executed_at?: string | null
          execution_payload?: Json
          id?: string
          intent?: string
          message_id?: string | null
          proposed_changes?: Json
          status?: string
          summary?: string
          thread_id?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "assistant_action_logs_message_id_fkey"
            columns: ["message_id"]
            isOneToOne: false
            referencedRelation: "assistant_messages"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "assistant_action_logs_thread_id_fkey"
            columns: ["thread_id"]
            isOneToOne: false
            referencedRelation: "assistant_threads"
            referencedColumns: ["id"]
          },
        ]
      }
      assistant_messages: {
        Row: {
          content: string
          context: Json
          created_at: string
          id: string
          role: string
          thread_id: string
          user_id: string
        }
        Insert: {
          content: string
          context?: Json
          created_at?: string
          id?: string
          role: string
          thread_id: string
          user_id: string
        }
        Update: {
          content?: string
          context?: Json
          created_at?: string
          id?: string
          role?: string
          thread_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "assistant_messages_thread_id_fkey"
            columns: ["thread_id"]
            isOneToOne: false
            referencedRelation: "assistant_threads"
            referencedColumns: ["id"]
          },
        ]
      }
      assistant_threads: {
        Row: {
          audience_role: string
          created_at: string
          id: string
          page_context: Json
          title: string
          updated_at: string
          user_id: string
        }
        Insert: {
          audience_role?: string
          created_at?: string
          id?: string
          page_context?: Json
          title?: string
          updated_at?: string
          user_id: string
        }
        Update: {
          audience_role?: string
          created_at?: string
          id?: string
          page_context?: Json
          title?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      audit_logs: {
        Row: {
          action: string
          actor_id: string | null
          after: Json | null
          before: Json | null
          created_at: string
          id: string
          metadata: Json
          source: string
          target_id: string | null
          target_type: string | null
        }
        Insert: {
          action: string
          actor_id?: string | null
          after?: Json | null
          before?: Json | null
          created_at?: string
          id?: string
          metadata?: Json
          source?: string
          target_id?: string | null
          target_type?: string | null
        }
        Update: {
          action?: string
          actor_id?: string | null
          after?: Json | null
          before?: Json | null
          created_at?: string
          id?: string
          metadata?: Json
          source?: string
          target_id?: string | null
          target_type?: string | null
        }
        Relationships: []
      }
      business_settings: {
        Row: {
          business_name: string | null
          geofence_enabled: boolean
          geofence_lat: number | null
          geofence_lng: number | null
          geofence_radius_meters: number
          id: string
          logo_url: string | null
          updated_at: string
        }
        Insert: {
          business_name?: string | null
          geofence_enabled?: boolean
          geofence_lat?: number | null
          geofence_lng?: number | null
          geofence_radius_meters?: number
          id?: string
          logo_url?: string | null
          updated_at?: string
        }
        Update: {
          business_name?: string | null
          geofence_enabled?: boolean
          geofence_lat?: number | null
          geofence_lng?: number | null
          geofence_radius_meters?: number
          id?: string
          logo_url?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      check_templates: {
        Row: {
          account_holder: string
          account_holder_address: string | null
          account_number: string
          bank_address: string | null
          bank_name: string
          created_at: string
          created_by: string | null
          fractional_routing: string | null
          id: string
          is_active: boolean
          is_default: boolean
          layout: Json
          memo_default: string | null
          name: string
          next_check_number: number
          routing_number: string
          signature_image_url: string | null
          signature_label: string
          stock_mode: string
          updated_at: string
        }
        Insert: {
          account_holder: string
          account_holder_address?: string | null
          account_number: string
          bank_address?: string | null
          bank_name: string
          created_at?: string
          created_by?: string | null
          fractional_routing?: string | null
          id?: string
          is_active?: boolean
          is_default?: boolean
          layout?: Json
          memo_default?: string | null
          name: string
          next_check_number?: number
          routing_number: string
          signature_image_url?: string | null
          signature_label?: string
          stock_mode?: string
          updated_at?: string
        }
        Update: {
          account_holder?: string
          account_holder_address?: string | null
          account_number?: string
          bank_address?: string | null
          bank_name?: string
          created_at?: string
          created_by?: string | null
          fractional_routing?: string | null
          id?: string
          is_active?: boolean
          is_default?: boolean
          layout?: Json
          memo_default?: string | null
          name?: string
          next_check_number?: number
          routing_number?: string
          signature_image_url?: string | null
          signature_label?: string
          stock_mode?: string
          updated_at?: string
        }
        Relationships: []
      }
      conversation_members: {
        Row: {
          conversation_id: string
          joined_at: string
          last_read_at: string
          user_id: string
        }
        Insert: {
          conversation_id: string
          joined_at?: string
          last_read_at?: string
          user_id: string
        }
        Update: {
          conversation_id?: string
          joined_at?: string
          last_read_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "conversation_members_conversation_id_fkey"
            columns: ["conversation_id"]
            isOneToOne: false
            referencedRelation: "conversations"
            referencedColumns: ["id"]
          },
        ]
      }
      conversation_messages: {
        Row: {
          attachment_path: string | null
          body: string | null
          conversation_id: string
          created_at: string
          id: string
          image_url: string | null
          sender_id: string
        }
        Insert: {
          attachment_path?: string | null
          body?: string | null
          conversation_id: string
          created_at?: string
          id?: string
          image_url?: string | null
          sender_id: string
        }
        Update: {
          attachment_path?: string | null
          body?: string | null
          conversation_id?: string
          created_at?: string
          id?: string
          image_url?: string | null
          sender_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "conversation_messages_conversation_id_fkey"
            columns: ["conversation_id"]
            isOneToOne: false
            referencedRelation: "conversations"
            referencedColumns: ["id"]
          },
        ]
      }
      conversations: {
        Row: {
          created_at: string
          created_by: string | null
          id: string
          is_group: boolean
          last_message_at: string
          last_message_preview: string | null
          last_sender_id: string | null
          title: string | null
        }
        Insert: {
          created_at?: string
          created_by?: string | null
          id?: string
          is_group?: boolean
          last_message_at?: string
          last_message_preview?: string | null
          last_sender_id?: string | null
          title?: string | null
        }
        Update: {
          created_at?: string
          created_by?: string | null
          id?: string
          is_group?: boolean
          last_message_at?: string
          last_message_preview?: string | null
          last_sender_id?: string | null
          title?: string | null
        }
        Relationships: []
      }
      copilot_actions: {
        Row: {
          created_at: string
          error: string | null
          finished_at: string | null
          id: string
          input: Json
          output: Json | null
          route_context: string | null
          session_id: string | null
          started_at: string | null
          status: string
          summary: string | null
          thread_id: string | null
          tool_name: string
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          error?: string | null
          finished_at?: string | null
          id?: string
          input?: Json
          output?: Json | null
          route_context?: string | null
          session_id?: string | null
          started_at?: string | null
          status?: string
          summary?: string | null
          thread_id?: string | null
          tool_name: string
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          error?: string | null
          finished_at?: string | null
          id?: string
          input?: Json
          output?: Json | null
          route_context?: string | null
          session_id?: string | null
          started_at?: string | null
          status?: string
          summary?: string | null
          thread_id?: string | null
          tool_name?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "copilot_actions_session_id_fkey"
            columns: ["session_id"]
            isOneToOne: false
            referencedRelation: "copilot_sessions"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "copilot_actions_thread_id_fkey"
            columns: ["thread_id"]
            isOneToOne: false
            referencedRelation: "assistant_threads"
            referencedColumns: ["id"]
          },
        ]
      }
      copilot_navigation_events: {
        Row: {
          action_id: string | null
          created_at: string
          id: string
          mode: string
          module: string | null
          route: string
          session_id: string | null
          user_id: string
        }
        Insert: {
          action_id?: string | null
          created_at?: string
          id?: string
          mode?: string
          module?: string | null
          route: string
          session_id?: string | null
          user_id: string
        }
        Update: {
          action_id?: string | null
          created_at?: string
          id?: string
          mode?: string
          module?: string | null
          route?: string
          session_id?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "copilot_navigation_events_action_id_fkey"
            columns: ["action_id"]
            isOneToOne: false
            referencedRelation: "copilot_actions"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "copilot_navigation_events_session_id_fkey"
            columns: ["session_id"]
            isOneToOne: false
            referencedRelation: "copilot_sessions"
            referencedColumns: ["id"]
          },
        ]
      }
      copilot_sessions: {
        Row: {
          active_route: string | null
          context: Json
          created_at: string
          id: string
          status: string
          thread_id: string | null
          updated_at: string
          user_id: string
          workflow: string | null
        }
        Insert: {
          active_route?: string | null
          context?: Json
          created_at?: string
          id?: string
          status?: string
          thread_id?: string | null
          updated_at?: string
          user_id: string
          workflow?: string | null
        }
        Update: {
          active_route?: string | null
          context?: Json
          created_at?: string
          id?: string
          status?: string
          thread_id?: string | null
          updated_at?: string
          user_id?: string
          workflow?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "copilot_sessions_thread_id_fkey"
            columns: ["thread_id"]
            isOneToOne: false
            referencedRelation: "assistant_threads"
            referencedColumns: ["id"]
          },
        ]
      }
      copilot_tasks: {
        Row: {
          assigned_to: string | null
          created_at: string
          created_by: string
          description: string | null
          due_at: string | null
          id: string
          metadata: Json
          priority: string
          status: string
          title: string
          updated_at: string
        }
        Insert: {
          assigned_to?: string | null
          created_at?: string
          created_by: string
          description?: string | null
          due_at?: string | null
          id?: string
          metadata?: Json
          priority?: string
          status?: string
          title: string
          updated_at?: string
        }
        Update: {
          assigned_to?: string | null
          created_at?: string
          created_by?: string
          description?: string | null
          due_at?: string | null
          id?: string
          metadata?: Json
          priority?: string
          status?: string
          title?: string
          updated_at?: string
        }
        Relationships: []
      }
      customers: {
        Row: {
          created_at: string
          customer_number: string
          date_of_birth: string | null
          email: string
          id: string
          is_employee: boolean
          is_fire: boolean
          is_military: boolean
          is_police: boolean
          is_senior: boolean
          last_age_verified_at: string | null
          license_number: string | null
          name: string
          notes: string
          phone: string
          service_discount_note: string | null
          updated_at: string
        }
        Insert: {
          created_at?: string
          customer_number: string
          date_of_birth?: string | null
          email?: string
          id?: string
          is_employee?: boolean
          is_fire?: boolean
          is_military?: boolean
          is_police?: boolean
          is_senior?: boolean
          last_age_verified_at?: string | null
          license_number?: string | null
          name?: string
          notes?: string
          phone?: string
          service_discount_note?: string | null
          updated_at?: string
        }
        Update: {
          created_at?: string
          customer_number?: string
          date_of_birth?: string | null
          email?: string
          id?: string
          is_employee?: boolean
          is_fire?: boolean
          is_military?: boolean
          is_police?: boolean
          is_senior?: boolean
          last_age_verified_at?: string | null
          license_number?: string | null
          name?: string
          notes?: string
          phone?: string
          service_discount_note?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      document_requests: {
        Row: {
          completed_at: string | null
          created_at: string
          doc_type: string
          due_date: string | null
          employee_id: string
          file_mime: string | null
          file_name: string | null
          file_size: number | null
          id: string
          label: string
          notes: string | null
          rejection_reason: string | null
          requested_at: string
          requested_by: string | null
          status: string
          storage_path: string | null
          updated_at: string
          verified_at: string | null
          verified_by: string | null
        }
        Insert: {
          completed_at?: string | null
          created_at?: string
          doc_type: string
          due_date?: string | null
          employee_id: string
          file_mime?: string | null
          file_name?: string | null
          file_size?: number | null
          id?: string
          label: string
          notes?: string | null
          rejection_reason?: string | null
          requested_at?: string
          requested_by?: string | null
          status?: string
          storage_path?: string | null
          updated_at?: string
          verified_at?: string | null
          verified_by?: string | null
        }
        Update: {
          completed_at?: string | null
          created_at?: string
          doc_type?: string
          due_date?: string | null
          employee_id?: string
          file_mime?: string | null
          file_name?: string | null
          file_size?: number | null
          id?: string
          label?: string
          notes?: string | null
          rejection_reason?: string | null
          requested_at?: string
          requested_by?: string | null
          status?: string
          storage_path?: string | null
          updated_at?: string
          verified_at?: string | null
          verified_by?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "document_requests_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
        ]
      }
      email_send_log: {
        Row: {
          created_at: string
          error_message: string | null
          id: string
          message_id: string | null
          metadata: Json | null
          recipient_email: string
          status: string
          template_name: string
        }
        Insert: {
          created_at?: string
          error_message?: string | null
          id?: string
          message_id?: string | null
          metadata?: Json | null
          recipient_email: string
          status: string
          template_name: string
        }
        Update: {
          created_at?: string
          error_message?: string | null
          id?: string
          message_id?: string | null
          metadata?: Json | null
          recipient_email?: string
          status?: string
          template_name?: string
        }
        Relationships: []
      }
      email_send_state: {
        Row: {
          auth_email_ttl_minutes: number
          batch_size: number
          id: number
          retry_after_until: string | null
          send_delay_ms: number
          transactional_email_ttl_minutes: number
          updated_at: string
        }
        Insert: {
          auth_email_ttl_minutes?: number
          batch_size?: number
          id?: number
          retry_after_until?: string | null
          send_delay_ms?: number
          transactional_email_ttl_minutes?: number
          updated_at?: string
        }
        Update: {
          auth_email_ttl_minutes?: number
          batch_size?: number
          id?: number
          retry_after_until?: string | null
          send_delay_ms?: number
          transactional_email_ttl_minutes?: number
          updated_at?: string
        }
        Relationships: []
      }
      email_templates: {
        Row: {
          body_html: string
          created_at: string
          description: string | null
          display_name: string
          enabled: boolean
          id: string
          subject: string
          template_name: string
          updated_at: string
          variables: Json
        }
        Insert: {
          body_html: string
          created_at?: string
          description?: string | null
          display_name: string
          enabled?: boolean
          id?: string
          subject: string
          template_name: string
          updated_at?: string
          variables?: Json
        }
        Update: {
          body_html?: string
          created_at?: string
          description?: string | null
          display_name?: string
          enabled?: boolean
          id?: string
          subject?: string
          template_name?: string
          updated_at?: string
          variables?: Json
        }
        Relationships: []
      }
      email_unsubscribe_tokens: {
        Row: {
          created_at: string
          email: string
          id: string
          token: string
          used_at: string | null
        }
        Insert: {
          created_at?: string
          email: string
          id?: string
          token: string
          used_at?: string | null
        }
        Update: {
          created_at?: string
          email?: string
          id?: string
          token?: string
          used_at?: string | null
        }
        Relationships: []
      }
      employee_payroll_profiles: {
        Row: {
          created_at: string
          deductions: number
          direct_deposit_account: string | null
          direct_deposit_routing: string | null
          doubletime_multiplier: number
          employee_id: string
          hourly_rate: number
          id: string
          is_active: boolean
          overtime_multiplier: number
          tax_filing_status: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          deductions?: number
          direct_deposit_account?: string | null
          direct_deposit_routing?: string | null
          doubletime_multiplier?: number
          employee_id: string
          hourly_rate?: number
          id?: string
          is_active?: boolean
          overtime_multiplier?: number
          tax_filing_status?: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          deductions?: number
          direct_deposit_account?: string | null
          direct_deposit_routing?: string | null
          doubletime_multiplier?: number
          employee_id?: string
          hourly_rate?: number
          id?: string
          is_active?: boolean
          overtime_multiplier?: number
          tax_filing_status?: string
          updated_at?: string
        }
        Relationships: []
      }
      employee_shifts: {
        Row: {
          approval_status: string
          approved_at: string | null
          approved_by: string | null
          created_at: string
          created_by: string | null
          ends_at: string
          id: string
          notes: string | null
          position: string | null
          published: boolean
          rejection_reason: string | null
          starts_at: string
          status: string
          updated_at: string
          user_id: string
        }
        Insert: {
          approval_status?: string
          approved_at?: string | null
          approved_by?: string | null
          created_at?: string
          created_by?: string | null
          ends_at: string
          id?: string
          notes?: string | null
          position?: string | null
          published?: boolean
          rejection_reason?: string | null
          starts_at: string
          status?: string
          updated_at?: string
          user_id: string
        }
        Update: {
          approval_status?: string
          approved_at?: string | null
          approved_by?: string | null
          created_at?: string
          created_by?: string | null
          ends_at?: string
          id?: string
          notes?: string | null
          position?: string | null
          published?: boolean
          rejection_reason?: string | null
          starts_at?: string
          status?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      employees: {
        Row: {
          approved_at: string | null
          approved_by: string | null
          assigned_role: string
          badge_number: string
          created_at: string
          created_by: string | null
          date_of_birth: string
          email: string
          emergency_contact: string
          full_name: string
          government_id_url: string | null
          id: string
          live_scan_status: string
          location: string | null
          manager_id: string | null
          manager_note: string | null
          mmic_number: string | null
          phone: string
          rejected_at: string | null
          rejection_reason: string | null
          role: string
          sop_handbook_acknowledged: boolean
          start_date: string | null
          status: string
          updated_at: string
          user_id: string | null
        }
        Insert: {
          approved_at?: string | null
          approved_by?: string | null
          assigned_role?: string
          badge_number: string
          created_at?: string
          created_by?: string | null
          date_of_birth: string
          email: string
          emergency_contact: string
          full_name: string
          government_id_url?: string | null
          id?: string
          live_scan_status: string
          location?: string | null
          manager_id?: string | null
          manager_note?: string | null
          mmic_number?: string | null
          phone: string
          rejected_at?: string | null
          rejection_reason?: string | null
          role: string
          sop_handbook_acknowledged?: boolean
          start_date?: string | null
          status?: string
          updated_at?: string
          user_id?: string | null
        }
        Update: {
          approved_at?: string | null
          approved_by?: string | null
          assigned_role?: string
          badge_number?: string
          created_at?: string
          created_by?: string | null
          date_of_birth?: string
          email?: string
          emergency_contact?: string
          full_name?: string
          government_id_url?: string | null
          id?: string
          live_scan_status?: string
          location?: string | null
          manager_id?: string | null
          manager_note?: string | null
          mmic_number?: string | null
          phone?: string
          rejected_at?: string | null
          rejection_reason?: string | null
          role?: string
          sop_handbook_acknowledged?: boolean
          start_date?: string | null
          status?: string
          updated_at?: string
          user_id?: string | null
        }
        Relationships: []
      }
      generated_documents: {
        Row: {
          approved_at: string | null
          approved_by: string | null
          body: string
          created_at: string
          doc_type: string
          employee_id: string | null
          generated_by: string | null
          id: string
          recipient_name: string | null
          requires_approval: boolean
          source: string
          status: string
          title: string
          updated_at: string
          variables: Json
        }
        Insert: {
          approved_at?: string | null
          approved_by?: string | null
          body: string
          created_at?: string
          doc_type: string
          employee_id?: string | null
          generated_by?: string | null
          id?: string
          recipient_name?: string | null
          requires_approval?: boolean
          source?: string
          status?: string
          title: string
          updated_at?: string
          variables?: Json
        }
        Update: {
          approved_at?: string | null
          approved_by?: string | null
          body?: string
          created_at?: string
          doc_type?: string
          employee_id?: string | null
          generated_by?: string | null
          id?: string
          recipient_name?: string | null
          requires_approval?: boolean
          source?: string
          status?: string
          title?: string
          updated_at?: string
          variables?: Json
        }
        Relationships: [
          {
            foreignKeyName: "generated_documents_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
        ]
      }
      generated_reports: {
        Row: {
          created_at: string
          data: Json
          generated_by: string | null
          id: string
          params: Json
          period_end: string | null
          period_start: string | null
          report_type: string
          source: string
          summary: string | null
          title: string
        }
        Insert: {
          created_at?: string
          data?: Json
          generated_by?: string | null
          id?: string
          params?: Json
          period_end?: string | null
          period_start?: string | null
          report_type: string
          source?: string
          summary?: string | null
          title: string
        }
        Update: {
          created_at?: string
          data?: Json
          generated_by?: string | null
          id?: string
          params?: Json
          period_end?: string | null
          period_start?: string | null
          report_type?: string
          source?: string
          summary?: string | null
          title?: string
        }
        Relationships: []
      }
      internal_job_secrets: {
        Row: {
          created_at: string
          name: string
          token: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          name: string
          token?: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          name?: string
          token?: string
          updated_at?: string
        }
        Relationships: []
      }
      label_templates: {
        Row: {
          config: Json
          created_at: string
          description: string | null
          id: string
          is_shared: boolean
          name: string
          updated_at: string
          user_id: string
        }
        Insert: {
          config?: Json
          created_at?: string
          description?: string | null
          id?: string
          is_shared?: boolean
          name: string
          updated_at?: string
          user_id: string
        }
        Update: {
          config?: Json
          created_at?: string
          description?: string | null
          id?: string
          is_shared?: boolean
          name?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      metrc_package_links: {
        Row: {
          created_at: string | null
          id: string
          item_name: string | null
          metrc_tag: string
          package_name: string | null
          product_id: string | null
          quantity: number | null
          unit_of_measure: string | null
          updated_at: string | null
        }
        Insert: {
          created_at?: string | null
          id?: string
          item_name?: string | null
          metrc_tag: string
          package_name?: string | null
          product_id?: string | null
          quantity?: number | null
          unit_of_measure?: string | null
          updated_at?: string | null
        }
        Update: {
          created_at?: string | null
          id?: string
          item_name?: string | null
          metrc_tag?: string
          package_name?: string | null
          product_id?: string | null
          quantity?: number | null
          unit_of_measure?: string | null
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "metrc_package_links_product_id_fkey"
            columns: ["product_id"]
            isOneToOne: false
            referencedRelation: "products"
            referencedColumns: ["id"]
          },
        ]
      }
      metrc_settings: {
        Row: {
          auto_sync_sales: boolean | null
          created_at: string | null
          enabled: boolean | null
          facility_name: string | null
          id: string
          last_sync_at: string | null
          license_number: string | null
          updated_at: string | null
        }
        Insert: {
          auto_sync_sales?: boolean | null
          created_at?: string | null
          enabled?: boolean | null
          facility_name?: string | null
          id?: string
          last_sync_at?: string | null
          license_number?: string | null
          updated_at?: string | null
        }
        Update: {
          auto_sync_sales?: boolean | null
          created_at?: string | null
          enabled?: boolean | null
          facility_name?: string | null
          id?: string
          last_sync_at?: string | null
          license_number?: string | null
          updated_at?: string | null
        }
        Relationships: []
      }
      metrc_sync_log: {
        Row: {
          created_at: string | null
          details: Json | null
          id: string
          operation: string
          status: string
        }
        Insert: {
          created_at?: string | null
          details?: Json | null
          id?: string
          operation: string
          status: string
        }
        Update: {
          created_at?: string | null
          details?: Json | null
          id?: string
          operation?: string
          status?: string
        }
        Relationships: []
      }
      onboarding_checklist_items: {
        Row: {
          category: string
          checklist_id: string
          completed_at: string | null
          completed_by: string | null
          created_at: string
          due_date: string | null
          id: string
          key: string
          label: string
          notes: string | null
          required: boolean
          sort_order: number
          status: string
          updated_at: string
        }
        Insert: {
          category?: string
          checklist_id: string
          completed_at?: string | null
          completed_by?: string | null
          created_at?: string
          due_date?: string | null
          id?: string
          key: string
          label: string
          notes?: string | null
          required?: boolean
          sort_order?: number
          status?: string
          updated_at?: string
        }
        Update: {
          category?: string
          checklist_id?: string
          completed_at?: string | null
          completed_by?: string | null
          created_at?: string
          due_date?: string | null
          id?: string
          key?: string
          label?: string
          notes?: string | null
          required?: boolean
          sort_order?: number
          status?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "onboarding_checklist_items_checklist_id_fkey"
            columns: ["checklist_id"]
            isOneToOne: false
            referencedRelation: "onboarding_checklists"
            referencedColumns: ["id"]
          },
        ]
      }
      onboarding_checklists: {
        Row: {
          created_at: string
          created_by: string | null
          employee_id: string
          id: string
          notes: string | null
          progress_percent: number
          status: string
          template_key: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          created_by?: string | null
          employee_id: string
          id?: string
          notes?: string | null
          progress_percent?: number
          status?: string
          template_key?: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          created_by?: string | null
          employee_id?: string
          id?: string
          notes?: string | null
          progress_percent?: number
          status?: string
          template_key?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "onboarding_checklists_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
        ]
      }
      order_discount_events: {
        Row: {
          created_at: string
          created_by: string | null
          event_kind: string
          id: string
          manager_override: boolean
          order_id: string | null
          payload: Json
          reason: string
        }
        Insert: {
          created_at?: string
          created_by?: string | null
          event_kind: string
          id?: string
          manager_override?: boolean
          order_id?: string | null
          payload?: Json
          reason?: string
        }
        Update: {
          created_at?: string
          created_by?: string | null
          event_kind?: string
          id?: string
          manager_override?: boolean
          order_id?: string | null
          payload?: Json
          reason?: string
        }
        Relationships: [
          {
            foreignKeyName: "order_discount_events_order_id_fkey"
            columns: ["order_id"]
            isOneToOne: false
            referencedRelation: "orders"
            referencedColumns: ["id"]
          },
        ]
      }
      order_items: {
        Row: {
          applied_discount_ids: Json
          base_unit_price: number
          created_at: string
          discount_amount: number
          discounted_unit_price: number
          id: string
          order_id: string
          product_id: string
          product_name: string
          quantity: number
          total_price: number
          unit_price: number
          weight: string
        }
        Insert: {
          applied_discount_ids?: Json
          base_unit_price?: number
          created_at?: string
          discount_amount?: number
          discounted_unit_price?: number
          id?: string
          order_id: string
          product_id: string
          product_name: string
          quantity?: number
          total_price?: number
          unit_price?: number
          weight?: string
        }
        Update: {
          applied_discount_ids?: Json
          base_unit_price?: number
          created_at?: string
          discount_amount?: number
          discounted_unit_price?: number
          id?: string
          order_id?: string
          product_id?: string
          product_name?: string
          quantity?: number
          total_price?: number
          unit_price?: number
          weight?: string
        }
        Relationships: [
          {
            foreignKeyName: "order_items_order_id_fkey"
            columns: ["order_id"]
            isOneToOne: false
            referencedRelation: "orders"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "order_items_product_id_fkey"
            columns: ["product_id"]
            isOneToOne: false
            referencedRelation: "products"
            referencedColumns: ["id"]
          },
        ]
      }
      orders: {
        Row: {
          cashier_short_id: string | null
          cashier_verified_at: string | null
          created_at: string
          created_by: string | null
          customer_age: number | null
          customer_id: string | null
          customer_name_override: string | null
          discount_snapshot_json: Json
          discount_summary: string
          discount_total: number
          id: string
          payment_method: string
          status: string
          subtotal: number
          tax: number
          total: number
        }
        Insert: {
          cashier_short_id?: string | null
          cashier_verified_at?: string | null
          created_at?: string
          created_by?: string | null
          customer_age?: number | null
          customer_id?: string | null
          customer_name_override?: string | null
          discount_snapshot_json?: Json
          discount_summary?: string
          discount_total?: number
          id?: string
          payment_method?: string
          status?: string
          subtotal?: number
          tax?: number
          total?: number
        }
        Update: {
          cashier_short_id?: string | null
          cashier_verified_at?: string | null
          created_at?: string
          created_by?: string | null
          customer_age?: number | null
          customer_id?: string | null
          customer_name_override?: string | null
          discount_snapshot_json?: Json
          discount_summary?: string
          discount_total?: number
          id?: string
          payment_method?: string
          status?: string
          subtotal?: number
          tax?: number
          total?: number
        }
        Relationships: [
          {
            foreignKeyName: "orders_customer_id_fkey"
            columns: ["customer_id"]
            isOneToOne: false
            referencedRelation: "customers"
            referencedColumns: ["id"]
          },
        ]
      }
      pay_periods: {
        Row: {
          created_at: string
          created_by: string | null
          end_date: string
          id: string
          start_date: string
          status: string
          total_ot_hours: number
          total_wages: number
        }
        Insert: {
          created_at?: string
          created_by?: string | null
          end_date: string
          id?: string
          start_date: string
          status?: string
          total_ot_hours?: number
          total_wages?: number
        }
        Update: {
          created_at?: string
          created_by?: string | null
          end_date?: string
          id?: string
          start_date?: string
          status?: string
          total_ot_hours?: number
          total_wages?: number
        }
        Relationships: []
      }
      payroll_exceptions: {
        Row: {
          created_at: string
          details: Json
          employee_id: string | null
          flagged_by: string | null
          id: string
          kind: string
          message: string
          pay_period_id: string | null
          resolution_note: string | null
          resolved_at: string | null
          resolved_by: string | null
          severity: string
          status: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          details?: Json
          employee_id?: string | null
          flagged_by?: string | null
          id?: string
          kind: string
          message: string
          pay_period_id?: string | null
          resolution_note?: string | null
          resolved_at?: string | null
          resolved_by?: string | null
          severity?: string
          status?: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          details?: Json
          employee_id?: string | null
          flagged_by?: string | null
          id?: string
          kind?: string
          message?: string
          pay_period_id?: string | null
          resolution_note?: string | null
          resolved_at?: string | null
          resolved_by?: string | null
          severity?: string
          status?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "payroll_exceptions_pay_period_id_fkey"
            columns: ["pay_period_id"]
            isOneToOne: false
            referencedRelation: "pay_periods"
            referencedColumns: ["id"]
          },
        ]
      }
      payslips: {
        Row: {
          created_at: string
          deductions: number
          doubletime_hours: number
          employee_id: string
          gross_pay: number
          id: string
          net_pay: number
          ot_hours: number
          pay_period_id: string
          pdf_url: string | null
          regular_hours: number
        }
        Insert: {
          created_at?: string
          deductions?: number
          doubletime_hours?: number
          employee_id: string
          gross_pay?: number
          id?: string
          net_pay?: number
          ot_hours?: number
          pay_period_id: string
          pdf_url?: string | null
          regular_hours?: number
        }
        Update: {
          created_at?: string
          deductions?: number
          doubletime_hours?: number
          employee_id?: string
          gross_pay?: number
          id?: string
          net_pay?: number
          ot_hours?: number
          pay_period_id?: string
          pdf_url?: string | null
          regular_hours?: number
        }
        Relationships: [
          {
            foreignKeyName: "payslips_pay_period_id_fkey"
            columns: ["pay_period_id"]
            isOneToOne: false
            referencedRelation: "pay_periods"
            referencedColumns: ["id"]
          },
        ]
      }
      pos_audit_events: {
        Row: {
          created_at: string
          created_by: string | null
          event_type: string
          id: string
          metadata: Json
        }
        Insert: {
          created_at?: string
          created_by?: string | null
          event_type: string
          id?: string
          metadata?: Json
        }
        Update: {
          created_at?: string
          created_by?: string | null
          event_type?: string
          id?: string
          metadata?: Json
        }
        Relationships: []
      }
      products: {
        Row: {
          aroma: string
          batch_number: string
          brand: string
          cbd: string
          clearance_active: boolean
          clearance_price: number | null
          clearance_reason: string | null
          confidence: number
          created_at: string
          created_by: string | null
          effects: string
          expiration_date: string | null
          genetics: string
          id: string
          images: Json
          in_stock: boolean
          limit_category: string | null
          long_description: string
          medical_uses: string
          name: string
          package_size: string
          price: number
          product_type: string | null
          quantity: number
          sale_ends_at: string | null
          sale_label: string | null
          sale_price: number | null
          sale_starts_at: string | null
          short_description: string
          sku: string
          status: string
          strain: string
          strain_type: string | null
          taste: string
          terpenes: string
          thc: string
          type: string
          updated_at: string
          weight_grams: number
        }
        Insert: {
          aroma?: string
          batch_number?: string
          brand: string
          cbd?: string
          clearance_active?: boolean
          clearance_price?: number | null
          clearance_reason?: string | null
          confidence?: number
          created_at?: string
          created_by?: string | null
          effects?: string
          expiration_date?: string | null
          genetics?: string
          id?: string
          images?: Json
          in_stock?: boolean
          limit_category?: string | null
          long_description?: string
          medical_uses?: string
          name: string
          package_size?: string
          price?: number
          product_type?: string | null
          quantity?: number
          sale_ends_at?: string | null
          sale_label?: string | null
          sale_price?: number | null
          sale_starts_at?: string | null
          short_description?: string
          sku?: string
          status?: string
          strain?: string
          strain_type?: string | null
          taste?: string
          terpenes?: string
          thc?: string
          type: string
          updated_at?: string
          weight_grams?: number
        }
        Update: {
          aroma?: string
          batch_number?: string
          brand?: string
          cbd?: string
          clearance_active?: boolean
          clearance_price?: number | null
          clearance_reason?: string | null
          confidence?: number
          created_at?: string
          created_by?: string | null
          effects?: string
          expiration_date?: string | null
          genetics?: string
          id?: string
          images?: Json
          in_stock?: boolean
          limit_category?: string | null
          long_description?: string
          medical_uses?: string
          name?: string
          package_size?: string
          price?: number
          product_type?: string | null
          quantity?: number
          sale_ends_at?: string | null
          sale_label?: string | null
          sale_price?: number | null
          sale_starts_at?: string | null
          short_description?: string
          sku?: string
          status?: string
          strain?: string
          strain_type?: string | null
          taste?: string
          terpenes?: string
          thc?: string
          type?: string
          updated_at?: string
          weight_grams?: number
        }
        Relationships: []
      }
      profiles: {
        Row: {
          avatar_url: string
          created_at: string
          full_name: string
          id: string
          updated_at: string
        }
        Insert: {
          avatar_url?: string
          created_at?: string
          full_name?: string
          id: string
          updated_at?: string
        }
        Update: {
          avatar_url?: string
          created_at?: string
          full_name?: string
          id?: string
          updated_at?: string
        }
        Relationships: []
      }
      scheduled_emails: {
        Row: {
          created_at: string
          created_by: string | null
          dispatched_at: string | null
          error_message: string | null
          id: string
          message_id: string
          payload: Json
          recipient_email: string
          scheduled_at: string
          status: string
          template_name: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          created_by?: string | null
          dispatched_at?: string | null
          error_message?: string | null
          id?: string
          message_id: string
          payload: Json
          recipient_email: string
          scheduled_at: string
          status?: string
          template_name: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          created_by?: string | null
          dispatched_at?: string | null
          error_message?: string | null
          id?: string
          message_id?: string
          payload?: Json
          recipient_email?: string
          scheduled_at?: string
          status?: string
          template_name?: string
          updated_at?: string
        }
        Relationships: []
      }
      shift_reports: {
        Row: {
          closed_by: string | null
          counted_cash: number | null
          created_at: string
          expected_cash: number | null
          id: string
          notes: string
          opening_float: number | null
          order_count: number
          period_end: string
          period_start: string
          total_card: number
          total_cash: number
          total_other: number
          total_sales: number
          variance_notes: string
        }
        Insert: {
          closed_by?: string | null
          counted_cash?: number | null
          created_at?: string
          expected_cash?: number | null
          id?: string
          notes?: string
          opening_float?: number | null
          order_count?: number
          period_end: string
          period_start: string
          total_card?: number
          total_cash?: number
          total_other?: number
          total_sales?: number
          variance_notes?: string
        }
        Update: {
          closed_by?: string | null
          counted_cash?: number | null
          created_at?: string
          expected_cash?: number | null
          id?: string
          notes?: string
          opening_float?: number | null
          order_count?: number
          period_end?: string
          period_start?: string
          total_card?: number
          total_cash?: number
          total_other?: number
          total_sales?: number
          variance_notes?: string
        }
        Relationships: []
      }
      suppressed_emails: {
        Row: {
          created_at: string
          email: string
          id: string
          metadata: Json | null
          reason: string
        }
        Insert: {
          created_at?: string
          email: string
          id?: string
          metadata?: Json | null
          reason: string
        }
        Update: {
          created_at?: string
          email?: string
          id?: string
          metadata?: Json | null
          reason?: string
        }
        Relationships: []
      }
      time_entries: {
        Row: {
          clock_in: string
          clock_out: string | null
          created_at: string
          id: string
          notes: string
          user_id: string
        }
        Insert: {
          clock_in?: string
          clock_out?: string | null
          created_at?: string
          id?: string
          notes?: string
          user_id: string
        }
        Update: {
          clock_in?: string
          clock_out?: string | null
          created_at?: string
          id?: string
          notes?: string
          user_id?: string
        }
        Relationships: []
      }
      tool_registry: {
        Row: {
          allowed_roles: Database["public"]["Enums"]["app_role"][]
          category: string
          created_at: string
          description: string
          enabled: boolean
          id: string
          input_schema: Json
          name: string
          phase: number
          requires_approval: boolean
          updated_at: string
        }
        Insert: {
          allowed_roles?: Database["public"]["Enums"]["app_role"][]
          category?: string
          created_at?: string
          description: string
          enabled?: boolean
          id?: string
          input_schema?: Json
          name: string
          phase?: number
          requires_approval?: boolean
          updated_at?: string
        }
        Update: {
          allowed_roles?: Database["public"]["Enums"]["app_role"][]
          category?: string
          created_at?: string
          description?: string
          enabled?: boolean
          id?: string
          input_schema?: Json
          name?: string
          phase?: number
          requires_approval?: boolean
          updated_at?: string
        }
        Relationships: []
      }
      user_credentials: {
        Row: {
          created_at: string
          created_by: string | null
          display_name: string | null
          id: string
          pin_hash: string | null
          short_id: string
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          created_by?: string | null
          display_name?: string | null
          id?: string
          pin_hash?: string | null
          short_id: string
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          created_by?: string | null
          display_name?: string | null
          id?: string
          pin_hash?: string | null
          short_id?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          created_at: string
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      delete_email: {
        Args: { message_id: number; queue_name: string }
        Returns: boolean
      }
      enqueue_email: {
        Args: { payload: Json; queue_name: string }
        Returns: number
      }
      generate_default_onboarding_checklist: {
        Args: { _employee_id: string; _role?: string }
        Returns: string
      }
      get_or_create_dm: { Args: { _other_user_id: string }; Returns: string }
      get_unread_conversation_counts: {
        Args: never
        Returns: {
          conversation_id: string
          unread_count: number
        }[]
      }
      get_user_roles: {
        Args: { _user_id: string }
        Returns: Database["public"]["Enums"]["app_role"][]
      }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      is_conversation_member: {
        Args: { _conversation_id: string; _user_id: string }
        Returns: boolean
      }
      mark_conversation_read: {
        Args: { _conversation_id: string }
        Returns: undefined
      }
      move_to_dlq: {
        Args: {
          dlq_name: string
          message_id: number
          payload: Json
          source_queue: string
        }
        Returns: number
      }
      read_email_batch: {
        Args: { batch_size: number; queue_name: string; vt: number }
        Returns: {
          message: Json
          msg_id: number
          read_ct: number
        }[]
      }
      short_id_exists: { Args: { _short_id: string }; Returns: boolean }
    }
    Enums: {
      app_role: "admin" | "staff" | "reviewer"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin", "staff", "reviewer"],
    },
  },
} as const
