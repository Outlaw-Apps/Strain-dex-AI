import { PRODUCT_TYPES } from "@/lib/constants";

export interface GeneratedDraftLike {
  descriptionShort?: string;
  descriptionLong?: string;
  sections?: Array<{
    fields?: Array<{
      label?: string;
      value?: string;
    }>;
  }>;
}

export interface IntakeAiSuggestions {
  name: string;
  strain: string;
  productType: string;
  vendor: string;
  thc: string;
  cbd: string;
  flavorProfile: string;
  aromaProfile: string;
  notes: string;
}

export interface CatalogAiUpdate {
  name: string;
  brand: string;
  strain: string;
  sku: string;
  packageSize: string;
  productType: string;
  type: string;
  thc: string;
  cbd: string;
  terpenes: string;
  aroma: string;
  taste: string;
  effects: string;
  medicalUses: string;
  shortDescription: string;
  longDescription: string;
}

const cleanValue = (value: string | null | undefined) => (value ?? "").trim();

function normalizeKey(value: string) {
  return cleanValue(value)
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, " ")
    .trim();
}

const PRODUCT_TYPE_ALIASES = new Map(
  PRODUCT_TYPES.flatMap((productType) => {
    const normalized = normalizeKey(productType);
    const aliases = [normalized];

    if (productType === "Pre roll") {
      aliases.push("pre roll", "pre rolls", "pre-roll", "pre-rolls", "preroll", "prerolls");
    }
    if (productType === "Vape (All in One)") {
      aliases.push("vape all in one", "all in one vape", "aio vape");
    }
    if (productType === "Vape Cartridge") {
      aliases.push("vape cart", "vape carts", "cartridge", "cartridges");
    }

    return aliases.map((alias) => [alias, productType] as const);
  }),
);

function buildFieldLookup(draft: GeneratedDraftLike | null | undefined) {
  const fieldMap = new Map<string, string>();
  if (!draft) {
    return fieldMap;
  }

  const sections = Array.isArray(draft.sections) ? draft.sections : [];
  for (const section of sections) {
    const fields = Array.isArray(section?.fields) ? section.fields : [];
    for (const field of fields) {
      const normalizedKey = normalizeKey(field?.label ?? "");
      const cleaned = cleanValue(field?.value);
      if (normalizedKey && cleaned) {
        fieldMap.set(normalizedKey, cleaned);
      }
    }
  }

  const shortDescription = cleanValue(draft.descriptionShort);
  const longDescription = cleanValue(draft.descriptionLong);
  if (shortDescription) {
    fieldMap.set(normalizeKey("Short Description"), shortDescription);
  }
  if (longDescription) {
    fieldMap.set(normalizeKey("Long Description"), longDescription);
  }

  return fieldMap;
}

function getFieldValue(fieldMap: Map<string, string>, ...labels: string[]) {
  for (const label of labels) {
    const value = fieldMap.get(normalizeKey(label));
    if (value) {
      return value;
    }
  }

  return "";
}

function joinDistinct(values: Array<string | null | undefined>, separator: string) {
  const distinct = new Map<string, string>();

  for (const value of values) {
    const cleaned = cleanValue(value);
    if (!cleaned) {
      continue;
    }

    const key = normalizeKey(cleaned);
    if (!distinct.has(key)) {
      distinct.set(key, cleaned);
    }
  }

  return Array.from(distinct.values()).join(separator);
}

export function normalizeProductType(value: string | null | undefined) {
  const cleaned = cleanValue(value);
  if (!cleaned) {
    return "";
  }

  const directMatch = PRODUCT_TYPES.find(
    (productType) => productType.toLowerCase() === cleaned.toLowerCase(),
  );
  if (directMatch) {
    return directMatch;
  }

  return PRODUCT_TYPE_ALIASES.get(normalizeKey(cleaned)) ?? cleaned;
}

export function buildIntakeAiSuggestionsFromDraft(
  draft: GeneratedDraftLike | null | undefined,
): IntakeAiSuggestions {
  const fieldMap = buildFieldLookup(draft);
  const effects = getFieldValue(fieldMap, "Effects");
  const onset = getFieldValue(fieldMap, "Onset");
  const medicalUses = getFieldValue(fieldMap, "Medical Uses", "May Help With");
  const terpenes = joinDistinct(
    [
      getFieldValue(fieldMap, "Dominant Terpenes"),
      getFieldValue(fieldMap, "Supporting Terpenes"),
    ],
    ", ",
  );

  return {
    name: getFieldValue(fieldMap, "Product Title", "Product Name"),
    strain: getFieldValue(fieldMap, "Strain Name", "Strain"),
    productType: normalizeProductType(getFieldValue(fieldMap, "Category", "Product Type")),
    vendor: getFieldValue(fieldMap, "Vendor"),
    thc: getFieldValue(fieldMap, "THC"),
    cbd: getFieldValue(fieldMap, "CBD"),
    flavorProfile: joinDistinct(
      [
        getFieldValue(fieldMap, "Taste Profile", "Flavor Profile"),
        getFieldValue(fieldMap, "Finish"),
      ],
      " - ",
    ),
    aromaProfile: joinDistinct(
      [
        getFieldValue(fieldMap, "Aroma Profile"),
        getFieldValue(fieldMap, "Aroma Notes"),
      ],
      " - ",
    ),
    notes: joinDistinct(
      [
        terpenes ? `Terpenes: ${terpenes}` : "",
        effects ? `Effects: ${effects}` : "",
        onset ? `Onset: ${onset}` : "",
        medicalUses ? `Reported uses: ${medicalUses}` : "",
      ],
      "\n",
    ),
  };
}

export function buildCatalogAiUpdateFromDraft(
  draft: GeneratedDraftLike | null | undefined,
): CatalogAiUpdate {
  const fieldMap = buildFieldLookup(draft);
  const productType = normalizeProductType(getFieldValue(fieldMap, "Category", "Product Type"));

  return {
    name: getFieldValue(fieldMap, "Product Title", "Product Name"),
    brand: getFieldValue(fieldMap, "Brand Name", "Brand"),
    strain: getFieldValue(fieldMap, "Strain Name", "Strain"),
    sku: getFieldValue(fieldMap, "SKU"),
    packageSize: getFieldValue(fieldMap, "Package", "Package Size"),
    productType,
    type: productType ? productType.toLowerCase() : "",
    thc: getFieldValue(fieldMap, "THC"),
    cbd: getFieldValue(fieldMap, "CBD"),
    terpenes: joinDistinct(
      [
        getFieldValue(fieldMap, "Dominant Terpenes"),
        getFieldValue(fieldMap, "Supporting Terpenes"),
      ],
      ", ",
    ),
    aroma: joinDistinct(
      [
        getFieldValue(fieldMap, "Aroma Profile"),
        getFieldValue(fieldMap, "Aroma Notes"),
      ],
      " - ",
    ),
    taste: joinDistinct(
      [
        getFieldValue(fieldMap, "Taste Profile", "Flavor Profile"),
        getFieldValue(fieldMap, "Finish"),
      ],
      " - ",
    ),
    effects: joinDistinct(
      [
        getFieldValue(fieldMap, "Effects"),
        getFieldValue(fieldMap, "Onset"),
      ],
      " - ",
    ),
    medicalUses: joinDistinct(
      [
        getFieldValue(fieldMap, "Medical Uses"),
        getFieldValue(fieldMap, "May Help With"),
      ],
      " - ",
    ),
    shortDescription: getFieldValue(fieldMap, "Short Description"),
    longDescription: getFieldValue(fieldMap, "Long Description"),
  };
}
