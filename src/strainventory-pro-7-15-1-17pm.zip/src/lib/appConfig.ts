export type AppEnvironment = "development" | "staging" | "production";

export interface AppConfig {
  environment: AppEnvironment;
  isProduction: boolean;
  isStaging: boolean;
  isDevelopment: boolean;
  supabaseUrl: string;
  supabasePublishableKey: string;
  edgeFunctionBaseUrl: string;
  /** Public site URL used for OAuth redirects, share links, emails. */
  siteUrl: string;
  /** Supabase Storage bucket for product images (env-scoped). */
  productImagesBucket: string;
  /** Supabase Storage bucket for employee avatars (env-scoped). */
  avatarsBucket: string;
  /** Optional Sentry/observability DSN. */
  sentryDsn: string;
  /** Build/release identifier surfaced in logs and error reports. */
  releaseTag: string;
}

declare global {
  interface Window {
    STRAINVENTORY_CONFIG?: Partial<AppConfig>;
  }
}

const runtimeConfig =
  typeof window !== "undefined" ? window.STRAINVENTORY_CONFIG : undefined;

const trimTrailingSlash = (value: string) => value.replace(/\/+$/, "");

const readConfigValue = (
  runtimeValue: string | undefined,
  envValue: string | undefined,
  fallback = "",
) => trimTrailingSlash(runtimeValue || envValue || fallback);

const readRaw = (
  runtimeValue: string | undefined,
  envValue: string | undefined,
  fallback = "",
) => runtimeValue || envValue || fallback;

const resolveEnvironment = (): AppEnvironment => {
  const raw = (
    runtimeConfig?.environment ||
    (import.meta.env.VITE_APP_ENV as string | undefined) ||
    (import.meta.env.MODE as string | undefined) ||
    "development"
  ).toLowerCase();

  if (raw === "production" || raw === "prod") return "production";
  if (raw === "staging" || raw === "stage" || raw === "preview") return "staging";
  return "development";
};

const environment = resolveEnvironment();

const supabaseUrl = readConfigValue(
  runtimeConfig?.supabaseUrl,
  import.meta.env.VITE_SUPABASE_URL as string | undefined,
);

const supabasePublishableKey = readRaw(
  runtimeConfig?.supabasePublishableKey,
  import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY as string | undefined,
);

const edgeFunctionBaseUrl = readConfigValue(
  runtimeConfig?.edgeFunctionBaseUrl,
  import.meta.env.VITE_EDGE_FUNCTION_BASE_URL as string | undefined,
  supabaseUrl ? `${supabaseUrl}/functions/v1` : "",
);

const defaultSiteUrl =
  typeof window !== "undefined" ? window.location.origin : "";

const siteUrl = readConfigValue(
  runtimeConfig?.siteUrl,
  import.meta.env.VITE_SITE_URL as string | undefined,
  defaultSiteUrl,
);

// Storage buckets are env-scoped so staging never writes to production assets.
const defaultProductBucket =
  environment === "production"
    ? "product-images"
    : environment === "staging"
      ? "product-images-staging"
      : "product-images";

const defaultAvatarsBucket =
  environment === "production"
    ? "avatars"
    : environment === "staging"
      ? "avatars-staging"
      : "avatars";

const productImagesBucket = readRaw(
  runtimeConfig?.productImagesBucket,
  import.meta.env.VITE_PRODUCT_IMAGES_BUCKET as string | undefined,
  defaultProductBucket,
);

const avatarsBucket = readRaw(
  runtimeConfig?.avatarsBucket,
  import.meta.env.VITE_AVATARS_BUCKET as string | undefined,
  defaultAvatarsBucket,
);

const sentryDsn = readRaw(
  runtimeConfig?.sentryDsn,
  import.meta.env.VITE_SENTRY_DSN as string | undefined,
);

const releaseTag = readRaw(
  runtimeConfig?.releaseTag,
  import.meta.env.VITE_RELEASE_TAG as string | undefined,
  "dev",
);

if (!supabaseUrl || !supabasePublishableKey) {
  console.error(
    "[StrainVentory] Missing required Supabase configuration. Set " +
      "VITE_SUPABASE_URL and VITE_SUPABASE_PUBLISHABLE_KEY, or provide " +
      "window.STRAINVENTORY_CONFIG before the app bundle loads.",
  );
}

export const appConfig: AppConfig = {
  environment,
  isProduction: environment === "production",
  isStaging: environment === "staging",
  isDevelopment: environment === "development",
  supabaseUrl,
  supabasePublishableKey,
  edgeFunctionBaseUrl,
  siteUrl,
  productImagesBucket,
  avatarsBucket,
  sentryDsn,
  releaseTag,
};
