// Appearance customization: persisted user preferences applied as CSS variables
// on <html>. Loaded once at startup (main.tsx) and updated live from Settings.

export type AccentPresetId =
  | "gold"
  | "emerald"
  | "indigo"
  | "rose"
  | "amber"
  | "cyan"
  | "violet"
  | "slate";

export type FontFamilyId = "dm-sans" | "inter" | "system-serif" | "mono";
export type FontScaleId = "compact" | "comfortable" | "large";

export interface AppearanceSettings {
  accent: AccentPresetId;
  brightness: number; // 80 - 120 (%)
  contrast: number; // 80 - 120 (%)
  fontFamily: FontFamilyId;
  fontScale: FontScaleId;
}

export const ACCENT_PRESETS: Record<
  AccentPresetId,
  { label: string; swatch: string; hsl: string; ring: string }
> = {
  gold: { label: "Royal Gold", swatch: "#d4a84c", hsl: "42 78% 46%", ring: "42 80% 48%" },
  emerald: { label: "Emerald", swatch: "#0d7a5f", hsl: "161 50% 26%", ring: "161 55% 32%" },
  indigo: { label: "Indigo", swatch: "#4f46e5", hsl: "239 84% 58%", ring: "239 84% 60%" },
  rose: { label: "Rose", swatch: "#e11d48", hsl: "350 84% 50%", ring: "350 84% 52%" },
  amber: { label: "Amber", swatch: "#f59e0b", hsl: "38 92% 50%", ring: "38 92% 52%" },
  cyan: { label: "Cyan", swatch: "#0891b2", hsl: "191 91% 36%", ring: "191 91% 40%" },
  violet: { label: "Violet", swatch: "#7c3aed", hsl: "262 83% 58%", ring: "262 83% 60%" },
  slate: { label: "Graphite", swatch: "#475569", hsl: "215 19% 35%", ring: "215 19% 42%" },
};

export const FONT_FAMILIES: Record<FontFamilyId, { label: string; stack: string }> = {
  "dm-sans": {
    label: "DM Sans (default)",
    stack: '"DM Sans", Inter, "Segoe UI", -apple-system, BlinkMacSystemFont, sans-serif',
  },
  inter: {
    label: "Inter",
    stack: 'Inter, "DM Sans", "Segoe UI", -apple-system, BlinkMacSystemFont, sans-serif',
  },
  "system-serif": {
    label: "System Serif",
    stack: '"Iowan Old Style", Georgia, "Times New Roman", ui-serif, serif',
  },
  mono: {
    label: "Mono",
    stack: '"Cascadia Mono", ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace',
  },
};

export const FONT_SCALES: Record<FontScaleId, { label: string; value: number }> = {
  compact: { label: "Compact", value: 0.9375 }, // 15px
  comfortable: { label: "Comfortable", value: 1 }, // 16px
  large: { label: "Large", value: 1.125 }, // 18px
};

export const DEFAULT_APPEARANCE: AppearanceSettings = {
  accent: "gold",
  brightness: 100,
  contrast: 100,
  fontFamily: "dm-sans",
  fontScale: "comfortable",
};

const STORAGE_KEY = "strain-ventory:appearance:v1";

export function loadAppearance(): AppearanceSettings {
  if (typeof window === "undefined") return DEFAULT_APPEARANCE;
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return DEFAULT_APPEARANCE;
    const parsed = JSON.parse(raw) as Partial<AppearanceSettings>;
    return { ...DEFAULT_APPEARANCE, ...parsed };
  } catch {
    return DEFAULT_APPEARANCE;
  }
}

export function saveAppearance(s: AppearanceSettings) {
  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(s));
  } catch {
    // ignore quota / privacy errors
  }
}

export function applyAppearance(s: AppearanceSettings) {
  if (typeof document === "undefined") return;
  const root = document.documentElement;

  // Accent + ring tokens (override design system accent in both light + dark)
  const preset = ACCENT_PRESETS[s.accent] ?? ACCENT_PRESETS.gold;
  root.style.setProperty("--accent", preset.hsl);
  root.style.setProperty("--ring", preset.ring);
  root.style.setProperty("--sidebar-ring", preset.ring);

  // Typography
  const family = FONT_FAMILIES[s.fontFamily] ?? FONT_FAMILIES["dm-sans"];
  root.style.setProperty("--font-body", family.stack);
  root.style.setProperty("--font-sans", family.stack);

  const scale = FONT_SCALES[s.fontScale]?.value ?? 1;
  root.style.fontSize = `${scale * 100}%`;

  // Brightness / contrast — applied to body to avoid filtering the html
  // background fallback. Guarded for SSR by the document check above.
  const body = document.body;
  if (body) {
    body.style.filter =
      s.brightness === 100 && s.contrast === 100
        ? ""
        : `brightness(${s.brightness}%) contrast(${s.contrast}%)`;
  }
}

const EVENT = "strain-ventory:appearance-change";

export function emitAppearanceChange(s: AppearanceSettings) {
  window.dispatchEvent(new CustomEvent<AppearanceSettings>(EVENT, { detail: s }));
}

export function onAppearanceChange(cb: (s: AppearanceSettings) => void) {
  const handler = (e: Event) => cb((e as CustomEvent<AppearanceSettings>).detail);
  window.addEventListener(EVENT, handler);
  return () => window.removeEventListener(EVENT, handler);
}
