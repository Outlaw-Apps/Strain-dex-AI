import type { Json } from "@/integrations/supabase/types";

export const ASSISTANT_ROUTE_SUMMARY = [
  "/",
  "/auth",
  "/product-intake",
  "/ai-draft",
  "/image-finder",
  "/catalog",
  "/catalog/:id",
  "/bulk-intake",
  "/review",
  "/assistant",
  "/messages",
  "/pos",
  "/shift-close",
  "/settings",
  "/onboarding",
  "/payroll",
  "/payroll/run",
  "/vinny-preview",
] as const;

const EXACT_ROUTES = new Set<string>([
  "/",
  "/auth",
  "/product-intake",
  "/ai-draft",
  "/image-finder",
  "/catalog",
  "/bulk-intake",
  "/review",
  "/assistant",
  "/messages",
  "/pos",
  "/shift-close",
  "/settings",
  "/onboarding",
  "/payroll",
  "/payroll/run",
  "/vinny-preview",
]);

const ROUTE_ALIASES = new Map<string, string>([
  ["/home", "/"],
  ["/dashboard", "/"],
  ["/sign-in", "/auth"],
  ["/login", "/auth"],
  ["/intake", "/product-intake"],
  ["/product", "/catalog"],
  ["/products", "/catalog"],
  ["/product-detail", "/catalog"],
  ["/product-details", "/catalog"],
  ["/inventory", "/catalog"],
  ["/vault", "/catalog"],
  ["/ai", "/assistant"],
  ["/ai-assistant", "/assistant"],
  ["/chat", "/assistant"],
  ["/copilot", "/assistant"],
  ["/draft", "/ai-draft"],
  ["/ai-drafts", "/ai-draft"],
  ["/preview", "/vinny-preview"],
  ["/vinny", "/vinny-preview"],
  ["/images", "/image-finder"],
  ["/photos", "/image-finder"],
  ["/review-workspace", "/review"],
  ["/approve", "/review"],
  ["/approval", "/review"],
  ["/approvals", "/review"],
  ["/checkout", "/pos"],
  ["/sales", "/shift-close"],
  ["/sales-report", "/shift-close"],
  ["/reports", "/shift-close"],
  ["/performance", "/shift-close"],
  ["/employees", "/onboarding"],
  ["/employee-onboarding", "/onboarding"],
  ["/payroll-run", "/payroll/run"],
  ["/admin", "/settings"],
  ["/authorize", "/settings"],
  ["/authorization", "/settings"],
  ["/consent", "/settings"],
]);

const CATALOG_ALIASES_WITH_ID = [
  /^\/products\/([^/?#]+)/i,
  /^\/product\/([^/?#]+)/i,
  /^\/product-detail\/([^/?#]+)/i,
  /^\/product-details\/([^/?#]+)/i,
] as const;

const getPayloadString = (payload: Record<string, unknown>, key: string) => {
  const value = payload[key];
  return typeof value === "string" && value.trim() ? value.trim() : "";
};

const asInternalPath = (route: string) => {
  const trimmed = route.trim();
  if (!trimmed) return "";

  if (/^https?:\/\//i.test(trimmed)) {
    try {
      const parsed = new URL(trimmed);
      const sameOrigin =
        typeof window !== "undefined" && parsed.origin === window.location.origin;
      if (!sameOrigin) return "";
      if (parsed.hash.startsWith("#/")) return parsed.hash.slice(1);
      return `${parsed.pathname}${parsed.search}${parsed.hash}`;
    } catch {
      return "";
    }
  }

  if (trimmed.startsWith("#/")) return trimmed.slice(1);
  return trimmed.startsWith("/") ? trimmed : `/${trimmed}`;
};

export function resolveAssistantRoute(
  rawRoute: unknown,
  payload: Record<string, unknown> = {},
): string | null {
  if (typeof rawRoute !== "string") return null;

  const internalPath = asInternalPath(rawRoute);
  if (!internalPath) return null;

  const [pathname] = internalPath.split(/[?#]/, 1);
  const lowerPath = pathname.toLowerCase().replace(/\/+$/, "") || "/";
  const productId = getPayloadString(payload, "product_id") || getPayloadString(payload, "id");

  if (ROUTE_ALIASES.has(lowerPath)) {
    const route = ROUTE_ALIASES.get(lowerPath);
    if (route === "/catalog" && productId) return `/catalog/${encodeURIComponent(productId)}`;
    return route ?? null;
  }

  for (const pattern of CATALOG_ALIASES_WITH_ID) {
    const match = lowerPath.match(pattern);
    if (match?.[1]) return `/catalog/${encodeURIComponent(match[1])}`;
  }

  if (EXACT_ROUTES.has(lowerPath)) return lowerPath;
  if (/^\/catalog\/[^/?#]+$/i.test(pathname)) return lowerPath;

  return null;
}

export function resolveAssistantActionRoute(
  intent: string,
  payload: Record<string, unknown> = {},
): string | null {
  const route = resolveAssistantRoute(payload.route, payload);
  if (route) return route;

  const normalizedIntent = intent.toLowerCase();
  const productId = getPayloadString(payload, "product_id") || getPayloadString(payload, "id");

  if (normalizedIntent.includes("intake")) return "/product-intake";
  if (normalizedIntent.includes("draft")) return "/ai-draft";
  if (normalizedIntent.includes("review") || normalizedIntent.includes("approve")) return "/review";
  if (normalizedIntent.includes("image") || normalizedIntent.includes("photo")) return "/image-finder";
  if (
    normalizedIntent.includes("catalog") ||
    normalizedIntent.includes("product") ||
    normalizedIntent.includes("inventory") ||
    normalizedIntent.includes("vault")
  ) {
    return productId ? `/catalog/${encodeURIComponent(productId)}` : "/catalog";
  }
  if (
    normalizedIntent.includes("pos") ||
    normalizedIntent.includes("checkout") ||
    normalizedIntent.includes("cart")
  ) {
    return "/pos";
  }
  if (
    normalizedIntent.includes("sales") ||
    normalizedIntent.includes("report") ||
    normalizedIntent.includes("performance") ||
    normalizedIntent.includes("shift")
  ) {
    return "/shift-close";
  }
  if (normalizedIntent.includes("payroll")) return "/payroll";
  if (normalizedIntent.includes("employee") || normalizedIntent.includes("onboarding")) return "/onboarding";
  if (
    normalizedIntent.includes("setting") ||
    normalizedIntent.includes("authorize") ||
    normalizedIntent.includes("authorization") ||
    normalizedIntent.includes("consent")
  ) {
    return "/settings";
  }
  if (normalizedIntent.includes("assistant") || normalizedIntent.includes("chat")) return "/assistant";
  if (normalizedIntent.includes("login") || normalizedIntent.includes("sign in")) return "/auth";
  if (normalizedIntent.includes("message")) return "/messages";

  return null;
}

export function safeExternalUrl(value: unknown): string | null {
  if (typeof value !== "string" || !value.trim()) return null;
  try {
    const url = new URL(value.trim());
    return url.protocol === "https:" || url.protocol === "http:" ? url.toString() : null;
  } catch {
    return null;
  }
}

export function createDownloadFromPayload(payload: Record<string, unknown>): boolean {
  const fileValue = payload.file;
  const file =
    fileValue && typeof fileValue === "object" && !Array.isArray(fileValue)
      ? (fileValue as Record<string, unknown>)
      : null;
  const content =
    file && typeof file.content === "string"
      ? file.content
      : typeof payload.download_text === "string"
        ? payload.download_text
        : "";

  if (!content) return false;

  const filename =
    file && typeof file.filename === "string" && file.filename.trim()
      ? file.filename.trim()
      : typeof payload.filename === "string" && payload.filename.trim()
        ? payload.filename.trim()
      : "strain-vinny-export.txt";
  const mimeType =
    file && typeof file.mime_type === "string" && file.mime_type.trim()
      ? file.mime_type.trim()
      : typeof payload.mime_type === "string" && payload.mime_type.trim()
        ? payload.mime_type.trim()
      : "text/plain;charset=utf-8";
  const blob = new Blob([content], { type: mimeType });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  link.click();
  URL.revokeObjectURL(url);
  return true;
}

const waitForVideoReady = async (video: HTMLVideoElement) => {
  if (video.readyState >= HTMLMediaElement.HAVE_CURRENT_DATA && video.videoWidth > 0 && video.videoHeight > 0) {
    return;
  }

  await new Promise<void>((resolve, reject) => {
    let settled = false;

    const settle = (error?: Error) => {
      if (settled) return;
      settled = true;
      clearTimeout(timeoutId);
      video.removeEventListener("loadeddata", onReady);
      if (error) reject(error);
      else resolve();
    };

    const onReady = () => {
      if (video.videoWidth > 0 && video.videoHeight > 0) {
        settle();
      }
    };

    const timeoutId = setTimeout(() => {
      settle(new Error("Screen capture video did not become ready in time."));
    }, 5000);
    video.addEventListener("loadeddata", onReady, { once: true });
  });
};

export async function captureScreenDownload(filename = "strain-vinny-screenshot.png") {
  if (!navigator.mediaDevices?.getDisplayMedia) {
    throw new Error("Screen capture is not available in this browser.");
  }

  const stream = await navigator.mediaDevices.getDisplayMedia({ video: true });
  try {
    const video = document.createElement("video");
    video.srcObject = stream;
    video.muted = true;
    await video.play();
    await waitForVideoReady(video);

    const canvas = document.createElement("canvas");
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    const context = canvas.getContext("2d");
    if (!context) throw new Error("Unable to prepare screenshot canvas.");
    context.drawImage(video, 0, 0, canvas.width, canvas.height);

    const blob = await new Promise<Blob>((resolve, reject) => {
      canvas.toBlob((result) => {
        if (result) resolve(result);
        else reject(new Error("Unable to create screenshot file."));
      }, "image/png");
    });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = filename;
    link.click();
    URL.revokeObjectURL(url);
  } finally {
    stream.getTracks().forEach((track) => track.stop());
  }
}

export function jsonToRecord(value: Json | undefined): Record<string, unknown> {
  return value && typeof value === "object" && !Array.isArray(value)
    ? (value as Record<string, unknown>)
    : {};
}
