import type { AssistantPageContext } from "@/types/assistant";

const CONTEXT_MAP: Array<{ pattern: RegExp; context: AssistantPageContext }> = [
  {
    pattern: /^\/product-intake/,
    context: {
      id: "product_intake",
      title: "Product Intake",
      description: "Capture compliant intake details, identify missing fields, and prep clean records for drafting.",
    },
  },
  {
    pattern: /^\/ai-draft/,
    context: {
      id: "ai_draft",
      title: "AI Draft",
      description: "Generate structured draft copy and section-level metadata for cannabis products.",
    },
  },
  {
    pattern: /^\/image-finder/,
    context: {
      id: "image_finder",
      title: "Image Finder",
      description: "Find high-confidence product imagery and avoid generic strain photos.",
    },
  },
  {
    pattern: /^\/review/,
    context: {
      id: "review_workspace",
      title: "Review Workspace",
      description: "Refine AI-generated copy, verify claims, and prepare final publishable catalog entries.",
    },
  },
  {
    pattern: /^\/catalog/,
    context: {
      id: "catalog",
      title: "Catalog",
      description: "Manage published products, inventory details, and consistency across listings.",
    },
  },
  {
    pattern: /^\/pos|^\/shift-close/,
    context: {
      id: "pos",
      title: "Point of Sale",
      description: "Support frontline checkout operations, daily reconciliation, and customer-safe recommendations.",
    },
  },
];

const DEFAULT_CONTEXT: AssistantPageContext = {
  id: "general",
  title: "General Workspace",
  description: "Provide operational guidance across intake, drafting, catalog, and POS workflows.",
};

export function resolveAssistantPageContext(pathname: string): AssistantPageContext {
  const match = CONTEXT_MAP.find((entry) => entry.pattern.test(pathname));
  return match?.context ?? DEFAULT_CONTEXT;
}

