export type AssistantFailureKind = "auth" | "lock_contention" | "generation_failure";

export interface AssistantErrorDescription {
  kind: AssistantFailureKind;
  toastMessage: string;
  recoveryMessage?: string;
  shouldAttemptHistoryRecovery: boolean;
  severity: "error" | "warning";
}

interface AssistantErrorOptions {
  assistantReplyReceived: boolean;
  isAuthError: boolean;
}

export const ASSISTANT_HISTORY_LOCK_NOTICE =
  "Assistant history is busy syncing in Supabase. Your reply is preserved on screen; recent threads may refresh on the next try.";

function readStringField(value: unknown, key: string): string {
  return value && typeof value === "object" && key in value
    ? String((value as Record<string, unknown>)[key] ?? "")
    : "";
}

function readNestedError(value: unknown, key: string): unknown {
  return value && typeof value === "object" && key in value
    ? (value as Record<string, unknown>)[key]
    : undefined;
}

export function isSupabaseLockAcquireError(error: unknown, depth = 0): boolean {
  if (!error || depth > 3) return false;

  const name = readStringField(error, "name");
  const message = error instanceof Error
    ? error.message
    : readStringField(error, "message");
  const isAcquireTimeout =
    typeof error === "object" &&
    "isAcquireTimeout" in error &&
    (error as { isAcquireTimeout?: unknown }).isAcquireTimeout === true;

  if (isAcquireTimeout) return true;
  if (/LockAcquireTimeoutError/i.test(name) || /SupabaseAuthLockAcquireTimeoutError/i.test(name)) {
    return true;
  }
  if (/LockAcquireTimeoutError/i.test(message)) return true;
  if (/navigator\.locks/i.test(message) && /timeout|timed out|acquire/i.test(message)) {
    return true;
  }
  if (/Supabase auth lock/i.test(message) && /timeout|timed out/i.test(message)) {
    return true;
  }

  return [
    readNestedError(error, "cause"),
    readNestedError(error, "error"),
    readNestedError(error, "context"),
  ].some((nested) => isSupabaseLockAcquireError(nested, depth + 1));
}

export function describeAssistantError(
  error: unknown,
  options: AssistantErrorOptions,
): AssistantErrorDescription {
  if (options.isAuthError) {
    return {
      kind: "auth",
      toastMessage: "Your session may have expired. Please sign in again and retry.",
      recoveryMessage: "Your session may have expired. Please sign in again and retry.",
      shouldAttemptHistoryRecovery: false,
      severity: "error",
    };
  }

  if (isSupabaseLockAcquireError(error)) {
    return {
      kind: "lock_contention",
      toastMessage: ASSISTANT_HISTORY_LOCK_NOTICE,
      recoveryMessage: options.assistantReplyReceived
        ? undefined
        : "Supabase history is busy syncing, so I could not refresh this assistant thread yet. Your message is still on screen; retry in a moment.",
      shouldAttemptHistoryRecovery: false,
      severity: "warning",
    };
  }

  const message = error instanceof Error ? error.message : "Assistant request failed";
  return {
    kind: "generation_failure",
    toastMessage: message,
    recoveryMessage:
      "I hit an issue reaching the assistant service. Please retry, and I'll continue from your current workflow context.",
    shouldAttemptHistoryRecovery: true,
    severity: "error",
  };
}
