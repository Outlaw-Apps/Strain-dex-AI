import type { Json } from "@/integrations/supabase/types";
import type {
  AssistantActionEnvelope,
  AssistantAudienceRole,
  AssistantMessage,
  AssistantMessageRecord,
  AssistantSourceCitation,
  AssistantThreadRecord,
} from "@/types/assistant";

export const NEW_ASSISTANT_THREAD_VALUE = "__new_thread__";

const ASSISTANT_WELCOME_COPY =
  "Strain Vinny is online. I can recommend next steps for intake, drafting, imagery, review, and operations.";

function isActionEnvelope(value: unknown): value is AssistantActionEnvelope {
  if (!value || typeof value !== "object" || Array.isArray(value)) {
    return false;
  }

  const candidate = value as Record<string, unknown>;

  return (
    typeof candidate.intent === "string" &&
    typeof candidate.summary === "string" &&
    Array.isArray(candidate.proposed_changes) &&
    typeof candidate.requires_confirmation === "boolean" &&
    candidate.execution_payload !== undefined
  );
}

function isSourceCitation(value: unknown): value is AssistantSourceCitation {
  if (!value || typeof value !== "object" || Array.isArray(value)) {
    return false;
  }

  const candidate = value as Record<string, unknown>;
  return (
    typeof candidate.source === "string" &&
    typeof candidate.domain === "string" &&
    typeof candidate.url === "string" &&
    typeof candidate.title === "string"
  );
}

export function extractAssistantActions(value: Json): AssistantActionEnvelope[] {
  if (!value || typeof value !== "object" || Array.isArray(value)) {
    return [];
  }

  const actions = (value as Record<string, Json>).actions;
  if (!Array.isArray(actions)) {
    return [];
  }

  return actions.filter(isActionEnvelope) as unknown as AssistantActionEnvelope[];
}

export function extractAssistantSources(value: Json): AssistantSourceCitation[] {
  if (!value || typeof value !== "object" || Array.isArray(value)) {
    return [];
  }

  const sources = (value as Record<string, Json>).sources;
  if (!Array.isArray(sources)) {
    return [];
  }

  return (sources as unknown[]).filter(isSourceCitation);
}

export function createWelcomeAssistantMessage(): AssistantMessage {
  return {
    id: "assistant-welcome",
    role: "assistant",
    content: ASSISTANT_WELCOME_COPY,
    createdAt: new Date().toISOString(),
  };
}

export function mapStoredAssistantMessages(messages: AssistantMessageRecord[]): AssistantMessage[] {
  if (messages.length === 0) {
    return [createWelcomeAssistantMessage()];
  }

  return messages.map((message) => {
    const role: AssistantMessage["role"] = message.role === "assistant" ? "assistant" : "user";
    return {
      id: message.id,
      role,
      content: message.content,
      createdAt: message.created_at,
      actions: role === "assistant" ? extractAssistantActions(message.context) : undefined,
      sources: role === "assistant" ? extractAssistantSources(message.context) : undefined,
    };
  });
}

export interface AssistantThreadOption {
  id: string;
  title: string;
  audienceRole: AssistantAudienceRole;
  updatedAt: string;
}

function readPageContextTitle(pageContext: Json): string | undefined {
  if (!pageContext || typeof pageContext !== "object" || Array.isArray(pageContext)) {
    return undefined;
  }

  const title = (pageContext as Record<string, Json>).title;
  return typeof title === "string" ? title : undefined;
}

const ASSISTANT_AUDIENCE_ROLES: readonly AssistantAudienceRole[] = ["employee", "vendor", "management"];

function coerceAudienceRole(value: string): AssistantAudienceRole {
  return (ASSISTANT_AUDIENCE_ROLES as readonly string[]).includes(value)
    ? (value as AssistantAudienceRole)
    : "employee";
}

export function toAssistantThreadOption(thread: AssistantThreadRecord): AssistantThreadOption {
  return {
    id: thread.id,
    title: thread.title || readPageContextTitle(thread.page_context) || "Assistant Thread",
    audienceRole: coerceAudienceRole(thread.audience_role),
    updatedAt: thread.updated_at,
  };
}
