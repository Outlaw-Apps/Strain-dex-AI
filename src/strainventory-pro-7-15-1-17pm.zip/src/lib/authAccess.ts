const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export function normalizeAuthEmail(email: string) {
  return email.trim().toLowerCase();
}

export function getEmailActionState(email: string) {
  const normalizedEmail = normalizeAuthEmail(email);

  if (!normalizedEmail) {
    return {
      canSubmit: false,
      helperText: "Enter your email address to continue.",
    };
  }

  if (!EMAIL_PATTERN.test(normalizedEmail)) {
    return {
      canSubmit: false,
      helperText: "Enter a valid email address.",
    };
  }

  return {
    canSubmit: true,
    helperText: "We'll use this email for sign-in or recovery.",
  };
}

const PASSWORD_STRENGTH_LABELS = ["Add a password", "Weak", "Fair", "Good", "Strong"] as const;

export function getPasswordStrength(password: string) {
  if (!password) {
    return {
      score: 0,
      label: PASSWORD_STRENGTH_LABELS[0],
    };
  }

  let score = password.length >= 8 ? 1 : 0;

  if (/[a-z]/.test(password) && /[A-Z]/.test(password)) {
    score += 1;
  }

  if (/\d/.test(password)) {
    score += 1;
  }

  if (/[^A-Za-z0-9]/.test(password)) {
    score += 1;
  }

  const normalizedScore = Math.max(1, Math.min(score, 4));

  return {
    score: normalizedScore,
    label: PASSWORD_STRENGTH_LABELS[normalizedScore],
  };
}
