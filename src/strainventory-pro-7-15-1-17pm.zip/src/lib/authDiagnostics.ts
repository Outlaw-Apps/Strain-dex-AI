// Lightweight in-memory auth diagnostics log.
// Records each auth step (sign-in, magic link, reset, PIN) with status,
// duration, and — when things go wrong — a human-readable hint.

export type AuthDiagStatus = "pending" | "success" | "error";

export type AuthDiagStep =
  | "email-signin"
  | "email-signup"
  | "pin-signin"
  | "magic-link"
  | "password-reset";

export interface AuthDiagEntry {
  id: string;
  step: AuthDiagStep;
  status: AuthDiagStatus;
  startedAt: number;
  finishedAt?: number;
  durationMs?: number;
  message?: string;
  hint?: string;
  meta?: Record<string, unknown>;
}

const STEP_LABELS: Record<AuthDiagStep, string> = {
  "email-signin": "Sign in with email",
  "email-signup": "Create account",
  "pin-signin": "Sign in with ID + PIN",
  "magic-link": "Send magic link",
  "password-reset": "Request password reset",
};

export function labelForStep(step: AuthDiagStep): string {
  return STEP_LABELS[step];
}

const MAX_ENTRIES = 25;
type Listener = (entries: AuthDiagEntry[]) => void;

let entries: AuthDiagEntry[] = [];
const listeners = new Set<Listener>();

function emit() {
  const snapshot = entries.slice();
  listeners.forEach((l) => l(snapshot));
}

export function subscribeAuthDiagnostics(listener: Listener): () => void {
  listeners.add(listener);
  listener(entries.slice());
  return () => {
    listeners.delete(listener);
  };
}

export function getAuthDiagnostics(): AuthDiagEntry[] {
  return entries.slice();
}

export function clearAuthDiagnostics(): void {
  entries = [];
  emit();
}

function makeId(): string {
  return `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
}

/**
 * Try to translate a raw error into an actionable hint the user can act on.
 * Deliberately conservative — only pattern-matches well-known messages.
 */
export function hintForError(raw: string | undefined): string | undefined {
  if (!raw) return undefined;
  const msg = raw.toLowerCase();

  if (msg.includes("failed to fetch") || msg.includes("networkerror") || msg.includes("load failed")) {
    const inPreview =
      typeof window !== "undefined" && /lovable(project|\.app)/i.test(window.location.hostname);
    if (inPreview) {
      return "The Lovable preview proxy sometimes blocks auth POSTs. Try Publish → sign in on the .lovable.app URL, or run locally.";
    }
    return "Network request failed. Check your connection, VPN, ad-blockers, and any browser extensions that filter requests.";
  }

  if (msg.includes("invalid login credentials")) {
    return "Email/password didn't match. Use “Reset password” if you're unsure.";
  }
  if (msg.includes("email not confirmed")) {
    return "Confirm your email from the verification message, then try again.";
  }
  if (msg.includes("email rate limit") || msg.includes("over_email_send_rate_limit")) {
    return "Too many auth emails sent recently. Wait a few minutes before retrying.";
  }
  if (msg.includes("user already registered")) {
    return "This email is already registered — switch to Sign In.";
  }
  if (msg.includes("signups not allowed") || msg.includes("signup is disabled")) {
    return "New sign-ups are disabled. Ask an admin to invite you.";
  }
  if (msg.includes("token") && msg.includes("expired")) {
    return "The recovery link expired. Request a new password reset email.";
  }
  return undefined;
}

export function startAuthStep(step: AuthDiagStep, meta?: Record<string, unknown>): string {
  const id = makeId();
  const entry: AuthDiagEntry = {
    id,
    step,
    status: "pending",
    startedAt: Date.now(),
    meta,
  };
  entries = [entry, ...entries].slice(0, MAX_ENTRIES);
  emit();
  return id;
}

function finish(id: string, patch: Partial<AuthDiagEntry>) {
  const now = Date.now();
  entries = entries.map((e) => {
    if (e.id !== id) return e;
    return {
      ...e,
      ...patch,
      finishedAt: now,
      durationMs: now - e.startedAt,
    };
  });
  emit();
}

export function completeAuthStep(id: string, message?: string): void {
  finish(id, { status: "success", message });
}

export function failAuthStep(id: string, error: unknown): void {
  const message =
    error instanceof Error
      ? error.message
      : typeof error === "string"
        ? error
        : error && typeof error === "object" && "message" in error
          ? String((error as { message: unknown }).message)
          : "Unknown error";
  finish(id, { status: "error", message, hint: hintForError(message) });
}
