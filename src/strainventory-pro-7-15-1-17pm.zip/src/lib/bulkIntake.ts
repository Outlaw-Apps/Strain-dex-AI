import type { TablesInsert } from "@/integrations/supabase/types";

export interface ParsedProduct {
  strain: string;
  brand: string;
  details: string;
  productType: string;
  packageSize: string;
  productName?: string;
  thc?: string;
  cbd?: string;
  description?: string;
}

const productTypeMatchers: Array<{ type: string; patterns: RegExp[] }> = [
  { type: "flower", patterns: [/\bflower\b/i, /\bbud(s)?\b/i] },
  { type: "pre-roll", patterns: [/\bpre[ -]?roll\b/i, /\bjoint(s)?\b/i] },
  { type: "vape-cartridge", patterns: [/\bvape\b/i, /\bcart(ridge)?\b/i, /\bpod\b/i] },
  { type: "concentrate", patterns: [/\bconcentrate\b/i, /\bbadder\b/i, /\bshatter\b/i, /\bhash\b/i] },
  { type: "wax", patterns: [/\bwax\b/i] },
  { type: "live-resin", patterns: [/\blive resin\b/i] },
  { type: "edible", patterns: [/\bedible\b/i, /\bgumm(y|ies)\b/i, /\bchocolate\b/i, /\bmint(s)?\b/i] },
  { type: "tincture", patterns: [/\btincture\b/i, /\bdrops?\b/i] },
  { type: "topical", patterns: [/\btopical\b/i, /\bcream\b/i, /\bbalm\b/i, /\blotion\b/i] },
];

const headerTokens = ["strain", "brand", "details", "description", "product", "package", "type", "thc", "cbd"];

type HeaderField =
  | "productName"
  | "strain"
  | "brand"
  | "productType"
  | "packageSize"
  | "thc"
  | "cbd"
  | "description";

const headerFieldAliases: Record<string, HeaderField> = {
  product_name: "productName",
  product: "productName",
  name: "productName",
  strain: "strain",
  brand: "brand",
  product_type: "productType",
  type: "productType",
  package: "packageSize",
  package_size: "packageSize",
  size: "packageSize",
  thc: "thc",
  thc_percent: "thc",
  cbd: "cbd",
  cbd_percent: "cbd",
  description: "description",
  details: "description",
};

const splitCsvLine = (line: string) => {
  const values: string[] = [];
  let current = "";
  let inQuotes = false;

  for (let index = 0; index < line.length; index += 1) {
    const char = line[index];
    const nextChar = line[index + 1];

    if (char === "\"") {
      if (inQuotes && nextChar === "\"") {
        current += "\"";
        index += 1;
      } else {
        inQuotes = !inQuotes;
      }
      continue;
    }

    if (char === "," && !inQuotes) {
      values.push(current.trim());
      current = "";
      continue;
    }

    current += char;
  }

  values.push(current.trim());
  return values;
};

const normalizeHeader = (value: string) =>
  value
    .toLowerCase()
    .replace(/%/g, "_percent")
    .replace(/[^a-z0-9]+/g, "_")
    .replace(/^_+|_+$/g, "");

const getHeaderFields = (row: string[]) =>
  row.reduce<Partial<Record<HeaderField, number>>>((fields, cell, index) => {
    const field = headerFieldAliases[normalizeHeader(cell)];
    if (field) {
      fields[field] = index;
    }
    return fields;
  }, {});

const MIN_HEADER_FIELD_MATCHES = 2;

const normalizeHeaderToken = (value: string) => normalizeHeader(value).replace(/_/g, " ");

const isLikelyHeader = (row: string[]) => {
  const matchedHeaderFields = Object.keys(getHeaderFields(row)).length;
  if (matchedHeaderFields >= MIN_HEADER_FIELD_MATCHES) {
    return true;
  }

  if (matchedHeaderFields === 0) {
    return false;
  }

  const normalizedTokens = new Set(headerTokens.map(normalizeHeaderToken));
  return row.some((cell) => normalizedTokens.has(normalizeHeaderToken(cell)));
};
const inferProductType = (details: string) => {
  for (const matcher of productTypeMatchers) {
    if (matcher.patterns.some((pattern) => pattern.test(details))) {
      return matcher.type;
    }
  }

  return "other";
};

const extractPackageSize = (details: string) => {
  const match = details.match(/\b\d+(?:\.\d+)?\s?(?:g|mg|kg|ml|oz|lb|pk|pack|ct)\b/i);
  return match?.[0] ?? "";
};

const humanizeProductType = (productType: string) =>
  productType
    .split("-")
    .filter(Boolean)
    .map((part) => part.charAt(0).toUpperCase() + part.slice(1))
    .join(" ");

const normalizeField = (value: string) => value.replace(/\s+/g, " ").trim();

const normalizeProductType = (value: string) => {
  const normalized = normalizeField(value);
  if (!normalized) return "";

  const inferred = inferProductType(normalized);
  if (inferred !== "other") {
    return inferred;
  }

  return normalized
    .toLowerCase()
    .replace(/&/g, " and ")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");
};

const joinDetails = (values: Array<string | undefined>) =>
  normalizeField(values.filter(Boolean).join(" · "));

const parseStructuredRow = (
  parts: string[],
  headerFields: Partial<Record<HeaderField, number>>,
): ParsedProduct => {
  const productName = normalizeField(parts[headerFields.productName ?? headerFields.strain ?? -1] ?? "");
  const strain = normalizeField(parts[headerFields.strain ?? headerFields.productName ?? -1] ?? "");
  const brand = normalizeField(parts[headerFields.brand ?? -1] ?? "");
  const description = normalizeField(parts[headerFields.description ?? -1] ?? "");
  const thc = normalizeField(parts[headerFields.thc ?? -1] ?? "");
  const cbd = normalizeField(parts[headerFields.cbd ?? -1] ?? "");
  const rawProductType = normalizeField(parts[headerFields.productType ?? -1] ?? "");
  const details = joinDetails([
    description,
    thc ? `THC ${thc}` : "",
    cbd ? `CBD ${cbd}` : "",
  ]);
  const combinedText = normalizeField([productName, description, details].filter(Boolean).join(" "));
  const packageSize = normalizeField(parts[headerFields.packageSize ?? -1] ?? "") || extractPackageSize(combinedText);
  const productType = normalizeProductType(rawProductType) || inferProductType(combinedText);

  return {
    strain: strain || productName,
    brand,
    details,
    productType,
    packageSize,
    productName: productName || strain,
    thc,
    cbd,
    description,
  };
};

const parseLegacyRow = (parts: string[]): ParsedProduct => {
  const strain = normalizeField(parts[0] ?? "");
  const brand = normalizeField(parts[1] ?? "");
  const details = normalizeField(parts.slice(2).join(", "));
  const packageSize = extractPackageSize(details);
  const productType = inferProductType(details);

  return { strain, brand, details, productType, packageSize };
};

export const parseBulkIntakeText = (text: string): ParsedProduct[] => {
  const rows = text
    .replace(/\r\n?/g, "\n")
    .split("\n")
    .map((line) => line.trim())
    .filter(Boolean)
    .map(splitCsvLine);

  const hasRows = rows.length > 0;
  const headerFields = hasRows ? getHeaderFields(rows[0]) : {};
  const hasHeader = hasRows && isLikelyHeader(rows[0]);
  const hasStructuredHeader = ["productName", "productType", "packageSize", "thc", "cbd"].some(
    (field) => headerFields[field as HeaderField] !== undefined,
  );
  const dataRows = hasHeader ? rows.slice(1) : rows;

  return dataRows
    .map((parts) => (hasStructuredHeader ? parseStructuredRow(parts, headerFields) : parseLegacyRow(parts)))
    .filter((product) => product.productName || product.strain || product.brand || product.details || product.description);
};

const buildProductName = (product: ParsedProduct) => {
  if (product.productName) {
    return product.productName;
  }

  const parts = [
    product.strain,
    product.packageSize,
    product.productType !== "other" ? humanizeProductType(product.productType) : "",
  ].filter(Boolean);

  if (parts.length > 0) {
    return parts.join(" ");
  }

  return normalizeField([product.brand, product.details].filter(Boolean).join(" ")) || "Untitled Product";
};

const buildConfidenceScore = (product: ParsedProduct) => {
  const filledFields = [
    product.productName,
    product.strain,
    product.brand,
    product.description,
    product.details,
    product.productType,
    product.packageSize,
    product.thc,
    product.cbd,
  ]
    .filter(Boolean)
    .length;
  return Math.min(85, Math.max(25, filledFields * 15));
};

export const buildCatalogDraftRow = (product: ParsedProduct): TablesInsert<"products"> => {
  const shortDescription = joinDetails([
    product.description,
    product.thc ? `THC ${product.thc}` : "",
    product.cbd ? `CBD ${product.cbd}` : "",
  ]) || product.details || buildProductName(product);

  return {
    id: crypto.randomUUID(),
    name: buildProductName(product),
    brand: product.brand || "Unknown Brand",
    type: product.productType || "other",
    status: "draft",
    confidence: buildConfidenceScore(product),
    strain: product.strain,
    package_size: product.packageSize,
    short_description: shortDescription,
    long_description: shortDescription ? `${shortDescription}.` : "",
    images: [],
  };
};
