/**
 * cannabisPos.ts
 * StrainVentory — Cannabis POS Integration Layer
 *
 * This module explores and provides starter code for integrating with the leading
 * cannabis-specific POS and e-commerce platforms (2026 landscape).
 *
 * Recommended for StrainVentory:
 * 1. Dutchie (highest market share, excellent API for menu + orders + customers)
 * 2. IHeartJane (strong CA compliance, loyalty, online ordering)
 * 3. Flowhub (robust Metrc/BioTrack sync, great for in-store hardware)
 *
 * Key integration patterns:
 * - Push approved catalog items → POS menu (via AI Draft + Review workflow)
 * - Pull sales data → StrainVentory analytics, payroll, shift-close
 * - Real-time inventory sync (avoid overselling)
 * - Customer loyalty / daily limit enforcement across channels
 */

export interface PosProvider {
    name: string;
    type: "pos" | "ecomm" | "hybrid";
    apiBase: string;
    authType: "apiKey" | "oauth" | "jwt";
    supports: {
      menuSync: boolean;
      orderImport: boolean;
      inventoryPush: boolean;
      salesPull: boolean;
      customerSync: boolean;
      metrc: boolean;
      webhooks: boolean;
    };
    docsUrl: string;
    notes: string;
  }
  
  export const POS_PROVIDERS: PosProvider[] = [
    {
      name: "Dutchie",
      type: "hybrid",
      apiBase: "https://api.dutchie.com/v2",
      authType: "apiKey",
      supports: {
        menuSync: true,
        orderImport: true,
        inventoryPush: true,
        salesPull: true,
        customerSync: true,
        metrc: true,
        webhooks: true,
      },
      docsUrl: "https://docs.dutchie.com/",
      notes: "Dominant player. Best for multi-channel (in-store + online + delivery). Strong webhook support for real-time order notifications. Recommended first integration for StrainVentory.",
    },
    {
      name: "IHeartJane",
      type: "hybrid",
      apiBase: "https://api.iheartjane.com/v1",
      authType: "apiKey",
      supports: {
        menuSync: true,
        orderImport: true,
        inventoryPush: true,
        salesPull: true,
        customerSync: true,
        metrc: true,
        webhooks: true,
      },
      docsUrl: "https://developers.iheartjane.com/",
      notes: "Excellent California compliance + loyalty program. Great for customer 360 view. Jane's 'Express' mode is popular for quick in-store checkouts.",
    },
    {
      name: "Flowhub",
      type: "pos",
      apiBase: "https://api.flowhub.com/v1",
      authType: "oauth",
      supports: {
        menuSync: true,
        orderImport: false,
        inventoryPush: true,
        salesPull: true,
        customerSync: true,
        metrc: true,
        webhooks: true,
      },
      docsUrl: "https://docs.flowhub.com/",
      notes: "Pure-play cannabis POS with excellent Metrc integration. Ideal if dispensary uses Flowhub registers and wants StrainVentory as the 'brain' (AI catalog + payroll).",
    },
    {
      name: "Cova",
      type: "pos",
      apiBase: "https://api.covasoftware.com/v1",
      authType: "apiKey",
      supports: {
        menuSync: true,
        orderImport: true,
        inventoryPush: true,
        salesPull: true,
        customerSync: true,
        metrc: true,
        webhooks: true,
      },
      docsUrl: "https://developer.covasoftware.com/",
      notes: "Strong in Canada + US. Good ERP features (accounting, HR). Useful for larger multi-location operators.",
    },
    {
      name: "Blaze",
      type: "pos",
      apiBase: "https://api.blaze.me/v1",
      authType: "apiKey",
      supports: {
        menuSync: true,
        orderImport: true,
        inventoryPush: true,
        salesPull: true,
        customerSync: true,
        metrc: true,
        webhooks: true,
      },
      docsUrl: "https://developers.blaze.me/",
      notes: "Modern UI, fast checkout. Good for high-volume stores. Strong analytics API.",
    },
  ];
  
  /**
   * Example: Dutchie Menu Sync
   * Push StrainVentory approved products to Dutchie menu.
   * Call this after a product is approved in ReviewWorkspace.
   */
  export async function syncProductToDutchie(product: {
    id: string;
    name: string;
    brand: string;
    type: string;
    thc: number;
    cbd: number;
    price: number;
    description: string;
    imageUrl?: string;
    strain?: string;
  }, apiKey: string) {
    const res = await fetch("https://api.dutchie.com/v2/menu/items", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${apiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        external_id: product.id,
        name: product.name,
        brand: product.brand,
        category: product.type,
        thc_content: product.thc,
        cbd_content: product.cbd,
        price: product.price,
        description: product.description,
        image_url: product.imageUrl,
        strain: product.strain,
        // Add effects, terpenes, etc. from Strain Vinny draft
      }),
    });
  
    if (!res.ok) throw new Error(`Dutchie sync failed: ${res.status}`);
    return res.json();
  }
  
  /**
   * Example: Pull today's sales from Dutchie for StrainVentory shift close / payroll
   */
  export async function pullDutchieSales(date: string, apiKey: string) {
    const res = await fetch(`https://api.dutchie.com/v2/sales?date=${date}`, {
      headers: { Authorization: `Bearer ${apiKey}` },
    });
    if (!res.ok) throw new Error("Failed to fetch Dutchie sales");
    return res.json();
  }
  
  /**
   * Metrc Integration Helper (critical for CA compliance)
   * Many POS already handle Metrc, but StrainVentory can push adjustments or receive sales events.
   */
  export interface MetrcSaleEvent {
    package_label: string;
    quantity: number;
    unit_of_measure: "Grams" | "Each";
    total_price: number;
    customer_type: "Medical" | "Recreational";
    sale_time: string;
  }
  
  export async function pushMetrcSale(event: MetrcSaleEvent, metrcApiKey: string, licenseNumber: string) {
    // In production use official Metrc SDK or direct REST to https://api-ca.metrc.com/
    console.log("[Metrc] Pushing sale event for license", licenseNumber, event);
    // TODO: implement real Metrc call (requires facility license + API key per state)
    return { success: true, metrcId: "MRC-" + Date.now() };
  }
  
  /**
   * Recommended Integration Architecture for StrainVentory
   *
   * 1. Catalog is master in StrainVentory (AI Draft + ImageFinder + Review)
   * 2. On "Publish" → sync to chosen POS (Dutchie/Jane/Flowhub) via above helpers
   * 3. POS webhooks → StrainVentory (inventory decrement, sales events for analytics)
   * 4. Nightly/Shift-close job → pull sales → update payroll, daily limits, trends
   * 5. AI Brain (Strain Vinny) reads live POS data for "insights" mode:
   *    "Based on last 7 days POS velocity, Gelato #33 is your #1 seller — consider 15% price increase"
   *
   * Next steps to implement:
   * - Add POS provider selection in Settings.tsx
   * - Create usePosIntegration hook
   * - Wire webhook receiver in Supabase Edge Function
   * - Add "Sync to POS" button in ReviewWorkspace after approval
   */
  
  export const INTEGRATION_RECOMMENDATION = {
    primary: "Dutchie",
    reason: "Highest adoption rate + best balance of in-store POS + online ordering + developer-friendly API + Metrc support. Perfect complement to StrainVentory's AI catalog strengths.",
    secondary: "IHeartJane",
    tertiary: "Flowhub (if dispensary already uses their hardware)",
  };