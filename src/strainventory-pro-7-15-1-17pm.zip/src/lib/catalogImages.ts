import type { ProductImage, ProductSearchDraft } from "@/types/catalog";
import type { SupabaseClient } from "@supabase/supabase-js";
import type { Database, Json } from "@/integrations/supabase/types";

export interface ImageVerification {
  isMatch: boolean;
  reason: string;
  confidence: number;
}

export interface CatalogImageCandidate {
  id: string;
  url: string;
  alt: string;
  width: number;
  height: number;
  fileSize: string;
  thumbnailUrl: string;
  source: string;
  pageUrl?: string;
  verification?: ImageVerification;
  score?: number;
}

export interface CatalogImageSearchInput {
  name?: string;
  brand?: string;
  type?: string;
  packageSize?: string;
  sku?: string;
  vendor?: string;
}

export const buildCatalogImageSearchInput = (draft: ProductSearchDraft): CatalogImageSearchInput => ({
  name: draft.strain,
  brand: draft.brand,
  type: draft.productType,
  packageSize: draft.packageSize,
  sku: draft.sku,
  vendor: draft.vendor,
});

const normalized = (value: string | undefined) => (value ?? "").trim().toLowerCase();
const trustedCatalogDomains = [
  "allbud",
  "weedmaps",
  "myhavenstores",
  "shopphaven",
  "chronicguru",
  "coronaculture",
  "culturecannabisclub",
] as const;

export const rankCatalogImage = (image: CatalogImageCandidate, input: CatalogImageSearchInput) => {
  let score = image.verification?.confidence ?? 0;
  const alt = normalized(image.alt);
  const brand = normalized(input.brand);
  const name = normalized(input.name);
  const type = normalized(input.type);
  const sourceDetails = `${normalized(image.source)} ${normalized(image.pageUrl)}`;

  if (image.verification?.isMatch) {
    score += 25;
  }
  if (brand && alt.includes(brand)) {
    score += 8;
  }
  if (name && alt.includes(name)) {
    score += 12;
  }
  if (type && alt.includes(type)) {
    score += 5;
  }
  if (image.width >= 1200) {
    score += 6;
  } else if (image.width >= 800) {
    score += 3;
  }
  if (trustedCatalogDomains.some((domain) => sourceDetails.includes(domain))) {
    score += 4;
  }
  if (image.source.includes("official") || image.source.includes("brand")) {
    score += 6;
  }

  return score;
};

export const rankCatalogImages = (images: CatalogImageCandidate[], input: CatalogImageSearchInput) =>
  images
    .map((image) => ({ ...image, score: rankCatalogImage(image, input) }))
    .sort((left, right) => (right.score ?? 0) - (left.score ?? 0));

export const selectBestCatalogImage = (
  images: CatalogImageCandidate[],
  input: CatalogImageSearchInput,
) => rankCatalogImages(images, input)[0] ?? null;

const isProductImage = (value: Json): value is Json & ProductImage => {
  if (!value || typeof value !== "object" || Array.isArray(value)) {
    return false;
  }

  return (
    typeof value.url === "string" &&
    typeof value.alt === "string" &&
    typeof value.primary === "boolean"
  );
};

const updateProductPrimaryImage = async ({
  supabase,
  productId,
  url,
  alt,
}: {
  supabase: SupabaseClient<Database>;
  productId: string;
  url: string;
  alt: string;
}) => {
  const { data: product, error: productError } = await supabase
    .from("products")
    .select("images")
    .eq("id", productId)
    .maybeSingle();

  if (productError) {
    throw productError;
  }

  const existingImages = Array.isArray(product?.images) ? product.images.filter(isProductImage) : [];
  const nextImages = [
    { url, alt, primary: true },
    ...existingImages.map((image) => ({ url: image.url, alt: image.alt, primary: false })),
  ] as unknown as Json;

  const { error: updateError } = await supabase
    .from("products")
    .update({ images: nextImages, updated_at: new Date().toISOString() })
    .eq("id", productId);

  if (updateError) {
    throw updateError;
  }

  return url;
};

export const syncCatalogImageToProduct = async ({
  supabase,
  productId,
  candidate,
}: {
  supabase: SupabaseClient<Database>;
  productId: string;
  candidate: CatalogImageCandidate;
}) => {
  const linkRemoteImage = () =>
    updateProductPrimaryImage({
      supabase,
      productId,
      url: candidate.url,
      alt: candidate.alt,
    });

  let response: Response;
  try {
    response = await fetch(candidate.url);
  } catch (error) {
    console.warn("[catalogImages] Remote image fetch blocked; linking source URL instead.", error);
    return linkRemoteImage();
  }

  if (!response.ok) {
    console.warn("[catalogImages] Remote image fetch returned", response.status, "linking source URL instead.");
    return linkRemoteImage();
  }

  const blob = await response.blob();
  const ext = candidate.url.split(".").pop()?.split("?")[0] || "jpg";
  const path = `${productId}/${crypto.randomUUID()}.${ext}`;

  const { error: uploadError } = await supabase.storage
    .from("product-images")
    .upload(path, blob, { contentType: blob.type });
  if (uploadError) {
    console.warn("[catalogImages] Product image storage upload failed; linking source URL instead.", uploadError);
    return linkRemoteImage();
  }

  const { data: publicUrl } = supabase.storage.from("product-images").getPublicUrl(path);

  return updateProductPrimaryImage({
    supabase,
    productId,
    url: publicUrl.publicUrl,
    alt: candidate.alt,
  });
};

