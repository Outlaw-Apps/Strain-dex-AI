import { AlertTriangle, CheckCircle2, Globe, Shield, ShieldCheck, Check, Sparkles } from "lucide-react";
import { appConfig } from "@/lib/appConfig";

export const ENV = {
  SUPABASE_URL: appConfig.supabaseUrl,
  SUPABASE_PUBLISHABLE_KEY: appConfig.supabasePublishableKey,
  EDGE_FUNCTION_BASE_URL: appConfig.edgeFunctionBaseUrl,
} as const;

// ── Edge-function URLs ───────────────────────────────────────────────────────
export const EDGE_FUNCTIONS = {
  GENERATE_DRAFT: `${ENV.EDGE_FUNCTION_BASE_URL}/generate-draft`,
  FETCH_PRODUCT_IMAGES: `${ENV.EDGE_FUNCTION_BASE_URL}/fetch-product-images`,
  ASSISTANT_CHAT: `${ENV.EDGE_FUNCTION_BASE_URL}/assistant-chat`,
  SYNC_STRAIN_KNOWLEDGE: `${ENV.EDGE_FUNCTION_BASE_URL}/sync-strain-knowledge`,
  PROVISION_PIN_USER: `${ENV.EDGE_FUNCTION_BASE_URL}/provision-pin-user`,
  ADMIN_USERS: `${ENV.EDGE_FUNCTION_BASE_URL}/admin-users`,
  AI_DIAGNOSTICS: `${ENV.EDGE_FUNCTION_BASE_URL}/ai-diagnostics`,
} as const;

// ── Canonical product type values ────────────────────────────────────────────
// Single source of truth shared by ProductIntake, CatalogLibrary, and the
// SQL CHECK constraint on products.product_type.
export const PRODUCT_TYPES = [
  "Flower",
  "Wax",
  "Live Resin",
  "Vape (All in One)",
  "Vape Cartridge",
  "Edible",
  "Pre roll",
  "Concentrate",
  "Tincture",
  "Topical",
] as const;

export type ProductType = (typeof PRODUCT_TYPES)[number];

// ── Shared confidence-badge configuration ───────────────────────────────────
// Used by AIDraftGenerator, ReviewWorkspace, and any other component that
// needs to display a confidence level badge.  Keeping it here avoids the same
// object being duplicated across three files.

export const confidenceConfig = {
  // ---- AIDraftGenerator style (filled-background badges) ----
  verified: {
    icon: Shield,
    label: "Brand Verified",
    color: "bg-success/15 text-success",
  },
  matched: {
    icon: CheckCircle2,
    label: "Source Matched",
    color: "bg-emerald/15 text-emerald",
  },
  inferred: {
    icon: Globe,
    label: "Web Inferred",
    color: "bg-accent/20 text-accent-foreground",
  },
  review: {
    icon: AlertTriangle,
    label: "Needs Review",
    color: "bg-warning/15 text-warning",
  },
} as const;

// ReviewWorkspace uses a slightly different className format (border variant).
export const reviewConfidenceConfig: Record<
  keyof typeof confidenceConfig,
  { label: string; className: string; icon: React.ElementType }
> = {
  verified: {
    label: "Verified",
    className: "bg-emerald/15 text-emerald border-emerald/20",
    icon: ShieldCheck,
  },
  matched: {
    label: "Matched",
    className: "bg-accent/20 text-accent-foreground border-accent/30",
    icon: Check,
  },
  inferred: {
    label: "Inferred",
    className: "bg-warning/15 text-warning-foreground border-warning/25",
    icon: Sparkles,
  },
  review: {
    label: "Needs Review",
    className: "bg-destructive/10 text-destructive border-destructive/20",
    icon: AlertTriangle,
  },
};
