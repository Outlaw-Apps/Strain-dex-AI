// Copilot orchestrator — persists actions, navigation events, and audit logs.
// Phase 1 executes read/safe tools client-side; write tools stage as drafts.
import { supabase } from "@/integrations/supabase/client";
import type { Json } from "@/integrations/supabase/types";
import type {
  CopilotActionRecord,
  CopilotActionStatus,
  ToolRegistryEntry,
} from "./types";

interface StartActionInput {
  userId: string;
  toolName: string;
  summary?: string;
  input: Json;
  sessionId?: string | null;
  threadId?: string | null;
  routeContext?: string | null;
  status?: CopilotActionStatus;
}

export async function recordAction(
  args: StartActionInput,
): Promise<CopilotActionRecord | null> {
  const { data, error } = await supabase
    .from("copilot_actions")
    .insert({
      user_id: args.userId,
      tool_name: args.toolName,
      summary: args.summary ?? null,
      input: args.input,
      session_id: args.sessionId ?? null,
      thread_id: args.threadId ?? null,
      route_context: args.routeContext ?? null,
      status: args.status ?? "draft",
    })
    .select()
    .single();
  if (error) {
    console.error("recordAction failed", error);
    return null;
  }
  return data as CopilotActionRecord;
}

export async function updateActionStatus(
  actionId: string,
  patch: {
    status?: CopilotActionStatus;
    output?: Json;
    error?: string;
    started_at?: string;
    finished_at?: string;
  },
): Promise<void> {
  const { error } = await supabase
    .from("copilot_actions")
    .update(patch as never)
    .eq("id", actionId);
  if (error) console.error("updateActionStatus failed", error);
}

export async function recordNavigation(args: {
  userId: string;
  route: string;
  module?: string;
  mode?: "headless" | "real";
  sessionId?: string | null;
  actionId?: string | null;
}): Promise<void> {
  const { error } = await supabase.from("copilot_navigation_events").insert({
    user_id: args.userId,
    route: args.route,
    module: args.module ?? null,
    mode: args.mode ?? "headless",
    session_id: args.sessionId ?? null,
    action_id: args.actionId ?? null,
  });
  if (error) console.error("recordNavigation failed", error);
}

export async function logAudit(args: {
  actorId: string;
  action: string;
  targetType?: string;
  targetId?: string;
  before?: Json;
  after?: Json;
  metadata?: Json;
  source?: "vinny" | "user" | "system";
}): Promise<void> {
  const { error } = await supabase.from("audit_logs").insert({
    actor_id: args.actorId,
    action: args.action,
    target_type: args.targetType ?? null,
    target_id: args.targetId ?? null,
    before: args.before ?? null,
    after: args.after ?? null,
    metadata: args.metadata ?? {},
    source: args.source ?? "vinny",
  });
  if (error) console.error("logAudit failed", error);
}

export async function requestApproval(args: {
  actionId: string;
  requestedBy: string;
  reason?: string;
}): Promise<void> {
  await supabase.from("approval_requests").insert({
    action_id: args.actionId,
    requested_by: args.requestedBy,
    reason: args.reason ?? null,
  });
  await updateActionStatus(args.actionId, { status: "awaiting_approval" });
}

/** Execute a Phase 1 tool client-side. Returns the output payload. */
export async function executeTool(
  tool: ToolRegistryEntry,
  input: Record<string, unknown>,
): Promise<Json> {
  switch (tool.name) {
    case "navigateToPage":
    case "openModule": {
      // Actual navigation is handled by the caller (NavigationHint button).
      return { acknowledged: true, route: (input.route as string) ?? null };
    }
    case "searchInventory": {
      const query = String(input.query ?? "").trim();
      if (!query) return { results: [] };
      const { data, error } = await supabase
        .from("products")
        .select("id, name, sku, brand, product_type, quantity, price")
        .or(
          `name.ilike.%${query}%,sku.ilike.%${query}%,brand.ilike.%${query}%`,
        )
        .limit(20);
      if (error) throw error;
      return { results: data ?? [] };
    }
    case "reviewTimecards": {
      const userIdFilter = input.user_id as string | undefined;
      let q = supabase
        .from("time_entries")
        .select("*")
        .order("clock_in", { ascending: false })
        .limit(50);
      if (userIdFilter) q = q.eq("user_id", userIdFilter);
      const { data, error } = await q;
      if (error) throw error;
      return { entries: data ?? [] };
    }
    case "createTask": {
      const { data, error } = await supabase
        .from("copilot_tasks")
        .insert({
          created_by: (input.created_by as string) ?? "",
          assigned_to: (input.assigned_to as string) ?? null,
          title: String(input.title ?? "Untitled task"),
          description: (input.description as string) ?? null,
          priority: (input.priority as string) ?? "normal",
        })
        .select()
        .single();
      if (error) throw error;
      return { task: data };
    }
    case "updateTask": {
      const id = String(input.id ?? "");
      if (!id) throw new Error("Missing task id");
      const patch: {
        status?: string;
        title?: string;
        description?: string;
      } = {};
      if (input.status) patch.status = String(input.status);
      if (input.title) patch.title = String(input.title);
      if (input.description) patch.description = String(input.description);
      const { data, error } = await supabase
        .from("copilot_tasks")
        .update(patch as never)
        .eq("id", id)
        .select()
        .single();
      if (error) throw error;
      return { task: data };
    }
    case "logAuditEvent": {
      return { logged: true };
    }

    // ─── Phase 2: workforce / onboarding ───────────────────────────
    case "createEmployee": {
      const payload = {
        full_name: String(input.full_name ?? "").trim(),
        date_of_birth: String(input.date_of_birth ?? ""),
        phone: String(input.phone ?? ""),
        email: String(input.email ?? "").trim().toLowerCase(),
        emergency_contact: String(input.emergency_contact ?? ""),
        role: String(input.role ?? "budtender"),
        badge_number: String(input.badge_number ?? "PENDING"),
        live_scan_status: String(input.live_scan_status ?? "pending"),
        assigned_role: String(input.assigned_role ?? "staff"),
        location: (input.location as string) ?? null,
        manager_id: (input.manager_id as string) ?? null,
        start_date: (input.start_date as string) ?? null,
        manager_note: (input.manager_note as string) ?? null,
        status: "pending_review",
        created_by: (input.created_by as string) ?? null,
      };
      if (!payload.full_name || !payload.email) {
        throw new Error("full_name and email are required to create an employee");
      }
      const { data, error } = await supabase
        .from("employees")
        .insert(payload)
        .select()
        .single();
      if (error) throw error;
      return { employee: data };
    }
    case "updateEmployee": {
      const id = String(input.id ?? "");
      if (!id) throw new Error("Missing employee id");
      const patch: Record<string, unknown> = {};
      for (const key of [
        "full_name","phone","email","emergency_contact","role","badge_number",
        "live_scan_status","mmic_number","status","assigned_role","location",
        "manager_id","start_date","manager_note",
      ]) {
        if (input[key] !== undefined) patch[key] = input[key];
      }
      const { data, error } = await supabase
        .from("employees")
        .update(patch as never)
        .eq("id", id)
        .select()
        .single();
      if (error) throw error;
      return { employee: data };
    }
    case "assignRole": {
      const id = String(input.employee_id ?? input.id ?? "");
      const assigned_role = String(input.assigned_role ?? input.role ?? "staff");
      if (!id) throw new Error("Missing employee id");
      const { data, error } = await supabase
        .from("employees")
        .update({ assigned_role })
        .eq("id", id)
        .select()
        .single();
      if (error) throw error;
      return { employee: data };
    }
    case "assignManager": {
      const id = String(input.employee_id ?? input.id ?? "");
      const manager_id = (input.manager_id as string) ?? null;
      const location = (input.location as string) ?? undefined;
      if (!id) throw new Error("Missing employee id");
      const patch: Record<string, unknown> = { manager_id };
      if (location !== undefined) patch.location = location;
      const { data, error } = await supabase
        .from("employees")
        .update(patch as never)
        .eq("id", id)
        .select()
        .single();
      if (error) throw error;
      return { employee: data };
    }
    case "createOnboardingChecklist": {
      const employee_id = String(input.employee_id ?? "");
      const role = (input.role as string) ?? "default";
      if (!employee_id) throw new Error("Missing employee_id");
      const { data, error } = await supabase.rpc(
        "generate_default_onboarding_checklist",
        { _employee_id: employee_id, _role: role },
      );
      if (error) throw error;
      return { checklist_id: data };
    }
    case "requestDocument": {
      const employee_id = String(input.employee_id ?? "");
      const doc_type = String(input.doc_type ?? "");
      const label = String(input.label ?? doc_type);
      if (!employee_id || !doc_type) {
        throw new Error("employee_id and doc_type are required");
      }
      const { data, error } = await supabase
        .from("document_requests")
        .insert({
          employee_id,
          doc_type,
          label,
          notes: (input.notes as string) ?? null,
          due_date: (input.due_date as string) ?? null,
          requested_by: (input.requested_by as string) ?? null,
        })
        .select()
        .single();
      if (error) throw error;
      return { request: data };
    }
    case "completeChecklistItem": {
      const item_id = String(input.item_id ?? "");
      if (!item_id) throw new Error("Missing item_id");
      const patch: Record<string, unknown> = {
        status: "completed",
        completed_at: new Date().toISOString(),
        completed_by: (input.completed_by as string) ?? null,
      };
      if (input.notes !== undefined) patch.notes = input.notes;
      const { data, error } = await supabase
        .from("onboarding_checklist_items")
        .update(patch as never)
        .eq("id", item_id)
        .select()
        .single();
      if (error) throw error;
      return { item: data };
    }
    case "getOnboardingProgress": {
      const employee_id = String(input.employee_id ?? "");
      if (!employee_id) throw new Error("Missing employee_id");
      const { data: checklists, error: cErr } = await supabase
        .from("onboarding_checklists")
        .select("*, onboarding_checklist_items(*)")
        .eq("employee_id", employee_id)
        .order("created_at", { ascending: false });
      if (cErr) throw cErr;
      const { data: docs, error: dErr } = await supabase
        .from("document_requests")
        .select("*")
        .eq("employee_id", employee_id)
        .order("created_at", { ascending: false });
      if (dErr) throw dErr;
      return { checklists: checklists ?? [], documents: docs ?? [] };
    }
    case "verifyDocument": {
      const id = String(input.id ?? "");
      if (!id) throw new Error("Missing document id");
      const { data, error } = await supabase
        .from("document_requests")
        .update({
          status: "verified",
          verified_at: new Date().toISOString(),
          verified_by: (input.verified_by as string) ?? null,
          rejection_reason: null,
        } as never)
        .eq("id", id)
        .select()
        .single();
      if (error) throw error;
      return { request: data };
    }
    case "rejectDocument": {
      const id = String(input.id ?? "");
      const reason = String(input.reason ?? "").trim();
      if (!id || !reason) throw new Error("id and reason are required");
      const { data, error } = await supabase
        .from("document_requests")
        .update({
          status: "rejected",
          rejection_reason: reason,
          verified_at: new Date().toISOString(),
          verified_by: (input.verified_by as string) ?? null,
        } as never)
        .eq("id", id)
        .select()
        .single();
      if (error) throw error;
      return { request: data };
    }

    // ─── Phase 3: employee messaging ──────────────────────────────
    case "sendEmployeeMessage": {
      const recipient = String(input.recipient_user_id ?? "");
      const body = String(input.body ?? "").trim();
      if (!recipient || !body) {
        throw new Error("recipient_user_id and body are required");
      }
      const { data: convoId, error: convoErr } = await supabase.rpc(
        "get_or_create_dm",
        { _other_user_id: recipient },
      );
      if (convoErr) throw convoErr;
      const { data: { user } } = await supabase.auth.getUser();
      const { data: msg, error: msgErr } = await supabase
        .from("conversation_messages")
        .insert({
          conversation_id: convoId as unknown as string,
          sender_id: user?.id ?? "",
          body,
        })
        .select()
        .single();
      if (msgErr) throw msgErr;
      return { conversation_id: convoId, message: msg };
    }
    case "sendTeamAnnouncement": {
      const title = String(input.title ?? "").trim();
      const body = String(input.body ?? "").trim();
      const audience_role = String(input.audience_role ?? "staff");
      if (!title || !body) throw new Error("title and body are required");
      const { data: { user } } = await supabase.auth.getUser();
      const requires_approval = audience_role === "all";
      const { data, error } = await supabase
        .from("announcement_broadcasts")
        .insert({
          sender_id: user?.id ?? null,
          title,
          body,
          audience_role,
          status: requires_approval ? "awaiting_approval" : "sent",
          requires_approval,
          sent_at: requires_approval ? null : new Date().toISOString(),
        })
        .select()
        .single();
      if (error) throw error;
      return { announcement: data };
    }

    // ─── Phase 4: payroll ─────────────────────────────────────────
    case "createPayrollDraft": {
      const start_date = String(input.start_date ?? "");
      const end_date = String(input.end_date ?? "");
      if (!start_date || !end_date) {
        throw new Error("start_date and end_date are required (YYYY-MM-DD)");
      }
      const { data: authData } = await supabase.auth.getUser();
      const created_by = authData.user?.id ?? null;

      // Create the pay period
      const { data: period, error: pErr } = await supabase
        .from("pay_periods")
        .insert({ start_date, end_date, created_by, status: "draft" })
        .select()
        .single();
      if (pErr) throw pErr;

      // Load active profiles + all time entries in range
      const { data: profiles, error: prErr } = await supabase
        .from("employee_payroll_profiles")
        .select("*")
        .eq("is_active", true);
      if (prErr) throw prErr;

      const startISO = new Date(start_date).toISOString();
      const endISO = new Date(new Date(end_date).getTime() + 86_400_000 - 1).toISOString();
      const { data: entries, error: eErr } = await supabase
        .from("time_entries")
        .select("id, user_id, clock_in, clock_out")
        .gte("clock_in", startISO)
        .lte("clock_in", endISO);
      if (eErr) throw eErr;

      // Lazy import engine (pure logic, no supabase)
      const { calculatePayroll } = await import("@/lib/payroll/payroll.engine");
      const periodStart = new Date(start_date);
      const periodEnd = new Date(end_date);
      periodEnd.setHours(23, 59, 59, 999);

      const payslipRows: Array<Record<string, unknown>> = [];
      const exceptionRows: Array<Record<string, unknown>> = [];
      let totalWages = 0;
      let totalOT = 0;

      for (const profile of profiles ?? []) {
        const breakdown = calculatePayroll(
          (entries ?? []) as never,
          profile as never,
          periodStart,
          periodEnd,
        );
        payslipRows.push({
          pay_period_id: period.id,
          employee_id: profile.employee_id,
          regular_hours: breakdown.regular_hours,
          ot_hours: breakdown.ot_hours,
          doubletime_hours: breakdown.doubletime_hours,
          gross_pay: breakdown.gross_pay,
          deductions: breakdown.deductions,
          net_pay: breakdown.net_pay,
        });
        totalWages += breakdown.gross_pay;
        totalOT += breakdown.ot_hours + breakdown.doubletime_hours;

        // Auto-flag exceptions
        if (breakdown.ot_hours + breakdown.doubletime_hours > 20) {
          exceptionRows.push({
            pay_period_id: period.id,
            employee_id: profile.employee_id,
            kind: "high_overtime",
            severity: "warning",
            message: `High overtime: ${breakdown.ot_hours + breakdown.doubletime_hours}h premium in period.`,
            details: { ot: breakdown.ot_hours, dt: breakdown.doubletime_hours },
            flagged_by: created_by,
          });
        }
        if (breakdown.gross_pay > 0 && profile.hourly_rate <= 0) {
          exceptionRows.push({
            pay_period_id: period.id,
            employee_id: profile.employee_id,
            kind: "missing_rate",
            severity: "error",
            message: "Employee has hours but no hourly rate on file.",
            flagged_by: created_by,
          });
        }
      }

      // Open shift detection
      for (const e of entries ?? []) {
        if (!e.clock_out) {
          exceptionRows.push({
            pay_period_id: period.id,
            employee_id: e.user_id,
            kind: "missing_clockout",
            severity: "error",
            message: "Time entry has no clock-out within the pay period.",
            details: { entry_id: e.id, clock_in: e.clock_in },
            flagged_by: created_by,
          });
        }
      }

      if (payslipRows.length) {
        const { error: psErr } = await supabase.from("payslips").insert(payslipRows as never);
        if (psErr) throw psErr;
      }
      if (exceptionRows.length) {
        await supabase.from("payroll_exceptions").insert(exceptionRows as never);
      }
      await supabase
        .from("pay_periods")
        .update({ total_wages: totalWages, total_ot_hours: totalOT } as never)
        .eq("id", period.id);

      return {
        pay_period: period,
        payslip_count: payslipRows.length,
        exception_count: exceptionRows.length,
        total_wages: totalWages,
        total_ot_hours: totalOT,
      };
    }
    case "flagPayrollException": {
      const pay_period_id = (input.pay_period_id as string) ?? null;
      const employee_id = (input.employee_id as string) ?? null;
      const kind = String(input.kind ?? "manual");
      const severity = String(input.severity ?? "warning");
      const message = String(input.message ?? "").trim();
      if (!message) throw new Error("message is required");
      const { data: authData } = await supabase.auth.getUser();
      const { data, error } = await supabase
        .from("payroll_exceptions")
        .insert({
          pay_period_id,
          employee_id,
          kind,
          severity,
          message,
          details: (input.details as Json) ?? {},
          flagged_by: authData.user?.id ?? null,
        })
        .select()
        .single();
      if (error) throw error;
      return { exception: data };
    }
    case "getPayrollSummary": {
      const pay_period_id = String(input.pay_period_id ?? "");
      if (!pay_period_id) throw new Error("pay_period_id is required");
      const [{ data: period }, { data: slips }, { data: exceptions }] = await Promise.all([
        supabase.from("pay_periods").select("*").eq("id", pay_period_id).single(),
        supabase.from("payslips").select("*").eq("pay_period_id", pay_period_id),
        supabase.from("payroll_exceptions").select("*").eq("pay_period_id", pay_period_id),
      ]);
      return {
        period,
        payslips: slips ?? [],
        exceptions: exceptions ?? [],
        open_exception_count: (exceptions ?? []).filter(
          (e: { status?: string }) => e.status === "open",
        ).length,
      };
    }
    case "finalizePayrollRun": {
      const pay_period_id = String(input.pay_period_id ?? "");
      if (!pay_period_id) throw new Error("pay_period_id is required");
      const { data: openExc } = await supabase
        .from("payroll_exceptions")
        .select("id")
        .eq("pay_period_id", pay_period_id)
        .eq("status", "open")
        .eq("severity", "error");
      if ((openExc ?? []).length > 0) {
        throw new Error(
          `Cannot finalize: ${openExc!.length} unresolved error-level exception(s). Resolve them first.`,
        );
      }
      const { data, error } = await supabase
        .from("pay_periods")
        .update({ status: "processed" } as never)
        .eq("id", pay_period_id)
        .select()
        .single();
      if (error) throw error;
      return { pay_period: data };
    }
    case "resolvePayrollException": {
      const id = String(input.id ?? "");
      const note = String(input.resolution_note ?? "").trim();
      if (!id) throw new Error("Missing exception id");
      const { data: authData } = await supabase.auth.getUser();
      const { data, error } = await supabase
        .from("payroll_exceptions")
        .update({
          status: "resolved",
          resolved_at: new Date().toISOString(),
          resolved_by: authData.user?.id ?? null,
          resolution_note: note || null,
        } as never)
        .eq("id", id)
        .select()
        .single();
      if (error) throw error;
      return { exception: data };
    }


    // ─── Phase 5: reports & documents ─────────────────────────────
    case "generateReport": {
      const report_type = String(input.report_type ?? input.type ?? "").trim();
      if (!report_type) throw new Error("report_type is required (sales|inventory_low_stock|timecards|payroll|onboarding)");
      const period_start = (input.period_start as string) ?? null;
      const period_end = (input.period_end as string) ?? null;
      const { data: authData } = await supabase.auth.getUser();
      const generated_by = authData.user?.id ?? null;

      let title = "";
      let summary = "";
      let data: Record<string, unknown> = {};

      const startISO = period_start ? new Date(period_start).toISOString() : null;
      const endISO = period_end
        ? new Date(new Date(period_end).getTime() + 86_400_000 - 1).toISOString()
        : null;

      if (report_type === "sales") {
        let q = supabase.from("orders").select("id, total, subtotal, tax, status, created_at").eq("status", "completed");
        if (startISO) q = q.gte("created_at", startISO);
        if (endISO) q = q.lte("created_at", endISO);
        const { data: orders, error } = await q;
        if (error) throw error;
        const gross = (orders ?? []).reduce((s, o: { total?: number }) => s + Number(o.total ?? 0), 0);
        const tax = (orders ?? []).reduce((s, o: { tax?: number }) => s + Number(o.tax ?? 0), 0);
        const count = (orders ?? []).length;
        const avg = count ? gross / count : 0;
        title = `Sales report${period_start ? ` ${period_start} → ${period_end ?? "today"}` : ""}`;
        summary = `${count} completed orders • $${gross.toFixed(2)} gross • $${tax.toFixed(2)} tax • avg ticket $${avg.toFixed(2)}.`;
        data = { order_count: count, gross, tax, average_ticket: avg };
      } else if (report_type === "inventory_low_stock") {
        const threshold = Number(input.threshold ?? 5);
        const { data: prods, error } = await supabase
          .from("products")
          .select("id, name, sku, brand, quantity, low_stock_threshold")
          .lte("quantity", threshold)
          .order("quantity", { ascending: true })
          .limit(200);
        if (error) throw error;
        title = `Low-stock inventory (≤ ${threshold})`;
        summary = `${(prods ?? []).length} SKUs at or below ${threshold} units.`;
        data = { threshold, items: prods ?? [] };
      } else if (report_type === "timecards") {
        let q = supabase.from("time_entries").select("id, user_id, clock_in, clock_out");
        if (startISO) q = q.gte("clock_in", startISO);
        if (endISO) q = q.lte("clock_in", endISO);
        const { data: entries, error } = await q;
        if (error) throw error;
        const rows = entries ?? [];
        const open = rows.filter((e: { clock_out?: string | null }) => !e.clock_out).length;
        const totalHours = rows.reduce((s, e: { clock_in: string; clock_out?: string | null }) => {
          if (!e.clock_out) return s;
          return s + (new Date(e.clock_out).getTime() - new Date(e.clock_in).getTime()) / 3_600_000;
        }, 0);
        title = `Timecard report${period_start ? ` ${period_start} → ${period_end ?? "today"}` : ""}`;
        summary = `${rows.length} entries • ${totalHours.toFixed(1)} total hours • ${open} still open (no clock-out).`;
        data = { entry_count: rows.length, total_hours: totalHours, open_shifts: open };
      } else if (report_type === "payroll") {
        const pay_period_id = String(input.pay_period_id ?? "");
        if (!pay_period_id) throw new Error("payroll report requires pay_period_id");
        const [{ data: period }, { data: slips }, { data: exceptions }] = await Promise.all([
          supabase.from("pay_periods").select("*").eq("id", pay_period_id).single(),
          supabase.from("payslips").select("*").eq("pay_period_id", pay_period_id),
          supabase.from("payroll_exceptions").select("*").eq("pay_period_id", pay_period_id),
        ]);
        const gross = (slips ?? []).reduce((s, p: { gross_pay?: number }) => s + Number(p.gross_pay ?? 0), 0);
        const open = (exceptions ?? []).filter((e: { status?: string }) => e.status === "open").length;
        title = `Payroll report — period ${period?.start_date ?? ""} → ${period?.end_date ?? ""}`;
        summary = `${(slips ?? []).length} payslips • $${gross.toFixed(2)} gross • ${open} open exceptions.`;
        data = { period, payslip_count: (slips ?? []).length, gross_total: gross, open_exceptions: open };
      } else if (report_type === "onboarding") {
        const { data: checklists, error } = await supabase
          .from("onboarding_checklists")
          .select("id, employee_id, status, progress_percent, created_at")
          .order("created_at", { ascending: false })
          .limit(200);
        if (error) throw error;
        const rows = checklists ?? [];
        const done = rows.filter((c: { status?: string }) => c.status === "completed").length;
        const inProgress = rows.filter((c: { status?: string }) => c.status !== "completed").length;
        title = "Onboarding status report";
        summary = `${rows.length} employees tracked • ${done} completed • ${inProgress} in progress.`;
        data = { total: rows.length, completed: done, in_progress: inProgress, checklists: rows };
      } else {
        throw new Error(`Unknown report_type: ${report_type}`);
      }

      const { data: saved, error: sErr } = await supabase
        .from("generated_reports")
        .insert({
          report_type,
          title,
          summary,
          data: data as Json,
          params: input as Json,
          period_start,
          period_end,
          generated_by,
        })
        .select()
        .single();
      if (sErr) throw sErr;
      return { report: saved };
    }

    case "generateDocument": {
      const doc_type = String(input.doc_type ?? "").trim();
      const employee_id = (input.employee_id as string) ?? null;
      if (!doc_type) throw new Error("doc_type is required");

      const sensitive = doc_type === "disciplinary_notice" || doc_type === "termination_notice";
      const { data: authData } = await supabase.auth.getUser();
      const generated_by = authData.user?.id ?? null;

      let employee: Record<string, unknown> | null = null;
      if (employee_id) {
        const { data: emp } = await supabase
          .from("employees")
          .select("id, full_name, email, role, assigned_role, location, start_date")
          .eq("id", employee_id)
          .maybeSingle();
        employee = emp ?? null;
      }

      const vars: Record<string, string> = {
        full_name: String(employee?.full_name ?? input.recipient_name ?? "Team Member"),
        role: String(employee?.role ?? employee?.assigned_role ?? "staff"),
        location: String(employee?.location ?? "our dispensary"),
        start_date: String(employee?.start_date ?? input.start_date ?? "TBD"),
        reason: String(input.reason ?? ""),
        effective_date: String(input.effective_date ?? new Date().toISOString().slice(0, 10)),
        manager_name: String(input.manager_name ?? "Management"),
      };

      const templates: Record<string, { title: string; body: string }> = {
        welcome_letter: {
          title: `Welcome to the team, ${vars.full_name}`,
          body: `Hi ${vars.full_name},\n\nWelcome aboard! We're glad to have you joining ${vars.location} as a ${vars.role}. Your first day is ${vars.start_date}.\n\nYou'll get your onboarding checklist shortly — knock those out so we can clear you for the floor. Any questions, hit up ${vars.manager_name}.\n\n— The Team`,
        },
        offer_letter: {
          title: `Offer of employment — ${vars.full_name}`,
          body: `Dear ${vars.full_name},\n\nWe are pleased to offer you the position of ${vars.role} at ${vars.location}, with a proposed start date of ${vars.start_date}. Compensation, schedule, and benefits will be reviewed on day one.\n\nPlease sign and return this letter to accept. This offer is contingent on Live Scan clearance and DCC badge verification.\n\nSincerely,\n${vars.manager_name}`,
        },
        sop_ack: {
          title: `SOP & Handbook Acknowledgement — ${vars.full_name}`,
          body: `I, ${vars.full_name}, acknowledge that I have received, read, and understood the Standard Operating Procedures and Employee Handbook for ${vars.location}. I agree to comply with all policies including compliance, cash handling, and customer verification procedures.\n\nSigned: ______________________   Date: ${vars.effective_date}`,
        },
        disciplinary_notice: {
          title: `Disciplinary Notice — ${vars.full_name}`,
          body: `Employee: ${vars.full_name}\nRole: ${vars.role}\nLocation: ${vars.location}\nDate: ${vars.effective_date}\n\nReason for notice:\n${vars.reason || "(reason to be completed by manager)"}\n\nExpected corrective action and follow-up will be discussed with ${vars.manager_name}. Continued issues may result in further disciplinary action, up to and including termination.\n\nAcknowledged by employee: ______________________\nIssued by: ${vars.manager_name}`,
        },
        termination_notice: {
          title: `Notice of Termination — ${vars.full_name}`,
          body: `Employee: ${vars.full_name}\nRole: ${vars.role}\nLocation: ${vars.location}\nEffective date: ${vars.effective_date}\n\nThis letter confirms the termination of your employment. Reason:\n${vars.reason || "(reason to be completed by manager)"}\n\nFinal paycheck, benefits information, and return of company property (badge, keys, uniform) will be handled per California labor law. Please contact ${vars.manager_name} to coordinate.\n\nIssued by: ${vars.manager_name}`,
        },
      };

      const tpl = templates[doc_type];
      if (!tpl) throw new Error(`Unknown doc_type: ${doc_type}`);

      const { data: saved, error } = await supabase
        .from("generated_documents")
        .insert({
          doc_type,
          title: tpl.title,
          employee_id,
          recipient_name: vars.full_name,
          body: tpl.body,
          variables: vars as Json,
          status: sensitive ? "awaiting_approval" : "draft",
          requires_approval: sensitive,
          generated_by,
        })
        .select()
        .single();
      if (error) throw error;
      return { document: saved, requires_approval: sensitive };
    }

    // ─── Phase 6: POS write actions ───────────────────────────────
    case "createPOSCart": {
      const { data: authData } = await supabase.auth.getUser();
      const { data, error } = await supabase
        .from("orders")
        .insert({
          created_by: authData.user?.id ?? null,
          customer_id: (input.customer_id as string) ?? null,
          customer_name_override: (input.customer_name as string) ?? null,
          customer_age: (input.customer_age as number) ?? null,
          payment_method: (input.payment_method as string) ?? "cash",
          subtotal: 0,
          tax: 0,
          total: 0,
          discount_total: 0,
          status: "draft",
        })
        .select()
        .single();
      if (error) throw error;
      return { order: data };
    }
    case "addItemToCart": {
      const order_id = String(input.order_id ?? "");
      const product_id = String(input.product_id ?? "");
      const quantity = Math.max(1, Number(input.quantity ?? 1));
      if (!order_id || !product_id) throw new Error("order_id and product_id are required");

      const { data: product, error: pErr } = await supabase
        .from("products")
        .select("id, name, price, sale_price, weight_grams, quantity")
        .eq("id", product_id)
        .single();
      if (pErr) throw pErr;
      if ((product.quantity ?? 0) < quantity) {
        throw new Error(`Insufficient stock for ${product.name} (${product.quantity ?? 0} available)`);
      }
      const unit_price = Number(product.sale_price ?? product.price ?? 0);
      const total_price = unit_price * quantity;

      const { data: item, error: iErr } = await supabase
        .from("order_items")
        .insert({
          order_id,
          product_id,
          product_name: product.name,
          weight: product.weight_grams ? `${product.weight_grams}g` : null,
          quantity,
          unit_price,
          total_price,
          base_unit_price: unit_price,
          discounted_unit_price: unit_price,
          discount_amount: 0,
        })
        .select()
        .single();
      if (iErr) throw iErr;

      const { data: items } = await supabase
        .from("order_items")
        .select("total_price")
        .eq("order_id", order_id);
      const subtotal = (items ?? []).reduce((s, r: { total_price?: number }) => s + Number(r.total_price ?? 0), 0);
      const tax = Number((subtotal * 0.15).toFixed(2));
      const total = Number((subtotal + tax).toFixed(2));
      await supabase.from("orders").update({ subtotal, tax, total } as never).eq("id", order_id);

      return { item, order_totals: { subtotal, tax, total } };
    }
    case "applyDiscount": {
      const order_id = String(input.order_id ?? "");
      const amount = Number(input.amount ?? 0);
      const reason = String(input.reason ?? "").trim();
      if (!order_id || amount <= 0 || !reason) {
        throw new Error("order_id, positive amount, and reason are required (approval-gated)");
      }
      const { data: authData } = await supabase.auth.getUser();
      const { data: order, error: oErr } = await supabase
        .from("orders")
        .select("subtotal, discount_total")
        .eq("id", order_id)
        .single();
      if (oErr) throw oErr;

      await supabase.from("order_discount_events").insert({
        order_id,
        created_by: authData.user?.id ?? null,
        event_kind: "manual_discount",
        reason,
        manager_override: Boolean(input.manager_override ?? true),
        payload: { amount } as Json,
      });

      const newDiscount = Number(order.discount_total ?? 0) + amount;
      const newSubtotal = Math.max(0, Number(order.subtotal ?? 0) - amount);
      const tax = Number((newSubtotal * 0.15).toFixed(2));
      const total = Number((newSubtotal + tax).toFixed(2));
      const { data: updated, error: uErr } = await supabase
        .from("orders")
        .update({
          discount_total: newDiscount,
          discount_summary: reason,
          subtotal: newSubtotal,
          tax,
          total,
        } as never)
        .eq("id", order_id)
        .select()
        .single();
      if (uErr) throw uErr;
      return { order: updated, applied_discount: amount };
    }
    case "requestManagerOverride": {
      const order_id = (input.order_id as string) ?? null;
      const reason = String(input.reason ?? "").trim();
      const kind = String(input.kind ?? "generic_override");
      if (!reason) throw new Error("reason is required");
      const { data: authData } = await supabase.auth.getUser();
      const { data: audit, error: aErr } = await supabase
        .from("pos_audit_events")
        .insert({
          event_type: `override_requested:${kind}`,
          created_by: authData.user?.id ?? null,
          metadata: { order_id, reason, kind } as Json,
        })
        .select()
        .single();
      if (aErr) throw aErr;
      return {
        pos_audit_event: audit,
        pending_approval: true,
        message: "Manager override requested. Awaiting approval before applying.",
      };
    }
    case "startReturn": {
      const original_order_id = String(input.order_id ?? "");
      const reason = String(input.reason ?? "").trim();
      if (!original_order_id || !reason) {
        throw new Error("order_id and reason are required to start a return");
      }
      const { data: authData } = await supabase.auth.getUser();
      const { data: original, error: oErr } = await supabase
        .from("orders")
        .select("subtotal, tax, total, customer_id, payment_method")
        .eq("id", original_order_id)
        .single();
      if (oErr) throw oErr;

      const { data: refund, error: rErr } = await supabase
        .from("orders")
        .insert({
          created_by: authData.user?.id ?? null,
          customer_id: original.customer_id,
          payment_method: original.payment_method,
          subtotal: -Number(original.subtotal ?? 0),
          tax: -Number(original.tax ?? 0),
          total: -Number(original.total ?? 0),
          status: "refund_pending",
          discount_summary: `Return of order ${original_order_id}: ${reason}`,
        })
        .select()
        .single();
      if (rErr) throw rErr;

      await supabase.from("pos_audit_events").insert({
        event_type: "return_started",
        created_by: authData.user?.id ?? null,
        metadata: {
          original_order_id,
          refund_order_id: refund.id,
          reason,
        } as Json,
      });
      return { refund_order: refund, requires_approval: true };
    }
    case "finalizePOSCart": {
      const order_id = String(input.order_id ?? "");
      if (!order_id) throw new Error("order_id is required");
      const { data, error } = await supabase
        .from("orders")
        .update({ status: "completed" } as never)
        .eq("id", order_id)
        .select()
        .single();
      if (error) throw error;
      return { order: data };
    }

    default:
      return {
        stubbed: true,
        message: `${tool.name} is queued for Phase ${tool.phase}.`,
      };
  }
}
