// Client-side accessor for the tool registry. Server-side gating remains
// authoritative via RLS; this helper powers UI decisions like which
// action cards render an "Approve & Run" button vs. a "Run" button.
import { supabase } from "@/integrations/supabase/client";
import type { AppRole, ToolRegistryEntry } from "./types";

export async function fetchToolRegistry(): Promise<ToolRegistryEntry[]> {
  const { data, error } = await supabase
    .from("tool_registry")
    .select("*")
    .eq("enabled", true)
    .order("phase", { ascending: true });
  if (error) throw error;
  return (data ?? []) as ToolRegistryEntry[];
}

export function canRunTool(tool: ToolRegistryEntry, roles: AppRole[]): boolean {
  if (!tool.enabled) return false;
  if (roles.includes("admin")) return true;
  return tool.allowed_roles.some((r) => roles.includes(r));
}

export function requiresApproval(tool: ToolRegistryEntry): boolean {
  return tool.requires_approval;
}
