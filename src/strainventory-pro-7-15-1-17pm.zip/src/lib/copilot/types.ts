// Strain Vinny copilot — Phase 1 shared types.
import type { Database, Json } from "@/integrations/supabase/types";

export type AppRole = Database["public"]["Enums"]["app_role"];

export type CopilotActionStatus =
  | "draft"
  | "awaiting_approval"
  | "running"
  | "completed"
  | "failed";

export interface ToolRegistryEntry {
  id: string;
  name: string;
  description: string;
  category: string;
  allowed_roles: AppRole[];
  requires_approval: boolean;
  phase: number;
  enabled: boolean;
  input_schema: Json;
}

export interface CopilotActionRecord {
  id: string;
  session_id: string | null;
  thread_id: string | null;
  user_id: string;
  tool_name: string;
  summary: string | null;
  input: Json;
  output: Json | null;
  status: CopilotActionStatus;
  route_context: string | null;
  error: string | null;
  started_at: string | null;
  finished_at: string | null;
  created_at: string;
  updated_at: string;
}

export interface CopilotSessionRecord {
  id: string;
  user_id: string;
  thread_id: string | null;
  workflow: string | null;
  active_route: string | null;
  context: Json;
  status: string;
  created_at: string;
  updated_at: string;
}

export interface NavigationHint {
  route: string;
  label: string;
  mode: "headless" | "real";
}
