import type { CartItem } from "@/pages/PointOfSale";
import { parseWeightGrams } from "@/lib/posPricing";

export const FLOWER_LIMIT_GRAMS = 28.5;
export const CONCENTRATE_LIMIT_GRAMS = 8;

const CONCENTRATE_TYPES = new Set([
  "concentrate",
  "wax",
  "live resin",
  "vape cartridge",
  "vape (all in one)",
  "vape",
  "shatter",
  "rosin",
  "budder",
  "bubble hash",
  "bubblegum hash",
  "badder",
  "crumble",
  "distillate",
  "sauce",
  "diamonds",
  "hash",
  "kief",
  "edible",
  "gummy",
  "chocolate",
  "mint",
  "tincture",
  "topical",
  "cream",
  "balm",
  "lotion",
]);

const FLOWER_TYPES = new Set([
  "flower",
  "pre roll",
  "pre-roll",
  "preroll",
  "bud",
  "buds",
  "shake",
  "smalls",
]);

function resolveCategory(item: CartItem): "Flower" | "Concentrate" | null {
  const explicit = (item.limit_category ?? "").trim().toLowerCase();
  if (explicit === "flower") return "Flower";
  if (explicit === "concentrate") return "Concentrate";

  const pt = (item.product_type ?? "").trim().toLowerCase();
  if (pt && CONCENTRATE_TYPES.has(pt)) return "Concentrate";
  if (pt && FLOWER_TYPES.has(pt)) return "Flower";

  const fallback = (item.type ?? "").trim().toLowerCase();
  if (CONCENTRATE_TYPES.has(fallback)) return "Concentrate";
  if (FLOWER_TYPES.has(fallback)) return "Flower";

  return null;
}

export function computeDailyLimits(cart: CartItem[]) {
  let flower = 0;
  let concentrate = 0;

  for (const item of cart) {
    const grams = parseWeightGrams(item.weight) * item.qty;
    const cat = resolveCategory(item);
    if (cat === "Flower") {
      flower += grams;
    } else if (cat === "Concentrate") {
      concentrate += grams;
    }
  }

  const flowerPct = (flower / FLOWER_LIMIT_GRAMS) * 100;
  const concentratePct = (concentrate / CONCENTRATE_LIMIT_GRAMS) * 100;

  return {
    flowerGrams: flower,
    concentrateGrams: concentrate,
    flowerPct,
    concentratePct,
    isOverLimit: flowerPct > 100 || concentratePct > 100,
  };
}
