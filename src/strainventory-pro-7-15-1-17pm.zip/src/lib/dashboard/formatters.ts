export const formatWholeCurrency = (value: number) =>
  new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    maximumFractionDigits: 0,
  }).format(value);

export const formatCompactNumber = (value: number) =>
  new Intl.NumberFormat("en-US", {
    notation: "compact",
    maximumFractionDigits: 1,
  }).format(value);

export const formatMomentum = (value: number | null | undefined) => {
  if (value === null || value === undefined) return "New this week";
  return `${value > 0 ? "+" : ""}${value}% vs last week`;
};
