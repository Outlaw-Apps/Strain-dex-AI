import { addDays, differenceInCalendarDays, endOfDay, isWithinInterval, startOfDay, startOfWeek, subWeeks } from "date-fns";

export interface WeeklyStrainProduct {
  brand?: string | null;
  strain_type?: string | null;
  type?: string | null;
  effects?: string | null;
  thc?: string | null;
  cbd?: string | null;
  terpenes?: string | null;
  quantity?: number | null;
}

export interface WeeklyStrainOrderItem {
  product_id?: string | null;
  product_name?: string | null;
  quantity?: number | null;
  total_price?: number | null;
  product?: WeeklyStrainProduct | null;
}

export interface WeeklyStrainOrder {
  id: string;
  created_at: string;
  total?: number | null;
  items?: WeeklyStrainOrderItem[] | null;
}

export interface WeeklyStrainPerformanceInput {
  orders: WeeklyStrainOrder[];
  now?: Date;
}

export interface StrainPerformer {
  id: string;
  name: string;
  brand: string;
  strainType: string;
  productType: string;
  effects: string[];
  thc: string;
  cbd: string;
  terpenes: string[];
  revenue: number;
  units: number;
  averagePrice: number;
  sharePercent: number;
  stockLeft: number | null;
  status: "Trending" | "Restock watch" | "Steady";
}

export interface DailyStrainRevenue {
  date: string;
  label: string;
  revenue: number;
  units: number;
}

export interface StrainTypeMix {
  type: string;
  revenue: number;
  units: number;
  sharePercent: number;
}

export interface WeeklyStrainPerformance {
  totalRevenue: number;
  previousRevenue: number;
  totalUnits: number;
  orderCount: number;
  momentumPercent: number | null;
  leadingType: string;
  topStrains: StrainPerformer[];
  dailyRevenue: DailyStrainRevenue[];
  typeMix: StrainTypeMix[];
}

interface StrainAccumulator {
  id: string;
  name: string;
  brand: string;
  strainType: string;
  productType: string;
  effects: string[];
  thc: string;
  cbd: string;
  terpenes: string[];
  revenue: number;
  units: number;
  stockLeft: number | null;
}

const WEEK_STARTS_ON = 1;
const LOW_STOCK_WATCH = 5;

function toNumber(value: number | null | undefined) {
  return Number.isFinite(Number(value)) ? Number(value) : 0;
}

function splitTags(value: string | null | undefined) {
  return (value ?? "")
    .split(",")
    .map((tag) => tag.trim())
    .filter(Boolean)
    .slice(0, 3);
}

function roundCurrency(value: number) {
  return Math.round(value * 100) / 100;
}

function getWeekWindow(now: Date) {
  const weekStart = startOfDay(startOfWeek(now, { weekStartsOn: WEEK_STARTS_ON }));
  const weekEnd = endOfDay(addDays(weekStart, 6));
  const previousWeekStart = subWeeks(weekStart, 1);
  const previousWeekEnd = endOfDay(addDays(previousWeekStart, 6));

  return { weekStart, weekEnd, previousWeekStart, previousWeekEnd };
}

function getMomentumPercent(current: number, previous: number) {
  if (previous === 0) {
    return current > 0 ? 100 : null;
  }

  return Math.round(((current - previous) / previous) * 100);
}

export function buildWeeklyStrainPerformance({
  orders,
  now = new Date(),
}: WeeklyStrainPerformanceInput): WeeklyStrainPerformance {
  const { weekStart, weekEnd, previousWeekStart, previousWeekEnd } = getWeekWindow(now);
  const currentOrders = orders.filter((order) =>
    isWithinInterval(new Date(order.created_at), { start: weekStart, end: weekEnd }),
  );
  const previousOrders = orders.filter((order) =>
    isWithinInterval(new Date(order.created_at), { start: previousWeekStart, end: previousWeekEnd }),
  );

  const strainMap = new Map<string, StrainAccumulator>();
  const typeMap = new Map<string, { revenue: number; units: number }>();
  const dailyRevenue = Array.from({ length: 7 }, (_, index) => {
    const date = addDays(weekStart, index);
    return {
      date: date.toISOString(),
      label: date.toLocaleDateString("en-US", { weekday: "short" }),
      revenue: 0,
      units: 0,
    };
  });

  let totalRevenue = 0;
  let totalUnits = 0;

  currentOrders.forEach((order) => {
    totalRevenue += toNumber(order.total);
    const dayIndex = differenceInCalendarDays(startOfDay(new Date(order.created_at)), weekStart);
    if (dailyRevenue[dayIndex]) {
      dailyRevenue[dayIndex].revenue += toNumber(order.total);
    }

    order.items?.forEach((item) => {
      const product = item.product;
      const id = item.product_id || item.product_name || "unknown";
      const revenue = toNumber(item.total_price);
      const units = toNumber(item.quantity);
      const strainType = product?.strain_type || product?.type || "Uncategorized";

      totalUnits += units;
      if (dailyRevenue[dayIndex]) {
        dailyRevenue[dayIndex].units += units;
      }

      const existing =
        strainMap.get(id) ??
        {
          id,
          name: item.product_name || "Unknown strain",
          brand: product?.brand || "House",
          strainType,
          productType: product?.type || "Product",
          effects: splitTags(product?.effects),
          thc: product?.thc || "N/A",
          cbd: product?.cbd || "N/A",
          terpenes: splitTags(product?.terpenes),
          revenue: 0,
          units: 0,
          stockLeft: typeof product?.quantity === "number" ? product.quantity : null,
        };

      existing.revenue += revenue;
      existing.units += units;
      strainMap.set(id, existing);

      const typeBucket = typeMap.get(strainType) ?? { revenue: 0, units: 0 };
      typeBucket.revenue += revenue;
      typeBucket.units += units;
      typeMap.set(strainType, typeBucket);
    });
  });

  const topStrains = Array.from(strainMap.values())
    .sort((a, b) => b.revenue - a.revenue || b.units - a.units)
    .map((strain, index): StrainPerformer => {
      const sharePercent = totalRevenue ? Math.round((strain.revenue / totalRevenue) * 100) : 0;
      const isLowStock = strain.stockLeft !== null && strain.stockLeft <= LOW_STOCK_WATCH;

      return {
        ...strain,
        revenue: roundCurrency(strain.revenue),
        averagePrice: strain.units ? roundCurrency(strain.revenue / strain.units) : 0,
        sharePercent,
        status: isLowStock ? "Restock watch" : index === 0 || sharePercent >= 40 ? "Trending" : "Steady",
      };
    });

  const typeMix = Array.from(typeMap.entries())
    .map(([type, totals]) => ({
      type,
      revenue: roundCurrency(totals.revenue),
      units: totals.units,
      sharePercent: totalRevenue ? Math.round((totals.revenue / totalRevenue) * 100) : 0,
    }))
    .sort((a, b) => b.revenue - a.revenue);

  const previousRevenue = previousOrders.reduce((sum, order) => sum + toNumber(order.total), 0);

  return {
    totalRevenue: roundCurrency(totalRevenue),
    previousRevenue: roundCurrency(previousRevenue),
    totalUnits,
    orderCount: currentOrders.length,
    momentumPercent: getMomentumPercent(totalRevenue, previousRevenue),
    leadingType: typeMix[0]?.type ?? "No sales yet",
    topStrains,
    dailyRevenue: dailyRevenue.map((day) => ({ ...day, revenue: roundCurrency(day.revenue) })),
    typeMix,
  };
}
