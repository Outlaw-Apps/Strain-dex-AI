import type { PayrollTimeEntry } from "@/lib/payroll";

/**
 * Calculates the duration (in hours) of a time entry.
 * - Returns null when the timestamps are invalid.
 * - For open entries (no clock_out) it uses `now` as the implied end time.
 */
export function calculateTimeEntryHours(
  entry: PayrollTimeEntry,
  now: Date,
): number | null {
  const start = new Date(entry.clock_in);
  const end = entry.clock_out ? new Date(entry.clock_out) : now;
  if (Number.isNaN(start.getTime()) || Number.isNaN(end.getTime())) return null;
  const ms = end.getTime() - start.getTime();
  if (ms <= 0) return 0;
  return ms / (1000 * 60 * 60);
}
