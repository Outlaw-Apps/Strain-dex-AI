export interface BogoLineUnit {
  /** Stable key for merging discount back onto cart rows — product id suffices in this POS. */
  cartLineKey: string;
  productId: string;
  /** Dollars for one weighed unit before BOGO splits */
  unitAdjustedPrice: number;
  /** Rows with clearance pricing must skip BOGO (non-stack). */
  /** Number of weighed units on this cart line */
  qty: number;
  /** Rows with clearance pricing must skip BOGO (non-stack). */
  hasClearance: boolean;
}

type BogoUnit = Omit<BogoLineUnit, "qty">;

/**
 * Computes total BOGO markdown dollars per cart line (`cartLineKey`),
 * enforcing same-SKU pooling and cheapest-free / cheapest-half rules.
 */
export function computeBogoLineDiscounts(
  lines: Pick<BogoLineUnit, "qty" | "cartLineKey" | "productId" | "unitAdjustedPrice" | "hasClearance">[],
  mode: "buy1_get1_free" | "buy1_get1_half",
): Map<string, number> {
  const out = new Map<string, number>();

  /** Expand qty → discrete units grouped by SKU */
  type Unit = BogoUnit;
  const bySku = new Map<string, Unit[]>();

  for (const line of lines) {
    if (!line.qty || line.unitAdjustedPrice < 0) continue;

    let arr = bySku.get(line.productId);
    if (!arr) {
      arr = [];
      bySku.set(line.productId, arr);
    }

    const entry: Unit = {
      cartLineKey: line.cartLineKey,
      productId: line.productId,
      unitAdjustedPrice: Math.max(0, line.unitAdjustedPrice),
      hasClearance: line.hasClearance,
    };

    for (let q = 0; q < line.qty; q += 1) {
      arr.push({ ...entry });
    }
  }

  const pct = mode === "buy1_get1_free" ? 1 : 0.5;

  for (const [, units] of bySku.entries()) {
    const eligible = units.filter((u) => !u.hasClearance && u.unitAdjustedPrice > 0);
    eligible.sort((a, b) => a.unitAdjustedPrice - b.unitAdjustedPrice);

    for (let idx = 0; idx < eligible.length; idx += 1) {
      /** BOGO pairing: cheapest item in every pair is rewarded (classic retail pattern). */
      if (idx % 2 !== 1) continue;
      const u = eligible[idx]!;
      const discount = Number((u.unitAdjustedPrice * pct).toFixed(2));
      const prior = out.get(u.cartLineKey) ?? 0;
      out.set(u.cartLineKey, Number((prior + discount).toFixed(2)));
    }
  }

  return out;
}
