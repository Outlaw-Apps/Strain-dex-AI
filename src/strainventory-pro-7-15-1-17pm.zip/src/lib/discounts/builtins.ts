import type { DiscountDefinition } from "@/lib/discounts/types";

export const CUSTOMER_PERCENT_DEFINITIONS: DiscountDefinition[] = [
  {
    id: "cust-employee",
    name: "Employee",
    type: "customer_percent",
    scope: "ticket",
    percentOff: 25,
    requiresApproval: true,
    requiresCustomerFlag: "employee",
    priority: 440,
  },
  {
    id: "cust-senior",
    name: "Senior",
    type: "customer_percent",
    scope: "ticket",
    percentOff: 10,
    requiresApproval: false,
    requiresCustomerFlag: "senior",
    priority: 430,
  },
  {
    id: "cust-military",
    name: "Military",
    type: "customer_percent",
    scope: "ticket",
    percentOff: 20,
    requiresApproval: false,
    requiresCustomerFlag: "military",
    priority: 420,
  },
  {
    id: "cust-police",
    name: "Police",
    type: "customer_percent",
    scope: "ticket",
    percentOff: 20,
    requiresApproval: false,
    requiresCustomerFlag: "police",
    priority: 419,
  },
  {
    id: "cust-fire",
    name: "Fire",
    type: "customer_percent",
    scope: "ticket",
    percentOff: 20,
    requiresApproval: false,
    requiresCustomerFlag: "fire",
    priority: 418,
  },
];

export const BOGO_DEFINITION_ID = "cart-bogo-mixed";

export function findBuiltinCustomerDiscount(id: string): DiscountDefinition | undefined {
  return CUSTOMER_PERCENT_DEFINITIONS.find((d) => d.id === id);
}
