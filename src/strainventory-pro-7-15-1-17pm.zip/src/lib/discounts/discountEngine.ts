import type { CartItem } from "@/pages/PointOfSale";
import type { Customer } from "@/hooks/useCustomers";
import { getCartLineTotal, getWeightedUnitPrice } from "@/lib/posPricing";
import { computeBogoLineDiscounts } from "@/lib/discounts/bogo";
import type {
  AppliedDiscount,
  CartLinePricing,
  CartPricingResult,
  DiscountDefinition,
  TicketPromotionSelection,
} from "@/lib/discounts/types";
import { findBuiltinCustomerDiscount, BOGO_DEFINITION_ID } from "@/lib/discounts/builtins";
import { isAgeVerified, isSeniorEligible } from "@/lib/discounts/eligibility";
import { summarizeAppliedDiscounts } from "@/lib/discounts/formatters";
import { resolveProductPricing } from "@/lib/discounts/productPrice";

export const DEFAULT_POS_TAX_RATE = 0.15;

function round2(value: number) {
  return Math.round(Math.max(0, value) * 100) / 100;
}

function customerFlagSatisfied(
  customer: Customer,
  flag: NonNullable<DiscountDefinition["requiresCustomerFlag"]>,
  now: Date,
  employeeManagerOk: boolean,
): boolean {
  switch (flag) {
    case "employee":
      return customer.is_employee && employeeManagerOk;
    case "senior":
      return isSeniorEligible(customer, now);
    case "military":
      return customer.is_military;
    case "police":
      return customer.is_police;
    case "fire":
      return customer.is_fire;
    default:
      return false;
  }
}

export function isCustomerDiscountEligible(
  customer: Customer | null,
  definitionId: string,
  now: Date,
  employeeManagerOk: boolean,
): boolean {
  if (!customer || !isAgeVerified(customer)) return false;
  const def = findBuiltinCustomerDiscount(definitionId);
  if (!def?.requiresCustomerFlag) return false;
  return customerFlagSatisfied(customer, def.requiresCustomerFlag, now, employeeManagerOk);
}

export interface CartPricingInput {
  cart: CartItem[];
  customer: Customer | null;
  now?: Date;
  taxRate?: number;
  ticket: TicketPromotionSelection;
  /** Manager Override ON satisfies employee discount governance. */
  employeeDiscountManagerOk: boolean;
}

export function calculateCartPricing({
  cart,
  customer,
  now = new Date(),
  taxRate = DEFAULT_POS_TAX_RATE,
  ticket,
  employeeDiscountManagerOk,
}: CartPricingInput): CartPricingResult {
  const appliedAutomatic: AppliedDiscount[] = [];

  type Row = {
    cartLineKey: string;
    productId: string;
    productName: string;
    weight: string;
    qty: number;
    listUnitPrice: number;
    adjustedUnitPreCart: number;
    clearance: boolean;
    sale: boolean;
    lineListTotal: number;
    lineAdjustedSubtotal: number;
    autoIds: string[];
  };

  const rows: Row[] = [];
  let listSubtotalAll = 0;
  let saleSaved = 0;
  let clearanceSaved = 0;

  for (const item of cart) {
    if (item.qty <= 0) continue;

    const slice = resolveProductPricing(item, now);

    const listUnit = round2(getWeightedUnitPrice(slice.listPpg, item.weight));
    const adjUnit = round2(getWeightedUnitPrice(slice.effectivePpg, item.weight));

    const lineListTotal = round2(getCartLineTotal(slice.listPpg, item.weight, item.qty));
    const lineAdjustedSubtotal = round2(getCartLineTotal(slice.effectivePpg, item.weight, item.qty));

    listSubtotalAll = round2(listSubtotalAll + lineListTotal);

    if (slice.clearance && lineListTotal > lineAdjustedSubtotal) {
      clearanceSaved = round2(clearanceSaved + Math.max(0, lineListTotal - lineAdjustedSubtotal));
    } else if (slice.sale && lineListTotal > lineAdjustedSubtotal) {
      saleSaved = round2(saleSaved + Math.max(0, lineListTotal - lineAdjustedSubtotal));
    }

    const autoIds: string[] = [];
    if (slice.clearance) autoIds.push(`clearance-price:${item.id}`);
    else if (slice.sale) autoIds.push(`sale-price:${item.id}`);

    rows.push({
      cartLineKey: item.id,
      productId: item.id,
      productName: item.name,
      weight: item.weight,
      qty: item.qty,
      listUnitPrice: listUnit,
      adjustedUnitPreCart: adjUnit,
      clearance: slice.clearance,
      sale: slice.sale,
      lineListTotal,
      lineAdjustedSubtotal,
      autoIds,
    });
  }

  if (saleSaved > 0) {
    appliedAutomatic.push({
      definitionId: "auto-sale-pricing",
      definitionName: "Sale pricing",
      summary: itemSaleLabel(rows),
      amountOff: saleSaved,
      automated: true,
    });
  }

  if (clearanceSaved > 0) {
    appliedAutomatic.push({
      definitionId: "auto-clearance-pricing",
      definitionName: "Clearance pricing",
      summary: "Markdown active on tagged items.",
      amountOff: clearanceSaved,
      automated: true,
    });
  }

  const bogoMap =
    ticket.kind === "bogo"
      ? computeBogoLineDiscounts(
          rows.map((r) => ({
            cartLineKey: r.cartLineKey,
            productId: r.productId,
            qty: r.qty,
            unitAdjustedPrice: round2(r.lineAdjustedSubtotal / Math.max(1, r.qty)),
            hasClearance: r.clearance,
          })),
          ticket.mode,
        )
      : new Map<string, number>();

  let bogoTotal = 0;
  const afterBogo = rows.map((r) => {
    const chop = ticket.kind === "bogo" ? round2(bogoMap.get(r.cartLineKey) ?? 0) : 0;
    bogoTotal = round2(bogoTotal + chop);
    return {
      ...r,
      lineAfterBogo: round2(Math.max(0, r.lineAdjustedSubtotal - chop)),
    };
  });

  if (ticket.kind === "bogo") {
    if (bogoTotal > 0) {
      appliedAutomatic.push({
        definitionId: BOGO_DEFINITION_ID,
        definitionName:
          ticket.mode === "buy1_get1_half" ? "BOGO · second item half off" : "BOGO · buy one get one free",
        summary: `Same SKU, cheapest rewarded; clearance excluded.`,
        amountOff: bogoTotal,
        automated: false,
      });
    } else if (cart.length > 0) {
      appliedAutomatic.push({
        definitionId: BOGO_DEFINITION_ID,
        definitionName: "BOGO (no qualifying pair)",
        summary: `Add paired same-SKU eligible units (excluding clearance).`,
        amountOff: 0,
        automated: false,
      });
    }
  }

  const ticketDiscountsManual: AppliedDiscount[] = [];

  /** dollars taken from each eligible line via ticket %-off */
  const customerShareMap = new Map<string, number>();

  if (
    ticket.kind === "customer" &&
    ticket.definitionId &&
    customer &&
    isAgeVerified(customer)
  ) {
    const def = findBuiltinCustomerDiscount(ticket.definitionId);
    const pctRaw = def?.percentOff ?? 0;
    const pct = Math.max(0, pctRaw) / 100;

    if (def?.requiresCustomerFlag && customerFlagSatisfied(customer, def.requiresCustomerFlag, now, employeeDiscountManagerOk) && pct > 0) {
      /** Customer % does not apply to clearance items (maintain margins). */
      const eligibleLines = afterBogo.filter((r) => !r.clearance && r.lineAfterBogo > 0);

      const eligibleBase = eligibleLines.reduce((s, r) => round2(s + r.lineAfterBogo), 0);

      if (eligibleBase > 0.001) {
        const grossOff = round2(eligibleBase * pct);

        let allocated = 0;
        eligibleLines.forEach((r, idx) => {
          const isLast = idx === eligibleLines.length - 1;
          const share = isLast ? round2(grossOff - allocated) : round2((grossOff * r.lineAfterBogo) / eligibleBase);
          const capped = Math.min(share, r.lineAfterBogo, round2(grossOff - allocated));
          allocated = round2(allocated + capped);
          customerShareMap.set(r.cartLineKey, capped);
        });

        ticketDiscountsManual.push({
          definitionId: def.id,
          definitionName: def.name,
          summary: `${pctRaw}% on eligible merchandise`,
          amountOff: round2(Array.from(customerShareMap.values()).reduce((s, x) => s + x, 0)),
          automated: false,
          usedManagerOverride: def.id === "cust-employee" ? employeeDiscountManagerOk : undefined,
        });
      }
    }
  }

  const linesOut: CartLinePricing[] = afterBogo.map((r) => {
    const bogoAmt = ticket.kind === "bogo" ? round2(bogoMap.get(r.cartLineKey) ?? 0) : 0;
    const share = round2(customerShareMap.get(r.cartLineKey) ?? 0);

    const lineAfterBogo = r.lineAfterBogo;
    const lineFinal = round2(Math.max(0, lineAfterBogo - share));
    const discUnit =
      r.qty > 0 ? round2(lineFinal / r.qty) : 0;

    return {
      cartLineId: r.cartLineKey,
      productId: r.productId,
      productName: r.productName,
      weight: r.weight,
      qty: r.qty,
      listUnitPrice: r.listUnitPrice,
      adjustedUnitPricePreCart: r.adjustedUnitPreCart,
      lineSubtotalAfterBogo: lineAfterBogo,
      clearanceApplied: r.clearance,
      saleApplied: r.sale && !r.clearance,
      customerDiscountShare: share,
      discountedUnitPrice: discUnit,
      lineTotalFinal: lineFinal,
      appliedAutomaticIds: [...r.autoIds],
    };
  });

  const merchandiseSubtotal = round2(rows.reduce((s, r) => s + r.lineAdjustedSubtotal, 0));

  const mergedApplied = [...appliedAutomatic, ...ticketDiscountsManual];

  const finalSum = round2(linesOut.reduce((s, l) => s + l.lineTotalFinal, 0));
  const discountTotal = round2(listSubtotalAll - finalSum);
  const tax = round2(finalSum * taxRate);
  const grandTotal = round2(finalSum + tax);

  const payload: CartPricingResult = {
    lines: linesOut,
    appliedDiscounts: mergedApplied,
    listSubtotal: listSubtotalAll,
    merchandiseSubtotal,
    discountTotal,
    discountSummary: summarizeAppliedDiscounts(mergedApplied),
    taxableSubtotal: finalSum,
    tax,
    grandTotal,
    snapshot: {
      version: 1 as const,
      at: now.toISOString(),
      ticketSelection: ticket,
      taxRate,
      totals: {
        listSubtotal: listSubtotalAll,
        merchandiseSubtotal,
        discountTotal,
        taxableSubtotal: finalSum,
        tax,
        grandTotal,
      },
      lines: linesOut,
      definitionsApplied: mergedApplied.map((a) => ({
        id: a.definitionId,
        name: a.definitionName,
        amountOff: a.amountOff,
        automated: a.automated,
        summary: a.summary,
      })),
    },
  };

  return payload;
}

function itemSaleLabel(rows: Array<{ productName: string; sale: boolean; clearance: boolean }>) {
  const labels = rows
    .filter((r) => r.sale && !r.clearance)
    .map((r) => r.productName)
    .slice(0, 3);
  if (labels.length === 0) return "Promotional price window.";
  if (labels.length <= 2) return labels.join(", ");
  return `${labels.join(", ")}, …`;
}
