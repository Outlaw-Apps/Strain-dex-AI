import type { Customer } from "@/hooks/useCustomers";

const SENIOR_AGE_MIN = 65;

export function isAgeVerified(customer: Customer | null): boolean {
  return Boolean(customer?.last_age_verified_at);
}

/** Senior via explicit flag or DOB (California-style budtender check still requires ID ✓ gate). */
export function isSeniorEligible(customer: Customer | null, reference: Date): boolean {
  if (!customer) return false;
  if (customer.is_senior) return true;
  if (!customer.date_of_birth) return false;
  const computed = computeAgeYears(customer.date_of_birth, reference);
  return computed !== null && computed >= SENIOR_AGE_MIN;
}

export function computeAgeYears(isoDate: string, reference: Date): number | null {
  const d = new Date(isoDate);
  if (Number.isNaN(d.getTime())) return null;

  let years = reference.getFullYear() - d.getFullYear();
  const m = reference.getMonth() - d.getMonth();
  if (m < 0 || (m === 0 && reference.getDate() < d.getDate())) {
    years -= 1;
  }
  return years;
}
