import type { AppliedDiscount } from "@/lib/discounts/types";

export function summarizeAppliedDiscounts(applied: AppliedDiscount[]): string {
  const parts = applied
    .filter((a) => a.amountOff > 0.005 || a.definitionName.includes("BOGO"))
    .map((a) => `${a.definitionName}`);
  return parts.length ? parts.join("; ") : "None";
}

export function receiptDiscountLines(applied: AppliedDiscount[]): string[] {
  return applied
    .filter((a) => a.amountOff > 0 || !a.automated)
    .map((a) => `${a.definitionName}${a.summary ? `: ${a.summary}` : ""} (${a.amountOff.toFixed(2)})`);
}
