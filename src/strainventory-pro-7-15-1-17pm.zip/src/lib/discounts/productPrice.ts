/** Product shelf pricing tiers: clearance beats sale beats list catalog price (/g). */

import type { Product } from "@/hooks/useProducts";

export interface ProductPricingSlice {
  listPpg: number;
  effectivePpg: number;
  clearance: boolean;
  sale: boolean;
}

function readSaleLive(
  saleStarts: string | null | undefined,
  saleEnds: string | null | undefined,
  now: Date,
) {
  if (saleStarts) {
    const t = new Date(saleStarts).getTime();
    if (!Number.isNaN(t) && now.getTime() < t) return false;
  }
  if (saleEnds) {
    const t = new Date(saleEnds).getTime();
    if (!Number.isNaN(t) && now.getTime() > t) return false;
  }
  return true;
}

/** Works for live catalog rows or cart snapshots (both carry the same wholesale fields). */
export function resolveProductPricing(
  item: Pick<
    Product,
    | "price"
    | "clearance_price"
    | "clearance_active"
    | "sale_price"
    | "sale_starts_at"
    | "sale_ends_at"
  >,
  now: Date,
): ProductPricingSlice {
  const listPpg = Math.max(0, Number(item.price) || 0);

  const clearanceRaw = item.clearance_price;
  const clearanceActive =
    Boolean(item.clearance_active) && clearanceRaw != null && !Number.isNaN(Number(clearanceRaw));
  if (clearanceActive) {
    const cppg = Math.max(0, Number(clearanceRaw));
    return { listPpg, effectivePpg: cppg, clearance: true, sale: false };
  }

  const saleRaw = item.sale_price;
  if (
    saleRaw != null &&
    !Number.isNaN(Number(saleRaw)) &&
    readSaleLive(item.sale_starts_at, item.sale_ends_at, now)
  ) {
    const sppg = Math.max(0, Number(saleRaw));
    return { listPpg, effectivePpg: sppg, clearance: false, sale: true };
  }

  return { listPpg, effectivePpg: listPpg, clearance: false, sale: false };
}
