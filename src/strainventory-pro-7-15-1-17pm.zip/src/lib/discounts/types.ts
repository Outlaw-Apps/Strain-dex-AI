export type DiscountDefinitionType =
  | "customer_percent"
  | "product_override"
  | "cart_rule";

export type DiscountScope = "ticket" | "line_item" | "cart_group";

/** Static definition used by the POS engine before optional DB rows mirror this. */
export interface DiscountDefinition {
  id: string;
  name: string;
  type: DiscountDefinitionType;
  scope: DiscountScope;
  percentOff?: number;
  pricingMode?: string;
  requiresApproval: boolean;
  requiresCustomerFlag?: "employee" | "senior" | "military" | "police" | "fire";
  /** Lower runs first inside the phase; precedence order is enforced in engine. */
  priority: number;
}

export interface AppliedDiscount {
  definitionId: string;
  definitionName: string;
  /** Human-readable rationale / receipt line */
  summary: string;
  amountOff: number;
  /** Whether this application should show in “manual” UX */
  automated: boolean;
  /** BOGO/customer tiers can require manager acknowledgement */
  usedManagerOverride?: boolean;
}

export type TicketPromotionSelection =
  | { kind: "none" }
  | { kind: "customer"; definitionId: string }
  | { kind: "bogo"; mode: "buy1_get1_free" | "buy1_get1_half" };

export interface CartLinePricing {
  cartLineId: string;
  productId: string;
  productName: string;
  weight: string;
  qty: number;
  listUnitPrice: number;
  adjustedUnitPricePreCart: number;
  /** After cart-level BOGO allocations */
  lineSubtotalAfterBogo: number;
  clearanceApplied: boolean;
  saleApplied: boolean;
  /** Share of allocated ticket-level percent discount (if any), dollars */
  customerDiscountShare: number;
  discountedUnitPrice: number;
  lineTotalFinal: number;
  appliedAutomaticIds: string[];
}

export interface CartPricingResult {
  lines: CartLinePricing[];
  appliedDiscounts: AppliedDiscount[];
  /** Sum of weighted list totals (catalog list price × weight × qty) */
  listSubtotal: number;
  /** After sale/clearance and BOGO, before ticket % */
  merchandiseSubtotal: number;
  /** Total dollars removed from catalog list → final */
  discountTotal: number;
  /** Text summary joined for order.discount_summary */
  discountSummary: string;
  taxableSubtotal: number;
  tax: number;
  grandTotal: number;
  snapshot: Record<string, unknown>;
}
