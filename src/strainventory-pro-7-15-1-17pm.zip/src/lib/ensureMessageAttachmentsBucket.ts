import { supabase } from "@/integrations/supabase/client";

/**
 * Verifies the `message-attachments` storage bucket exists, and asks the
 * `cleanup-message-attachments` edge function to create it if missing.
 *
 * Runs at most once per browser session to avoid noisy network calls.
 */
let ensurePromise: Promise<void> | null = null;

export const ensureMessageAttachmentsBucket = (): Promise<void> => {
  if (ensurePromise) return ensurePromise;
  ensurePromise = (async () => {
    try {
      const { error } = await supabase.functions.invoke(
        "cleanup-message-attachments",
        { body: { mode: "ensure" } },
      );
      if (error) {
        // Reset so a future caller (e.g. an upload retry) can try again.
        ensurePromise = null;
        console.warn("[startup] message-attachments bucket check failed", error);
      }
    } catch (err) {
      ensurePromise = null;
      console.warn("[startup] message-attachments bucket check threw", err);
    }
  })();
  return ensurePromise;
};
