import { toast } from "sonner";

const sanitize = (name: string) =>
  name.replace(/[^a-z0-9._-]+/gi, "_").slice(0, 80) || "image";

export async function downloadImage(url: string, alt: string) {
  const extMatch = url.split("?")[0].match(/\.(jpg|jpeg|png|webp|gif|avif)$/i);
  const ext = extMatch ? extMatch[1].toLowerCase() : "jpg";
  const filename = `${sanitize(alt)}.${ext}`;
  try {
    const res = await fetch(url, { mode: "cors" });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const blob = await res.blob();
    const objectUrl = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = objectUrl;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(objectUrl), 1000);
    toast.success("Image downloaded.");
  } catch {
    // CORS or network — fall back to opening original
    window.open(url, "_blank", "noopener,noreferrer");
    toast.info("Opened image in a new tab — right-click to save.");
  }
}
