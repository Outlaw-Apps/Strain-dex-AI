import { supabase } from "@/integrations/supabase/client";
import { z } from "zod";

/**
 * Production-safe image upload helpers for Supabase Storage.
 *
 * Two flows are exposed:
 *
 *   1. `uploadImage(...)` — client uploads directly using the user's JWT.
 *      RLS on `storage.objects` scopes writes to `{auth.uid()}/...`, so the
 *      caller can only write inside their own folder. Use this for interactive
 *      uploads from a logged-in user (avatar, product photo they own).
 *
 *   2. `createSignedUploadTicket(...)` — mint a one-shot signed upload URL
 *      server-side and hand it to the browser. Use this when the writer is
 *      NOT the acting user (background job, admin uploading for another
 *      user, unauthenticated form). The ticket bypasses RLS, so it must be
 *      minted by trusted server code (edge function using the service role).
 *
 * Reads on private buckets always go through `getSignedImageUrl(...)` — the
 * client never fabricates a public URL for a private bucket.
 */

// ---------------------------------------------------------------------------
// Validation
// ---------------------------------------------------------------------------

export const IMAGE_MIME_TYPES = [
  "image/jpeg",
  "image/png",
  "image/webp",
  "image/gif",
  "image/avif",
] as const;

export type ImageMimeType = (typeof IMAGE_MIME_TYPES)[number];

export const DEFAULT_MAX_BYTES = 10 * 1024 * 1024; // 10 MB

const imageFileSchema = (maxBytes: number, allowed: readonly string[]) =>
  z
    .instanceof(File, { message: "A file is required" })
    .refine((f) => f.size > 0, { message: "File is empty" })
    .refine((f) => f.size <= maxBytes, {
      message: `File must be ${(maxBytes / 1024 / 1024).toFixed(0)} MB or smaller`,
    })
    .refine((f) => (allowed as readonly string[]).includes(f.type), {
      message: `Unsupported file type. Allowed: ${allowed.join(", ")}`,
    });

// ---------------------------------------------------------------------------
// Path builders — always prefix with the acting user's id so RLS lets the
// write through and one user can never overwrite another user's file.
// ---------------------------------------------------------------------------

const safeName = (name: string) =>
  name
    .toLowerCase()
    .replace(/[^a-z0-9._-]+/g, "-")
    .replace(/-+/g, "-")
    .replace(/^-|-$/g, "")
    .slice(0, 80) || "file";

const extFromMime = (mime: string) =>
  ({
    "image/jpeg": "jpg",
    "image/png": "png",
    "image/webp": "webp",
    "image/gif": "gif",
    "image/avif": "avif",
  })[mime] ?? "bin";

export const buildOwnedObjectPath = (
  userId: string,
  file: File,
  subfolder?: string,
) => {
  const stamp = `${Date.now()}-${crypto.randomUUID().slice(0, 8)}`;
  const base = safeName(file.name.replace(/\.[^.]+$/, ""));
  const ext = file.name.includes(".")
    ? safeName(file.name.split(".").pop() ?? extFromMime(file.type))
    : extFromMime(file.type);
  const folder = subfolder ? `${userId}/${safeName(subfolder)}` : userId;
  return `${folder}/${stamp}-${base}.${ext}`;
};

// ---------------------------------------------------------------------------
// Client-side upload (user's JWT + RLS)
// ---------------------------------------------------------------------------

export interface UploadImageOptions {
  bucket: string;
  file: File;
  subfolder?: string;
  maxBytes?: number;
  allowedMimeTypes?: readonly string[];
  /** Set false to force a fresh object (default: overwrites the same key). */
  upsert?: boolean;
}

export interface UploadImageResult {
  bucket: string;
  path: string;
  /** Public URL when the bucket is public — otherwise call getSignedImageUrl. */
  publicUrl: string | null;
}

export async function uploadImage(
  opts: UploadImageOptions,
): Promise<UploadImageResult> {
  const {
    bucket,
    file,
    subfolder,
    maxBytes = DEFAULT_MAX_BYTES,
    allowedMimeTypes = IMAGE_MIME_TYPES,
    upsert = false,
  } = opts;

  const parsed = imageFileSchema(maxBytes, allowedMimeTypes).safeParse(file);
  if (!parsed.success) {
    throw new Error(parsed.error.issues[0]?.message ?? "Invalid file");
  }

  const {
    data: { user },
    error: authError,
  } = await supabase.auth.getUser();
  if (authError || !user) throw new Error("You must be signed in to upload");

  const path = buildOwnedObjectPath(user.id, file, subfolder);

  const { error: uploadError } = await supabase.storage
    .from(bucket)
    .upload(path, file, {
      contentType: file.type,
      cacheControl: "3600",
      upsert,
    });
  if (uploadError) throw uploadError;

  // Fetch the public URL — Supabase returns a URL string for private buckets
  // too, but it 400s at fetch time. We probe the bucket setting once via a
  // signed URL call is unnecessary; callers who need a URL for a private
  // bucket should use getSignedImageUrl instead.
  const { data } = supabase.storage.from(bucket).getPublicUrl(path);
  return { bucket, path, publicUrl: data.publicUrl ?? null };
}

// ---------------------------------------------------------------------------
// Signed read (private buckets)
// ---------------------------------------------------------------------------

export async function getSignedImageUrl(
  bucket: string,
  path: string,
  expiresInSeconds = 60 * 60, // 1 hour default
): Promise<string> {
  const { data, error } = await supabase.storage
    .from(bucket)
    .createSignedUrl(path, expiresInSeconds);
  if (error || !data?.signedUrl) {
    throw error ?? new Error("Failed to sign URL");
  }
  return data.signedUrl;
}

// ---------------------------------------------------------------------------
// Signed upload (server-issued ticket → client PUT)
// Use in an edge function with the service role, then return the token to
// the browser. The browser calls `uploadWithSignedTicket` below.
// ---------------------------------------------------------------------------

export interface SignedUploadTicket {
  bucket: string;
  path: string;
  token: string;
}

export async function uploadWithSignedTicket(
  ticket: SignedUploadTicket,
  file: File,
  opts?: { maxBytes?: number; allowedMimeTypes?: readonly string[] },
): Promise<UploadImageResult> {
  const parsed = imageFileSchema(
    opts?.maxBytes ?? DEFAULT_MAX_BYTES,
    opts?.allowedMimeTypes ?? IMAGE_MIME_TYPES,
  ).safeParse(file);
  if (!parsed.success) {
    throw new Error(parsed.error.issues[0]?.message ?? "Invalid file");
  }

  const { error } = await supabase.storage
    .from(ticket.bucket)
    .uploadToSignedUrl(ticket.path, ticket.token, file, {
      contentType: file.type,
      upsert: false,
    });
  if (error) throw error;

  const { data } = supabase.storage.from(ticket.bucket).getPublicUrl(ticket.path);
  return { bucket: ticket.bucket, path: ticket.path, publicUrl: data.publicUrl ?? null };
}

// ---------------------------------------------------------------------------
// Delete (RLS still applies)
// ---------------------------------------------------------------------------

export async function deleteImage(bucket: string, path: string): Promise<void> {
  const { error } = await supabase.storage.from(bucket).remove([path]);
  if (error) throw error;
}
