import jsPDF from "jspdf";
import JsBarcode from "jsbarcode";
import QRCode from "qrcode";
import type { LabelTemplateConfig } from "@/hooks/useLabelTemplates";

export interface LabelItem {
  id: string;
  title: string;
  subtitle?: string;
  value: string;
  price?: number | null;
  brand?: string;
  strain?: string;
  strainType?: string;
  productType?: string;
  packageSize?: string;
  thc?: string;
  cbd?: string;
  sku?: string;
  terpenes?: string;
  description?: string;
}

const SIZE_INCHES: Record<string, { w: number; h: number }> = {
  small: { w: 2, h: 1 },
  medium: { w: 2.625, h: 1 },
  large: { w: 4, h: 2 },
  shelf: { w: 4, h: 3 },
};

function dims(cfg: LabelTemplateConfig) {
  if (cfg.size === "custom") {
    return { w: cfg.customWidthIn ?? 2.625, h: cfg.customHeightIn ?? 1 };
  }
  return SIZE_INCHES[cfg.size] ?? SIZE_INCHES.medium;
}

function fontName(family: LabelTemplateConfig["fontFamily"]): string {
  if (family === "serif") return "times";
  if (family === "mono") return "courier";
  return "helvetica";
}

async function renderBarcodeDataURL(value: string, format: string): Promise<string> {
  const canvas = document.createElement("canvas");
  JsBarcode(canvas, value, {
    format,
    width: 2,
    height: 60,
    displayValue: true,
    fontSize: 12,
    margin: 4,
    background: "#ffffff",
  });
  return canvas.toDataURL("image/png");
}

async function renderQrDataURL(value: string, level: "L" | "M" | "Q" | "H"): Promise<string> {
  return await QRCode.toDataURL(value, {
    errorCorrectionLevel: level,
    margin: 1,
    width: 320,
  });
}

export async function exportLabelsPdf(
  labels: LabelItem[],
  cfg: LabelTemplateConfig,
  filename = "labels.pdf",
) {
  if (!labels.length) return;
  const { w, h } = dims(cfg);
  const doc = new jsPDF({ unit: "in", format: "letter" });
  const pageW = doc.internal.pageSize.getWidth();
  const pageH = doc.internal.pageSize.getHeight();
  const marginX = 0.25;
  const marginY = 0.5;
  const gap = 0.1;
  const cols = Math.max(1, Math.floor((pageW - marginX * 2 + gap) / (w + gap)));
  const rows = Math.max(1, Math.floor((pageH - marginY * 2 + gap) / (h + gap)));
  const perPage = cols * rows;

  const font = fontName(cfg.fontFamily);

  for (let i = 0; i < labels.length; i++) {
    const l = labels[i];
    const pageIdx = Math.floor(i / perPage);
    const slot = i % perPage;
    const row = Math.floor(slot / cols);
    const col = slot % cols;
    if (slot === 0 && pageIdx > 0) doc.addPage();

    const x = marginX + col * (w + gap);
    const y = marginY + row * (h + gap);

    doc.setDrawColor(180);
    doc.setLineWidth(0.005);
    doc.rect(x, y, w, h);

    const innerPad = 0.08;
    const contentW = w - innerPad * 2;
    let cursorY = y + innerPad + 0.12;

    // Auto-fit title — shrink font until single-line fits
    let titleSize = cfg.titleFontSize;
    doc.setFont(font, cfg.fontWeight);
    while (titleSize > 6 && doc.getStringUnitWidth(l.title) * (titleSize / 72) > contentW) {
      titleSize -= 0.5;
    }
    doc.setFontSize(titleSize);
    doc.setTextColor(20);
    doc.text(l.title, x + w / 2, cursorY, { align: "center" });
    cursorY += titleSize / 60;

    if (cfg.showSubtitle && l.subtitle) {
      doc.setFont(font, "normal");
      doc.setFontSize(cfg.subtitleFontSize);
      doc.setTextColor(90);
      doc.text(l.subtitle, x + w / 2, cursorY, { align: "center" });
      cursorY += cfg.subtitleFontSize / 70;
    }

    // Shelf / extra catalog detail lines
    const detailLines: string[] = [];
    const potency: string[] = [];
    if (cfg.showThc && l.thc) potency.push(`THC ${l.thc}`);
    if (cfg.showCbd && l.cbd) potency.push(`CBD ${l.cbd}`);
    if (potency.length) detailLines.push(potency.join("  ·  "));
    if (cfg.showStrainType && l.strainType) detailLines.push(l.strainType);
    if (cfg.showTerpenes && l.terpenes) detailLines.push(`Terps: ${l.terpenes}`);
    if (cfg.showDescription && l.description) detailLines.push(l.description);
    if (cfg.showSku && l.sku) detailLines.push(`SKU ${l.sku}`);

    if (detailLines.length) {
      doc.setFont(font, "normal");
      const detailSize = Math.max(6, cfg.subtitleFontSize - 1);
      doc.setFontSize(detailSize);
      doc.setTextColor(60);
      for (const line of detailLines) {
        const wrapped = doc.splitTextToSize(line, contentW);
        for (const wl of wrapped.slice(0, 2)) {
          doc.text(wl, x + w / 2, cursorY, { align: "center" });
          cursorY += detailSize / 70;
        }
      }
    }

    const codeTop = cursorY + 0.04;
    const codeBottomReserve = cfg.showPrice && typeof l.price === "number" ? 0.28 : 0.06;
    const codeAreaH = Math.max(0.3, y + h - codeTop - codeBottomReserve);
    const codeAreaW = contentW;

    if (cfg.mode === "qr") {
      const dataUrl = await renderQrDataURL(l.value, cfg.qrErrorLevel);
      const side = Math.min(codeAreaW, codeAreaH);
      const cx = x + (w - side) / 2;
      doc.addImage(dataUrl, "PNG", cx, codeTop, side, side);
    } else {
      const dataUrl = await renderBarcodeDataURL(l.value, cfg.barcodeFormat);
      const barW = Math.min(codeAreaW, w - innerPad * 2);
      const barH = Math.min(codeAreaH, cfg.size === "shelf" ? 0.9 : 0.6);
      doc.addImage(dataUrl, "PNG", x + (w - barW) / 2, codeTop, barW, barH);
    }

    if (cfg.showPrice && typeof l.price === "number") {
      doc.setFont(font, "bold");
      const priceSize = cfg.size === "shelf"
        ? Math.max(cfg.priceFontSize, 18)
        : cfg.priceFontSize;
      doc.setFontSize(priceSize);
      doc.setTextColor(20);
      doc.text(`$${l.price.toFixed(2)}`, x + w / 2, y + h - 0.1, { align: "center" });
    }
  }

  doc.save(filename);
}
