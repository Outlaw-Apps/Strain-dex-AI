import type { SupabaseClient } from "@supabase/supabase-js";
import type { Database, TablesInsert } from "@/integrations/supabase/types";

const STORAGE_KEY = "strain-ventory/pending-product-upserts/v1";

export interface PendingProductUpsert {
  id: string;
  row: TablesInsert<"products">;
  mode: "draft" | "published";
  queuedAt: string;
}

const readQueue = (): PendingProductUpsert[] => {
  if (typeof window === "undefined") {
    return [];
  }

  const raw = window.localStorage.getItem(STORAGE_KEY);
  if (!raw) {
    return [];
  }

  try {
    return JSON.parse(raw) as PendingProductUpsert[];
  } catch {
    window.localStorage.removeItem(STORAGE_KEY);
    return [];
  }
};

const writeQueue = (queue: PendingProductUpsert[]) => {
  if (typeof window === "undefined") {
    return;
  }

  window.localStorage.setItem(STORAGE_KEY, JSON.stringify(queue));
};

export const enqueueProductUpsert = (entry: PendingProductUpsert) => {
  const queue = readQueue();
  const withoutSameProduct = queue.filter((item) => item.row.id !== entry.row.id);
  writeQueue([...withoutSameProduct, entry]);
};

export const getPendingProductUpserts = () => readQueue();

export const flushPendingProductUpserts = async (supabase: SupabaseClient<Database>) => {
  const queue = readQueue();
  if (queue.length === 0) {
    return { flushed: 0 };
  }

  let flushed = 0;
  const remaining: PendingProductUpsert[] = [];

  for (const item of queue) {
    const { error } = await supabase.from("products").upsert(item.row);
    if (error) {
      remaining.push(item);
      continue;
    }
    flushed += 1;
  }

  writeQueue(remaining);
  return { flushed };
};

