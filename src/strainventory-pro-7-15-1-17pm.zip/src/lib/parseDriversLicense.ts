/**
 * AAMVA Driver's License / ID PDF417 barcode parser.
 *
 * Supports AAMVA versions 1–9, which covers all 50 US states, DC, and most
 * Canadian provinces.  The raw string decoded from the PDF417 barcode is fed
 * into `parseDriversLicense()`, which extracts the standard subfile fields and
 * returns structured data plus an age-verification result.
 *
 * Reference: AAMVA North American Standard – DL/ID Card Design Specification
 * (version 10, 2020).  Element IDs used here are stable across versions 1–10.
 */

export interface DriverLicenseData {
  firstName: string;
  middleName: string;
  lastName: string;
  /** ISO date string YYYY-MM-DD, e.g. "1990-04-15" */
  dateOfBirth: string;
  /** Raw DOB as it appears in the barcode (MMDDYYYY or YYYYMMDD) */
  dobRaw: string;
  licenseNumber: string;
  address: string;
  city: string;
  state: string;
  zip: string;
  /** ISO expiration date string YYYY-MM-DD */
  expirationDate: string;
  /** Calculated age in years at the time of parsing */
  age: number;
}

export interface AgeVerificationResult {
  passed: boolean;
  /** Age in years, or -1 if DOB could not be determined */
  age: number;
  /** Reason for failure, or empty string when passed */
  reason: string;
  /** Parsed data, present even when age check fails */
  data: DriverLicenseData | null;
}

const MIN_AGE = 21;

/** Extract a named field from a line-delimited AAMVA subfile string. */
function getField(raw: string, id: string): string {
  const regex = new RegExp(`^${id}(.*)$`, "m");
  const match = raw.match(regex);
  return match ? match[1].trim() : "";
}

/**
 * Parse an AAMVA DOB field.  AAMVA stores dates as MMDDYYYY (versions 1–3)
 * or YYYYMMDD (versions 4+).  We detect format by the length of the first
 * four digits relative to a plausible year.
 */
function parseDOB(raw: string): string | null {
  if (!raw || raw.length < 8) return null;
  const digits = raw.replace(/\D/g, "");
  if (digits.length < 8) return null;

  let year: number;
  let month: number;
  let day: number;

  const first4 = parseInt(digits.slice(0, 4), 10);
  if (first4 >= 1900 && first4 <= 2099) {
    // YYYYMMDD
    year = first4;
    month = parseInt(digits.slice(4, 6), 10);
    day = parseInt(digits.slice(6, 8), 10);
  } else {
    // MMDDYYYY
    month = parseInt(digits.slice(0, 2), 10);
    day = parseInt(digits.slice(2, 4), 10);
    year = parseInt(digits.slice(4, 8), 10);
  }

  if (!year || !month || !day) return null;
  if (!isValidYMD(year, month, day)) return null;
  const mm = String(month).padStart(2, "0");
  const dd = String(day).padStart(2, "0");
  return `${year}-${mm}-${dd}`;
}

/** Parse an AAMVA expiration date (MMDDYYYY or YYYYMMDD) → YYYY-MM-DD. */
function parseExpDate(raw: string): string {
  const iso = parseDOB(raw); // same format rules
  return iso ?? "";
}

/** Validate a year/month/day combination, including per-month limits and leap years. */
function isValidYMD(year: number, month: number, day: number): boolean {
  if (!Number.isInteger(year) || !Number.isInteger(month) || !Number.isInteger(day)) {
    return false;
  }
  if (month < 1 || month > 12) return false;
  if (day < 1) return false;

  const isLeapYear =
    (year % 4 === 0 && year % 100 !== 0) ||
    (year % 400 === 0);

  const daysInMonth = [31, isLeapYear ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  const maxDay = daysInMonth[month - 1];
  return day <= maxDay;
}

/** Calculate age in full years from a YYYY-MM-DD string. */
function calcAge(isoDate: string): number {
  const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(isoDate);
  if (!match) return -1;

  const birthYear = Number(match[1]);
  const birthMonth = Number(match[2]);
  const birthDay = Number(match[3]);
  if (!Number.isFinite(birthYear) || !Number.isFinite(birthMonth) || !Number.isFinite(birthDay)) {
    return -1;
  }

  const now = new Date();
  const currentYear = now.getFullYear();
  const currentMonth = now.getMonth() + 1;
  const currentDay = now.getDate();

  let age = currentYear - birthYear;
  if (currentMonth < birthMonth || (currentMonth === birthMonth && currentDay < birthDay)) {
    age--;
  }
  return age;
}

/**
 * Parse the raw PDF417 string from a US/Canadian driver's license and return
 * structured data along with an age-verification result.
 *
 * @param raw - The full raw string decoded by the barcode scanner.
 * @returns An `AgeVerificationResult`.
 */
export function parseDriversLicense(raw: string): AgeVerificationResult {
  const fail = (reason: string, data: DriverLicenseData | null = null): AgeVerificationResult => ({
    passed: false,
    age: data?.age ?? -1,
    reason,
    data,
  });

  if (!raw || !raw.includes("ANSI ") && !raw.includes("@\n") && !raw.includes("@\r")) {
    // Basic sanity check – AAMVA files start with "@\n" or contain "ANSI "
    if (!raw.includes("DAQ") && !raw.includes("DBA")) {
      return fail("Not a recognized AAMVA driver's license barcode.");
    }
  }

  // Field IDs for the DL subfile (AAMVA standard element identifiers)
  const dobRaw = getField(raw, "DBB");
  const dobIso = parseDOB(dobRaw);

  if (!dobIso) {
    return fail("Unable to read date of birth from the ID barcode.");
  }

  const age = calcAge(dobIso);
  if (age < 0) {
    return fail("Unable to calculate age from date of birth.");
  }

  const expRaw = getField(raw, "DBA");
  const expIso = parseExpDate(expRaw);

  // Check ID expiry
  if (expIso) {
    const exp = new Date(expIso);
    if (!isNaN(exp.getTime()) && exp < new Date()) {
      return fail("The presented ID is expired.", buildData(raw, dobRaw, dobIso, expIso, age));
    }
  }

  const data = buildData(raw, dobRaw, dobIso, expIso, age);

  if (age < MIN_AGE) {
    return {
      passed: false,
      age,
      reason: `Customer is ${age} years old — must be ${MIN_AGE}+ to purchase.`,
      data,
    };
  }

  return { passed: true, age, reason: "", data };
}

function buildData(
  raw: string,
  dobRaw: string,
  dobIso: string,
  expIso: string,
  age: number,
): DriverLicenseData {
  // Some states put first name in DAC, some in DCT with middle name combined
  let firstName = getField(raw, "DAC");
  let middleName = getField(raw, "DAD");

  // Fallback: DCT = "FIRST MIDDLE" combined
  if (!firstName) {
    const dct = getField(raw, "DCT");
    const parts = dct.split(/\s+/);
    firstName = parts[0] ?? "";
    middleName = parts.slice(1).join(" ");
  }

  const lastName = getField(raw, "DCS") || getField(raw, "DAB");

  return {
    firstName,
    middleName,
    lastName,
    dateOfBirth: dobIso,
    dobRaw,
    licenseNumber: getField(raw, "DAQ"),
    address: getField(raw, "DAG"),
    city: getField(raw, "DAI"),
    state: getField(raw, "DAJ"),
    zip: getField(raw, "DAK").slice(0, 5),
    expirationDate: expIso,
    age,
  };
}
