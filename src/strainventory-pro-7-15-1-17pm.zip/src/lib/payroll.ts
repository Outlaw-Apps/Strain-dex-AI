import { calculateTimeEntryHours } from "@/lib/diagnosticsExport";

export type DemoPayrollProvider = "gusto" | "adp" | "quickbooks" | "square";
export type DemoPayrollStatus = "ready" | "hold" | "off-cycle";
export type DemoPaySchedule = "weekly" | "biweekly" | "semimonthly";

export interface PayrollEmployee {
  id: string;
  full_name: string;
}

export interface PayrollTimeEntry {
  user_id: string;
  clock_in: string;
  clock_out: string | null;
}

export interface PayrollEmployeeOverride {
  providerEmployeeId?: string;
  regularHours?: number;
  overtimeHours?: number;
  hourlyRate?: number;
  bonus?: number;
  deduction?: number;
  reimbursement?: number;
  taxRate?: number;
  status?: DemoPayrollStatus;
}

export interface DemoPayrollSettings {
  provider: DemoPayrollProvider;
  providerCompanyId: string;
  providerWorkspace: string;
  paySchedule: DemoPaySchedule;
  payPeriodStart: string;
  payPeriodEnd: string;
  overtimeThreshold: number;
  overtimeMultiplier: number;
  defaultHourlyRate: number;
  defaultTaxRate: number;
  notes: string;
  lastSimulatedSyncAt: string | null;
  employeeOverrides: Record<string, PayrollEmployeeOverride>;
}

export interface PayrollRow {
  userId: string;
  name: string;
  providerEmployeeId: string;
  status: DemoPayrollStatus;
  timeEntryCount: number;
  sourceRegularHours: number;
  sourceOvertimeHours: number;
  sourceHours: number;
  regularHours: number;
  overtimeHours: number;
  hourlyRate: number;
  bonus: number;
  deduction: number;
  reimbursement: number;
  taxRate: number;
  taxablePay: number;
  grossPay: number;
  taxes: number;
  netPay: number;
}

export interface DemoPayrollRun {
  rows: PayrollRow[];
  summary: {
    employeeCount: number;
    readyCount: number;
    holdCount: number;
    offCycleCount: number;
    totalRegularHours: number;
    totalOvertimeHours: number;
    totalTaxablePay: number;
    totalGrossPay: number;
    totalTaxes: number;
    totalNetPay: number;
  };
}

const roundToTwo = (value: number) => Number(value.toFixed(2));

const formatDateForInput = (date: Date) =>
  `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;

const getRangeBounds = (settings: Pick<DemoPayrollSettings, "payPeriodStart" | "payPeriodEnd">) => ({
  periodStart: new Date(`${settings.payPeriodStart}T00:00:00`),
  periodEnd: new Date(`${settings.payPeriodEnd}T23:59:59.999`),
});

const getWeekBucketKey = (value: string) => {
  const date = new Date(value);
  date.setHours(0, 0, 0, 0);
  date.setDate(date.getDate() - date.getDay());
  return formatDateForInput(date);
};

const isTimeEntryInPayPeriod = (
  entry: PayrollTimeEntry,
  settings: Pick<DemoPayrollSettings, "payPeriodStart" | "payPeriodEnd">,
  now: Date,
) => {
  const { periodStart, periodEnd } = getRangeBounds(settings);
  const clockIn = new Date(entry.clock_in);
  const clockOut = entry.clock_out ? new Date(entry.clock_out) : now;

  if (Number.isNaN(clockIn.getTime()) || Number.isNaN(clockOut.getTime())) {
    return false;
  }

  return clockOut >= periodStart && clockIn <= periodEnd;
};

const getSourceHoursForEmployee = (
  userId: string,
  timeEntries: PayrollTimeEntry[],
  settings: Pick<DemoPayrollSettings, "payPeriodStart" | "payPeriodEnd" | "overtimeThreshold">,
  now: Date,
) => {
  const employeeEntries = timeEntries.filter(
    (entry) => entry.user_id === userId && isTimeEntryInPayPeriod(entry, settings, now),
  );

  const hoursByWeek = new Map<string, number>();

  employeeEntries.forEach((entry) => {
    const hours = calculateTimeEntryHours(entry, now);
    if (hours === null) {
      return;
    }

    const weekKey = getWeekBucketKey(entry.clock_in);
    hoursByWeek.set(weekKey, (hoursByWeek.get(weekKey) ?? 0) + hours);
  });

  let sourceRegularHours = 0;
  let sourceOvertimeHours = 0;

  for (const weeklyHours of hoursByWeek.values()) {
    sourceRegularHours += Math.min(weeklyHours, settings.overtimeThreshold);
    sourceOvertimeHours += Math.max(weeklyHours - settings.overtimeThreshold, 0);
  }

  return {
    timeEntryCount: employeeEntries.length,
    sourceRegularHours: roundToTwo(sourceRegularHours),
    sourceOvertimeHours: roundToTwo(sourceOvertimeHours),
  };
};

export const getDefaultPayPeriod = (today = new Date()) => {
  const end = new Date(today);
  const start = new Date(today);
  start.setDate(end.getDate() - 13);

  return {
    payPeriodStart: formatDateForInput(start),
    payPeriodEnd: formatDateForInput(end),
  };
};

export const buildDemoPayrollRun = (
  employees: PayrollEmployee[],
  timeEntries: PayrollTimeEntry[],
  settings: DemoPayrollSettings,
  now = new Date(),
): DemoPayrollRun => {
  const employeeMap = new Map<string, string>();
  employees.forEach((employee) => {
    employeeMap.set(employee.id, employee.full_name || `Team Member ${employee.id.slice(0, 8)}`);
  });
  timeEntries.forEach((entry) => {
    if (!employeeMap.has(entry.user_id)) {
      employeeMap.set(entry.user_id, `Team Member ${entry.user_id.slice(0, 8)}`);
    }
  });

  const rows = Array.from(employeeMap.entries())
    .map(([userId, name]) => {
      const source = getSourceHoursForEmployee(userId, timeEntries, settings, now);
      const override = settings.employeeOverrides[userId] ?? {};

      const regularHours = roundToTwo(override.regularHours ?? source.sourceRegularHours);
      const overtimeHours = roundToTwo(override.overtimeHours ?? source.sourceOvertimeHours);
      const hourlyRate = roundToTwo(override.hourlyRate ?? settings.defaultHourlyRate);
      const bonus = roundToTwo(override.bonus ?? 0);
      const deduction = roundToTwo(override.deduction ?? 0);
      const reimbursement = roundToTwo(override.reimbursement ?? 0);
      const taxRate = roundToTwo(override.taxRate ?? settings.defaultTaxRate);
      const status = override.status ?? "ready";

      const taxablePay = roundToTwo(
        regularHours * hourlyRate +
        overtimeHours * hourlyRate * settings.overtimeMultiplier +
        bonus,
      );
      const grossPay = roundToTwo(taxablePay + reimbursement);
      const taxes = roundToTwo(taxablePay * taxRate);
      const netPay = roundToTwo(grossPay - taxes - deduction);

      return {
        userId,
        name,
        providerEmployeeId: override.providerEmployeeId ?? "",
        status,
        timeEntryCount: source.timeEntryCount,
        sourceRegularHours: source.sourceRegularHours,
        sourceOvertimeHours: source.sourceOvertimeHours,
        sourceHours: roundToTwo(source.sourceRegularHours + source.sourceOvertimeHours),
        regularHours,
        overtimeHours,
        hourlyRate,
        bonus,
        deduction,
        reimbursement,
        taxRate,
        taxablePay,
        grossPay,
        taxes,
        netPay,
      } satisfies PayrollRow;
    })
    .sort((left, right) => left.name.localeCompare(right.name));

  return {
    rows,
    summary: {
      employeeCount: rows.length,
      readyCount: rows.filter((row) => row.status === "ready").length,
      holdCount: rows.filter((row) => row.status === "hold").length,
      offCycleCount: rows.filter((row) => row.status === "off-cycle").length,
      totalRegularHours: roundToTwo(rows.reduce((sum, row) => sum + row.regularHours, 0)),
      totalOvertimeHours: roundToTwo(rows.reduce((sum, row) => sum + row.overtimeHours, 0)),
      totalTaxablePay: roundToTwo(rows.reduce((sum, row) => sum + row.taxablePay, 0)),
      totalGrossPay: roundToTwo(rows.reduce((sum, row) => sum + row.grossPay, 0)),
      totalTaxes: roundToTwo(rows.reduce((sum, row) => sum + row.taxes, 0)),
      totalNetPay: roundToTwo(rows.reduce((sum, row) => sum + row.netPay, 0)),
    },
  };
};
