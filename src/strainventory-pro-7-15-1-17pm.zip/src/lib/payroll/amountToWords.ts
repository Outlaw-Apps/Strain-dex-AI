const ONES = [
  "Zero", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine",
  "Ten", "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen",
  "Seventeen", "Eighteen", "Nineteen",
];
const TENS = ["", "", "Twenty", "Thirty", "Forty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninety"];

function under1000(n: number): string {
  if (n < 20) return ONES[n];
  if (n < 100) {
    const t = Math.floor(n / 10);
    const o = n % 10;
    return o === 0 ? TENS[t] : `${TENS[t]}-${ONES[o]}`;
  }
  const h = Math.floor(n / 100);
  const rem = n % 100;
  return rem === 0 ? `${ONES[h]} Hundred` : `${ONES[h]} Hundred ${under1000(rem)}`;
}

/**
 * Convert 12345.67 → "Twelve Thousand Three Hundred Forty-Five and 67/100"
 */
export function amountToWords(amount: number): string {
  if (!Number.isFinite(amount) || amount < 0) return "Zero and 00/100";
  const dollars = Math.floor(amount);
  const cents = Math.round((amount - dollars) * 100);
  if (dollars === 0) return `Zero and ${String(cents).padStart(2, "0")}/100`;

  const scales = ["", "Thousand", "Million", "Billion"];
  let remaining = dollars;
  const parts: string[] = [];
  let scale = 0;
  while (remaining > 0) {
    const chunk = remaining % 1000;
    if (chunk > 0) {
      const chunkText = under1000(chunk);
      parts.unshift(scales[scale] ? `${chunkText} ${scales[scale]}` : chunkText);
    }
    remaining = Math.floor(remaining / 1000);
    scale += 1;
  }
  return `${parts.join(" ")} and ${String(cents).padStart(2, "0")}/100`;
}
