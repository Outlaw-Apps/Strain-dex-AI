/**
 * Bank check PDF generator.
 *
 * Renders one 8.5" x 11" page per check (US letter). The check itself occupies
 * the top portion of the page at height `layout.check_height` (in points).
 *
 * IMPORTANT: This generator uses PDF built-in Courier font. Real bank MICR
 * clearing requires the MICR E-13B font printed with magnetic toner. If your
 * template `stock_mode` is "preprinted", the MICR line is omitted and only
 * amounts / date / payee / signature are printed onto pre-printed check stock.
 * When `stock_mode` is "blank", we render a best-effort MICR line using
 * MICR-substitute glyphs — you MUST replace the printer font with a licensed
 * MICR E-13B font at the OS level for bank acceptance.
 */

import type { CheckTemplate } from "./checkTemplates.types";
import { amountToWords } from "./amountToWords";

const PAGE_WIDTH = 612;
const PAGE_HEIGHT = 792;

export interface CheckLineInput {
  payee_name: string;
  amount: number;
  memo?: string;
  date?: Date;
  check_number: number;
}

interface PdfCheckPage {
  template: CheckTemplate;
  check: CheckLineInput;
}

const currencyFormatter = new Intl.NumberFormat("en-US", {
  style: "currency",
  currency: "USD",
});

function sanitize(value: string) {
  return value
    .replace(/\\/g, "\\\\")
    .replace(/\(/g, "\\(")
    .replace(/\)/g, "\\)")
    .replace(/\r/g, "")
    .replace(/\n/g, " ")
    .normalize("NFKD")
    .replace(/[^\x20-\x7E]/g, "");
}

function fmtDate(d: Date) {
  return d.toLocaleDateString("en-US", { month: "2-digit", day: "2-digit", year: "numeric" });
}

/**
 * Build a MICR line string.
 * ASCII substitutes: `A` = transit ⑆, `C` = on-us ⑈, `B` = amount ⑇, `D` = dash ⑉.
 * This is legible on-screen; production printing must use a MICR E-13B font
 * that maps those glyph positions to magnetic characters.
 */
export function buildMicrLine(routing: string, account: string, checkNumber: number) {
  const chk = String(checkNumber).padStart(4, "0");
  const acct = account.replace(/\s+/g, "");
  const rtn = routing.replace(/\s+/g, "").padStart(9, "0");
  return `A${rtn}A ${acct}C ${chk}`;
}

function buildContent(page: PdfCheckPage): string {
  const { template, check } = page;
  const L = template.layout;
  const baseY = PAGE_HEIGHT - L.check_height; // check occupies top of page
  const y = (yInCheck: number) => baseY + yInCheck;

  const dt = check.date ?? new Date();
  const amountNum = currencyFormatter.format(check.amount);
  const amountWords = amountToWords(check.amount);
  const memo = check.memo ?? template.memo_default ?? "";

  const cmds: string[] = [];

  // Check number (top-right)
  cmds.push("BT", "/F2 12 Tf",
    `${L.check_number_x} ${y(L.check_number_y)} Td`,
    `(${sanitize(`No. ${check.check_number}`)}) Tj`, "ET");

  // Date
  cmds.push("BT", "/F1 11 Tf",
    `${L.date_x} ${y(L.date_y)} Td`,
    `(${sanitize(fmtDate(dt))}) Tj`, "ET");

  // Payee "Pay to the order of"
  cmds.push("BT", "/F1 9 Tf",
    `${L.payee_x - 60} ${y(L.payee_y)} Td`,
    `(Pay to the) Tj`,
    `0 -10 Td`,
    `(order of) Tj`, "ET");
  cmds.push("BT", "/F2 12 Tf",
    `${L.payee_x} ${y(L.payee_y)} Td`,
    `(${sanitize(check.payee_name)}) Tj`, "ET");

  // Numeric amount box
  cmds.push("BT", "/F2 12 Tf",
    `${L.amount_num_x} ${y(L.amount_num_y)} Td`,
    `(${sanitize(`$ ${amountNum.replace("$", "")}`)}) Tj`, "ET");

  // Amount words
  cmds.push("BT", "/F1 11 Tf",
    `${L.amount_words_x} ${y(L.amount_words_y)} Td`,
    `(${sanitize(amountWords)}) Tj`, "ET");

  // Bank block (only when blank stock)
  if (template.stock_mode === "blank") {
    cmds.push("BT", "/F2 10 Tf",
      `${L.amount_words_x} ${y(L.amount_words_y - 30)} Td`,
      `(${sanitize(template.bank_name)}) Tj`, "ET");
    if (template.bank_address) {
      cmds.push("BT", "/F1 8 Tf",
        `${L.amount_words_x} ${y(L.amount_words_y - 42)} Td`,
        `(${sanitize(template.bank_address)}) Tj`, "ET");
    }
    // Account holder block (top-left)
    cmds.push("BT", "/F2 10 Tf",
      `${L.payee_x - 60} ${y(L.check_height - 40)} Td`,
      `(${sanitize(template.account_holder)}) Tj`, "ET");
    if (template.account_holder_address) {
      cmds.push("BT", "/F1 8 Tf",
        `${L.payee_x - 60} ${y(L.check_height - 52)} Td`,
        `(${sanitize(template.account_holder_address)}) Tj`, "ET");
    }
  }

  // Memo
  cmds.push("BT", "/F1 9 Tf",
    `${L.memo_x - 30} ${y(L.memo_y)} Td`,
    `(Memo:) Tj`, "ET");
  if (memo) {
    cmds.push("BT", "/F1 10 Tf",
      `${L.memo_x} ${y(L.memo_y)} Td`,
      `(${sanitize(memo)}) Tj`, "ET");
  }

  // Signature line
  cmds.push("BT", "/F1 8 Tf",
    `${L.signature_x} ${y(L.signature_y - 10)} Td`,
    `(${sanitize(template.signature_label)}) Tj`, "ET");

  // MICR line (only when blank stock)
  if (template.stock_mode === "blank") {
    const micr = buildMicrLine(template.routing_number, template.account_number, check.check_number);
    cmds.push("BT", "/F2 12 Tf",
      `${L.micr_x} ${y(L.micr_y)} Td`,
      `(${sanitize(micr)}) Tj`, "ET");
  }

  // Payslip stub area below the check
  const stubTop = baseY - 20;
  cmds.push("BT", "/F2 12 Tf",
    `50 ${stubTop} Td`,
    `(${sanitize(`Paycheck Stub — ${template.account_holder}`)}) Tj`, "ET");
  cmds.push("BT", "/F1 10 Tf",
    `50 ${stubTop - 20} Td`,
    `(${sanitize(`Payee: ${check.payee_name}`)}) Tj`,
    `0 -14 Td`,
    `(${sanitize(`Date: ${fmtDate(dt)}`)}) Tj`,
    `0 -14 Td`,
    `(${sanitize(`Check #: ${check.check_number}`)}) Tj`,
    `0 -14 Td`,
    `(${sanitize(`Amount: ${amountNum}`)}) Tj`,
    `0 -14 Td`,
    `(${sanitize(`Memo: ${memo || "—"}`)}) Tj`, "ET");

  return cmds.join("\n");
}

function serialize(pages: PdfCheckPage[]) {
  const objects: string[] = [];
  const pageObjs: number[] = [];
  let nextObj = 5;

  objects[1] = "<< /Type /Catalog /Pages 2 0 R >>";
  objects[3] = "<< /Type /Font /Subtype /Type1 /BaseFont /Courier >>";
  objects[4] = "<< /Type /Font /Subtype /Type1 /BaseFont /Courier-Bold >>";

  for (const page of pages) {
    const pgObj = nextObj;
    const cntObj = nextObj + 1;
    const stream = buildContent(page);
    const len = new TextEncoder().encode(stream).length;
    objects[pgObj] = [
      "<< /Type /Page",
      "/Parent 2 0 R",
      `/MediaBox [0 0 ${PAGE_WIDTH} ${PAGE_HEIGHT}]`,
      "/Resources << /Font << /F1 3 0 R /F2 4 0 R >> >>",
      `/Contents ${cntObj} 0 R`,
      ">>",
    ].join(" ");
    objects[cntObj] = `<< /Length ${len} >>\nstream\n${stream}\nendstream`;
    pageObjs.push(pgObj);
    nextObj += 2;
  }

  objects[2] = `<< /Type /Pages /Count ${pages.length} /Kids [${pageObjs.map((n) => `${n} 0 R`).join(" ")}] >>`;

  const enc = new TextEncoder();
  let pdf = "%PDF-1.4\n";
  const offsets: number[] = [0];
  for (let i = 1; i < objects.length; i += 1) {
    if (!objects[i]) continue;
    offsets[i] = enc.encode(pdf).length;
    pdf += `${i} 0 obj\n${objects[i]}\nendobj\n`;
  }
  const xref = enc.encode(pdf).length;
  pdf += `xref\n0 ${objects.length}\n0000000000 65535 f \n`;
  for (let i = 1; i < objects.length; i += 1) {
    pdf += `${String(offsets[i] ?? 0).padStart(10, "0")} 00000 n \n`;
  }
  pdf += `trailer\n<< /Size ${objects.length} /Root 1 0 R >>\nstartxref\n${xref}\n%%EOF`;
  return enc.encode(pdf);
}

export interface BuildChecksInput {
  template: CheckTemplate;
  checks: CheckLineInput[];
}

export function buildChecksPdf({ template, checks }: BuildChecksInput): Uint8Array {
  if (checks.length === 0) {
    return serialize([{
      template,
      check: { payee_name: "(no checks to print)", amount: 0, check_number: template.next_check_number },
    }]);
  }
  return serialize(checks.map((c) => ({ template, check: c })));
}
