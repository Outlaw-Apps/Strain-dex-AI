export interface CheckLayout {
  check_height: number;
  date_x: number; date_y: number;
  payee_x: number; payee_y: number;
  amount_num_x: number; amount_num_y: number;
  amount_words_x: number; amount_words_y: number;
  memo_x: number; memo_y: number;
  signature_x: number; signature_y: number;
  micr_x: number; micr_y: number;
  check_number_x: number; check_number_y: number;
}

export type CheckStockMode = "preprinted" | "blank";

export interface CheckTemplate {
  id: string;
  name: string;
  bank_name: string;
  bank_address: string | null;
  account_holder: string;
  account_holder_address: string | null;
  routing_number: string;
  account_number: string;
  fractional_routing: string | null;
  next_check_number: number;
  signature_label: string;
  memo_default: string | null;
  stock_mode: CheckStockMode;
  layout: CheckLayout;
  signature_image_url: string | null;
  is_default: boolean;
  is_active: boolean;
  created_by: string | null;
  created_at: string;
  updated_at: string;
}

export const DEFAULT_CHECK_LAYOUT: CheckLayout = {
  check_height: 264,
  date_x: 430, date_y: 205,
  payee_x: 70, payee_y: 175,
  amount_num_x: 470, amount_num_y: 175,
  amount_words_x: 40, amount_words_y: 145,
  memo_x: 60, memo_y: 60,
  signature_x: 340, signature_y: 60,
  micr_x: 60, micr_y: 22,
  check_number_x: 480, check_number_y: 235,
};
