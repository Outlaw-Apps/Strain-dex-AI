import { z } from "zod";

/** Minimal RFC-4180 CSV parser (handles quoted fields, escaped quotes, CRLF). */
export function parseCsv(text: string): string[][] {
  const rows: string[][] = [];
  let field = "";
  let row: string[] = [];
  let inQuotes = false;
  const src = text.replace(/^\uFEFF/, ""); // strip BOM

  for (let i = 0; i < src.length; i += 1) {
    const ch = src[i];
    if (inQuotes) {
      if (ch === '"') {
        if (src[i + 1] === '"') { field += '"'; i += 1; }
        else { inQuotes = false; }
      } else {
        field += ch;
      }
    } else {
      if (ch === '"') { inQuotes = true; }
      else if (ch === ",") { row.push(field); field = ""; }
      else if (ch === "\n" || ch === "\r") {
        if (ch === "\r" && src[i + 1] === "\n") i += 1;
        row.push(field); field = "";
        if (row.some((v) => v.length > 0) || rows.length > 0) rows.push(row);
        row = [];
      } else {
        field += ch;
      }
    }
  }
  if (field.length > 0 || row.length > 0) {
    row.push(field);
    if (row.some((v) => v.length > 0)) rows.push(row);
  }
  return rows;
}

export interface CsvMapping {
  employee: number;       // column index for employee name or UUID
  amount: number;         // column index for check amount
  memo: number | null;    // optional column index
  date: number | null;    // optional column index
  checkNumber: number | null; // optional column index; when null we auto-assign
}

export interface CsvImportRow {
  rowIndex: number;
  employeeInput: string;
  employeeId: string | null;
  employeeName: string;
  amount: number;
  memo: string;
  date: Date | null;
  checkNumber: number | null;
  status: "matched" | "unmatched" | "invalid_amount" | "duplicate";
  message?: string;
}

const amountSchema = z
  .string()
  .transform((v) => Number(v.replace(/[$,\s]/g, "")))
  .refine((n) => Number.isFinite(n) && n >= 0, { message: "Amount must be a non-negative number" });

const uuidRe = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

/**
 * Build a case-insensitive lookup from employee name → id, plus id → id passthrough.
 * `profileMap` uses id → display name (as elsewhere in the codebase).
 */
export function buildEmployeeLookup(profileMap: Map<string, string>): Map<string, string> {
  const lookup = new Map<string, string>();
  for (const [id, name] of profileMap.entries()) {
    lookup.set(id.toLowerCase(), id);
    if (name) lookup.set(name.trim().toLowerCase(), id);
  }
  return lookup;
}

function parseDateSafe(raw: string): Date | null {
  const t = raw.trim();
  if (!t) return null;
  const d = new Date(t);
  return Number.isNaN(d.getTime()) ? null : d;
}

export function mapCsvRows(
  headerAndData: string[][],
  mapping: CsvMapping,
  profileMap: Map<string, string>,
  hasHeader: boolean,
): CsvImportRow[] {
  const dataRows = hasHeader ? headerAndData.slice(1) : headerAndData;
  const lookup = buildEmployeeLookup(profileMap);
  const seen = new Set<string>();

  return dataRows.map((cols, i): CsvImportRow => {
    const rowIndex = i + (hasHeader ? 2 : 1); // 1-based, accounting for header
    const employeeInput = (cols[mapping.employee] ?? "").trim();
    const rawAmount = (cols[mapping.amount] ?? "").trim();
    const memo = mapping.memo !== null ? (cols[mapping.memo] ?? "").trim() : "";
    const dateStr = mapping.date !== null ? (cols[mapping.date] ?? "").trim() : "";
    const checkNoStr = mapping.checkNumber !== null ? (cols[mapping.checkNumber] ?? "").trim() : "";

    const parsedAmount = amountSchema.safeParse(rawAmount);
    if (!parsedAmount.success) {
      return {
        rowIndex, employeeInput, employeeId: null, employeeName: employeeInput,
        amount: 0, memo, date: parseDateSafe(dateStr),
        checkNumber: checkNoStr ? Number(checkNoStr) || null : null,
        status: "invalid_amount",
        message: parsedAmount.error.issues[0]?.message ?? "Invalid amount",
      };
    }

    let employeeId: string | null = null;
    if (uuidRe.test(employeeInput)) employeeId = employeeInput;
    else employeeId = lookup.get(employeeInput.toLowerCase()) ?? null;

    let status: CsvImportRow["status"] = employeeId ? "matched" : "unmatched";
    let message: string | undefined;

    if (employeeId) {
      if (seen.has(employeeId)) {
        status = "duplicate";
        message = "Duplicate employee row";
      } else {
        seen.add(employeeId);
      }
    } else {
      message = "No employee match — pick manually or fix the name";
    }

    const employeeName = employeeId ? (profileMap.get(employeeId) ?? employeeInput) : employeeInput;

    return {
      rowIndex,
      employeeInput,
      employeeId,
      employeeName,
      amount: parsedAmount.data,
      memo,
      date: parseDateSafe(dateStr),
      checkNumber: checkNoStr ? (Number(checkNoStr) || null) : null,
      status,
      message,
    };
  });
}

/** Guess a column index by trying common header names. */
export function guessColumn(headers: string[], candidates: string[]): number | null {
  const norm = headers.map((h) => h.trim().toLowerCase());
  for (const cand of candidates) {
    const idx = norm.indexOf(cand.toLowerCase());
    if (idx >= 0) return idx;
  }
  for (const cand of candidates) {
    const idx = norm.findIndex((h) => h.includes(cand.toLowerCase()));
    if (idx >= 0) return idx;
  }
  return null;
}
