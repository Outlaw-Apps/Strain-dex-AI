/**
 * React-Query hooks for payroll data.
 * Uses Supabase client; safe for both Electron and Android builds.
 */

import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import type { EmployeePayrollProfile, PayPeriod, Payslip } from "./payroll.types";

// ---------- Employee Payroll Profiles ----------

export const usePayrollProfiles = () =>
  useQuery({
    queryKey: ["payroll-profiles"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("employee_payroll_profiles")
        .select("*")
        .order("created_at", { ascending: false });
      if (error) throw error;
      return (data ?? []) as EmployeePayrollProfile[];
    },
    staleTime: 60_000,
  });

export const useMyPayrollProfile = () =>
  useQuery({
    queryKey: ["payroll-profiles", "mine"],
    queryFn: async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return null;
      const { data, error } = await supabase
        .from("employee_payroll_profiles")
        .select("*")
        .eq("employee_id", user.id)
        .maybeSingle();
      if (error) throw error;
      return data as EmployeePayrollProfile | null;
    },
    staleTime: 60_000,
  });

export const useUpsertPayrollProfile = () => {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (profile: Partial<EmployeePayrollProfile> & { employee_id: string }) => {
      const { data, error } = await supabase
        .from("employee_payroll_profiles")
        .upsert(
          { ...profile, updated_at: new Date().toISOString() },
          { onConflict: "employee_id" },
        )
        .select()
        .single();
      if (error) throw error;
      return data as EmployeePayrollProfile;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["payroll-profiles"] });
    },
  });
};

// ---------- Pay Periods ----------

export const usePayPeriods = () =>
  useQuery({
    queryKey: ["pay-periods"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("pay_periods")
        .select("*")
        .order("start_date", { ascending: false });
      if (error) throw error;
      return (data ?? []) as PayPeriod[];
    },
    staleTime: 30_000,
  });

export const useCreatePayPeriod = () => {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (period: { start_date: string; end_date: string }) => {
      const { data: { user } } = await supabase.auth.getUser();
      const { data, error } = await supabase
        .from("pay_periods")
        .insert({ ...period, created_by: user?.id ?? null })
        .select()
        .single();
      if (error) throw error;
      return data as PayPeriod;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["pay-periods"] });
    },
  });
};

export const useUpdatePayPeriod = () => {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async ({ id, ...rest }: Partial<PayPeriod> & { id: string }) => {
      const { data, error } = await supabase
        .from("pay_periods")
        .update(rest)
        .eq("id", id)
        .select()
        .single();
      if (error) throw error;
      return data as PayPeriod;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["pay-periods"] });
    },
  });
};

// ---------- Payslips ----------

export const usePayslips = (payPeriodId?: string) =>
  useQuery({
    queryKey: ["payslips", payPeriodId ?? "all"],
    queryFn: async () => {
      let q = supabase.from("payslips").select("*").order("created_at", { ascending: false });
      if (payPeriodId) {
        q = q.eq("pay_period_id", payPeriodId);
      }
      const { data, error } = await q;
      if (error) throw error;
      return (data ?? []) as Payslip[];
    },
    staleTime: 30_000,
    enabled: payPeriodId !== undefined ? !!payPeriodId : true,
  });

export const useMyPayslips = () =>
  useQuery({
    queryKey: ["payslips", "mine"],
    queryFn: async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return [];
      const { data, error } = await supabase
        .from("payslips")
        .select("*")
        .eq("employee_id", user.id)
        .order("created_at", { ascending: false });
      if (error) throw error;
      return (data ?? []) as Payslip[];
    },
    staleTime: 30_000,
  });

export const useBulkInsertPayslips = () => {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (payslips: Omit<Payslip, "id" | "created_at">[]) => {
      const { data, error } = await supabase.from("payslips").insert(payslips).select();
      if (error) throw error;
      return (data ?? []) as Payslip[];
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["payslips"] });
      qc.invalidateQueries({ queryKey: ["pay-periods"] });
    },
  });
};
