/**
 * California-compliant payroll calculator.
 *
 * Rules implemented:
 *  - Daily OT after 8 hours worked
 *  - Daily double-time after 12 hours worked
 *  - 7th consecutive day in a workweek: first 8 hrs at OT rate, beyond 8 at DT rate
 *  - Configurable rounding (already rounded via time-clock)
 *
 * This module is pure logic — no Supabase imports — so it can run offline
 * on both Electron and Android.
 */

import type { EmployeePayrollProfile, PayrollBreakdown, DailyDetail } from "./payroll.types";

export interface TimeEntryInput {
  id: string;
  user_id: string;
  clock_in: string;
  clock_out: string | null;
}

/** Format a Date as YYYY-MM-DD using local time. */
function toLocalDateStr(d: Date): string {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

/** Parse a YYYY-MM-DD string into a local-midnight Date (avoids UTC shift). */
function parseLocalDate(dateStr: string): Date {
  const [y, m, d] = dateStr.split("-").map(Number);
  return new Date(y, m - 1, d);
}

/**
 * Group time entries by local calendar date and sum hours per day.
 * Splits shifts that cross midnight so hours are attributed to the correct
 * calendar day (critical for CA daily OT/DT calculations).
 * Returns a map of YYYY-MM-DD string → total hours.
 */
function groupByDate(entries: TimeEntryInput[]): Map<string, number> {
  const map = new Map<string, number>();
  for (const e of entries) {
    if (!e.clock_out) continue; // skip open shifts
    let cursor = new Date(e.clock_in);
    const end = new Date(e.clock_out);
    if (end <= cursor) continue; // invalid / zero-length

    while (cursor < end) {
      // Next midnight boundary in local time
      const nextMidnight = new Date(
        cursor.getFullYear(),
        cursor.getMonth(),
        cursor.getDate() + 1,
      );
      const segEnd = nextMidnight < end ? nextMidnight : end;
      const hours = (segEnd.getTime() - cursor.getTime()) / 3_600_000;
      const dateKey = toLocalDateStr(cursor);
      map.set(dateKey, (map.get(dateKey) ?? 0) + Math.max(0, hours));
      cursor = segEnd;
    }
  }
  return map;
}

/**
 * Detect consecutive work-day streaks within a workweek (Sun-Sat)
 * and return a Set of dates that qualify as "7th consecutive day".
 */
function find7thDays(sortedDates: string[]): Set<string> {
  const seventh = new Set<string>();
  if (sortedDates.length === 0) return seventh;

  // Group dates by workweek (Sun-Sat) using local-time parsing
  const weekMap = new Map<string, string[]>();
  for (const d of sortedDates) {
    const dt = parseLocalDate(d);
    const sun = new Date(dt);
    sun.setDate(dt.getDate() - dt.getDay());
    const weekKey = toLocalDateStr(sun);
    if (!weekMap.has(weekKey)) weekMap.set(weekKey, []);
    weekMap.get(weekKey)!.push(d);
  }

  for (const [, weekDates] of weekMap) {
    if (weekDates.length < 7) continue;
    weekDates.sort();
    let consecutive = 1;
    for (let i = 1; i < weekDates.length; i++) {
      const prev = parseLocalDate(weekDates[i - 1]);
      const curr = parseLocalDate(weekDates[i]);
      const diff = (curr.getTime() - prev.getTime()) / 86_400_000;
      if (diff === 1) {
        consecutive++;
        if (consecutive >= 7) {
          seventh.add(weekDates[i]);
        }
      } else {
        consecutive = 1;
      }
    }
  }

  return seventh;
}

/**
 * Calculate California-compliant payroll for one employee.
 */
export function calculatePayroll(
  timeEntries: TimeEntryInput[],
  profile: EmployeePayrollProfile,
  periodStart: Date,
  periodEnd: Date,
): PayrollBreakdown {
  // Filter entries to the pay period
  const filtered = timeEntries.filter((e) => {
    const clockIn = new Date(e.clock_in);
    return (
      e.user_id === profile.employee_id &&
      clockIn >= periodStart &&
      clockIn <= periodEnd
    );
  });

  const dailyMap = groupByDate(filtered);
  const sortedDates = Array.from(dailyMap.keys()).sort();
  const seventhDays = find7thDays(sortedDates);

  let totalRegular = 0;
  let totalOT = 0;
  let totalDT = 0;
  const dailyDetails: DailyDetail[] = [];

  for (const date of sortedDates) {
    const hoursWorked = dailyMap.get(date) ?? 0;
    let regular = 0;
    let overtime = 0;
    let doubletime = 0;

    if (seventhDays.has(date)) {
      // 7th consecutive day: first 8 hrs at OT, beyond 8 at DT
      overtime = Math.min(hoursWorked, 8);
      doubletime = Math.max(0, hoursWorked - 8);
    } else {
      // Normal day: first 8 regular, 8-12 OT, beyond 12 DT
      regular = Math.min(hoursWorked, 8);
      overtime = Math.max(0, Math.min(hoursWorked, 12) - 8);
      doubletime = Math.max(0, hoursWorked - 12);
    }

    totalRegular += regular;
    totalOT += overtime;
    totalDT += doubletime;

    dailyDetails.push({
      date,
      total_hours: Math.round(hoursWorked * 100) / 100,
      regular: Math.round(regular * 100) / 100,
      overtime: Math.round(overtime * 100) / 100,
      doubletime: Math.round(doubletime * 100) / 100,
    });
  }

  const rate = profile.hourly_rate;
  const otMultiplier = profile.overtime_multiplier;
  const dtMultiplier = profile.doubletime_multiplier;

  const regularPay = round2(totalRegular * rate);
  const otPay = round2(totalOT * rate * otMultiplier);
  const dtPay = round2(totalDT * rate * dtMultiplier);
  const grossPay = round2(regularPay + otPay + dtPay);
  const deductions = Math.min(profile.deductions, grossPay);
  const netPay = round2(grossPay - deductions);

  return {
    employee_id: profile.employee_id,
    regular_hours: round2(totalRegular),
    ot_hours: round2(totalOT),
    doubletime_hours: round2(totalDT),
    regular_pay: regularPay,
    ot_pay: otPay,
    doubletime_pay: dtPay,
    gross_pay: grossPay,
    deductions,
    net_pay: netPay,
    daily_details: dailyDetails,
  };
}

function round2(n: number): number {
  return Math.round(n * 100) / 100;
}

/**
 * Generate a simple CSV string from an array of payslip-like data.
 */
export function payrollToCSV(
  breakdowns: PayrollBreakdown[],
  employeeNames: Map<string, string>,
): string {
  const header = "Employee,Regular Hrs,OT Hrs,DT Hrs,Regular Pay,OT Pay,DT Pay,Gross,Deductions,Net";
  const rows = breakdowns.map((b) => {
    const name = employeeNames.get(b.employee_id) ?? b.employee_id.slice(0, 8);
    return [
      `"${name.replace(/"/g, '""')}"`,
      b.regular_hours,
      b.ot_hours,
      b.doubletime_hours,
      b.regular_pay,
      b.ot_pay,
      b.doubletime_pay,
      b.gross_pay,
      b.deductions,
      b.net_pay,
    ].join(",");
  });
  return [header, ...rows].join("\n");
}
