/** Shared payroll types — used by both Electron and Android builds */

export interface EmployeePayrollProfile {
  id: string;
  employee_id: string;
  hourly_rate: number;
  overtime_multiplier: number;
  doubletime_multiplier: number;
  tax_filing_status: string;
  deductions: number;
  direct_deposit_account: string | null;
  direct_deposit_routing: string | null;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export interface PayPeriod {
  id: string;
  start_date: string;
  end_date: string;
  status: "draft" | "processed" | "paid";
  total_wages: number;
  total_ot_hours: number;
  created_by: string | null;
  created_at: string;
}

export interface Payslip {
  id: string;
  pay_period_id: string;
  employee_id: string;
  regular_hours: number;
  ot_hours: number;
  doubletime_hours: number;
  gross_pay: number;
  deductions: number;
  net_pay: number;
  pdf_url: string | null;
  created_at: string;
}

/** Breakdown returned by the payroll engine for a single employee */
export interface PayrollBreakdown {
  employee_id: string;
  regular_hours: number;
  ot_hours: number;
  doubletime_hours: number;
  regular_pay: number;
  ot_pay: number;
  doubletime_pay: number;
  gross_pay: number;
  deductions: number;
  net_pay: number;
  daily_details: DailyDetail[];
}

export interface DailyDetail {
  date: string;
  total_hours: number;
  regular: number;
  overtime: number;
  doubletime: number;
}
