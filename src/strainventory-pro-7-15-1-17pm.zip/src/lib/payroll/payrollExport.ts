import type { PayrollBreakdown } from "./payroll.types";

interface BuildPayrollPdfInputArgs {
  businessName?: string;
  startDate: string;
  endDate: string;
  employeeNames: Map<string, string>;
  breakdowns: PayrollBreakdown[];
}

export function buildPayrollPdfInput({
  businessName = "StrainVentory",
  startDate,
  endDate,
  employeeNames,
  breakdowns,
}: BuildPayrollPdfInputArgs) {
  return {
    businessName,
    startDate,
    endDate,
    employeeNames,
    breakdowns,
  };
}
