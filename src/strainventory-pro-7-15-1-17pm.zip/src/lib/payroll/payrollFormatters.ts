export function formatCurrency(n: number) {
  return new Intl.NumberFormat("en-US", { style: "currency", currency: "USD" }).format(n);
}

export function formatPayDate(d: string) {
  const [y, m, day] = d.split("-").map(Number);
  if (y && m && day) {
    return new Date(y, m - 1, day).toLocaleDateString("en-US", {
      month: "short",
      day: "numeric",
      year: "numeric",
    });
  }
  return new Date(d).toLocaleDateString("en-US", {
    month: "short",
    day: "numeric",
    year: "numeric",
  });
}

export const payrollStatusColors: Record<string, string> = {
  draft: "bg-muted text-muted-foreground",
  processed: "bg-warning/15 text-warning",
  paid: "bg-success/15 text-success",
};
