import type { PayrollBreakdown } from "./payroll.types";

const PAGE_WIDTH = 612;
const PAGE_HEIGHT = 792;
const BODY_FONT_SIZE = 10;
const BODY_LINE_HEIGHT = 14;
const BODY_LINES_PER_PAGE = 46;

interface PdfPage {
  heading: string;
  lines: string[];
}

interface PayrollPdfInput {
  businessName?: string;
  startDate: string;
  endDate: string;
  generatedAt?: Date;
  employeeNames: Map<string, string>;
  breakdowns: PayrollBreakdown[];
}

const currencyFormatter = new Intl.NumberFormat("en-US", {
  style: "currency",
  currency: "USD",
});

function sanitizePdfText(value: string) {
  return value
    .replace(/\\/g, "\\\\")
    .replace(/\(/g, "\\(")
    .replace(/\)/g, "\\)")
    .replace(/\r/g, "")
    .replace(/\n/g, " ")
    .normalize("NFKD")
    .replace(/[^\x20-\x7E]/g, "");
}

function formatDate(value: string) {
  const parsed = new Date(`${value}T00:00:00`);
  return parsed.toLocaleDateString("en-US", {
    month: "short",
    day: "numeric",
    year: "numeric",
  });
}

function formatCurrency(value: number) {
  return currencyFormatter.format(value);
}

function pad(value: string, width: number, align: "left" | "right" = "left") {
  const trimmed = value.length > width ? value.slice(0, width) : value;
  return align === "right" ? trimmed.padStart(width, " ") : trimmed.padEnd(width, " ");
}

function chunkLines(heading: string, lines: string[]) {
  if (lines.length === 0) {
    return [{ heading, lines: ["No payroll data was available for this export."] }];
  }

  const pages: PdfPage[] = [];
  for (let start = 0; start < lines.length; start += BODY_LINES_PER_PAGE) {
    pages.push({
      heading: pages.length === 0 ? heading : `${heading} (continued)`,
      lines: lines.slice(start, start + BODY_LINES_PER_PAGE),
    });
  }
  return pages;
}

function buildContentStream(page: PdfPage, pageNumber: number, totalPages: number) {
  const commands: string[] = [];

  commands.push("BT");
  commands.push("/F2 16 Tf");
  commands.push(`50 ${PAGE_HEIGHT - 54} Td`);
  commands.push(`(${sanitizePdfText(page.heading)}) Tj`);
  commands.push("ET");

  commands.push("BT");
  commands.push(`/F1 ${BODY_FONT_SIZE} Tf`);
  commands.push(`50 ${PAGE_HEIGHT - 86} Td`);

  page.lines.forEach((line, index) => {
    if (index > 0) {
      commands.push(`0 -${BODY_LINE_HEIGHT} Td`);
    }
    commands.push(`(${sanitizePdfText(line)}) Tj`);
  });

  commands.push("ET");

  commands.push("BT");
  commands.push("/F1 9 Tf");
  commands.push(`50 28 Td`);
  commands.push(`(${sanitizePdfText(`Page ${pageNumber} of ${totalPages}`)}) Tj`);
  commands.push("ET");

  return commands.join("\n");
}

function serializePdf(pages: PdfPage[]) {
  const objects: string[] = [];
  const pageObjectNumbers: number[] = [];
  let nextObjectNumber = 5;

  objects[1] = "<< /Type /Catalog /Pages 2 0 R >>";
  objects[3] = "<< /Type /Font /Subtype /Type1 /BaseFont /Courier >>";
  objects[4] = "<< /Type /Font /Subtype /Type1 /BaseFont /Courier-Bold >>";

  for (let index = 0; index < pages.length; index += 1) {
    const pageNumber = index + 1;
    const pageObjectNumber = nextObjectNumber;
    const contentObjectNumber = nextObjectNumber + 1;
    const stream = buildContentStream(pages[index], pageNumber, pages.length);
    const streamLength = new TextEncoder().encode(stream).length;

    objects[pageObjectNumber] = [
      "<< /Type /Page",
      "/Parent 2 0 R",
      `/MediaBox [0 0 ${PAGE_WIDTH} ${PAGE_HEIGHT}]`,
      "/Resources << /Font << /F1 3 0 R /F2 4 0 R >> >>",
      `/Contents ${contentObjectNumber} 0 R`,
      ">>",
    ].join(" ");

    objects[contentObjectNumber] = `<< /Length ${streamLength} >>\nstream\n${stream}\nendstream`;
    pageObjectNumbers.push(pageObjectNumber);
    nextObjectNumber += 2;
  }

  objects[2] = `<< /Type /Pages /Count ${pages.length} /Kids [${pageObjectNumbers.map((pageObjectNumber) => `${pageObjectNumber} 0 R`).join(" ")}] >>`;

  const encoder = new TextEncoder();
  let pdf = "%PDF-1.4\n";
  const offsets: number[] = [0];

  for (let objectNumber = 1; objectNumber < objects.length; objectNumber += 1) {
    if (!objects[objectNumber]) {
      continue;
    }

    offsets[objectNumber] = encoder.encode(pdf).length;
    pdf += `${objectNumber} 0 obj\n${objects[objectNumber]}\nendobj\n`;
  }

  const xrefOffset = encoder.encode(pdf).length;
  pdf += `xref\n0 ${objects.length}\n`;
  pdf += "0000000000 65535 f \n";

  for (let objectNumber = 1; objectNumber < objects.length; objectNumber += 1) {
    const offset = offsets[objectNumber] ?? 0;
    pdf += `${String(offset).padStart(10, "0")} 00000 n \n`;
  }

  pdf += `trailer\n<< /Size ${objects.length} /Root 1 0 R >>\nstartxref\n${xrefOffset}\n%%EOF`;
  return encoder.encode(pdf);
}

function summarizeTotals(breakdowns: PayrollBreakdown[]) {
  return breakdowns.reduce(
    (totals, breakdown) => ({
      regularHours: totals.regularHours + breakdown.regular_hours,
      otHours: totals.otHours + breakdown.ot_hours,
      doubletimeHours: totals.doubletimeHours + breakdown.doubletime_hours,
      grossPay: totals.grossPay + breakdown.gross_pay,
      deductions: totals.deductions + breakdown.deductions,
      netPay: totals.netPay + breakdown.net_pay,
    }),
    {
      regularHours: 0,
      otHours: 0,
      doubletimeHours: 0,
      grossPay: 0,
      deductions: 0,
      netPay: 0,
    },
  );
}

export function buildPayrollSummaryPdf(input: PayrollPdfInput) {
  const generatedAt = input.generatedAt ?? new Date();
  const totals = summarizeTotals(input.breakdowns);
  const lines: string[] = [
    input.businessName ? `Business: ${input.businessName}` : "Business: StrainVentory",
    `Pay period: ${formatDate(input.startDate)} - ${formatDate(input.endDate)}`,
    `Generated: ${generatedAt.toLocaleString("en-US")}`,
    "",
    `Employees: ${input.breakdowns.length}`,
    `Regular hours: ${totals.regularHours.toFixed(2)}`,
    `OT hours: ${totals.otHours.toFixed(2)}`,
    `DT hours: ${totals.doubletimeHours.toFixed(2)}`,
    `Gross wages: ${formatCurrency(totals.grossPay)}`,
    `Deductions: ${formatCurrency(totals.deductions)}`,
    `Net wages: ${formatCurrency(totals.netPay)}`,
    "",
    `${pad("Employee", 22)} ${pad("Reg", 7, "right")} ${pad("OT", 7, "right")} ${pad("DT", 7, "right")} ${pad("Gross", 12, "right")} ${pad("Net", 12, "right")}`,
    "-".repeat(77),
  ];

  for (const breakdown of input.breakdowns) {
    const employeeName =
      input.employeeNames.get(breakdown.employee_id) ??
      breakdown.employee_id.slice(0, 8);
    lines.push(
      [
        pad(employeeName, 22),
        pad(breakdown.regular_hours.toFixed(2), 7, "right"),
        pad(breakdown.ot_hours.toFixed(2), 7, "right"),
        pad(breakdown.doubletime_hours.toFixed(2), 7, "right"),
        pad(formatCurrency(breakdown.gross_pay), 12, "right"),
        pad(formatCurrency(breakdown.net_pay), 12, "right"),
      ].join(" "),
    );
  }

  return serializePdf(chunkLines("Payroll Summary", lines));
}

export function buildPayslipPacketPdf(input: PayrollPdfInput) {
  const generatedAt = input.generatedAt ?? new Date();
  const pages = input.breakdowns.map((breakdown) => {
    const employeeName =
      input.employeeNames.get(breakdown.employee_id) ??
      breakdown.employee_id.slice(0, 8);

    return {
      heading: `Payslip - ${employeeName}`,
      lines: [
        input.businessName ? `Business: ${input.businessName}` : "Business: StrainVentory",
        `Pay period: ${formatDate(input.startDate)} - ${formatDate(input.endDate)}`,
        `Issued: ${generatedAt.toLocaleString("en-US")}`,
        "",
        `Regular hours: ${breakdown.regular_hours.toFixed(2)}`,
        `OT hours: ${breakdown.ot_hours.toFixed(2)}`,
        `Double-time hours: ${breakdown.doubletime_hours.toFixed(2)}`,
        "",
        `Regular pay: ${formatCurrency(breakdown.regular_pay)}`,
        `OT pay: ${formatCurrency(breakdown.ot_pay)}`,
        `Double-time pay: ${formatCurrency(breakdown.doubletime_pay)}`,
        `Gross pay: ${formatCurrency(breakdown.gross_pay)}`,
        `Deductions: ${formatCurrency(breakdown.deductions)}`,
        `Net pay: ${formatCurrency(breakdown.net_pay)}`,
        "",
        "Daily breakdown:",
        ...breakdown.daily_details.map(
          (day) =>
            `${day.date}: total ${day.total_hours.toFixed(2)} | reg ${day.regular.toFixed(2)} | OT ${day.overtime.toFixed(2)} | DT ${day.doubletime.toFixed(2)}`,
        ),
      ],
    };
  });

  return serializePdf(pages.length > 0 ? pages : chunkLines("Payslip Packet", []));
}
