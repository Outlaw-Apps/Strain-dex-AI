// Shared helpers for the short-ID + PIN login scheme.
// Keep in sync with supabase/functions/provision-pin-user/index.ts.

export const SHORT_ID_EMAIL_DOMAIN = "pin.strainventory.local";
export const PIN_PASSWORD_SUFFIX = ":strainv-pin";

export const SHORT_ID_PATTERN = /^[A-Za-z0-9]{3,10}$/;
export const PIN_PATTERN = /^\d{4,6}$/;

export const shortIdToEmail = (shortId: string) =>
  `${shortId.trim().toLowerCase()}@${SHORT_ID_EMAIL_DOMAIN}`;

export const pinToPassword = (pin: string) => `${pin}${PIN_PASSWORD_SUFFIX}`;

export const isShortIdEmail = (email: string | null | undefined) =>
  !!email && email.toLowerCase().endsWith(`@${SHORT_ID_EMAIL_DOMAIN}`);

export const shortIdFromEmail = (email: string | null | undefined) => {
  if (!email) return null;
  const lower = email.toLowerCase();
  const suffix = `@${SHORT_ID_EMAIL_DOMAIN}`;
  if (!lower.endsWith(suffix)) return null;
  return lower.slice(0, -suffix.length);
};
