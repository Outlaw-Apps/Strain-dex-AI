export const POS_WEIGHT_OPTIONS = ["1g", "3.5g", "7g", "14g", "28g"] as const;

export type PosWeightOption = (typeof POS_WEIGHT_OPTIONS)[number];

function roundToCents(value: number) {
  return Math.round(value * 100) / 100;
}

export function parseWeightGrams(weight: string) {
  const match = weight.match(/([\d.]+)/);
  return match ? parseFloat(match[1]) : 0;
}

export function getWeightMultiplier(weight: string) {
  const grams = parseWeightGrams(weight);
  return grams > 0 ? grams : 1;
}

export function getWeightedUnitPrice(pricePerGram: number, weight: string) {
  return roundToCents(Math.max(0, pricePerGram) * getWeightMultiplier(weight));
}

export function getCartLineTotal(pricePerGram: number, weight: string, quantity: number) {
  return roundToCents(getWeightedUnitPrice(pricePerGram, weight) * Math.max(0, quantity));
}

export function formatDisplayNumber(value: number) {
  if (!Number.isFinite(value)) {
    return "0";
  }

  return Number.isInteger(value)
    ? String(value)
    : value.toFixed(2).replace(/\.?0+$/, "");
}
