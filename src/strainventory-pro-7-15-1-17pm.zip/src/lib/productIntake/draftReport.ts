import type { GeneratedDraft } from "@/context/ProductDraftContext";
import type { IntakeForm } from "./types";

export function buildDraftReportMarkdown(form: IntakeForm, draft?: GeneratedDraft | null) {
  const ts = new Date();
  const lines: string[] = [];
  lines.push("# Product Intake Draft Report");
  lines.push(`Generated: ${ts.toLocaleString()}`);
  lines.push("");
  lines.push("## Identity");
  lines.push(`- Name: ${form.name || "—"}`);
  lines.push(`- Brand: ${form.brand || "—"}`);
  lines.push(`- Strain: ${form.strain || "—"}`);
  lines.push(`- Batch #: ${form.batchNumber || "—"}`);
  lines.push(`- SKU: ${form.sku || "—"}`);
  lines.push("");
  lines.push("## Classification");
  lines.push(`- Strain Type: ${form.strainType || "—"}`);
  lines.push(`- Limit Category: ${form.limitCategory || "—"}`);
  lines.push(`- Product Type: ${form.productType || "—"}`);
  lines.push(`- Genetics: ${form.genetics || "—"}`);
  lines.push(`- Vendor: ${form.vendor || "—"}`);
  lines.push("");
  lines.push("## Lab");
  lines.push(`- THC: ${form.thc || "—"}`);
  lines.push(`- CBD: ${form.cbd || "—"}`);
  lines.push("");
  lines.push("## Retail & Promotions");
  lines.push(`- List $/g: ${form.listPricePerGram || "—"}`);
  lines.push(`- Sale $/g: ${form.salePricePerGram || "—"}`);
  lines.push(`- Sale Window: ${form.saleStartsLocal || "—"} → ${form.saleEndsLocal || "—"}`);
  lines.push(`- Shelf Label: ${form.saleLabel || "—"}`);
  lines.push(`- Clearance Active: ${form.clearanceActive ? "Yes" : "No"}`);
  if (form.clearanceActive) {
    lines.push(`- Clearance $/g: ${form.clearancePricePerGram || "—"}`);
    lines.push(`- Clearance Reason: ${form.clearanceReason || "—"}`);
  }
  lines.push("");
  lines.push("## Profile");
  lines.push(`- Flavor: ${form.flavorProfile || "—"}`);
  lines.push(`- Aroma: ${form.aromaProfile || "—"}`);
  lines.push("");
  lines.push("## Notes");
  lines.push(form.notes || "—");

  if (draft) {
    lines.push("");
    lines.push("## AI Draft");
    lines.push(`- Short: ${draft.descriptionShort || "—"}`);
    lines.push(`- Long: ${draft.descriptionLong || "—"}`);
  }

  const slug =
    (form.name || form.strain || form.brand || "draft")
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/^-|-$/g, "") || "draft";

  const filename = `intake-draft-${slug}-${ts.toISOString().slice(0, 10)}.md`;
  return { content: lines.join("\n"), filename };
}

export function downloadMarkdown(content: string, filename: string) {
  const blob = new Blob([content], { type: "text/markdown" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
