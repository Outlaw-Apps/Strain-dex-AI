import type { GeneratedDraft } from "@/context/ProductDraftContext";

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

/** Type guard that validates the minimal shape of a GeneratedDraft. */
export function isGeneratedDraft(value: unknown): value is GeneratedDraft {
  if (!isRecord(value)) return false;
  if (!Array.isArray(value.sections)) return false;
  if (typeof value.descriptionShort !== "string") return false;
  if (typeof value.descriptionLong !== "string") return false;
  if (typeof value.overallConfidence !== "number") return false;
  return true;
}

/** Extract a typed `error` string from an unknown edge-function response payload. */
export function extractErrorMessage(payload: unknown, fallback: string): string {
  if (isRecord(payload) && typeof payload.error === "string" && payload.error.trim()) {
    return payload.error;
  }
  return fallback;
}

/** Safely extract a draft-like object (untyped) from an edge-function payload. */
export function extractDraftCandidate(payload: unknown): unknown {
  if (!isRecord(payload)) return undefined;
  return payload.draft;
}
