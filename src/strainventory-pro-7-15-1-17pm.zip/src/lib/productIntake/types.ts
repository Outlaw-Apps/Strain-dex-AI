import { PRODUCT_TYPES, type ProductType } from "@/lib/constants";

export const STRAIN_TYPES = [
  "Indica",
  "Sativa",
  "Hybrid",
  "Indica-Dominant Hybrid",
  "Sativa-Dominant Hybrid",
] as const;

export const LIMIT_CATEGORIES = ["Flower", "Concentrate"] as const;

export const CONCENTRATE_PRODUCT_TYPES = new Set<ProductType>([
  "Wax",
  "Live Resin",
  "Vape (All in One)",
  "Vape Cartridge",
  "Concentrate",
  "Tincture",
  "Topical",
]);

export type StrainType = (typeof STRAIN_TYPES)[number];
export type LimitCategory = (typeof LIMIT_CATEGORIES)[number];

export interface IntakeForm {
  name: string;
  brand: string;
  strain: string;
  batchNumber: string;
  sku: string;
  strainType: StrainType | "";
  limitCategory: LimitCategory | "";
  productType: ProductType | "";
  genetics: string;
  vendor: string;
  thc: string;
  cbd: string;
  flavorProfile: string;
  aromaProfile: string;
  notes: string;
  /** Retail list price per gram */
  listPricePerGram: string;
  salePricePerGram: string;
  saleStartsLocal: string;
  saleEndsLocal: string;
  saleLabel: string;
  clearanceActive: boolean;
  clearancePricePerGram: string;
  clearanceReason: string;
}

export const EMPTY_INTAKE_FORM: IntakeForm = {
  name: "",
  brand: "",
  strain: "",
  batchNumber: "",
  sku: "",
  strainType: "",
  limitCategory: "",
  productType: "",
  genetics: "",
  vendor: "",
  thc: "",
  cbd: "",
  flavorProfile: "",
  aromaProfile: "",
  notes: "",
  listPricePerGram: "",
  salePricePerGram: "",
  saleStartsLocal: "",
  saleEndsLocal: "",
  saleLabel: "",
  clearanceActive: false,
  clearancePricePerGram: "",
  clearanceReason: "",
};

export function inferLimitCategory(productType: string): LimitCategory | "" {
  if (!productType) return "";
  if (productType === "Flower" || productType === "Pre roll") return "Flower";
  return CONCENTRATE_PRODUCT_TYPES.has(productType as ProductType)
    ? "Concentrate"
    : "";
}

export function mergeDistinctLines(values: string[]) {
  const lines = new Map<string, string>();
  for (const value of values) {
    for (const line of value.split(/\r?\n/g)) {
      const cleaned = line.trim();
      if (!cleaned) continue;
      const key = cleaned.toLowerCase();
      if (!lines.has(key)) lines.set(key, cleaned);
    }
  }
  return Array.from(lines.values()).join("\n");
}

export function isValidProductType(value: string): value is ProductType {
  return PRODUCT_TYPES.includes(value as ProductType);
}
