export type ReviewRewriteActionId = "premium" | "shorten" | "verify" | "simplify";

export interface ReviewRewriteResult {
  fields: Record<string, string>;
  changed: boolean;
  changedLabels: string[];
}

const premiumLabels = new Set([
  "Short Description",
  "Long Description",
  "Aroma Profile",
  "Aroma Notes",
  "Taste Profile",
  "Finish",
  "Effects",
  "Onset",
  "Medical Uses",
  "May Help With",
]);

const simplifyLabels = new Set([
  "Short Description",
  "Long Description",
  "Aroma Profile",
  "Aroma Notes",
  "Taste Profile",
  "Finish",
  "Effects",
  "Onset",
  "Medical Uses",
  "May Help With",
]);

const verifyLabels = new Set([
  "Short Description",
  "Long Description",
  "Aroma Profile",
  "Aroma Notes",
  "Taste Profile",
  "Finish",
  "Effects",
  "Onset",
  "Medical Uses",
  "May Help With",
]);

const shortenLimits: Partial<Record<string, number>> = {
  "Short Description": 140,
  "Long Description": 280,
  "Medical Uses": 120,
  "May Help With": 120,
  Effects: 100,
  Onset: 80,
  "Aroma Profile": 80,
  "Taste Profile": 80,
};

const uncertainClaimPattern = /\b(unknown|not provided|n\/a|requires verification|needs verification|unverified|anecdotal|may help(?: with)?|might|could|possibly|likely|consult)\b/i;
const trailingPunctuationPattern = /[.!?]$/;

const normalizeWhitespace = (value: string) =>
  value
    .replace(/\s+/g, " ")
    .replace(/\s+([,.;!?])/g, "$1")
    .trim();

const appendSentencePunctuation = (value: string) => {
  if (!value) return "";
  return trailingPunctuationPattern.test(value) ? value : `${value}.`;
};

const trimSentence = (value: string) =>
  normalizeWhitespace(value)
    .replace(/^[-,;:]+/, "")
    .replace(/[-,;:]+$/, "")
    .trim();

const shortenText = (value: string, limit: number) => {
  const normalized = normalizeWhitespace(value);
  if (!normalized || normalized.length <= limit) {
    return normalized;
  }

  const safeLimit = Math.max(10, limit - 3);
  const sliced = normalized.slice(0, safeLimit);
  const lastSpace = sliced.lastIndexOf(" ");
  const shortened = lastSpace > safeLimit - 24 ? sliced.slice(0, lastSpace) : sliced;
  return `${shortened.trimEnd().replace(/[.,;:!?-]+$/, "")}...`;
};

const simplifyText = (value: string) => {
  const simplified = trimSentence(
    normalizeWhitespace(
      value
        .replace(/\([^)]*\)/g, " ")
        .replace(/[;|]+/g, ", "),
    ),
  );

  return appendSentencePunctuation(simplified);
};

const verifyText = (label: string, value: string) => {
  const normalized = normalizeWhitespace(value);
  if (!normalized) {
    return "";
  }

  if (!verifyLabels.has(label)) {
    return normalized;
  }

  if (label === "Medical Uses" || label === "May Help With") {
    return uncertainClaimPattern.test(normalized)
      ? ""
      : appendSentencePunctuation(normalized);
  }

  const clauses = normalized
    .split(/(?<=[.!?;])\s+/)
    .map(trimSentence)
    .filter(Boolean);

  const verifiedClauses = clauses.filter((clause) => !uncertainClaimPattern.test(clause));
  if (verifiedClauses.length === 0 && uncertainClaimPattern.test(normalized)) {
    return "";
  }

  return appendSentencePunctuation(verifiedClauses.join(" "));
};

const premiumText = (value: string) => appendSentencePunctuation(trimSentence(value));

export const applyReviewRewrite = (
  actionId: ReviewRewriteActionId,
  fields: Record<string, string>,
): ReviewRewriteResult => {
  const nextFields = { ...fields };
  const changedLabels: string[] = [];

  for (const [label, value] of Object.entries(fields)) {
    const normalizedValue = typeof value === "string" ? value : "";
    let rewrittenValue = normalizedValue;

    if (actionId === "premium" && premiumLabels.has(label)) {
      rewrittenValue = premiumText(normalizedValue);
    }

    if (actionId === "shorten" && shortenLimits[label]) {
      rewrittenValue = shortenText(normalizedValue, shortenLimits[label]!);
    }

    if (actionId === "verify") {
      rewrittenValue = verifyText(label, normalizedValue);
    }

    if (actionId === "simplify" && simplifyLabels.has(label)) {
      rewrittenValue = simplifyText(normalizedValue);
    }

    if (rewrittenValue !== normalizedValue) {
      nextFields[label] = rewrittenValue;
      changedLabels.push(label);
    }
  }

  return {
    fields: nextFields,
    changed: changedLabels.length > 0,
    changedLabels,
  };
};
