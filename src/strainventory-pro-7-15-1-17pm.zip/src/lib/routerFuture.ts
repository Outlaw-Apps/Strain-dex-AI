/** React Router v7 future flags — opt in early to silence v6 deprecation warnings. */
export const routerFuture = {
  v7_startTransition: true,
  v7_relativeSplatPath: true,
} as const;
