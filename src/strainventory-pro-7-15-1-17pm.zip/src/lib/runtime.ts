export const isDesktopShell = () =>
  typeof window !== "undefined" && window.__STRAINVENTORY_DESKTOP_SHELL__ === true;

export const shouldUseHashRouter = () => isDesktopShell();
