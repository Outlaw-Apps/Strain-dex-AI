export type PaymentBucket = "cash" | "card" | "other";

export function bucketPaymentMethod(method: string): PaymentBucket {
  const m = method.toLowerCase();
  if (m.includes("cash")) return "cash";
  if (m.includes("card") || m.includes("debit") || m.includes("credit") || m.includes("tap")) return "card";
  return "other";
}

export interface OrderTotalRow {
  payment_method: string;
  total: number;
}

export interface ShiftAggregates {
  order_count: number;
  total_sales: number;
  total_cash: number;
  total_card: number;
  total_other: number;
}

export function aggregateOrdersForShift(orders: OrderTotalRow[]): ShiftAggregates {
  let total_cash = 0;
  let total_card = 0;
  let total_other = 0;
  let total_sales = 0;
  const order_count = orders.length;

  for (const o of orders) {
    const t = Number(o.total) || 0;
    total_sales += t;
    const b = bucketPaymentMethod(o.payment_method || "");
    if (b === "cash") total_cash += t;
    else if (b === "card") total_card += t;
    else total_other += t;
  }

  return { order_count, total_sales, total_cash, total_card, total_other };
}

export function expectedDrawerCash(openingFloat: number | null | undefined, totalCashSales: number): number | null {
  if (openingFloat == null || Number.isNaN(openingFloat)) return null;
  return openingFloat + totalCashSales;
}
