import type { LockFunc } from "@supabase/supabase-js";

interface AcquireTimeoutError extends Error {
  isAcquireTimeout: true;
}

const lockQueue = new Map<string, Promise<void>>();

function createAcquireTimeoutError(name: string, acquireTimeout: number): AcquireTimeoutError {
  const error = new Error(
    `Timed out after ${acquireTimeout}ms waiting for the Supabase auth lock "${name}".`,
  ) as AcquireTimeoutError;
  error.name = "SupabaseAuthLockAcquireTimeoutError";
  error.isAcquireTimeout = true;
  return error;
}

async function waitForTurn(queue: Promise<void>, name: string, acquireTimeout: number) {
  if (acquireTimeout < 0) {
    await queue;
    return;
  }

  let timer: ReturnType<typeof setTimeout> | undefined;

  try {
    await Promise.race([
      queue,
      new Promise<never>((_, reject) => {
        timer = setTimeout(() => {
          reject(createAcquireTimeoutError(name, acquireTimeout));
        }, acquireTimeout);
      }),
    ]);
  } finally {
    if (timer) {
      clearTimeout(timer);
    }
  }
}

export const inProcessSupabaseLock: LockFunc = async (name, acquireTimeout, fn) => {
  const previous = lockQueue.get(name) ?? Promise.resolve();
  const waitForPrevious = previous.catch(() => undefined);

  let releaseCurrent!: () => void;
  const current = new Promise<void>((resolve) => {
    releaseCurrent = resolve;
  });
  const chained = waitForPrevious.then(() => current);

  lockQueue.set(name, chained);

  try {
    await waitForTurn(waitForPrevious, name, acquireTimeout);
  } catch (error) {
    releaseCurrent();
    if (lockQueue.get(name) === chained) {
      lockQueue.delete(name);
    }
    throw error;
  }

  try {
    return await fn();
  } finally {
    releaseCurrent();
    if (lockQueue.get(name) === chained) {
      lockQueue.delete(name);
    }
  }
};
