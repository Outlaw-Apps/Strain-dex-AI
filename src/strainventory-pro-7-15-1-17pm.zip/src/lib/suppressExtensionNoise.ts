const EXTENSION_MESSAGE_CHANNEL_ERROR =
  "message channel closed before a response was received";

/** Chrome extension messaging noise on login pages (password managers, etc.). */
export function suppressExtensionMessageChannelNoise() {
  if (!import.meta.env.DEV) return;

  window.addEventListener("unhandledrejection", (event) => {
    const message =
      event.reason instanceof Error
        ? event.reason.message
        : typeof event.reason === "string"
          ? event.reason
          : "";

    if (message.includes(EXTENSION_MESSAGE_CHANNEL_ERROR)) {
      event.preventDefault();
    }
  });
}
