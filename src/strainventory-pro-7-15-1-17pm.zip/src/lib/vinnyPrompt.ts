// Re-export wrapper for the spec path. The actual implementation lives in
// `supabase/functions/_shared/vinnyPrompt.ts` so it can be imported by both
// the Edge Function (Deno) and Vitest tests via relative path, mirroring how
// `assistantPayload.ts` is structured.
export {
  buildStrainVinnyPrompt,
  type StrainVinnyPromptContext,
  type WebSearchResult,
  type ConversationTurn,
  type UserPreferences,
  type PageContext,
  type ExperienceLevel,
} from "../../supabase/functions/_shared/vinnyPrompt";
