import { createRoot } from "react-dom/client";
import { HelmetProvider } from "react-helmet-async";
import App from "./App.tsx";
import { suppressExtensionMessageChannelNoise } from "@/lib/suppressExtensionNoise";
import { applyAppearance, loadAppearance } from "@/lib/appearance";
import "./index.css";

suppressExtensionMessageChannelNoise();
applyAppearance(loadAppearance());

createRoot(document.getElementById("root")!).render(
  <HelmetProvider>
    <App />
  </HelmetProvider>,
);
