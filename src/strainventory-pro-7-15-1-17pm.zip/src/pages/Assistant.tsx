import { motion } from "framer-motion";
import AssistantCopilotPanel from "@/components/assistant/AssistantCopilotPanel";

export default function AssistantPage() {
  return (
    <div className="relative h-[calc(100vh-3.5rem)] md:h-screen overflow-hidden p-3 sm:p-5 lg:p-8">
      <div aria-hidden className="pointer-events-none absolute -top-24 right-1/4 h-72 w-72 rounded-full bg-accent/15 blur-3xl" />
      <div aria-hidden className="pointer-events-none absolute -bottom-24 left-1/4 h-72 w-72 rounded-full bg-emerald-500/10 blur-3xl" />
      <motion.div
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.35 }}
        className="relative mx-auto h-full max-w-4xl"
      >
        <AssistantCopilotPanel embedded />
      </motion.div>
    </div>
  );
}
