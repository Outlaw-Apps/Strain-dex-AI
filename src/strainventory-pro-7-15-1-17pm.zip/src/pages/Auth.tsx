import { useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import {
  ArrowRight,
  Eye,
  EyeOff,
  Hash,
  KeyRound,
  Leaf,
  Lock,
  LogIn,
  Mail,
  RotateCcw,
  Sparkles,
  UserPlus,
  Delete,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useAuth } from "@/context/AuthContext";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import logoImg from "@/assets/Cannabis_logo.png";
import {
  getEmailActionState,
  getPasswordStrength,
  normalizeAuthEmail,
} from "@/lib/authAccess";
import { SHORT_ID_PATTERN, PIN_PATTERN } from "@/lib/pinAuth";
import Seo from "@/components/Seo";
import AuthDiagnosticsPanel from "@/components/auth/AuthDiagnosticsPanel";
import {
  startAuthStep,
  completeAuthStep,
  failAuthStep,
} from "@/lib/authDiagnostics";

type Mode = "pin" | "email";
type PendingAction = "pin-submit" | "email-submit" | "magic-link" | "password-reset" | null;

const Auth = () => {
  const navigate = useNavigate();
  const { signIn, signUp, sendMagicLink, requestPasswordReset, signInWithShortId } = useAuth();
  const [mode, setMode] = useState<Mode>("pin");
  const [isSignUp, setIsSignUp] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [shortId, setShortId] = useState("");
  const [pin, setPin] = useState("");
  const [pendingAction, setPendingAction] = useState<PendingAction>(null);
  const [showPassword, setShowPassword] = useState(false);
  const [showPin, setShowPin] = useState(false);

  const emailActionState = useMemo(() => getEmailActionState(email), [email]);
  const normalizedEmail = useMemo(() => normalizeAuthEmail(email), [email]);
  const passwordStrength = useMemo(() => getPasswordStrength(password), [password]);
  const isBusy = pendingAction !== null;

  const handleEmailSubmit = async (event: React.FormEvent) => {
    event.preventDefault();

    if (!emailActionState.canSubmit || !password.trim()) {
      toast.error(!password.trim() ? "Please fill in all fields." : emailActionState.helperText);
      return;
    }

    setPendingAction("email-submit");
    const diagId = startAuthStep(isSignUp ? "email-signup" : "email-signin", {
      email: normalizedEmail,
    });

    try {
      const { error } = isSignUp
        ? await signUp(normalizedEmail, password)
        : await signIn(normalizedEmail, password);

      if (error) {
        failAuthStep(diagId, error);
        toast.error(error.message);
      } else if (isSignUp) {
        completeAuthStep(diagId, "Account created — check email to confirm.");
        toast.success("Account created! Check your email to confirm.");
      } else {
        completeAuthStep(diagId, "Session established.");
        toast.success("Welcome back!");
        navigate("/");
      }
    } catch (err) {
      failAuthStep(diagId, err);
      throw err;
    } finally {
      setPendingAction(null);
    }
  };

  const handlePinSubmit = async (event: React.FormEvent) => {
    event.preventDefault();

    const cleanShortId = shortId.trim();
    const cleanPin = pin.trim();

    if (!SHORT_ID_PATTERN.test(cleanShortId)) {
      toast.error("Enter a valid short ID (3-10 letters/digits).");
      return;
    }

    if (!PIN_PATTERN.test(cleanPin)) {
      toast.error("PIN must be 4-6 digits.");
      return;
    }

    setPendingAction("pin-submit");
    const diagId = startAuthStep("pin-signin", { shortId: cleanShortId });

    try {
      const { error } = await signInWithShortId(cleanShortId, cleanPin);

      if (error) {
        failAuthStep(diagId, error);
        toast.error("Short ID or PIN is incorrect.");
        return;
      }

      completeAuthStep(diagId, "Session established.");
      toast.success("Welcome back!");
      navigate("/");
    } catch (err) {
      failAuthStep(diagId, err);
      throw err;
    } finally {
      setPendingAction(null);
    }
  };

  const handleMagicLink = async () => {
    if (!emailActionState.canSubmit) {
      toast.error(emailActionState.helperText);
      return;
    }

    setPendingAction("magic-link");
    const diagId = startAuthStep("magic-link", { email: normalizedEmail });

    try {
      const { error } = await sendMagicLink(normalizedEmail);

      if (error) {
        failAuthStep(diagId, error);
        toast.error(error.message);
        return;
      }

      completeAuthStep(diagId, "Magic link email sent.");
      toast.success("Magic link sent. Check your inbox to finish signing in.");
    } catch (err) {
      failAuthStep(diagId, err);
      throw err;
    } finally {
      setPendingAction(null);
    }
  };

  const handlePasswordReset = async () => {
    if (!emailActionState.canSubmit) {
      toast.error(emailActionState.helperText);
      return;
    }

    setPendingAction("password-reset");
    const diagId = startAuthStep("password-reset", { email: normalizedEmail });

    try {
      const { error } = await requestPasswordReset(normalizedEmail);

      if (error) {
        failAuthStep(diagId, error);
        toast.error(error.message);
        return;
      }

      completeAuthStep(diagId, "Password reset email sent.");
      toast.success("Password reset email sent. Check your inbox for the recovery link.");
    } catch (err) {
      failAuthStep(diagId, err);
      throw err;
    } finally {
      setPendingAction(null);
    }
  };

  return (
    <div className="dark relative min-h-screen overflow-hidden bg-background flex items-center justify-center p-4 sm:p-6">
      <Seo
        title="Sign in | Strain-ventory"
        description="Sign in to Strain-ventory — the AI-powered cannabis catalog, POS, and dispensary management platform."
        path="/auth"
      />
      {/* Ambient gold/emerald glow */}
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute -top-32 -left-32 h-96 w-96 rounded-full bg-accent/20 blur-3xl" />
        <div className="absolute -bottom-32 -right-32 h-96 w-96 rounded-full bg-emerald-500/10 blur-3xl" />
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_hsl(var(--accent)/0.08),_transparent_60%)]" />
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="relative w-full max-w-md"
      >
        <div className="flex flex-col items-center mb-8 sm:mb-10">
          <div className="relative mb-4">
            <div className="absolute inset-0 rounded-2xl bg-accent/30 blur-xl" />
            <img
              src={logoImg}
              alt="Strain-ventory"
              className="relative h-16 w-16 rounded-2xl object-cover shadow-elevated ring-2 ring-accent/40"
            />
          </div>
          <h1 className="text-display text-4xl font-bold text-foreground tracking-tight">
            Strain-ventory
          </h1>
          <p className="text-sm text-muted-foreground mt-1.5 tracking-wide">
            AI-Powered Cannabis Catalog
          </p>
        </div>

        <div className="rounded-2xl border-2 border-border/80 bg-card/80 backdrop-blur-xl shadow-elevated p-6 sm:p-8">
          <div className="flex items-center gap-2 mb-6">
            {mode === "pin" ? (
              <KeyRound className="h-5 w-5 text-accent" />
            ) : isSignUp ? (
              <UserPlus className="h-5 w-5 text-accent" />
            ) : (
              <LogIn className="h-5 w-5 text-accent" />
            )}
            <h2 className="text-lg font-semibold text-foreground">
              {mode === "pin"
                ? "Sign in with ID + PIN"
                : isSignUp
                  ? "Create Account"
                  : "Sign In"}
            </h2>
          </div>

          {mode === "pin" ? (
            <form onSubmit={handlePinSubmit} className="space-y-5">
              <div className="space-y-2">
                <Label htmlFor="shortId">User ID</Label>
                <div className="relative">
                  <Hash className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                  <Input
                    id="shortId"
                    type="text"
                    autoComplete="username"
                    autoCapitalize="characters"
                    spellCheck={false}
                    placeholder="e.g. DW01"
                    className="pl-10 bg-muted text-foreground placeholder:text-muted-foreground font-mono tracking-wide uppercase"
                    maxLength={10}
                    value={shortId}
                    onChange={(event) =>
                      setShortId(event.target.value.replace(/[^A-Za-z0-9]/g, ""))
                    }
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="pin">PIN</Label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                  <Input
                    id="pin"
                    type={showPin ? "text" : "password"}
                    inputMode="numeric"
                    autoComplete="off"
                    data-1p-ignore
                    data-bwignore
                    data-form-type="other"
                    data-lpignore="true"
                    placeholder="Enter PIN"
                    className="pl-10 pr-11 bg-muted text-foreground placeholder:text-muted-foreground tracking-widest"
                    maxLength={6}
                    value={pin}
                    onChange={(event) => setPin(event.target.value.replace(/\D/g, ""))}
                  />
                  <button
                    type="button"
                    aria-label={showPin ? "Hide PIN" : "Show PIN"}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground transition-colors hover:text-foreground"
                    onClick={() => setShowPin((current) => !current)}
                  >
                    {showPin ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </button>
              </div>

              {/* Big numeric keypad for counter tablets */}
              <div className="grid grid-cols-3 gap-2 pt-1">
                {["1","2","3","4","5","6","7","8","9"].map((d) => (
                  <button
                    key={d}
                    type="button"
                    onClick={() => setPin((p) => (p.length >= 6 ? p : p + d))}
                    disabled={isBusy}
                    className="h-14 rounded-lg border border-border bg-muted text-2xl font-semibold text-foreground transition-colors hover:bg-accent/10 active:bg-accent/20 disabled:opacity-50"
                  >
                    {d}
                  </button>
                ))}
                <button
                  type="button"
                  onClick={() => setPin("")}
                  disabled={isBusy}
                  className="h-14 rounded-lg border border-border bg-muted text-sm font-medium text-muted-foreground transition-colors hover:bg-accent/10"
                >
                  Clear
                </button>
                <button
                  type="button"
                  onClick={() => setPin((p) => (p.length >= 6 ? p : p + "0"))}
                  disabled={isBusy}
                  className="h-14 rounded-lg border border-border bg-muted text-2xl font-semibold text-foreground transition-colors hover:bg-accent/10 active:bg-accent/20 disabled:opacity-50"
                >
                  0
                </button>
                <button
                  type="button"
                  onClick={() => setPin((p) => p.slice(0, -1))}
                  disabled={isBusy}
                  aria-label="Backspace"
                  className="h-14 rounded-lg border border-border bg-muted text-foreground transition-colors hover:bg-accent/10 flex items-center justify-center"
                >
                  <Delete className="h-5 w-5" />
                </button>
              </div>
              </div>

              <Button
                variant="gold"
                size="lg"
                className="w-full gap-2"
                type="submit"
                disabled={isBusy}
              >
                {pendingAction === "pin-submit" ? (
                  <motion.div
                    animate={{ rotate: 360 }}
                    transition={{ repeat: Infinity, duration: 1, ease: "linear" }}
                  >
                    <Leaf className="h-4 w-4" />
                  </motion.div>
                ) : (
                  <>
                    Sign In <ArrowRight className="h-4 w-4" />
                  </>
                )}
              </Button>
            </form>
          ) : (
            <form onSubmit={handleEmailSubmit} className="space-y-5">
              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                  <Input
                    id="email"
                    type="email"
                    autoComplete="email"
                    autoCapitalize="none"
                    spellCheck={false}
                    placeholder="you@example.com"
                    className="pl-10 bg-muted text-foreground placeholder:text-muted-foreground"
                    value={email}
                    onChange={(event) => setEmail(event.target.value)}
                  />
                </div>
                <p className="text-xs text-muted-foreground" aria-live="polite">
                  {emailActionState.helperText}
                </p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="password">Password</Label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                  <Input
                    id="password"
                    type={showPassword ? "text" : "password"}
                    autoComplete={isSignUp ? "new-password" : "current-password"}
                    placeholder="Enter password"
                    className="pl-10 pr-11 bg-muted text-foreground placeholder:text-muted-foreground"
                    value={password}
                    onChange={(event) => setPassword(event.target.value)}
                  />
                  <button
                    type="button"
                    aria-label={showPassword ? "Hide password" : "Show password"}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground transition-colors hover:text-foreground"
                    onClick={() => setShowPassword((current) => !current)}
                  >
                    {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </button>
                </div>
              </div>

              {isSignUp && (
                <div className="space-y-2 rounded-lg border border-border/70 bg-background/70 p-3">
                  <div className="flex items-center justify-between gap-3 text-xs">
                    <span className="font-medium text-foreground">Password strength</span>
                    <span className="text-muted-foreground">{passwordStrength.label}</span>
                  </div>
                  <div className="h-2 overflow-hidden rounded-full bg-muted">
                    <div
                      className={cn(
                        "h-full rounded-full transition-all",
                        passwordStrength.score <= 1 && "bg-destructive",
                        passwordStrength.score === 2 && "bg-amber-500",
                        passwordStrength.score === 3 && "bg-accent",
                        passwordStrength.score >= 4 && "bg-emerald-500",
                      )}
                      style={{ width: `${Math.max(passwordStrength.score, 1) * 25}%` }}
                    />
                  </div>
                  <p className="text-xs text-muted-foreground">
                    Use at least 8 characters with upper and lower case letters, a number, and a symbol.
                  </p>
                </div>
              )}

              <Button
                variant="gold"
                size="lg"
                className="w-full gap-2"
                type="submit"
                disabled={isBusy || !emailActionState.canSubmit || !password.trim()}
              >
                {pendingAction === "email-submit" ? (
                  <motion.div
                    animate={{ rotate: 360 }}
                    transition={{ repeat: Infinity, duration: 1, ease: "linear" }}
                  >
                    <Leaf className="h-4 w-4" />
                  </motion.div>
                ) : (
                  <>
                    {isSignUp ? "Create Account" : "Sign In"}
                    <ArrowRight className="h-4 w-4" />
                  </>
                )}
              </Button>

              <div className="space-y-3 rounded-lg border border-border/70 bg-background/70 p-4">
                <div className="space-y-1">
                  <p className="text-sm font-medium text-foreground">Need faster account access?</p>
                  <p className="text-xs text-muted-foreground">
                    Use your email for a passwordless magic link or request a recovery email.
                  </p>
                </div>
                <div className="grid gap-2 sm:grid-cols-2">
                  <Button
                    type="button"
                    variant="outline"
                    className="justify-start"
                    onClick={() => void handleMagicLink()}
                    disabled={isBusy}
                  >
                    {pendingAction === "magic-link" ? (
                      <Leaf className="h-4 w-4 animate-spin" />
                    ) : (
                      <Sparkles className="h-4 w-4" />
                    )}
                    Email me a magic link
                  </Button>
                  <Button
                    type="button"
                    variant="outline"
                    className="justify-start"
                    onClick={() => void handlePasswordReset()}
                    disabled={isBusy}
                  >
                    {pendingAction === "password-reset" ? (
                      <Leaf className="h-4 w-4 animate-spin" />
                    ) : (
                      <RotateCcw className="h-4 w-4" />
                    )}
                    Reset password
                  </Button>
                </div>
              </div>
            </form>
          )}

          <div className="mt-6 flex flex-col items-center gap-2 text-sm">
            <button
              type="button"
              onClick={() => {
                setMode(mode === "pin" ? "email" : "pin");
                setIsSignUp(false);
                setPendingAction(null);
                setShowPassword(false);
                setShowPin(false);
              }}
              className="text-muted-foreground hover:text-foreground transition-colors"
            >
              {mode === "pin" ? (
                <>
                  Admin? <span className="text-accent font-medium">Sign in with email</span>
                </>
              ) : (
                <>
                  Staff? <span className="text-accent font-medium">Use your ID + PIN</span>
                </>
              )}
            </button>
            {mode === "email" && (
              <button
                type="button"
                onClick={() => {
                  setIsSignUp((current) => !current);
                  setPendingAction(null);
                  setShowPassword(false);
                }}
                className="text-muted-foreground hover:text-foreground transition-colors"
              >
                {isSignUp ? "Already have an account? " : "Don't have an account? "}
                <span className="font-medium text-accent">
                  {isSignUp ? "Sign In" : "Sign Up"}
                </span>
              </button>
            )}
          </div>
        </div>

        <AuthDiagnosticsPanel />

        <div className="mt-6 flex flex-wrap items-center justify-center gap-x-4 gap-y-1 text-xs text-muted-foreground">
          <a href="/privacy" className="hover:text-accent transition-colors">Privacy Policy</a>
          <span className="opacity-40">·</span>
          <a href="/terms" className="hover:text-accent transition-colors">Terms of Use</a>
          <span className="opacity-40">·</span>
          <a href="mailto:support@strainventory.com" className="hover:text-accent transition-colors">support@strainventory.com</a>
        </div>
      </motion.div>
    </div>
  );
};

export default Auth;
