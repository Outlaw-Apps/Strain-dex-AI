import { useState, useRef, useEffect } from "react";
import { motion } from "framer-motion";
import { Upload, FileSpreadsheet, CheckCircle2, Layers } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import { useNavigate } from "react-router-dom";
import { Badge } from "@/components/ui/badge";
import { useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { enqueueProductUpsert } from "@/lib/offlineProductQueue";
import { buildCatalogDraftRow, parseBulkIntakeText, type ParsedProduct } from "@/lib/bulkIntake";

const csvTemplateHeader = "product_name, brand, product_type, THC%, CBD%, description";

const BulkIntake = () => {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const batchTimerRef = useRef<number | null>(null);
  const [pasteText, setPasteText] = useState("");
  const [parsedProducts, setParsedProducts] = useState<ParsedProduct[]>([]);
  const [csvFileName, setCsvFileName] = useState<string | null>(null);
  const [processing, setProcessing] = useState(false);
  const [importing, setImporting] = useState(false);
  const [isDragging, setIsDragging] = useState(false);

  // Cancel any pending parse timer when the component unmounts.
  useEffect(() => {
    return () => {
      if (batchTimerRef.current !== null) {
        window.clearTimeout(batchTimerRef.current);
      }
    };
  }, []);

  const readFile = (file: File) => {
    if (!file.name.match(/\.(csv|txt)$/i)) {
      toast.error("Please upload a CSV or TXT file.");
      return;
    }

    setCsvFileName(file.name);
    const reader = new FileReader();
    reader.onload = (event) => {
      const text = typeof event.target?.result === "string" ? event.target.result : "";
      const products = parseBulkIntakeText(text);
      setParsedProducts(products);
      if (products.length === 0) {
        toast.error("We couldn't find any valid product rows in that file.");
        return;
      }
      toast.success(`Parsed ${products.length} product${products.length === 1 ? "" : "s"} from ${file.name}.`);
    };
    reader.readAsText(file);
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = "";
    if (!file) return;
    readFile(file);
  };

  const handleDrop = (event: React.DragEvent<HTMLDivElement>) => {
    event.preventDefault();
    setIsDragging(false);
    const file = event.dataTransfer.files?.[0];
    if (!file) return;
    readFile(file);
  };

  const handlePasteBatch = () => {
    if (!pasteText.trim()) {
      toast.error("Please paste some product data first.");
      return;
    }
    setProcessing(true);
    const products = parseBulkIntakeText(pasteText);

    // Store the timer id in a ref so it can be cancelled on unmount.
    if (batchTimerRef.current !== null) {
      window.clearTimeout(batchTimerRef.current);
    }
    batchTimerRef.current = window.setTimeout(() => {
      batchTimerRef.current = null;
      setParsedProducts(products);
      setProcessing(false);
      if (products.length === 0) {
        toast.error("We couldn't find any valid product rows in that paste.");
        return;
      }
      toast.success(`Parsed ${products.length} product${products.length === 1 ? "" : "s"}. Ready to create drafts.`);
    }, 800);
  };

  const handleEnrichAll = async () => {
    if (parsedProducts.length === 0) {
      toast.error("No products to turn into drafts. Upload or paste data first.");
      return;
    }

    const rows = parsedProducts.map(buildCatalogDraftRow);
    setImporting(true);

    const queueAllRows = () => {
      rows.forEach((row) =>
        enqueueProductUpsert({
          id: crypto.randomUUID(),
          row,
          mode: "draft",
          queuedAt: new Date().toISOString(),
        }),
      );
      queryClient.invalidateQueries({ queryKey: ["products"] });
      setImporting(false);
      toast.success(`Queued ${rows.length} catalog draft${rows.length === 1 ? "" : "s"} to sync when you're back online.`);
      navigate("/catalog");
    };

    if (!navigator.onLine) {
      queueAllRows();
      return;
    }

    const { error } = await supabase.from("products").upsert(rows);
    if (error) {
      if (/network|fetch|offline/i.test(error.message)) {
        queueAllRows();
        return;
      }

      setImporting(false);
      toast.error(`Failed to create catalog drafts: ${error.message}`);
      return;
    }

    await queryClient.invalidateQueries({ queryKey: ["products"] });
    setImporting(false);
    toast.success(`Created ${rows.length} catalog draft${rows.length === 1 ? "" : "s"} from your batch.`);
    navigate("/catalog");
  };

  return (
    <div className="p-4 sm:p-6 lg:p-10 max-w-6xl mx-auto">
      <motion.div
        initial={{ opacity: 0, y: -8 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
        className="mb-8 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between"
      >
        <div className="flex items-center gap-4">
          <div className="gold-gradient flex h-12 w-12 items-center justify-center rounded-2xl shadow-gold">
            <Layers className="h-6 w-6 text-accent-foreground" />
          </div>
          <div>
            <h1 className="text-display text-3xl sm:text-4xl font-semibold tracking-tight text-foreground flex items-center gap-3">
              Bulk Intake
              <span className="h-2 w-2 rounded-full bg-success animate-pulse" />
            </h1>
            <p className="mt-1 text-sm sm:text-base text-muted-foreground">
              Upload a batch. Strain Vinny drafts each one for your review queue.
            </p>
          </div>
        </div>
      </motion.div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 sm:gap-6">
        {/* CSV Upload */}
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.15 }}
          className={`rounded-2xl border-2 bg-card shadow-elevated p-6 sm:p-8 flex flex-col items-center justify-center text-center min-h-[280px] hover:shadow-gold transition-all cursor-pointer group ${isDragging ? "border-accent ring-2 ring-accent/30" : "border-border"}`}
          onClick={() => fileInputRef.current?.click()}
          onDragOver={(event) => {
            event.preventDefault();
            setIsDragging(true);
          }}
          onDragLeave={() => setIsDragging(false)}
          onDrop={handleDrop}
        >
          <label htmlFor="bulk-intake-file" className="sr-only">
            Select a CSV or TXT file to upload
          </label>
          <input
            id="bulk-intake-file"
            ref={fileInputRef}
            type="file"
            accept=".csv,.txt"
            className="hidden"
            onChange={handleFileSelect}
            aria-label="Select a CSV or TXT file to upload"
            title="Select a CSV or TXT file to upload"
          />
          <div className="gold-gradient flex h-14 w-14 items-center justify-center rounded-2xl mb-4 group-hover:scale-105 transition-transform shadow-gold">
            <FileSpreadsheet className="h-7 w-7 text-accent-foreground" />
          </div>
          <h2 className="text-base font-semibold text-foreground mb-1">Upload CSV</h2>
          <p className="text-xs text-muted-foreground max-w-[220px] mb-4">
            {csvFileName ? `Selected: ${csvFileName}` : "Drag and drop a CSV/TXT file or click to browse."}
          </p>
          <p className="mb-4 max-w-[320px] text-[11px] leading-relaxed text-muted-foreground">
            Template: <span className="font-medium text-foreground">{csvTemplateHeader}</span>
          </p>
          <Button
            variant="outline"
            size="sm"
            className="gap-2 border-2"
            onClick={(e) => {
              e.stopPropagation();
              fileInputRef.current?.click();
            }}
          >
            <Upload className="h-3.5 w-3.5" />
            Choose File
          </Button>
        </motion.div>

        {/* Paste List */}
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.25 }}
          className="rounded-2xl border-2 border-border bg-card shadow-elevated p-6 sm:p-8 space-y-4"
        >
          <h2 className="text-base font-semibold text-foreground">Paste Product List</h2>
          <Textarea
            placeholder={[
              csvTemplateHeader,
              "Blue Dream 3.5g Jar, Pacific Stone, Flower, 27%, 0.3%, Sweet berry aroma with a mellow finish",
              "Gelato 41 1g Cart, Stiiizy, Vape Cartridge, 84%, 0.1%, Creamy gas notes and smooth vapor",
            ].join("\n")}
            className="bg-background border-2 min-h-[180px] resize-y text-sm"
            value={pasteText}
            onChange={(e) => setPasteText(e.target.value)}
          />
          <Button variant="gold" size="sm" className="gap-2 border-2 border-accent shadow-gold" onClick={handlePasteBatch} disabled={processing}>
            {processing ? "Parsing…" : "Start Batch Enrichment"}
          </Button>
        </motion.div>
      </div>


      {/* Parsed products preview */}
      {parsedProducts.length > 0 && (
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4 }}
          className="mt-8 rounded-2xl border-2 border-border bg-card shadow-elevated overflow-hidden"
        >
          <div className="border-b-2 border-border bg-muted/50 px-4 sm:px-6 py-4 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="h-4 w-4 text-success" />
              <h2 className="text-sm font-semibold text-card-foreground">{parsedProducts.length} Products Parsed</h2>
            </div>
            <Button variant="gold" size="sm" className="gap-2 border-2 border-accent shadow-gold" onClick={() => void handleEnrichAll()} disabled={importing}>
              {importing ? "Creating Drafts…" : "Create Catalog Drafts"}
            </Button>
          </div>
          <div className="divide-y-2 divide-border max-h-72 overflow-y-auto">
            {parsedProducts.map((p, i) => (
              <div key={i} className="px-4 sm:px-6 py-3 flex items-center justify-between gap-3 hover:bg-muted/30 transition-colors">
                <div className="space-y-0.5 min-w-0">
                  <p className="text-sm font-medium text-card-foreground truncate">{p.productName || p.strain || "Unknown Product"}</p>
                  <p className="text-xs text-muted-foreground truncate">

                    {p.brand || "Unknown Brand"}
                    {p.packageSize ? ` · ${p.packageSize}` : ""}
                    {p.productType && p.productType !== "other" ? ` · ${p.productType}` : ""}
                    {p.thc ? ` · THC ${p.thc}` : ""}
                    {p.cbd ? ` · CBD ${p.cbd}` : ""}
                    {p.description ? ` · ${p.description}` : p.details ? ` · ${p.details}` : ""}
                  </p>
                </div>
                <Badge variant="secondary" className="bg-muted text-muted-foreground text-[10px]">Ready</Badge>
              </div>
            ))}
          </div>
        </motion.div>
      )}
    </div>
  );
};

export default BulkIntake;
