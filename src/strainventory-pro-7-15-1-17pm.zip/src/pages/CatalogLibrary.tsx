import { useState, useMemo, useEffect, useCallback, Fragment } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { motion } from "framer-motion";
import { Search, CheckSquare, Loader2, ChevronLeft, ChevronRight, ChevronsLeft, ChevronsRight, ArrowUpDown, ArrowUp, ArrowDown, DollarSign, Check, X, PackageCheck, PackageX, AlertTriangle, Minus, Plus, Trash2, CalendarClock } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { cn } from "@/lib/utils";
import { PRODUCT_TYPES } from "@/lib/constants";
import { useProducts, type Product } from "@/hooks/useProducts";
import { supabase } from "@/integrations/supabase/client";
import { useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { format } from "date-fns";
import { formatDisplayNumber } from "@/lib/posPricing";
import { resolveProductPricing } from "@/lib/discounts/productPrice";

const statusStyles: Record<string, string> = {
  draft: "bg-muted text-muted-foreground",
  review: "bg-warning/15 text-warning",
  approved: "bg-accent/20 text-accent-foreground",
  published: "bg-success/15 text-success",
};

const statusOptions = ["draft", "review", "approved", "published"];
const filters = ["All", ...PRODUCT_TYPES];
const pageSizeOptions = ["10", "25", "50", "100"];

type SortKey = "name" | "brand" | "confidence" | "status" | "updated_at" | "price" | "quantity";

const LOW_STOCK_THRESHOLD = 10;

const getSortValue = (product: Product, key: SortKey): string | number => {
  switch (key) {
    case "name":
      return product.name;
    case "brand":
      return product.brand;
    case "confidence":
      return product.confidence;
    case "status":
      return product.status;
    case "updated_at":
      return product.updated_at;
    case "price":
      return product.price;
    case "quantity":
      return product.quantity;
  }
};

const SortIcon = ({ active, dir }: { active: boolean; dir: "asc" | "desc" }) => {
  if (!active) return <ArrowUpDown className="h-3 w-3 opacity-40" />;
  return dir === "asc" ? <ArrowUp className="h-3 w-3" /> : <ArrowDown className="h-3 w-3" />;
};

/* Inline price editor */
const InlinePriceEditor = ({ productId, currentPrice }: { productId: string; currentPrice: number }) => {
  const [editing, setEditing] = useState(false);
  const [value, setValue] = useState(String(currentPrice || ""));
  const [saving, setSaving] = useState(false);
  const queryClient = useQueryClient();

  const save = useCallback(async () => {
    const num = parseFloat(value);
    if (isNaN(num) || num < 0) { toast.error("Invalid price"); return; }
    setSaving(true);
    const { error } = await supabase
      .from("products")
      .update({ price: num, updated_at: new Date().toISOString() })
      .eq("id", productId);
    setSaving(false);
    if (error) { toast.error("Failed to update price"); return; }
    queryClient.invalidateQueries({ queryKey: ["products"] });
    toast.success("Price updated");
    setEditing(false);
  }, [value, productId, queryClient]);

  if (editing) {
    return (
      <div className="flex items-center gap-1" onClick={(e) => e.stopPropagation()}>
        <span className="text-xs text-muted-foreground">$</span>
        <Input
          value={value}
          onChange={(e) => setValue(e.target.value)}
          className="h-7 w-20 text-xs tabular-nums"
          autoFocus
          onKeyDown={(e) => { if (e.key === "Enter") save(); if (e.key === "Escape") setEditing(false); }}
        />
        <button onClick={save} disabled={saving} className="text-success hover:text-success/80 p-0.5">
          {saving ? <Loader2 className="h-3 w-3 animate-spin" /> : <Check className="h-3 w-3" />}
        </button>
        <button onClick={() => setEditing(false)} className="text-muted-foreground hover:text-foreground p-0.5">
          <X className="h-3 w-3" />
        </button>
      </div>
    );
  }

  return (
    <button
      onClick={(e) => { e.stopPropagation(); setValue(String(currentPrice || "")); setEditing(true); }}
      className="text-sm tabular-nums text-foreground hover:text-accent transition-colors flex items-center gap-0.5"
    >
      <DollarSign className="h-3 w-3 text-muted-foreground" />
      {currentPrice > 0 ? currentPrice.toFixed(2) : "—"}
    </button>
  );
};

/* Inline quantity editor */
const InlineQuantityEditor = ({ productId, currentQty, inStock }: { productId: string; currentQty: number; inStock: boolean }) => {
  const [saving, setSaving] = useState(false);
  const [value, setValue] = useState(formatDisplayNumber(currentQty));
  const queryClient = useQueryClient();

  useEffect(() => {
    setValue(formatDisplayNumber(currentQty));
  }, [currentQty]);

  const saveQty = useCallback(async (nextValue: string) => {
    const parsed = Number.parseFloat(nextValue);
    if (!Number.isFinite(parsed) || parsed < 0) {
      toast.error("Invalid quantity");
      setValue(formatDisplayNumber(currentQty));
      return;
    }

    const newQty = Math.round(parsed * 100) / 100;
    setSaving(true);
    const { error } = await supabase
      .from("products")
      .update({ quantity: newQty, in_stock: newQty > 0, updated_at: new Date().toISOString() })
      .eq("id", productId);
    setSaving(false);
    if (error) {
      toast.error("Failed to update quantity");
      setValue(formatDisplayNumber(currentQty));
      return;
    }
    setValue(formatDisplayNumber(newQty));
    queryClient.invalidateQueries({ queryKey: ["products"] });
  }, [currentQty, productId, queryClient]);

  const updateQty = useCallback(async (newQty: number) => {
    if (newQty < 0) return;
    await saveQty(String(Math.round(newQty * 100) / 100));
  }, [saveQty]);

  const isLow = currentQty > 0 && currentQty <= LOW_STOCK_THRESHOLD;
  const isOut = currentQty <= 0 || !inStock;

  return (
    <div className="flex items-center gap-1.5" onClick={(e) => e.stopPropagation()}>
      <button
        onClick={() => updateQty(Math.max(0, currentQty - 1))}
        disabled={saving || currentQty <= 0}
        className="h-6 w-6 rounded-md border border-border flex items-center justify-center text-muted-foreground hover:bg-muted transition-colors disabled:opacity-30"
      >
        <Minus className="h-3 w-3" />
      </button>
      <div className="relative">
        <Input
          type="number"
          min="0"
          step="0.01"
          value={value}
          onChange={(e) => setValue(e.target.value)}
          onBlur={() => void saveQty(value)}
          onKeyDown={(e) => {
            if (e.key === "Enter") {
              void saveQty(value);
            }
            if (e.key === "Escape") {
              setValue(formatDisplayNumber(currentQty));
            }
          }}
          className={cn(
            "h-7 w-20 px-2 text-center text-sm tabular-nums",
            isOut && "text-destructive",
            isLow && !isOut && "text-warning",
            !isLow && !isOut && "text-foreground",
          )}
        />
        {saving && (
          <Loader2 className="pointer-events-none absolute right-2 top-2 h-3 w-3 animate-spin text-muted-foreground" />
        )}
      </div>
      <button
        onClick={() => updateQty(currentQty + 1)}
        disabled={saving}
        className="h-6 w-6 rounded-md border border-border flex items-center justify-center text-muted-foreground hover:bg-muted transition-colors disabled:opacity-30"
      >
        <Plus className="h-3 w-3" />
      </button>
      {isOut && (
        <Badge variant="secondary" className="text-[9px] gap-0.5 bg-destructive/10 text-destructive border-destructive/20 ml-1">
          <PackageX className="h-2.5 w-2.5" /> Out
        </Badge>
      )}
      {isLow && !isOut && (
        <Badge variant="secondary" className="text-[9px] gap-0.5 bg-warning/10 text-warning border-warning/20 ml-1">
          <AlertTriangle className="h-2.5 w-2.5" /> Low
        </Badge>
      )}
      {!isLow && !isOut && (
        <Badge variant="secondary" className="text-[9px] gap-0.5 bg-success/10 text-success border-success/20 ml-1">
          <PackageCheck className="h-2.5 w-2.5" /> OK
        </Badge>
      )}
    </div>
  );
};

/* Inline expiration date editor */
const InlineExpirationEditor = ({ productId, currentDate }: { productId: string; currentDate: string | null }) => {
  const [saving, setSaving] = useState(false);
  const [value, setValue] = useState(currentDate ? currentDate.slice(0, 10) : "");
  const queryClient = useQueryClient();

  useEffect(() => {
    setValue(currentDate ? currentDate.slice(0, 10) : "");
  }, [currentDate]);

  const save = useCallback(async (next: string) => {
    const normalized = next || null;
    if ((currentDate ? currentDate.slice(0, 10) : "") === (normalized ?? "")) return;
    setSaving(true);
    const { error } = await supabase
      .from("products")
      .update({ expiration_date: normalized, updated_at: new Date().toISOString() })
      .eq("id", productId);
    setSaving(false);
    if (error) {
      toast.error("Failed to update expiration date");
      setValue(currentDate ? currentDate.slice(0, 10) : "");
      return;
    }
    queryClient.invalidateQueries({ queryKey: ["products"] });
  }, [currentDate, productId, queryClient]);

  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const exp = value ? new Date(value + "T00:00:00") : null;
  const daysLeft = exp ? Math.round((exp.getTime() - today.getTime()) / 86400000) : null;
  const isExpired = daysLeft !== null && daysLeft < 0;
  const isSoon = daysLeft !== null && daysLeft >= 0 && daysLeft <= 14;

  return (
    <div className="flex items-center gap-1.5" onClick={(e) => e.stopPropagation()}>
      <div className="relative">
        <Input
          type="date"
          value={value}
          onChange={(e) => setValue(e.target.value)}
          onBlur={() => void save(value)}
          onKeyDown={(e) => {
            if (e.key === "Enter") void save(value);
            if (e.key === "Escape") setValue(currentDate ? currentDate.slice(0, 10) : "");
          }}
          className={cn(
            "h-7 w-36 px-2 text-xs tabular-nums",
            isExpired && "text-destructive border-destructive/40",
            isSoon && "text-warning border-warning/40",
          )}
        />
        {saving && (
          <Loader2 className="pointer-events-none absolute right-2 top-2 h-3 w-3 animate-spin text-muted-foreground" />
        )}
      </div>
      {isExpired && (
        <Badge variant="secondary" className="text-[9px] gap-0.5 bg-destructive/10 text-destructive border-destructive/20">
          Expired
        </Badge>
      )}
      {isSoon && (
        <Badge variant="secondary" className="text-[9px] gap-0.5 bg-warning/10 text-warning border-warning/20">
          {daysLeft}d
        </Badge>
      )}
    </div>
  );
};

const CatalogLibrary = () => {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const [activeFilter, setActiveFilter] = useState("All");
  const [search, setSearch] = useState(searchParams.get("search") || "");
  const [debouncedSearch, setDebouncedSearch] = useState(search);
  const { data: products = [], isLoading } = useProducts();
  const queryClient = useQueryClient();

  useEffect(() => {
    const timerId = window.setTimeout(() => setDebouncedSearch(search), 250);
    return () => window.clearTimeout(timerId);
  }, [search]);

  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [bulkStatus, setBulkStatus] = useState<string>("");
  const [bulkUpdating, setBulkUpdating] = useState(false);
  const [bulkDeleting, setBulkDeleting] = useState(false);
  const [bulkExpiration, setBulkExpiration] = useState<string>("");
  const [bulkExpUpdating, setBulkExpUpdating] = useState(false);
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(25);
  const [sortKey, setSortKey] = useState<SortKey | null>(null);
  const [sortDir, setSortDir] = useState<"asc" | "desc">("asc");

  const handleSort = (key: SortKey) => {
    if (sortKey === key) setSortDir((d) => (d === "asc" ? "desc" : "asc"));
    else { setSortKey(key); setSortDir("asc"); }
    setPage(1);
  };

  const filtered = useMemo(() => {
    const lowerSearch = debouncedSearch.toLowerCase();
    let result = products.filter((p) => {
      const lowerFilter = activeFilter.toLowerCase();
      const matchFilter = activeFilter === "All" || p.product_type === activeFilter || p.type?.toLowerCase() === lowerFilter;
      const matchSearch = !lowerSearch || p.name.toLowerCase().includes(lowerSearch) || p.brand.toLowerCase().includes(lowerSearch);
      return matchFilter && matchSearch;
    });
    if (sortKey) {
      result = [...result].sort((a, b) => {
        const av = getSortValue(a, sortKey);
        const bv = getSortValue(b, sortKey);
        if (sortKey === "confidence" || sortKey === "price" || sortKey === "quantity") {
          return sortDir === "asc" ? (Number(av) || 0) - (Number(bv) || 0) : (Number(bv) || 0) - (Number(av) || 0);
        }
        if (sortKey === "updated_at") {
          return sortDir === "asc" ? new Date(av).getTime() - new Date(bv).getTime() : new Date(bv).getTime() - new Date(av).getTime();
        }
        const as = String(av).toLowerCase();
        const bs = String(bv).toLowerCase();
        return sortDir === "asc" ? as.localeCompare(bs) : bs.localeCompare(as);
      });
    } else {
      // Default: group by product type, alphabetical within each group
      result = [...result].sort((a, b) => {
        const at = String(a.product_type || a.type || "Zzz").toLowerCase();
        const bt = String(b.product_type || b.type || "Zzz").toLowerCase();
        if (at !== bt) return at.localeCompare(bt);
        return a.name.toLowerCase().localeCompare(b.name.toLowerCase());
      });
    }
    return result;
  }, [products, activeFilter, debouncedSearch, sortKey, sortDir]);

  const totalPages = Math.max(1, Math.ceil(filtered.length / pageSize));
  const safePage = Math.min(page, totalPages);
  const paginatedProducts = useMemo(
    () => filtered.slice((safePage - 1) * pageSize, safePage * pageSize),
    [filtered, safePage, pageSize],
  );

  const handleFilterChange = (f: string) => { setActiveFilter(f); setPage(1); };
  const handleSearchChange = (v: string) => { setSearch(v); setPage(1); };
  const handlePageSizeChange = (v: string) => { setPageSize(Number(v)); setPage(1); };

  const toggleSelect = (id: string) => {
    setSelected((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  };

  const toggleAll = () => {
    if (selected.size === paginatedProducts.length && paginatedProducts.every((p) => selected.has(p.id))) {
      setSelected(new Set());
    } else {
      setSelected(new Set(paginatedProducts.map((p) => p.id)));
    }
  };

  const handleInlineStatusUpdate = async (productId: string, newStatus: string) => {
    const { error } = await supabase
      .from("products")
      .update({ status: newStatus, updated_at: new Date().toISOString() })
      .eq("id", productId);
    if (error) { toast.error("Status update failed: " + error.message); return; }
    queryClient.invalidateQueries({ queryKey: ["products"] });
    toast.success(`Status updated to "${newStatus}".`);
  };




  const handleBulkStatusUpdate = async () => {
    if (!bulkStatus || selected.size === 0) return;
    setBulkUpdating(true);
    const ids = Array.from(selected);
    const { error } = await supabase
      .from("products")
      .update({ status: bulkStatus, updated_at: new Date().toISOString() })
      .in("id", ids);
    setBulkUpdating(false);
    if (error) { toast.error("Bulk update failed: " + error.message); return; }
    queryClient.invalidateQueries({ queryKey: ["products"] });
    toast.success(`Updated ${ids.length} product(s) to "${bulkStatus}".`);
    setSelected(new Set());
    setBulkStatus("");
  };

  const handleBulkDelete = async () => {
    if (selected.size === 0) return;
    setBulkDeleting(true);
    const ids = Array.from(selected);
    const { error } = await supabase
      .from("products")
      .delete()
      .in("id", ids);
    setBulkDeleting(false);
    if (error) { toast.error("Bulk delete failed: " + error.message); return; }
    queryClient.invalidateQueries({ queryKey: ["products"] });
    toast.success(`Deleted ${ids.length} product(s).`);
    setSelected(new Set());
    setBulkStatus("");
  };

  const undoBulkExpiration = useCallback(async (
    snapshot: Array<{ id: string; expiration_date: string | null }>,
  ) => {
    if (snapshot.length === 0) return;
    // Group by previous value so we can do at most N grouped updates.
    const groups = new Map<string | null, string[]>();
    for (const row of snapshot) {
      const key = row.expiration_date;
      const arr = groups.get(key) ?? [];
      arr.push(row.id);
      groups.set(key, arr);
    }
    const nowIso = new Date().toISOString();
    let failures = 0;
    for (const [value, ids] of groups) {
      const { error } = await supabase
        .from("products")
        .update({ expiration_date: value, updated_at: nowIso })
        .in("id", ids);
      if (error) failures += ids.length;
    }
    queryClient.invalidateQueries({ queryKey: ["products"] });
    if (failures > 0) {
      toast.error(`Undo failed for ${failures} product(s).`);
    } else {
      toast.success(`Reverted expiration on ${snapshot.length} product(s).`);
    }
  }, [queryClient]);

  const handleBulkExpirationUpdate = async (clear: boolean) => {
    if (selected.size === 0) return;
    if (!clear && !bulkExpiration) {
      toast.error("Pick a date or choose clear");
      return;
    }
    setBulkExpUpdating(true);
    const ids = Array.from(selected);
    const idSet = new Set(ids);
    const snapshot = products
      .filter((p) => idSet.has(p.id))
      .map((p) => ({
        id: p.id,
        expiration_date:
          (p as Product & { expiration_date?: string | null }).expiration_date ?? null,
      }));
    const { error } = await supabase
      .from("products")
      .update({ expiration_date: clear ? null : bulkExpiration, updated_at: new Date().toISOString() })
      .in("id", ids);
    setBulkExpUpdating(false);
    if (error) { toast.error("Bulk expiration update failed: " + error.message); return; }
    queryClient.invalidateQueries({ queryKey: ["products"] });
    const summary = clear
      ? `Cleared expiration on ${ids.length} product(s).`
      : `Set expiration to ${bulkExpiration} on ${ids.length} product(s).`;
    toast.success(summary, {
      duration: 12000,
      action: {
        label: "Undo",
        onClick: () => { void undoBulkExpiration(snapshot); },
      },
    });
    setSelected(new Set());
    setBulkExpiration("");
  };

  const allPageSelected = paginatedProducts.length > 0 && paginatedProducts.every((p) => selected.has(p.id));

  const thClass = "px-4 py-3 text-left text-[10px] font-semibold uppercase tracking-widest text-muted-foreground";
  const sortableThClass = cn(thClass, "cursor-pointer select-none hover:text-foreground transition-colors");

  return (
    <div className="p-4 sm:p-6 lg:p-10 max-w-7xl mx-auto">
      <motion.div initial={{ opacity: 0, y: -8 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }} className="mb-6 sm:mb-8 flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
        <div className="flex items-center gap-3 sm:gap-4">
          <div className="flex h-11 w-11 sm:h-12 sm:w-12 items-center justify-center rounded-2xl bg-gradient-to-br from-accent to-accent/70 shadow-soft ring-1 ring-accent/40">
            <PackageCheck className="h-5 w-5 sm:h-6 sm:w-6 text-accent-foreground" />
          </div>
          <div>
            <h1 className="text-display text-3xl sm:text-4xl font-bold tracking-tight text-foreground">Catalog Library</h1>
            <p className="text-sm sm:text-base text-muted-foreground mt-1">Every entry, indexed and ready for reuse.</p>
          </div>
        </div>
        <div className="self-start sm:self-auto inline-flex items-center gap-2 rounded-full border-2 border-border bg-card px-3 py-1.5 text-xs font-semibold text-muted-foreground shadow-soft">
          <span className="h-1.5 w-1.5 rounded-full bg-success animate-pulse" />
          {filtered.length.toLocaleString()} products
        </div>
      </motion.div>

      <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.4, delay: 0.1 }} className="mb-6 space-y-4">
        <div className="relative w-full max-w-md">
          <Search className="absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input placeholder="Search products or brands…" value={search} onChange={(e) => handleSearchChange(e.target.value)} className="pl-10 h-12 bg-card border-2 border-border font-medium shadow-soft focus-visible:border-accent" />
        </div>
        <div className="flex flex-wrap gap-1.5 sm:gap-2">
          {filters.map((f) => (
            <Button
              key={f}
              variant={activeFilter === f ? "gold" : "outline"}
              size="sm"
              onClick={() => handleFilterChange(f)}
              className={cn(
                "rounded-full text-xs px-3.5 sm:px-4 font-semibold border-2 transition-all",
                activeFilter !== f && "hover:border-foreground/40 hover:bg-muted/40",
              )}
            >
              {f}
            </Button>
          ))}
        </div>
      </motion.div>

      {/* Bulk action bar */}
      {selected.size > 0 && (
        <motion.div initial={{ opacity: 0, y: -8 }} animate={{ opacity: 1, y: 0 }} className="mb-4 rounded-xl border border-accent/30 bg-accent/5 p-3 sm:p-4 flex flex-col sm:flex-row flex-wrap items-start sm:items-center gap-2 sm:gap-3">
          <div className="flex items-center gap-2">
            <CheckSquare className="h-4 w-4 text-accent" />
            <span className="text-sm font-medium text-foreground">{selected.size} selected</span>
          </div>
          <Select value={bulkStatus} onValueChange={setBulkStatus}>
            <SelectTrigger className="w-[140px] h-9 text-xs bg-card"><SelectValue placeholder="Set status…" /></SelectTrigger>
            <SelectContent>
              {statusOptions.map((s) => (
                <SelectItem key={s} value={s} className="text-xs capitalize">{s}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Button variant="gold" size="sm" disabled={!bulkStatus || bulkUpdating} onClick={handleBulkStatusUpdate} className="gap-1.5">
            {bulkUpdating ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : null}
            Apply
          </Button>
          <div className="flex items-center gap-1.5 pl-1 sm:pl-2 sm:border-l sm:border-border/60">
            <CalendarClock className="h-4 w-4 text-muted-foreground" />
            <Input
              type="date"
              value={bulkExpiration}
              onChange={(e) => setBulkExpiration(e.target.value)}
              className="h-9 w-[150px] text-xs bg-card"
              aria-label="Bulk expiration date"
            />
            <Button
              variant="gold"
              size="sm"
              disabled={!bulkExpiration || bulkExpUpdating}
              onClick={() => handleBulkExpirationUpdate(false)}
              className="gap-1.5"
            >
              {bulkExpUpdating ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : null}
              Set expiration
            </Button>
            <Button
              variant="outline"
              size="sm"
              disabled={bulkExpUpdating}
              onClick={() => handleBulkExpirationUpdate(true)}
            >
              Clear
            </Button>
          </div>
          <AlertDialog>
            <AlertDialogTrigger asChild>
              <Button variant="destructive" size="sm" className="gap-1.5" disabled={bulkDeleting}>
                {bulkDeleting ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Trash2 className="h-3.5 w-3.5" />}
                Delete
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Delete {selected.size} product{selected.size !== 1 ? "s" : ""}?</AlertDialogTitle>
                <AlertDialogDescription>
                  This action cannot be undone. The selected product{selected.size !== 1 ? "s" : ""} will be permanently removed from the catalog.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>Cancel</AlertDialogCancel>
                <AlertDialogAction onClick={handleBulkDelete} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
                  Delete
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
          <Button variant="ghost" size="sm" onClick={() => { setSelected(new Set()); setBulkStatus(""); setBulkExpiration(""); }}>Clear</Button>
        </motion.div>
      )}

      <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.4, delay: 0.2 }} className="rounded-2xl border-2 border-border bg-card shadow-elevated overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b-2 border-border bg-muted/40">

                <th className="px-4 py-3 w-10">
                  <Checkbox checked={allPageSelected} onCheckedChange={toggleAll} aria-label="Select all on page" />
                </th>
                <th className={sortableThClass} onClick={() => handleSort("name")}>
                  <span className="inline-flex items-center gap-1">Product <SortIcon active={sortKey === "name"} dir={sortDir} /></span>
                </th>
                <th className={sortableThClass} onClick={() => handleSort("brand")}>
                  <span className="inline-flex items-center gap-1">Brand <SortIcon active={sortKey === "brand"} dir={sortDir} /></span>
                </th>
                <th className={thClass}>Product Type</th>
                <th className={sortableThClass} onClick={() => handleSort("price")}>
                  <span className="inline-flex items-center gap-1">Price / g <SortIcon active={sortKey === "price"} dir={sortDir} /></span>
                </th>
                <th className={sortableThClass} onClick={() => handleSort("quantity")}>
                  <span className="inline-flex items-center gap-1">Stock <SortIcon active={sortKey === "quantity"} dir={sortDir} /></span>
                </th>
                <th className={thClass}>THC</th>
                <th className={sortableThClass} onClick={() => handleSort("confidence")}>
                  <span className="inline-flex items-center gap-1">Confidence <SortIcon active={sortKey === "confidence"} dir={sortDir} /></span>
                </th>
                <th className={sortableThClass} onClick={() => handleSort("status")}>
                  <span className="inline-flex items-center gap-1">Status <SortIcon active={sortKey === "status"} dir={sortDir} /></span>
                </th>
                <th className={sortableThClass} onClick={() => handleSort("updated_at")}>
                  <span className="inline-flex items-center gap-1">Updated <SortIcon active={sortKey === "updated_at"} dir={sortDir} /></span>
                </th>
                <th className={thClass}>Expires</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {paginatedProducts.map((product, idx) => {
                const price = Number(product.price) || 0;
                const quantity = Number(product.quantity) || 0;
                const groupLabel = String(product.product_type || product.type || "Other");
                const prev = idx > 0 ? paginatedProducts[idx - 1] : null;
                const prevLabel = prev ? String(prev.product_type || prev.type || "Other") : null;
                const showGroupHeader = !sortKey && groupLabel !== prevLabel;
                const inStock = product.in_stock !== false;
                const shelf = resolveProductPricing(product, new Date());
                const showClearanceTag = shelf.clearance;
                const showSaleTag = shelf.sale && !shelf.clearance;
                return (
                  <Fragment key={product.id}>
                    {showGroupHeader && (
                      <tr className="bg-muted/50 border-y-2 border-border">
                        <td colSpan={11} className="px-4 py-2.5 text-[11px] font-bold uppercase tracking-widest text-foreground">
                          <span className="inline-flex items-center gap-2">
                            <span className="h-1.5 w-1.5 rounded-full bg-accent" />
                            {groupLabel}
                          </span>
                        </td>
                      </tr>
                    )}
                  <tr className={cn("transition-colors hover:bg-muted/20 cursor-pointer", selected.has(product.id) && "bg-accent/5")}>
                    <td className="px-4 py-4" onClick={(e) => e.stopPropagation()}>
                      <Checkbox checked={selected.has(product.id)} onCheckedChange={() => toggleSelect(product.id)} aria-label={`Select ${product.name}`} />
                    </td>
                    <td className="px-4 py-4 text-sm font-medium text-card-foreground" onClick={() => navigate(`/catalog/${product.id}`)}>
                      <div className="flex flex-col gap-1">
                        <span>{product.name}</span>
                        {(showClearanceTag || showSaleTag) && (
                          <div className="flex flex-wrap gap-1">
                            {showClearanceTag && (
                              <Badge variant="destructive" className="h-5 w-fit px-1.5 py-0 text-[9px] font-medium">
                                Clearance
                              </Badge>
                            )}
                            {showSaleTag && (
                              <Badge variant="secondary" className="h-5 w-fit border border-accent/30 bg-accent/15 px-1.5 py-0 text-[9px] font-medium text-accent">
                                Sale
                              </Badge>
                            )}
                          </div>
                        )}
                      </div>
                    </td>
                    <td className="px-4 py-4 text-sm text-muted-foreground" onClick={() => navigate(`/catalog/${product.id}`)}>{product.brand}</td>
                    <td className="px-4 py-4" onClick={() => navigate(`/catalog/${product.id}`)}>
                      {product.product_type ? (
                        <Badge variant="secondary" className="text-[10px] uppercase tracking-wider font-medium bg-accent/10 text-accent-foreground">
                          {product.product_type}
                        </Badge>
                      ) : (
                        <span className="text-sm text-muted-foreground">{product.type || "—"}</span>
                      )}
                    </td>
                    <td className="px-4 py-4">
                      <InlinePriceEditor productId={product.id} currentPrice={price} />
                    </td>
                    <td className="px-4 py-4">
                      <InlineQuantityEditor productId={product.id} currentQty={quantity} inStock={inStock} />
                    </td>
                    <td className="px-4 py-4 text-sm tabular-nums text-muted-foreground" onClick={() => navigate(`/catalog/${product.id}`)}>{product.thc}</td>
                    <td className="px-4 py-4" onClick={() => navigate(`/catalog/${product.id}`)}>
                      <div className="flex items-center gap-2">
                        <div className="h-1.5 w-16 rounded-full bg-muted overflow-hidden">
                          <div className={cn("h-full rounded-full", product.confidence >= 90 ? "bg-success" : product.confidence >= 75 ? "bg-accent" : "bg-warning")} style={{ width: `${product.confidence}%` }} />
                        </div>
                        <span className="text-xs tabular-nums text-muted-foreground">{product.confidence}%</span>
                      </div>
                    </td>
                    <td className="px-4 py-4" onClick={(e) => e.stopPropagation()}>
                      <Popover>
                        <PopoverTrigger asChild>
                          <button className="focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-1 rounded-full">
                            <Badge variant="secondary" className={cn("text-[10px] uppercase tracking-wider font-medium cursor-pointer hover:ring-2 hover:ring-ring/30 transition-all", statusStyles[product.status])}>{product.status}</Badge>
                          </button>
                        </PopoverTrigger>
                        <PopoverContent className="w-36 p-1" align="start">
                          {statusOptions.map((s) => (
                            <button
                              key={s}
                              onClick={() => handleInlineStatusUpdate(product.id, s)}
                              className={cn("w-full text-left px-3 py-1.5 text-xs capitalize rounded-sm transition-colors hover:bg-muted", product.status === s && "font-semibold bg-muted/50")}
                            >
                              <Badge variant="secondary" className={cn("text-[10px] uppercase tracking-wider font-medium", statusStyles[s])}>{s}</Badge>
                            </button>
                          ))}
                        </PopoverContent>
                      </Popover>
                    </td>
                    <td className="px-4 py-4 text-xs text-muted-foreground" onClick={() => navigate(`/catalog/${product.id}`)}>{format(new Date(product.updated_at), "MMM d")}</td>
                    <td className="px-4 py-4">
                      <InlineExpirationEditor productId={product.id} currentDate={(product as Product & { expiration_date?: string | null }).expiration_date ?? null} />
                    </td>
                  </tr>
                  </Fragment>
                );
              })}
            </tbody>
          </table>
        </div>

        {/* Pagination controls */}
        {!isLoading && filtered.length > 0 && (
          <div className="border-t border-border px-3 sm:px-6 py-3 flex flex-col sm:flex-row items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <span className="text-xs text-muted-foreground">Rows per page</span>
              <Select value={String(pageSize)} onValueChange={handlePageSizeChange}>
                <SelectTrigger className="w-[70px] h-8 text-xs bg-background"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {pageSizeOptions.map((s) => (
                    <SelectItem key={s} value={s} className="text-xs">{s}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <span className="text-xs text-muted-foreground ml-2">
                {((safePage - 1) * pageSize) + 1}–{Math.min(safePage * pageSize, filtered.length)} of {filtered.length}
              </span>
            </div>
            <div className="flex items-center gap-1">
              <Button variant="ghost" size="icon" className="h-8 w-8" disabled={safePage <= 1} onClick={() => setPage(1)}><ChevronsLeft className="h-4 w-4" /></Button>
              <Button variant="ghost" size="icon" className="h-8 w-8" disabled={safePage <= 1} onClick={() => setPage((p) => Math.max(1, p - 1))}><ChevronLeft className="h-4 w-4" /></Button>
              <span className="text-xs text-muted-foreground px-2 tabular-nums">Page {safePage} of {totalPages}</span>
              <Button variant="ghost" size="icon" className="h-8 w-8" disabled={safePage >= totalPages} onClick={() => setPage((p) => Math.min(totalPages, p + 1))}><ChevronRight className="h-4 w-4" /></Button>
              <Button variant="ghost" size="icon" className="h-8 w-8" disabled={safePage >= totalPages} onClick={() => setPage(totalPages)}><ChevronsRight className="h-4 w-4" /></Button>
            </div>
          </div>
        )}

        {!isLoading && filtered.length === 0 && (
          <div className="px-6 py-16 text-center">
            <p className="text-sm text-muted-foreground">No products found. Try adjusting your search or filters.</p>
          </div>
        )}
        {isLoading && (
          <div className="px-6 py-16 text-center">
            <p className="text-sm text-muted-foreground">Loading products…</p>
          </div>
        )}
      </motion.div>
    </div>
  );
};

export default CatalogLibrary;
