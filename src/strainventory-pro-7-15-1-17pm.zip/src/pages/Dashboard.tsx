import { useMemo } from "react";
import { DollarSign, Package, TrendingUp, Users, Wallet } from "lucide-react";
import { useProducts } from "@/hooks/useProducts";
import { useTodaysSales } from "@/hooks/useTodaysSales";
import { useWeeklyStrainPerformance } from "@/hooks/useWeeklyStrainPerformance";
import { useActiveEmployees } from "@/hooks/useActiveEmployees";
import { useAuth } from "@/context/AuthContext";
import { useProfileMap } from "@/hooks/useProfiles";
import MetricCard from "@/components/dashboard/MetricCard";
import DashboardHeader from "@/components/dashboard/DashboardHeader";
import LiveInventoryCard from "@/components/dashboard/LiveInventoryCard";
import TodaysSalesCard from "@/components/dashboard/TodaysSalesCard";
import TeamOnDutyCard from "@/components/dashboard/TeamOnDutyCard";
import WeeklyStrainPerformancePanel from "@/components/dashboard/WeeklyStrainPerformancePanel";
import {
  formatCompactNumber,
  formatWholeCurrency,
} from "@/lib/dashboard/formatters";

const LOW_STOCK_THRESHOLD = 10;

const Dashboard = () => {
  const { user } = useAuth();
  const profileMap = useProfileMap();
  const { data: products = [] } = useProducts();
  const { data: todaysSales } = useTodaysSales();
  const { data: weeklyPerformance, isLoading: isWeeklyLoading } = useWeeklyStrainPerformance();
  const { data: activeEmployees = [] } = useActiveEmployees();

  const metrics = useMemo(() => {
    const lowStock = products.filter(
      (p) => (p.quantity ?? 0) <= LOW_STOCK_THRESHOLD && p.in_stock,
    ).length;
    const totalValue = products.reduce(
      (sum, p) => sum + (p.quantity ?? 0) * (Number(p.price) || 0),
      0,
    );
    return {
      revenue: todaysSales?.revenue ?? 0,
      avgTicket: todaysSales?.avgTicket ?? 0,
      lowStock,
      totalValue: Math.round(totalValue),
      activeStaff: activeEmployees.length,
    };
  }, [products, todaysSales, activeEmployees]);

  const topStrains = todaysSales?.topStrains ?? [];
  const displayName = user?.email?.split("@")[0] || "Team";

  return (
    <div className="p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto">
      <DashboardHeader displayName={displayName} />

      <div className="grid grid-cols-2 md:grid-cols-3 2xl:grid-cols-5 gap-3 sm:gap-4 mb-6 sm:mb-8">
        <MetricCard label="Today's Revenue" value={formatWholeCurrency(metrics.revenue)} icon={DollarSign} accent="emerald" delay={0.02} />
        <MetricCard label="Active Staff" value={metrics.activeStaff} icon={Users} accent="gold" delay={0.06} />
        <MetricCard label="Low Stock Items" value={metrics.lowStock} icon={Package} accent="warning" delay={0.10} />
        <MetricCard label="Avg Ticket" value={formatWholeCurrency(metrics.avgTicket)} icon={TrendingUp} accent="default" delay={0.14} />
        <MetricCard label="Inventory Value" value={formatCompactNumber(metrics.totalValue)} icon={Wallet} accent="success" delay={0.18} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 mb-6">
        <div className="lg:col-span-5">
          <LiveInventoryCard products={products} lowStockThreshold={LOW_STOCK_THRESHOLD} />
        </div>
        <div className="lg:col-span-4">
          <TodaysSalesCard revenue={metrics.revenue} topStrains={topStrains} />
        </div>
        <div className="lg:col-span-3">
          <TeamOnDutyCard activeEmployees={activeEmployees} profileMap={profileMap} />
        </div>
      </div>

      <WeeklyStrainPerformancePanel
        weeklyPerformance={weeklyPerformance}
        isLoading={isWeeklyLoading}
      />
    </div>
  );
};

export default Dashboard;
