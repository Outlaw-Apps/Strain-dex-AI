import { motion, AnimatePresence } from "framer-motion";
import {
  UserPlus, Shield, ClipboardCheck, FileText, ChevronRight,
  ChevronLeft, Loader2, CheckCircle2,
} from "lucide-react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { useUserRoles } from "@/hooks/useUserRoles";
import { useEmployeeOnboarding } from "@/hooks/useEmployeeOnboarding";
import { ManagerOverrideButton } from "@/components/ui/ManagerOverrideButton";
import OnboardingStepper, { type OnboardingStep } from "@/components/onboarding/OnboardingStepper";
import StepHRBasics from "@/components/onboarding/StepHRBasics";
import StepDCCCompliance from "@/components/onboarding/StepDCCCompliance";
import StepDocsSignatures from "@/components/onboarding/StepDocsSignatures";
import OnboardingProgressPanel from "@/components/onboarding/OnboardingProgressPanel";

const STEPS: readonly OnboardingStep[] = [
  { label: "HR Basics", icon: UserPlus, description: "Personal information" },
  { label: "DCC Compliance", icon: Shield, description: "Licensing & role" },
  { label: "Docs & Signatures", icon: FileText, description: "Upload & acknowledge" },
];

const EmployeeOnboarding = () => {
  const navigate = useNavigate();
  const { isAdmin, loading: rolesLoading } = useUserRoles();
  const {
    currentStep,
    formData,
    submitting,
    submitted,
    createdEmployeeId,
    fileInputRef,
    managerOverride,
    totalSteps,
    updateField,
    getError,
    handleNext,
    handleBack,
    handleFileChange,
    handleSubmit,
    resetForm,
  } = useEmployeeOnboarding();

  if (rolesLoading) {
    return (
      <div className="p-8 flex items-center justify-center min-h-[60vh]">
        <Loader2 className="h-6 w-6 text-muted-foreground animate-spin" />
      </div>
    );
  }

  if (!isAdmin) {
    return (
      <div className="p-8 lg:p-12 flex flex-col items-center justify-center min-h-[60vh]">
        <Shield className="h-12 w-12 text-destructive mb-4" />
        <h2 className="text-xl font-semibold text-foreground mb-2">Admin Access Required</h2>
        <p className="text-muted-foreground mb-6">You don't have permission to access employee onboarding.</p>
        <Button variant="outline" onClick={() => navigate("/")}>Back to Dashboard</Button>
      </div>
    );
  }

  if (submitted) {
    return (
      <div className="p-8 lg:p-12 max-w-3xl">
        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ type: "spring", bounce: 0.25, duration: 0.5 }}
          className="flex flex-col items-center text-center mb-8"
        >
          <CheckCircle2 className="h-14 w-14 text-green-500 mb-4" />
          <h2 className="text-2xl font-semibold text-foreground mb-2">Onboarding Submitted</h2>
          <p className="text-muted-foreground mb-1 max-w-md">
            <strong>{formData.fullName}</strong> has been submitted as a{" "}
            <strong className="capitalize">{formData.role.replace("_", " ")}</strong> with status{" "}
            <em>pending review</em>.
          </p>
          <p className="text-sm text-muted-foreground">
            Their default onboarding checklist has been generated below.
          </p>
        </motion.div>

        {createdEmployeeId && (
          <div className="mb-8">
            <OnboardingProgressPanel
              employeeId={createdEmployeeId}
              employeeName={formData.fullName}
              employeeRole={formData.role}
            />
          </div>
        )}

        <div className="flex gap-3 justify-center">
          <Button variant="outline" onClick={resetForm}>
            <UserPlus className="h-4 w-4 mr-2" />
            Onboard Another
          </Button>
          <Button variant="gold" onClick={() => navigate("/")}>
            Back to Dashboard
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="p-8 lg:p-12 max-w-3xl">
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.5 }}>
        <div className="flex items-center gap-3 mb-2">
          <ClipboardCheck className="h-7 w-7 text-accent" />
          <h1 className="text-3xl font-semibold tracking-tight text-foreground">Employee Onboarding</h1>
        </div>
        <div className="flex items-center justify-between mb-8">
          <p className="text-muted-foreground text-base">
            California dispensary DCC-compliant onboarding — complete all three steps.
          </p>
          <ManagerOverrideButton override={managerOverride} />
        </div>
      </motion.div>

      <OnboardingStepper steps={STEPS} currentStep={currentStep} />

      <AnimatePresence mode="wait">
        <motion.div
          key={currentStep}
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -20 }}
          transition={{ duration: 0.3 }}
        >
          <Card className="shadow-soft">
            <CardContent className="p-6 space-y-5">
              {currentStep === 0 && (
                <StepHRBasics formData={formData} updateField={updateField} getError={getError} />
              )}
              {currentStep === 1 && (
                <StepDCCCompliance formData={formData} updateField={updateField} getError={getError} />
              )}
              {currentStep === 2 && (
                <StepDocsSignatures
                  formData={formData}
                  updateField={updateField}
                  getError={getError}
                  fileInputRef={fileInputRef}
                  onFileChange={handleFileChange}
                />
              )}
            </CardContent>
          </Card>
        </motion.div>
      </AnimatePresence>

      <div className="flex items-center justify-between mt-6">
        <Button variant="outline" onClick={handleBack} disabled={currentStep === 0} className="gap-2">
          <ChevronLeft className="h-4 w-4" />
          Back
        </Button>

        <div className="flex gap-3">
          {currentStep < totalSteps - 1 ? (
            <Button variant="gold" onClick={handleNext} className="gap-2">
              Next
              <ChevronRight className="h-4 w-4" />
            </Button>
          ) : (
            <Button variant="gold" onClick={handleSubmit} disabled={submitting} className="gap-2">
              {submitting ? <Loader2 className="h-4 w-4 animate-spin" /> : <CheckCircle2 className="h-4 w-4" />}
              Submit Onboarding
            </Button>
          )}
        </div>
      </div>
    </div>
  );
};

export default EmployeeOnboarding;
