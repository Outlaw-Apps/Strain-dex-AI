import { useEffect } from "react";
import { Link } from "react-router-dom";
import { ArrowLeft, Database, Zap, ShieldCheck, TrendingUp } from "lucide-react";
import { Button } from "@/components/ui/button";

const TITLE = "Global Cannabis Catalog Guide: Automated Dispensary Intake | Strain-ventory";
const DESCRIPTION =
  "Learn how a global cannabis catalog powers automated dispensary intake, reduces manual entry errors, and speeds up cannabis inventory software workflows.";
const CANONICAL = "/guides/global-catalog";

const useSeo = () => {
  useEffect(() => {
    const prevTitle = document.title;
    document.title = TITLE;

    const upsertMeta = (attr: "name" | "property", key: string, content: string) => {
      let el = document.head.querySelector<HTMLMetaElement>(`meta[${attr}="${key}"]`);
      if (!el) {
        el = document.createElement("meta");
        el.setAttribute(attr, key);
        document.head.appendChild(el);
      }
      el.setAttribute("content", content);
      return el;
    };

    const desc = upsertMeta("name", "description", DESCRIPTION);
    const ogTitle = upsertMeta("property", "og:title", TITLE);
    const ogDesc = upsertMeta("property", "og:description", DESCRIPTION);
    const ogUrl = upsertMeta("property", "og:url", CANONICAL);
    const ogType = upsertMeta("property", "og:type", "article");

    let canonical = document.head.querySelector<HTMLLinkElement>('link[rel="canonical"]');
    const createdCanonical = !canonical;
    if (!canonical) {
      canonical = document.createElement("link");
      canonical.setAttribute("rel", "canonical");
      document.head.appendChild(canonical);
    }
    canonical.setAttribute("href", CANONICAL);

    const ld = document.createElement("script");
    ld.type = "application/ld+json";
    ld.text = JSON.stringify({
      "@context": "https://schema.org",
      "@type": "Article",
      headline: "Global Cannabis Catalog Guide: Automated Dispensary Intake",
      description: DESCRIPTION,
      author: { "@type": "Organization", name: "Strain-ventory" },
      mainEntityOfPage: CANONICAL,
    });
    document.head.appendChild(ld);

    return () => {
      document.title = prevTitle;
      ld.remove();
      if (createdCanonical) canonical?.remove();
      // leave meta tags in place; they'll be overwritten by next route
      void desc; void ogTitle; void ogDesc; void ogUrl; void ogType;
    };
  }, []);
};

const GlobalCatalogGuide = () => {
  useSeo();

  return (
    <div className="min-h-screen bg-background text-foreground">
      <div className="max-w-3xl mx-auto px-6 py-12">
        <Button asChild variant="ghost" size="sm" className="mb-6 gap-1.5">
          <Link to="/">
            <ArrowLeft className="h-4 w-4" /> Back
          </Link>
        </Button>

        <div className="flex items-center gap-3 mb-6">
          <div className="h-12 w-12 rounded-xl gold-gradient flex items-center justify-center shadow-gold">
            <Database className="h-6 w-6 text-accent-foreground" />
          </div>
          <div>
            <h1 className="text-display text-3xl sm:text-4xl font-semibold tracking-tight">
              The Global Cannabis Catalog Guide
            </h1>
            <p className="text-sm text-muted-foreground mt-1">
              How automated dispensary intake and cannabis inventory software eliminate
              manual data entry.
            </p>
          </div>
        </div>

        <article className="prose prose-invert max-w-none space-y-8 text-sm leading-relaxed text-muted-foreground">
          <section>
            <h2 className="text-base font-semibold text-foreground">
              What is a global cannabis catalog?
            </h2>
            <p>
              A <strong>global cannabis catalog</strong> is a shared, continuously
              maintained database of every SKU sold in the legal cannabis market —
              brands, strains, product types, package sizes, cannabinoid profiles,
              terpene percentages, and canonical imagery. Instead of every dispensary
              re-typing the same product details for the same jar of flower, the
              catalog stores one authoritative record that any retailer can pull from
              in seconds.
            </p>
            <p>
              This is the same model behind mainstream platforms like BLAZE's{" "}
              <em>global-catalog</em> support surface: a common product graph that
              turns intake from a data-entry chore into a lookup.
            </p>
          </section>

          <section>
            <h2 className="text-base font-semibold text-foreground">
              Why global catalogs matter for dispensary inventory management
            </h2>
            <ul className="space-y-3">
              <li className="flex gap-3">
                <Zap className="h-4 w-4 text-accent shrink-0 mt-0.5" />
                <span>
                  <strong className="text-foreground">Faster intake.</strong> A single
                  scan or SKU lookup hydrates name, brand, strain type, THC/CBD, net
                  weight, and product imagery — turning a 3-minute manual entry into a
                  3-second confirmation.
                </span>
              </li>
              <li className="flex gap-3">
                <ShieldCheck className="h-4 w-4 text-accent shrink-0 mt-0.5" />
                <span>
                  <strong className="text-foreground">Fewer errors.</strong> Manual
                  keying is the #1 source of mislabelled inventory, mispriced menus,
                  and compliance mismatches with state track-and-trace systems. A
                  shared catalog removes the typos entirely.
                </span>
              </li>
              <li className="flex gap-3">
                <TrendingUp className="h-4 w-4 text-accent shrink-0 mt-0.5" />
                <span>
                  <strong className="text-foreground">Consistent menus.</strong> Every
                  storefront integration — Dutchie, Leafly, Weedmaps, in-store POS —
                  reads the same normalized names and images, so customers see the
                  same product across every channel.
                </span>
              </li>
            </ul>
          </section>

          <section>
            <h2 className="text-base font-semibold text-foreground">
              How Strain-ventory automates dispensary intake
            </h2>
            <p>
              Strain-ventory is built around an AI-assisted catalog engine. When a
              new manifest arrives, staff can:
            </p>
            <ol className="list-decimal pl-5 space-y-2">
              <li>
                Scan or paste an SKU and Strain-ventory drafts the product record
                from its catalog and public sources automatically.
              </li>
              <li>
                Review AI-generated descriptions, terpene profiles, and imagery in a
                single card instead of hopping between tabs.
              </li>
              <li>
                Approve into published inventory — with pricing, labels, and
                Metrc-ready package IDs already attached.
              </li>
            </ol>
            <p>
              The result is the core promise of modern <em>cannabis inventory
              software</em>: the human stays in the loop for judgment calls, the
              machine handles the typing.
            </p>
          </section>

          <section>
            <h2 className="text-base font-semibold text-foreground">
              What to look for in a global catalog workflow
            </h2>
            <ul className="list-disc pl-5 space-y-2">
              <li>Barcode + SKU lookup that returns a fully-formed draft.</li>
              <li>Automated image assignment with a human review step.</li>
              <li>Bulk intake for full manifests, not just single jars.</li>
              <li>Structured fields for cannabinoids, terpenes, and expiration dates.</li>
              <li>Direct sync to your POS, e-commerce menu, and compliance system.</li>
            </ul>
          </section>

          <section>
            <h2 className="text-base font-semibold text-foreground">
              The bottom line
            </h2>
            <p>
              A global cannabis catalog is no longer a nice-to-have — it's the
              foundation of automated dispensary intake. Retailers that adopt a
              catalog-first workflow spend less time on data entry, ship fewer
              compliance errors, and get new drops on the menu the same day they land.
            </p>
            <p>
              Strain-ventory brings that workflow to independent dispensaries with an
              AI catalog, integrated POS, label maker, and Metrc-aware compliance
              tooling in one platform.
            </p>
          </section>

          <div className="pt-4">
            <Button asChild className="gap-2">
              <Link to="/auth">Try Strain-ventory</Link>
            </Button>
          </div>
        </article>
      </div>
    </div>
  );
};

export default GlobalCatalogGuide;
