import { memo, useCallback, useEffect, useMemo, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import {
  ArrowLeft,
  Check,
  CheckCircle2,
  Download,
  Globe,
  ImageIcon,
  Link2,
  Loader2,
  Search,
  ShieldCheck,
  Sparkles,
  Star,
  Upload,
  WandSparkles,
  X,
} from "lucide-react";
import { useNavigate } from "react-router-dom";
import { toast } from "sonner";
import WorkflowStepper from "@/components/WorkflowStepper";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useCatalogImageSearch } from "@/hooks/useCatalogImageSearch";
import {
  buildCatalogImageSearchInput,
  selectBestCatalogImage,
  syncCatalogImageToProduct,
  type CatalogImageCandidate,
} from "@/lib/catalogImages";
import { cn } from "@/lib/utils";
import { supabase } from "@/integrations/supabase/client";
import {
  useProductDraft,
  type ProductImageSearchResult,
  type SelectedImage,
} from "@/context/ProductDraftContext";
import AssignToProductDialog from "@/components/imageFinder/AssignToProductDialog";
import { downloadImage } from "@/lib/imageDownload";

interface CandidateImage extends CatalogImageCandidate {
  quality: "high" | "medium" | "low";
}

const qualityConfig = {
  high: { label: "High Res", color: "bg-success/15 text-success" },
  medium: { label: "Standard", color: "bg-accent/20 text-accent-foreground" },
  low: { label: "Low Res", color: "bg-warning/15 text-warning" },
} as const;

const sourceIcon = (source: string) => {
  if (source.toLowerCase().includes("duckduckgo")) return Search;
  if (source.toLowerCase().includes("brand")) return ShieldCheck;
  if (source.toLowerCase().includes("leafly") || source.toLowerCase().includes("weedmaps")) return Globe;
  return Sparkles;
};

const toSelectedImage = (image: CandidateImage): SelectedImage => ({
  id: image.id,
  url: image.url,
  alt: image.alt,
  quality: image.quality,
  source: image.source,
});

const toDraftSearchResult = (image: CandidateImage): ProductImageSearchResult => ({
  id: image.id,
  url: image.url,
  alt: image.alt,
  primary: false,
  quality: image.quality,
  source: image.source,
  verificationConfidence: image.verification?.confidence,
});

const toCandidateImage = (image: CatalogImageCandidate): CandidateImage => ({
  ...image,
  quality: image.width >= 1200 ? "high" : image.width >= 700 ? "medium" : "low",
});

const ImageCard = memo(({
  image,
  index,
  isPrimary,
  isAlternate,
  onSetPrimary,
  onToggleAlternate,
  onSync,
  onAssign,
  onDownload,
  canSync,
  syncing,
  showDraftActions,
}: {
  image: CandidateImage;
  index: number;
  isPrimary: boolean;
  isAlternate: boolean;
  onSetPrimary: () => void;
  onToggleAlternate: () => void;
  onSync: () => void;
  onAssign: () => void;
  onDownload: () => void;
  canSync: boolean;
  syncing: boolean;
  showDraftActions: boolean;
}) => {
  const Icon = sourceIcon(image.source);
  const quality = qualityConfig[image.quality];
  const verified = image.verification?.isMatch;

  return (
    <motion.div
      initial={{ opacity: 0, y: 14 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.08 + index * 0.04 }}
      className={cn(
        "group overflow-hidden rounded-xl border bg-card shadow-soft transition-all duration-200",
        isPrimary ? "border-accent ring-2 ring-accent/25" : "border-border hover:shadow-elevated",
        isAlternate && "border-emerald ring-1 ring-emerald/20",
      )}
    >
      <div className="relative aspect-square overflow-hidden bg-muted">
        <img src={image.url} alt={image.alt} className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105" loading="lazy" />
        <div className="absolute left-2 top-2 flex flex-col gap-1.5">
          <Badge variant="secondary" className={cn("gap-1 text-[9px] uppercase tracking-wider font-medium", quality.color)}>
            <Icon className="h-2.5 w-2.5" />
            {quality.label}
          </Badge>
          {image.verification && (
            <Badge
              variant="secondary"
              className={cn(
                "gap-1 text-[9px] uppercase tracking-wider font-medium",
                verified ? "bg-success/15 text-success" : "bg-destructive/10 text-destructive",
              )}
            >
              <ShieldCheck className="h-2.5 w-2.5" />
              {verified ? `${image.verification.confidence}% match` : "Needs review"}
            </Badge>
          )}
        </div>
        {(isPrimary || isAlternate) && showDraftActions && (
          <div className={cn("absolute right-2 top-2 flex h-7 w-7 items-center justify-center rounded-full", isPrimary ? "gold-gradient" : "emerald-gradient")}>
            <Check className="h-4 w-4 text-accent-foreground" />
          </div>
        )}
        <div className="absolute inset-0 flex items-center justify-center bg-foreground/0 opacity-0 transition-all duration-200 group-hover:bg-foreground/45 group-hover:opacity-100">
          <div className="flex flex-wrap justify-center gap-2 px-3">
            {showDraftActions && (
              <>
                <Button size="sm" variant={isPrimary ? "default" : "outline"} className="gap-1 bg-card/90 text-xs" onClick={(event) => { event.stopPropagation(); onSetPrimary(); }}>
                  <Star className="h-3 w-3" />
                  {isPrimary ? "Primary" : "Set Primary"}
                </Button>
                <Button size="sm" variant="outline" className="gap-1 bg-card/90 text-xs" onClick={(event) => { event.stopPropagation(); onToggleAlternate(); }}>
                  {isAlternate ? <X className="h-3 w-3" /> : <CheckCircle2 className="h-3 w-3" />}
                  {isAlternate ? "Remove" : "Alt"}
                </Button>
                <Button size="sm" variant="outline" className="gap-1 bg-card/90 text-xs" disabled={!canSync || syncing} onClick={(event) => { event.stopPropagation(); onSync(); }}>
                  {syncing ? <Loader2 className="h-3 w-3 animate-spin" /> : <Sparkles className="h-3 w-3" />}
                  Sync
                </Button>
              </>
            )}
            <Button size="sm" variant="gold" className="gap-1 text-xs" onClick={(event) => { event.stopPropagation(); onAssign(); }}>
              <Link2 className="h-3 w-3" />
              Assign to Product
            </Button>
            <Button size="sm" variant="outline" className="gap-1 bg-card/90 text-xs" onClick={(event) => { event.stopPropagation(); onDownload(); }}>
              <Download className="h-3 w-3" />
              Download
            </Button>
          </div>
        </div>
      </div>
      <div className="space-y-1 p-3">
        <p className="truncate text-xs font-medium text-foreground">{image.alt}</p>
        <div className="flex items-center justify-between text-[10px] text-muted-foreground">
          <span>{image.width && image.height ? `${image.width}×${image.height}` : "Unknown size"}</span>
          <span>{image.fileSize}</span>
        </div>
        {image.verification && (
          <p className="line-clamp-2 text-[10px] leading-tight text-muted-foreground">{image.verification.reason}</p>
        )}
      </div>
    </motion.div>
  );
});

ImageCard.displayName = "ImageCard";

const ImageFinder = () => {
  const navigate = useNavigate();
  const {
    product,
    setAlternateImages,
    setImageSearchResults,
    setPrimaryImage,
    setStatus,
  } = useProductDraft();
  const { intake, primaryImage, alternateImages, imageSearchResults, catalogId } = product;
  const fileInputRef = useRef<HTMLInputElement>(null);
  const searchImages = useCatalogImageSearch();

  const draftSearchInput = useMemo(() => buildCatalogImageSearchInput(intake), [intake]);
  const [search, setSearch] = useState([intake.brand, intake.strain, intake.productType].filter(Boolean).join(" ").trim());
  const [searched, setSearched] = useState(imageSearchResults.length > 0);
  const [remoteImages, setRemoteImages] = useState<CandidateImage[]>(() => imageSearchResults.map((image) => ({
    id: image.id,
    url: image.url,
    alt: image.alt,
    width: 0,
    height: 0,
    fileSize: "Unknown",
    thumbnailUrl: image.url,
    source: image.source,
    quality: image.quality as CandidateImage["quality"],
    verification: image.verificationConfidence
      ? { isMatch: image.verificationConfidence >= 75, reason: "Recovered from previous search", confidence: image.verificationConfidence }
      : undefined,
  })));
  const [uploadedImages, setUploadedImages] = useState<CandidateImage[]>([]);
  const [primaryId, setPrimaryId] = useState<string | null>(primaryImage?.id ?? null);
  const [alternateIds, setAlternateIds] = useState<Set<string>>(new Set(alternateImages.map((image) => image.id)));
  const [productId, setProductId] = useState<string | null>(catalogId);
  const [syncingId, setSyncingId] = useState<string | null>(null);
  const [assignImage, setAssignImage] = useState<CandidateImage | null>(null);

  const standalone = !intake.brand && !intake.strain && !intake.productType && !catalogId;

  useEffect(() => {
    if (catalogId) {
      setProductId(catalogId);
      return;
    }

    const resolveProductId = async () => {
      if (!intake.brand && !intake.strain) {
        return;
      }

      // Supabase's query builder is immutable — each chained method returns a
      // new object, so we must reassign `query` to accumulate filters.
      let query = supabase.from("products").select("id");
      if (intake.strain) {
        query = query.ilike("strain", `%${intake.strain}%`);
      }
      if (intake.brand) {
        query = query.ilike("brand", `%${intake.brand}%`);
      }

      const { data } = await query.limit(1).maybeSingle();
      if (data?.id) {
        setProductId(data.id);
      }
    };

    void resolveProductId();
  }, [catalogId, intake.brand, intake.strain]);

  const allImages = useMemo(() => [...remoteImages, ...uploadedImages], [remoteImages, uploadedImages]);
  const bestMatch = useMemo(() => selectBestCatalogImage(remoteImages, draftSearchInput), [draftSearchInput, remoteImages]);

  const autoSelectBestMatch = useCallback((images: CandidateImage[]) => {
    const selected = selectBestCatalogImage(images, draftSearchInput);
    if (!selected) {
      return;
    }

    setPrimaryId((current) => current ?? selected.id);
  }, [draftSearchInput]);

  const handleSearch = useCallback(async () => {
    setSearched(true);
    try {
      const results = (await searchImages.mutateAsync({ ...draftSearchInput, name: search || draftSearchInput.name })).map(toCandidateImage);
      setRemoteImages(results);
      setImageSearchResults(results.map(toDraftSearchResult));
      autoSelectBestMatch(results);

      if (results.length === 0) {
        toast.info("No candidate images found for this product.");
        return;
      }

      const best = selectBestCatalogImage(results, draftSearchInput);
      if (best?.verification?.isMatch) {
        toast.success(`Found ${results.length} image candidates. Best match is ${best.verification.confidence}% verified.`);
      } else {
        toast.success(`Found ${results.length} image candidates.`);
      }
    } catch (error) {
      const message = error instanceof Error ? error.message : "Image search failed";
      toast.error(message);
    }
  }, [autoSelectBestMatch, draftSearchInput, search, searchImages, setImageSearchResults]);

  const hasAutoSearched = useRef(false);
  useEffect(() => {
    if (!hasAutoSearched.current && remoteImages.length === 0 && (intake.brand || intake.strain)) {
      hasAutoSearched.current = true;
      void handleSearch();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [intake.brand, intake.strain]);

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (!files?.length) {
      return;
    }

    const uploaded: CandidateImage[] = [];
    for (const file of Array.from(files)) {
      const path = `${crypto.randomUUID()}.${file.name.split(".").pop() || "jpg"}`;
      const { error } = await supabase.storage.from("product-images").upload(path, file, { contentType: file.type });
      if (error) {
        toast.error(`Failed to upload ${file.name}: ${error.message}`);
        continue;
      }
      const { data } = supabase.storage.from("product-images").getPublicUrl(path);
      uploaded.push({
        id: `upload-${path}`,
        url: data.publicUrl,
        alt: file.name.replace(/\.[^.]+$/, ""),
        width: 0,
        height: 0,
        fileSize: `${Math.max(1, Math.round(file.size / 1024))} KB`,
        thumbnailUrl: data.publicUrl,
        source: "manual upload",
        quality: "high",
        verification: { isMatch: true, reason: "Uploaded manually by catalog editor.", confidence: 100 },
      });
    }

    if (uploaded.length > 0) {
      setUploadedImages((current) => [...current, ...uploaded]);
      setPrimaryId((current) => current ?? uploaded[0].id);
      toast.success(`${uploaded.length} image${uploaded.length === 1 ? "" : "s"} uploaded.`);
    }

    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  const handleSync = async (image: CandidateImage) => {
    if (!productId) {
      toast.info("Image selected for the draft. Publish or save the product first to sync it into the catalog bucket.");
      return;
    }

    setSyncingId(image.id);
    try {
      await syncCatalogImageToProduct({ supabase, productId, candidate: image });
      toast.success("Image synced to the product record.");
    } catch (error) {
      const message = error instanceof Error ? error.message : "Image sync failed";
      toast.error(message);
    } finally {
      setSyncingId(null);
    }
  };

  const toggleAlternate = (id: string) => {
    setAlternateIds((current) => {
      const next = new Set(current);
      if (next.has(id)) {
        next.delete(id);
      } else {
        next.add(id);
      }
      return next;
    });
  };

  const setPrimary = (id: string) => {
    setPrimaryId((current) => current === id ? null : id);
    setAlternateIds((current) => {
      const next = new Set(current);
      next.delete(id);
      return next;
    });
  };

  const handleApprove = () => {
    const selectedPrimary = allImages.find((image) => image.id === primaryId) ?? null;
    const selectedAlternates = allImages.filter((image) => alternateIds.has(image.id));

    setPrimaryImage(selectedPrimary ? toSelectedImage(selectedPrimary) : null);
    setAlternateImages(selectedAlternates.map(toSelectedImage));
    setImageSearchResults(remoteImages.map(toDraftSearchResult));
    setStatus("images_selected");
    toast.success("Image selections saved.");
    navigate("/review");
  };

  return (
    <div className="max-w-6xl p-8 lg:p-12">
      {!standalone && <WorkflowStepper currentStep="images_selected" />}
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.35 }}>
        {!standalone && (
          <button onClick={() => navigate("/ai-draft")} className="mb-6 flex items-center gap-1.5 text-sm text-muted-foreground transition-colors hover:text-foreground">
            <ArrowLeft className="h-4 w-4" />
            Back to draft
          </button>
        )}
        <h1 className="text-center font-serif text-3xl font-semibold tracking-tight text-foreground">Image Finder</h1>
        <p className="mb-8 text-center text-base text-muted-foreground">
          {standalone
            ? "Search the web for product imagery, then download it or assign it to any catalog product."
            : "Automatic real-product image retrieval is enabled. We rank candidates by packaging match, source quality, and verification confidence."}
        </p>
      </motion.div>


      <div className="mb-8 flex flex-wrap gap-3">
        <div className="relative max-w-xl flex-1">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            value={search}
            onChange={(event) => setSearch(event.target.value)}
            onKeyDown={(event) => event.key === "Enter" && void handleSearch()}
            placeholder="Search strain, brand, or package name…"
            className="h-11 border-border bg-card pl-10"
          />
        </div>
        <Button variant="gold" className="gap-2" onClick={() => void handleSearch()} disabled={searchImages.isPending}>
          {searchImages.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Search className="h-4 w-4" />}
          Refresh Images
        </Button>
        <Button
          variant="outline"
          className="gap-2"
          onClick={() => {
            if (bestMatch) {
              setPrimary(bestMatch.id);
              toast.success("Best verified match selected as the primary image.");
            }
          }}
          disabled={!bestMatch}
        >
          <WandSparkles className="h-4 w-4" />
          Auto-Pick Best Match
        </Button>
        <input ref={fileInputRef} type="file" accept="image/*" multiple className="hidden" onChange={handleFileUpload} />
        <Button variant="outline" className="gap-2" onClick={() => fileInputRef.current?.click()}>
          <Upload className="h-4 w-4" />
          Upload Images
        </Button>
      </div>

      {bestMatch && (
        <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="mb-6 rounded-xl border border-accent/30 bg-accent/5 p-4">
          <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
            <div>
              <p className="text-xs font-medium uppercase tracking-wider text-accent">Best verified candidate</p>
              <p className="text-sm text-foreground">{bestMatch.alt}</p>
              <p className="text-xs text-muted-foreground">{bestMatch.verification?.reason}</p>
            </div>
            <div className="flex items-center gap-2">
              <Badge variant="secondary" className="bg-success/15 text-success">
                {bestMatch.verification?.confidence ?? 0}% verified
              </Badge>
              <Button variant="gold" size="sm" onClick={() => setPrimary(bestMatch.id)}>
                Use as Primary
              </Button>
            </div>
          </div>
        </motion.div>
      )}

      <AnimatePresence>
        {searched && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6">
            <div className="flex items-center justify-between">
              <p className="text-sm text-muted-foreground">
                <span className="font-medium text-foreground">{allImages.length}</span> candidate images
              </p>
              {(primaryId || alternateIds.size > 0) && (
                <Badge variant="secondary" className="gap-1 bg-accent/20 text-accent-foreground">
                  <CheckCircle2 className="h-3 w-3" />
                  {(primaryId ? 1 : 0) + alternateIds.size} selected
                </Badge>
              )}
            </div>

            {searchImages.isPending ? (
              <div className="flex flex-col items-center justify-center rounded-xl border border-dashed border-border bg-card/50 py-16">
                <Loader2 className="mb-4 h-8 w-8 animate-spin text-muted-foreground" />
                <p className="text-sm text-muted-foreground">Searching for real product imagery…</p>
              </div>
            ) : allImages.length === 0 ? (
              <div className="rounded-xl border border-dashed border-border bg-card/50 p-16 text-center">
                <ImageIcon className="mx-auto mb-4 h-7 w-7 text-muted-foreground" />
                <p className="text-sm text-muted-foreground">No images found yet. Try refining the search or uploading a reference.</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
                {allImages.map((image, index) => (
                  <ImageCard
                    key={image.id}
                    image={image}
                    index={index}
                    isPrimary={primaryId === image.id}
                    isAlternate={alternateIds.has(image.id)}
                    onSetPrimary={() => setPrimary(image.id)}
                    onToggleAlternate={() => toggleAlternate(image.id)}
                    onSync={() => void handleSync(image)}
                    onAssign={() => setAssignImage(image)}
                    onDownload={() => void downloadImage(image.url, image.alt)}
                    canSync={Boolean(productId)}
                    syncing={syncingId === image.id}
                    showDraftActions={!standalone}
                  />
                ))}
              </div>
            )}

            {!standalone && (
              <div className="rounded-xl border border-border bg-card p-6 shadow-soft">
                <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
                  <div>
                    <h3 className="text-sm font-semibold text-foreground">Selection Summary</h3>
                    <p className="text-xs text-muted-foreground">
                      {primaryId ? "Primary image selected." : "Select a primary image before continuing."}
                    </p>
                  </div>
                  <div className="flex items-center gap-3">
                    <Button variant="outline" size="sm" onClick={() => { setPrimaryId(null); setAlternateIds(new Set()); }} disabled={!primaryId && alternateIds.size === 0}>
                      Clear Selection
                    </Button>
                    <Button variant="gold" size="lg" className="gap-2" disabled={!primaryId} onClick={handleApprove}>
                      <CheckCircle2 className="h-4 w-4" />
                      Approve & Continue
                    </Button>
                  </div>
                </div>
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>

      <AssignToProductDialog
        open={Boolean(assignImage)}
        onOpenChange={(open) => { if (!open) setAssignImage(null); }}
        image={assignImage}
      />
    </div>
  );
};


export default ImageFinder;
