/* eslint-disable @typescript-eslint/no-explicit-any -- dynamic template config + jsPDF interop */
import { useEffect, useLayoutEffect, useMemo, useRef, useState } from "react";
import { QRCodeSVG } from "qrcode.react";
import { Printer, QrCode, Barcode as BarcodeIcon, Search, Save, Trash2, FileDown, BookmarkPlus, Sparkles } from "lucide-react";
import { toast } from "sonner";
import { BarcodeDisplay } from "@/components/ui/BarcodeDisplay";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Checkbox } from "@/components/ui/checkbox";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { useProducts, type Product } from "@/hooks/useProducts";
import {
  useLabelTemplates,
  useSaveLabelTemplate,
  useDeleteLabelTemplate,
  type LabelTemplate,
  type LabelTemplateConfig,
} from "@/hooks/useLabelTemplates";
import { exportLabelsPdf, type LabelItem } from "@/lib/labelPdf";
import { useAuth } from "@/context/AuthContext";
import { cn } from "@/lib/utils";

const DEFAULT_CONFIG: LabelTemplateConfig = {
  mode: "barcode",
  size: "medium",
  copies: 1,
  showPrice: true,
  showSubtitle: true,
  showBrand: true,
  showStrain: true,
  showThc: false,
  showCbd: false,
  showSku: false,
  showStrainType: false,
  showTerpenes: false,
  showDescription: false,
  autoFit: true,
  titleFontSize: 9,
  subtitleFontSize: 7,
  priceFontSize: 10,
  fontWeight: "bold",
  fontFamily: "sans",
  barcodeFormat: "CODE128",
  qrErrorLevel: "M",
};

const SHELF_PRESET: LabelTemplateConfig = {
  ...DEFAULT_CONFIG,
  mode: "qr",
  size: "shelf",
  showPrice: true,
  showSubtitle: true,
  showBrand: true,
  showStrain: true,
  showThc: true,
  showCbd: true,
  showStrainType: true,
  showSku: true,
  showTerpenes: true,
  showDescription: false,
  titleFontSize: 16,
  subtitleFontSize: 11,
  priceFontSize: 28,
  autoFit: true,
};

const SIZE_DIMS: Record<string, { w: string; h: string }> = {
  small: { w: "2in", h: "1in" },
  medium: { w: "2.625in", h: "1in" },
  large: { w: "4in", h: "2in" },
  shelf: { w: "4in", h: "3in" },
};

const FONT_CLASSES: Record<LabelTemplateConfig["fontFamily"], string> = {
  sans: "font-sans",
  serif: "font-serif",
  mono: "font-mono",
};

function buildCatalogDeepLink(productId: string): string {
  if (typeof window === "undefined") return `/catalog/${productId}`;
  const { origin, pathname, hash } = window.location;
  // Preserve HashRouter style (#/catalog/...) when the app runs under a hash route.
  if (hash && hash.startsWith("#/")) {
    return `${origin}${pathname}#/catalog/${productId}`;
  }
  return `${origin}/catalog/${productId}`;
}

function productToLabel(p: Product, cfg: LabelTemplateConfig): LabelItem {
  const titleParts: string[] = [];
  if (cfg.showBrand && p.brand) titleParts.push(p.brand);
  if (cfg.showStrain && p.strain) titleParts.push(p.strain);
  const title = titleParts.join(" — ") || p.strain || p.brand || "Untitled";
  const subtitle = [p.product_type, p.package_size].filter(Boolean).join(" • ");
  // Shelf-tag QR codes deep-link into the in-app catalog page for quick scanning.
  const useDeepLink = cfg.mode === "qr" && cfg.size === "shelf";
  const value = useDeepLink ? buildCatalogDeepLink(p.id) : (p.sku || p.id);
  return {
    id: p.id,
    title,
    subtitle,
    value,
    price: p.price ?? null,
    brand: p.brand ?? undefined,
    strain: p.strain ?? undefined,
    strainType: (p as any).strain_type ?? undefined,
    productType: p.product_type ?? undefined,
    packageSize: p.package_size ?? undefined,
    thc: (p as any).thc ?? undefined,
    cbd: (p as any).cbd ?? undefined,
    sku: p.sku ?? undefined,
    terpenes: (p as any).terpenes ?? undefined,
    description: (p as any).short_description ?? undefined,
  };
}

export default function LabelMaker() {
  const { user } = useAuth();
  const { data: products = [], isLoading } = useProducts();
  const { data: templates = [] } = useLabelTemplates();
  const saveTpl = useSaveLabelTemplate();
  const deleteTpl = useDeleteLabelTemplate();

  const [cfg, setCfg] = useState<LabelTemplateConfig>(DEFAULT_CONFIG);
  const [activeTplId, setActiveTplId] = useState<string | null>(null);
  const [search, setSearch] = useState("");
  const [selected, setSelected] = useState<Record<string, boolean>>({});
  const [customTitle, setCustomTitle] = useState("");
  const [customValue, setCustomValue] = useState("");

  const [saveOpen, setSaveOpen] = useState(false);
  const [tplName, setTplName] = useState("");
  const [tplDesc, setTplDesc] = useState("");
  const [tplShared, setTplShared] = useState(true);

  const update = <K extends keyof LabelTemplateConfig>(k: K, v: LabelTemplateConfig[K]) =>
    setCfg((c) => ({ ...c, [k]: v }));

  const filtered = useMemo(() => {
    const q = search.toLowerCase().trim();
    if (!q) return products.slice(0, 100);
    return products
      .filter((p) =>
        [p.brand, p.strain, p.sku, p.product_type]
          .filter(Boolean)
          .some((f) => String(f).toLowerCase().includes(q)),
      )
      .slice(0, 100);
  }, [products, search]);

  const labels: LabelItem[] = useMemo(() => {
    const items: LabelItem[] = [];
    products
      .filter((p) => selected[p.id])
      .forEach((p) => {
        const base = productToLabel(p, cfg);
        for (let i = 0; i < cfg.copies; i++) items.push(base);
      });
    if (customTitle && customValue) {
      for (let i = 0; i < cfg.copies; i++) {
        items.push({ id: `custom-${i}`, title: customTitle, value: customValue });
      }
    }
    return items;
  }, [products, selected, cfg, customTitle, customValue]);

  const toggle = (id: string) => setSelected((s) => ({ ...s, [id]: !s[id] }));

  const applyTemplate = (t: LabelTemplate) => {
    setCfg({ ...DEFAULT_CONFIG, ...t.config });
    setActiveTplId(t.id);
    toast.success(`Loaded "${t.name}"`);
  };

  const handleSave = async () => {
    if (!tplName.trim()) {
      toast.error("Give the template a name");
      return;
    }
    try {
      await saveTpl.mutateAsync({
        name: tplName.trim(),
        description: tplDesc.trim() || undefined,
        config: cfg,
        is_shared: tplShared,
      });
      toast.success("Template saved");
      setSaveOpen(false);
      setTplName("");
      setTplDesc("");
    } catch (e: any) {
      toast.error(e.message ?? "Save failed");
    }
  };

  const handleUpdate = async () => {
    if (!activeTplId) return;
    const t = templates.find((x) => x.id === activeTplId);
    if (!t) return;
    try {
      await saveTpl.mutateAsync({
        id: t.id,
        name: t.name,
        description: t.description ?? undefined,
        config: cfg,
        is_shared: t.is_shared,
      });
      toast.success("Template updated");
    } catch (e: any) {
      toast.error(e.message ?? "Update failed");
    }
  };

  const handleDelete = async (id: string) => {
    try {
      await deleteTpl.mutateAsync(id);
      if (activeTplId === id) setActiveTplId(null);
      toast.success("Template deleted");
    } catch (e: any) {
      toast.error(e.message ?? "Delete failed");
    }
  };

  const handleExportPdf = async () => {
    if (!labels.length) {
      toast.error("Select items or fill in a custom label first");
      return;
    }
    try {
      await exportLabelsPdf(labels, cfg, `labels-${Date.now()}.pdf`);
      toast.success("PDF downloaded");
    } catch (e: any) {
      toast.error(e.message ?? "PDF export failed");
    }
  };

  useEffect(() => {
    if (activeTplId && !templates.find((t) => t.id === activeTplId)) setActiveTplId(null);
  }, [templates, activeTplId]);

  return (
    <div className="space-y-6 p-4 lg:p-8">
      <style>{`
        @media print {
          body * { visibility: hidden !important; }
          #label-print-sheet, #label-print-sheet * { visibility: visible !important; }
          #label-print-sheet { position: absolute; left: 0; top: 0; width: 100%; padding: 0.25in; }
          .label-tile { break-inside: avoid; page-break-inside: avoid; }
        }
      `}</style>

      <header className="flex flex-col gap-3 print:hidden sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="font-serif text-3xl font-bold tracking-tight">Label Maker</h1>
          <p className="text-sm text-muted-foreground">
            Barcode & QR labels, reusable templates, PDF export.
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Button
            variant="outline"
            onClick={() => { setCfg(SHELF_PRESET); setActiveTplId(null); toast.success("Shelf tag preset applied"); }}
          >
            <Sparkles className="mr-2 h-4 w-4" /> Shelf tag preset
          </Button>
          <Dialog open={saveOpen} onOpenChange={setSaveOpen}>
            <DialogTrigger asChild>
              <Button variant="outline">
                <BookmarkPlus className="mr-2 h-4 w-4" /> Save as template
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Save label template</DialogTitle>
              </DialogHeader>
              <div className="space-y-3">
                <div className="space-y-1.5">
                  <Label>Name</Label>
                  <Input value={tplName} onChange={(e) => setTplName(e.target.value)} placeholder="e.g. Shelf tag — eighths" />
                </div>
                <div className="space-y-1.5">
                  <Label>Description (optional)</Label>
                  <Textarea value={tplDesc} onChange={(e) => setTplDesc(e.target.value)} rows={2} />
                </div>
                <label className="flex items-center gap-2 text-sm">
                  <Checkbox checked={tplShared} onCheckedChange={(v) => setTplShared(!!v)} />
                  Share with my dispensary team
                </label>
              </div>
              <DialogFooter>
                <Button variant="ghost" onClick={() => setSaveOpen(false)}>Cancel</Button>
                <Button onClick={handleSave} disabled={saveTpl.isPending}>Save</Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
          {activeTplId && (
            <Button variant="outline" onClick={handleUpdate} disabled={saveTpl.isPending}>
              <Save className="mr-2 h-4 w-4" /> Update template
            </Button>
          )}
          <Button variant="outline" onClick={handleExportPdf} disabled={!labels.length}>
            <FileDown className="mr-2 h-4 w-4" /> Export PDF
          </Button>
          <Button onClick={() => window.print()} disabled={!labels.length}>
            <Printer className="mr-2 h-4 w-4" /> Print ({labels.length})
          </Button>
        </div>
      </header>

      <div className="grid gap-6 lg:grid-cols-[440px_1fr] print:block">
        {/* Controls */}
        <div className="space-y-4 print:hidden">
          {/* Templates */}
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="text-base">Saved templates</CardTitle>
              <Badge variant="secondary">{templates.length}</Badge>
            </CardHeader>
            <CardContent>
              {templates.length === 0 ? (
                <p className="text-xs text-muted-foreground">
                  No templates yet. Configure a layout below and click "Save as template".
                </p>
              ) : (
                <ScrollArea className="max-h-[180px]">
                  <div className="space-y-1.5">
                    {templates.map((t) => (
                      <div
                        key={t.id}
                        className={cn(
                          "flex items-center gap-2 rounded border p-2",
                          activeTplId === t.id && "border-primary bg-accent/40",
                        )}
                      >
                        <button
                          className="min-w-0 flex-1 text-left"
                          onClick={() => applyTemplate(t)}
                        >
                          <p className="truncate text-sm font-medium">{t.name}</p>
                          <p className="truncate text-[11px] text-muted-foreground">
                            {t.config.mode.toUpperCase()} · {t.config.size} · {t.is_shared ? "shared" : "private"}
                          </p>
                        </button>
                        {(t.user_id === user?.id) && (
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-7 w-7"
                            onClick={() => handleDelete(t.id)}
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                          </Button>
                        )}
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              )}
            </CardContent>
          </Card>

          {/* Settings */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Label settings</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Format</Label>
                <Tabs value={cfg.mode} onValueChange={(v) => update("mode", v as any)}>
                  <TabsList className="grid w-full grid-cols-2">
                    <TabsTrigger value="barcode"><BarcodeIcon className="mr-2 h-4 w-4" /> Barcode</TabsTrigger>
                    <TabsTrigger value="qr"><QrCode className="mr-2 h-4 w-4" /> QR Code</TabsTrigger>
                  </TabsList>
                </Tabs>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-2">
                  <Label>Size</Label>
                  <Select value={cfg.size} onValueChange={(v) => update("size", v as any)}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="small">Small (2×1")</SelectItem>
                      <SelectItem value="medium">Medium (2.6×1")</SelectItem>
                      <SelectItem value="large">Large (4×2")</SelectItem>
                      <SelectItem value="shelf">Shelf tag (4×3")</SelectItem>
                      <SelectItem value="custom">Custom</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Copies per item</Label>
                  <Input
                    type="number" min={1} max={100} value={cfg.copies}
                    onChange={(e) => update("copies", Math.max(1, Math.min(100, Number(e.target.value) || 1)))}
                  />
                </div>
              </div>

              {cfg.size === "custom" && (
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-2">
                    <Label>Width (in)</Label>
                    <Input type="number" step="0.1" min={0.5} max={8}
                      value={cfg.customWidthIn ?? 2.625}
                      onChange={(e) => update("customWidthIn", Number(e.target.value))} />
                  </div>
                  <div className="space-y-2">
                    <Label>Height (in)</Label>
                    <Input type="number" step="0.1" min={0.5} max={8}
                      value={cfg.customHeightIn ?? 1}
                      onChange={(e) => update("customHeightIn", Number(e.target.value))} />
                  </div>
                </div>
              )}

              {cfg.mode === "barcode" ? (
                <div className="space-y-2">
                  <Label>Barcode format</Label>
                  <Select value={cfg.barcodeFormat} onValueChange={(v) => update("barcodeFormat", v)}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="CODE128">Code 128</SelectItem>
                      <SelectItem value="CODE39">Code 39</SelectItem>
                      <SelectItem value="EAN13">EAN-13</SelectItem>
                      <SelectItem value="UPC">UPC</SelectItem>
                      <SelectItem value="ITF14">ITF-14</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              ) : (
                <div className="space-y-2">
                  <Label>QR error correction</Label>
                  <Select value={cfg.qrErrorLevel} onValueChange={(v) => update("qrErrorLevel", v as any)}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="L">Low (7%)</SelectItem>
                      <SelectItem value="M">Medium (15%)</SelectItem>
                      <SelectItem value="Q">Quartile (25%)</SelectItem>
                      <SelectItem value="H">High (30%)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              )}

              <div className="space-y-2 border-t pt-3">
                <Label className="text-xs uppercase tracking-wider text-muted-foreground">Fields</Label>
                <div className="grid grid-cols-2 gap-2 text-sm">
                  <label className="flex items-center gap-2"><Checkbox checked={cfg.showBrand} onCheckedChange={(v) => update("showBrand", !!v)} /> Brand</label>
                  <label className="flex items-center gap-2"><Checkbox checked={cfg.showStrain} onCheckedChange={(v) => update("showStrain", !!v)} /> Strain</label>
                  <label className="flex items-center gap-2"><Checkbox checked={cfg.showSubtitle} onCheckedChange={(v) => update("showSubtitle", !!v)} /> Type / size</label>
                  <label className="flex items-center gap-2"><Checkbox checked={cfg.showPrice} onCheckedChange={(v) => update("showPrice", !!v)} /> Price</label>
                  <label className="flex items-center gap-2"><Checkbox checked={!!cfg.showThc} onCheckedChange={(v) => update("showThc", !!v)} /> THC %</label>
                  <label className="flex items-center gap-2"><Checkbox checked={!!cfg.showCbd} onCheckedChange={(v) => update("showCbd", !!v)} /> CBD %</label>
                  <label className="flex items-center gap-2"><Checkbox checked={!!cfg.showStrainType} onCheckedChange={(v) => update("showStrainType", !!v)} /> Strain type</label>
                  <label className="flex items-center gap-2"><Checkbox checked={!!cfg.showSku} onCheckedChange={(v) => update("showSku", !!v)} /> SKU</label>
                  <label className="flex items-center gap-2"><Checkbox checked={!!cfg.showTerpenes} onCheckedChange={(v) => update("showTerpenes", !!v)} /> Terpenes</label>
                  <label className="flex items-center gap-2"><Checkbox checked={!!cfg.showDescription} onCheckedChange={(v) => update("showDescription", !!v)} /> Description</label>
                </div>
                <label className="flex items-center gap-2 pt-1 text-sm">
                  <Checkbox checked={cfg.autoFit !== false} onCheckedChange={(v) => update("autoFit", !!v)} />
                  Auto-fit content to label size
                </label>
              </div>

              <div className="space-y-3 border-t pt-3">
                <Label className="text-xs uppercase tracking-wider text-muted-foreground">Typography</Label>
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-2">
                    <Label>Font family</Label>
                    <Select value={cfg.fontFamily} onValueChange={(v) => update("fontFamily", v as any)}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="sans">Sans-serif</SelectItem>
                        <SelectItem value="serif">Serif</SelectItem>
                        <SelectItem value="mono">Monospace</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label>Weight</Label>
                    <Select value={cfg.fontWeight} onValueChange={(v) => update("fontWeight", v as any)}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="normal">Normal</SelectItem>
                        <SelectItem value="bold">Bold</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="grid grid-cols-3 gap-3">
                  <div className="space-y-1">
                    <Label className="text-[11px]">Title</Label>
                    <Input type="number" min={6} max={24} value={cfg.titleFontSize}
                      onChange={(e) => update("titleFontSize", Number(e.target.value) || 9)} />
                  </div>
                  <div className="space-y-1">
                    <Label className="text-[11px]">Subtitle</Label>
                    <Input type="number" min={5} max={20} value={cfg.subtitleFontSize}
                      onChange={(e) => update("subtitleFontSize", Number(e.target.value) || 7)} />
                  </div>
                  <div className="space-y-1">
                    <Label className="text-[11px]">Price</Label>
                    <Input type="number" min={6} max={24} value={cfg.priceFontSize}
                      onChange={(e) => update("priceFontSize", Number(e.target.value) || 10)} />
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-base">Custom label</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="space-y-1.5">
                <Label>Title</Label>
                <Input value={customTitle} onChange={(e) => setCustomTitle(e.target.value)} placeholder="e.g. Storage Bin A" />
              </div>
              <div className="space-y-1.5">
                <Label>Code value</Label>
                <Input value={customValue} onChange={(e) => setCustomValue(e.target.value)} placeholder="SKU / URL / text" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-base">Catalog items</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="relative">
                <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input className="pl-8" placeholder="Search brand, strain, SKU…"
                  value={search} onChange={(e) => setSearch(e.target.value)} />
              </div>
              <ScrollArea className="h-[300px] rounded-md border">
                <div className="divide-y">
                  {isLoading && <div className="p-3 text-sm text-muted-foreground">Loading…</div>}
                  {!isLoading && filtered.length === 0 && (
                    <div className="p-3 text-sm text-muted-foreground">No products found.</div>
                  )}
                  {filtered.map((p) => {
                    const lbl = productToLabel(p, cfg);
                    return (
                      <label key={p.id} className="flex cursor-pointer items-center gap-3 p-2.5 hover:bg-accent/50">
                        <Checkbox checked={!!selected[p.id]} onCheckedChange={() => toggle(p.id)} />
                        <div className="min-w-0 flex-1">
                          <p className="truncate text-sm font-medium">{lbl.title}</p>
                          <p className="truncate text-xs text-muted-foreground">
                            {lbl.subtitle || "—"} · {lbl.value}
                          </p>
                        </div>
                      </label>
                    );
                  })}
                </div>
              </ScrollArea>
              {Object.values(selected).some(Boolean) && (
                <Button variant="ghost" size="sm" onClick={() => setSelected({})}>Clear selection</Button>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Preview */}
        <Card className="print:border-0 print:shadow-none">
          <CardHeader className="print:hidden">
            <CardTitle className="text-base">Preview</CardTitle>
          </CardHeader>
          <CardContent>
            <div id="label-print-sheet" className="flex flex-wrap gap-2">
              {labels.length === 0 ? (
                <div className="w-full rounded-lg border border-dashed p-10 text-center text-sm text-muted-foreground print:hidden">
                  Select catalog items or fill in a custom label to preview.
                </div>
              ) : (
                labels.map((l, i) => (
                  <LabelTile key={`${l.id}-${i}`} label={l} cfg={cfg} />
                ))
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

interface LabelTileProps {
  label: LabelItem;
  cfg: LabelTemplateConfig;
}

function LabelTile({ label: l, cfg }: LabelTileProps) {
  const outerRef = useRef<HTMLDivElement>(null);
  const innerRef = useRef<HTMLDivElement>(null);
  const [scale, setScale] = useState(1);

  const dims = cfg.size === "custom"
    ? { w: `${cfg.customWidthIn ?? 2.625}in`, h: `${cfg.customHeightIn ?? 1}in` }
    : SIZE_DIMS[cfg.size] ?? SIZE_DIMS.medium;

  const isShelf = cfg.size === "shelf";
  const padPx = isShelf ? 12 : 6;
  const autoFit = cfg.autoFit !== false;

  // Code dimensions scale with label size
  const qrSize = isShelf ? 150 : cfg.size === "large" ? 110 : cfg.size === "medium" ? 64 : 54;
  const barHeight = isShelf ? 80 : cfg.size === "large" ? 60 : 36;
  const barWidth = isShelf ? 2.4 : cfg.size === "large" ? 2 : 1.4;

  useLayoutEffect(() => {
    if (!autoFit || !outerRef.current || !innerRef.current) {
      setScale(1);
      return;
    }
    const measure = () => {
      const outer = outerRef.current;
      const inner = innerRef.current;
      if (!outer || !inner) return;
      // Temporarily reset scale to measure natural size
      inner.style.transform = "scale(1)";
      const oW = outer.clientWidth - padPx * 2;
      const oH = outer.clientHeight - padPx * 2;
      const iW = inner.scrollWidth;
      const iH = inner.scrollHeight;
      if (iW === 0 || iH === 0) return;
      const s = Math.min(1, oW / iW, oH / iH);
      setScale(s < 0.4 ? 0.4 : s);
    };
    measure();
    const ro = new ResizeObserver(measure);
    ro.observe(outerRef.current);
    ro.observe(innerRef.current);
    return () => ro.disconnect();
  }, [autoFit, padPx, l, cfg]);

  const potency = [
    cfg.showThc && l.thc ? `THC ${l.thc}` : null,
    cfg.showCbd && l.cbd ? `CBD ${l.cbd}` : null,
  ].filter(Boolean).join("  ·  ");

  return (
    <div
      ref={outerRef}
      style={{ width: dims.w, height: dims.h, padding: `${padPx}px` }}
      className={cn(
        "label-tile relative flex items-stretch overflow-hidden rounded border border-foreground/30 bg-white text-black",
        FONT_CLASSES[cfg.fontFamily],
      )}
    >
      <div
        ref={innerRef}
        style={{ transform: `scale(${scale})`, transformOrigin: "top left", width: `${100 / scale}%`, height: `${100 / scale}%` }}
        className="flex flex-col items-center justify-between"
      >
        <div className="w-full text-center leading-tight">
          <p
            className={cn(autoFit ? "" : "truncate", cfg.fontWeight === "bold" ? "font-bold" : "font-normal")}
            style={{ fontSize: `${cfg.titleFontSize}px` }}
          >
            {l.title}
          </p>
          {cfg.showSubtitle && l.subtitle && (
            <p className={cn(autoFit ? "" : "truncate", "text-neutral-600")} style={{ fontSize: `${cfg.subtitleFontSize}px` }}>
              {l.subtitle}
            </p>
          )}
          {potency && (
            <p className="font-semibold text-neutral-800" style={{ fontSize: `${cfg.subtitleFontSize + 1}px` }}>
              {potency}
            </p>
          )}
          {cfg.showStrainType && l.strainType && (
            <p className="uppercase tracking-wide text-neutral-600" style={{ fontSize: `${Math.max(6, cfg.subtitleFontSize - 1)}px` }}>
              {l.strainType}
            </p>
          )}
          {cfg.showTerpenes && l.terpenes && (
            <p className="text-neutral-600" style={{ fontSize: `${Math.max(6, cfg.subtitleFontSize - 1)}px` }}>
              Terps: {l.terpenes}
            </p>
          )}
          {cfg.showDescription && l.description && (
            <p className="px-1 text-neutral-700" style={{ fontSize: `${Math.max(6, cfg.subtitleFontSize - 1)}px` }}>
              {l.description}
            </p>
          )}
        </div>

        <div className="flex w-full flex-1 items-center justify-center py-1">
          {cfg.mode === "barcode" ? (
            <BarcodeDisplay
              value={l.value}
              label={l.value}
              format={cfg.barcodeFormat}
              height={barHeight}
              width={barWidth}
            />
          ) : (
            <QRCodeSVG value={l.value} level={cfg.qrErrorLevel} size={qrSize} />
          )}
        </div>

        <div className="flex w-full items-center justify-between gap-2 px-1">
          {cfg.showSku && l.sku ? (
            <span className="text-neutral-500" style={{ fontSize: `${Math.max(6, cfg.subtitleFontSize - 2)}px` }}>
              SKU {l.sku}
            </span>
          ) : <span />}
          {cfg.showPrice && typeof l.price === "number" && (
            <span className="font-bold" style={{ fontSize: `${cfg.priceFontSize}px` }}>
              ${l.price.toFixed(2)}
            </span>
          )}
        </div>
      </div>
    </div>
  );
}
