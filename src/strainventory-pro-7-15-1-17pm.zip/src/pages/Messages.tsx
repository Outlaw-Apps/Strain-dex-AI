import { useEffect, useMemo, useRef, useState } from "react";
import { motion } from "framer-motion";
import {
  Bell,
  BellOff,
  ImagePlus,
  Loader2,
  MessageCircle,
  Search,
  Send,
  Trash2,
  UserCircle2,
  UserPlus,
} from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { cn } from "@/lib/utils";
import { useAuth } from "@/context/AuthContext";
import { useProfiles } from "@/hooks/useProfiles";
import {
  useConversations,
  useMessages,
  useStartDirectMessage,
  type ConversationSummary,
} from "@/hooks/useMessages";
import { useMessengerNotificationsContext } from "@/context/MessengerNotificationsContext";

const formatTimestamp = (iso: string) => {
  const then = new Date(iso);
  const now = new Date();
  const sameDay =
    then.getFullYear() === now.getFullYear() &&
    then.getMonth() === now.getMonth() &&
    then.getDate() === now.getDate();
  if (sameDay) {
    return then.toLocaleTimeString([], {
      hour: "2-digit",
      minute: "2-digit",
    });
  }
  const diffDays = Math.floor(
    (now.getTime() - then.getTime()) / (24 * 60 * 60 * 1000),
  );
  if (diffDays < 7) {
    return then.toLocaleDateString([], { weekday: "short" });
  }
  return then.toLocaleDateString([], { month: "short", day: "numeric" });
};

const Messages = () => {
  const { user } = useAuth();
  const { data: profiles = [] } = useProfiles();
  const conversationsQuery = useConversations();
  const startDm = useStartDirectMessage();

  const [activeConversationId, setActiveConversationId] = useState<string | null>(
    null,
  );
  const [draft, setDraft] = useState("");
  const [search, setSearch] = useState("");
  const [newDmOpen, setNewDmOpen] = useState(false);
  const [newDmSearch, setNewDmSearch] = useState("");

  const messages = useMessages(activeConversationId);
  const messagesEndRef = useRef<HTMLDivElement | null>(null);
  const imageInputRef = useRef<HTMLInputElement | null>(null);
  const [deletingMessageId, setDeletingMessageId] = useState<string | null>(null);
  const { setActiveChannelId, clearNotifications } = useMessengerNotificationsContext();
  const [notifPermission, setNotifPermission] = useState<NotificationPermission | "unsupported">(
    typeof Notification === "undefined" ? "unsupported" : Notification.permission,
  );

  const requestNotificationPermission = async () => {
    if (typeof Notification === "undefined") {
      toast.error("Notifications aren't supported in this browser.");
      return;
    }
    try {
      const result = await Notification.requestPermission();
      setNotifPermission(result);
      if (result === "granted") {
        toast.success("Notifications enabled. You'll be alerted to new messages.");
      } else if (result === "denied") {
        toast.error("Notifications blocked. Enable them in your browser settings.");
      }
    } catch {
      toast.error("Could not request notification permission.");
    }
  };


  // Tell the notifications layer which conversation is currently open so it
  // can suppress the chime + badge while the user is looking at it.
  useEffect(() => {
    setActiveChannelId(activeConversationId);
    return () => setActiveChannelId(null);
  }, [activeConversationId, setActiveChannelId]);

  // Clear the cumulative unread badge as soon as the user lands on the page.
  useEffect(() => {
    clearNotifications();
  }, [clearNotifications]);

  const profileMap = useMemo(() => {
    const map = new Map<string, string>();
    for (const p of profiles) {
      map.set(p.id, p.full_name || "Unknown");
    }
    return map;
  }, [profiles]);

  const filteredConversations = useMemo(() => {
    const list = conversationsQuery.data ?? [];
    if (!search.trim()) return list;
    const q = search.trim().toLowerCase();
    return list.filter((summary: ConversationSummary) => {
      const otherName = summary.otherUserId
        ? profileMap.get(summary.otherUserId) ?? ""
        : summary.conversation.title ?? "";
      const preview = summary.conversation.last_message_preview ?? "";
      return (
        otherName.toLowerCase().includes(q) || preview.toLowerCase().includes(q)
      );
    });
  }, [conversationsQuery.data, search, profileMap]);

  const activeSummary = useMemo(
    () =>
      (conversationsQuery.data ?? []).find(
        (c) => c.conversation.id === activeConversationId,
      ) ?? null,
    [conversationsQuery.data, activeConversationId],
  );

  // Auto-scroll to the latest message whenever the message list changes.
  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [messages.data]);

  // Mark the thread as read once it is visible and the message list has settled.
  // This avoids repeatedly hitting the RPC on unrelated rerenders while still
  // refreshing unread counts when new messages arrive.
  const latestMessageId = messages.data?.[messages.data.length - 1]?.id ?? null;
  const markActiveConversationRead = messages.markRead;
  const messagesLoading = messages.isLoading;
  useEffect(() => {
    if (!activeConversationId) return;
    if (messagesLoading) return;
    void markActiveConversationRead();
  }, [activeConversationId, messagesLoading, markActiveConversationRead, latestMessageId]);

  const teammateCandidates = useMemo(() => {
    if (!user?.id) return [];
    const q = newDmSearch.trim().toLowerCase();
    const filtered = profiles
      .filter((p) => p.id !== user.id)
      .filter((p) =>
        q ? (p.full_name ?? "").toLowerCase().includes(q) : true,
      )
      .sort((a, b) =>
        (a.full_name ?? "").localeCompare(b.full_name ?? ""),
      );
    return filtered.slice(0, 24);
  }, [profiles, newDmSearch, user?.id]);

  const handleStartDm = async (otherUserId: string) => {
    try {
      const conversationId = await startDm.mutateAsync(otherUserId);
      setActiveConversationId(conversationId);
      setNewDmOpen(false);
      setNewDmSearch("");
    } catch (err) {
      toast.error(
        err instanceof Error ? err.message : "Could not start conversation.",
      );
    }
  };

  const handleSend = async () => {
    const body = draft;
    if (!body.trim()) return;
    try {
      await messages.sendMessage(body);
      setDraft("");
    } catch (err) {
      toast.error(
        err instanceof Error ? err.message : "Could not send message.",
      );
    }
  };

  const handlePickImage = () => {
    if (!activeConversationId) {
      toast.info("Pick a conversation first.");
      return;
    }
    imageInputRef.current?.click();
  };

  const handleImageFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = ""; // allow re-picking same file
    if (!file) return;
    try {
      await messages.sendImage({ file, caption: draft });
      setDraft("");
      toast.success("Photo sent.");
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Could not send photo.");
    }
  };


  const handleDeleteMessage = async (messageId: string) => {
    const confirmed = window.confirm("Delete this message? This cannot be undone.");
    if (!confirmed) return;
    try {
      setDeletingMessageId(messageId);
      await messages.deleteMessage(messageId);
      toast.success("Message deleted.");
    } catch (err) {
      toast.error(
        err instanceof Error ? err.message : "Could not delete message.",
      );
    } finally {
      setDeletingMessageId(null);
    }
  };

  const handleDeleteAllMine = async () => {
    const mineCount = (messages.data ?? []).filter((m) => m.sender_id === user?.id).length;
    if (mineCount === 0) {
      toast.info("You have no messages to delete in this conversation.");
      return;
    }
    const confirmed = window.confirm(
      `Delete all ${mineCount} of your messages in this conversation? This cannot be undone.`,
    );
    if (!confirmed) return;
    try {
      await messages.deleteAllMine();
      toast.success("Your messages were deleted.");
    } catch (err) {
      toast.error(
        err instanceof Error ? err.message : "Could not delete messages.",
      );
    }
  };

  const conversationLabel = (summary: ConversationSummary) => {
    if (summary.conversation.is_group) {
      return summary.conversation.title ?? "Group chat";
    }
    if (summary.otherUserId) {
      return (
        profileMap.get(summary.otherUserId) ??
        `Member ${summary.otherUserId.slice(0, 8)}`
      );
    }
    return "Conversation";
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto">
      <motion.div
        initial={{ opacity: 0, y: -8 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.35 }}
        className="mb-5 sm:mb-7 flex flex-wrap items-end justify-between gap-3"
      >
        <div className="flex items-center gap-3 sm:gap-4">
          <div className="grid h-11 w-11 sm:h-12 sm:w-12 place-items-center rounded-2xl border-2 border-border bg-gradient-to-br from-accent/30 to-accent/5 shadow-soft">
            <MessageCircle className="h-5 w-5 sm:h-6 sm:w-6 text-accent" strokeWidth={2.25} />
          </div>
          <div>
            <p className="text-[11px] font-semibold uppercase tracking-[0.22em] text-muted-foreground">
              Inbox
            </p>
            <h1 className="text-display text-3xl sm:text-4xl font-bold tracking-tight text-foreground">
              Messages
            </h1>
          </div>
        </div>
        <p className="hidden md:block text-xs text-muted-foreground max-w-sm text-right">
          Private team conversations — only participants can see what's shared here.
        </p>
      </motion.div>

      <div className="grid gap-0 md:grid-cols-[340px_minmax(0,1fr)] rounded-3xl border-2 border-border bg-card shadow-elevated overflow-hidden min-h-[72vh]">
        {/* Conversation list */}
        <div className="border-b-2 md:border-b-0 md:border-r-2 border-border flex flex-col bg-muted/20">
          <div className="p-3 sm:p-4 border-b-2 border-border flex flex-col gap-2 bg-card">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search conversations…"
                className="pl-9 h-10 text-sm border-2 focus-visible:ring-2"
              />
            </div>
            <Dialog open={newDmOpen} onOpenChange={setNewDmOpen}>
              <DialogTrigger asChild>
                <Button
                  size="sm"
                  variant="gold"
                  className="gap-2 h-10 font-semibold shadow-soft bg-[linear-gradient(135deg,hsl(var(--accent))_0%,hsl(var(--accent)/0.85)_45%,hsl(var(--accent))_100%)] bg-[length:200%_200%] bg-left transition-all duration-200 hover:bg-right hover:shadow-[0_0_18px_hsl(var(--accent)/0.75),0_0_36px_hsl(var(--accent)/0.35)] active:scale-[0.98] active:shadow-[0_0_10px_hsl(var(--accent)/0.6)] focus-visible:ring-2 focus-visible:ring-accent/60"
                >
                  <UserPlus className="h-4 w-4" strokeWidth={2.5} />
                  New message
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Start a new conversation</DialogTitle>
                  <DialogDescription>
                    Pick a teammate to open a direct message with.
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-3">
                  <Input
                    value={newDmSearch}
                    onChange={(e) => setNewDmSearch(e.target.value)}
                    placeholder="Search teammates…"
                    autoFocus
                  />
                  <ScrollArea className="max-h-64">
                    <div className="space-y-1">
                      {teammateCandidates.length === 0 ? (
                        <p className="text-xs text-muted-foreground px-2 py-6 text-center">
                          No teammates match your search.
                        </p>
                      ) : (
                        teammateCandidates.map((p) => (
                          <button
                            key={p.id}
                            type="button"
                            className={cn(
                              "flex w-full items-center gap-2 rounded-md px-2 py-2 text-left text-sm",
                              "hover:bg-accent/10 transition-colors",
                            )}
                            onClick={() => void handleStartDm(p.id)}
                            disabled={startDm.isPending}
                          >
                            <UserCircle2 className="h-4 w-4 text-muted-foreground" />
                            <span className="flex-1 truncate">
                              {p.full_name || `Member ${p.id.slice(0, 8)}`}
                            </span>
                            {startDm.isPending && (
                              <Loader2 className="h-3.5 w-3.5 animate-spin" />
                            )}
                          </button>
                        ))
                      )}
                    </div>
                  </ScrollArea>
                </div>
                <DialogFooter>
                  <Button variant="ghost" onClick={() => setNewDmOpen(false)}>
                    Close
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </div>

          <ScrollArea className="flex-1">
            {conversationsQuery.isLoading ? (
              <div className="py-12 flex items-center justify-center text-muted-foreground">
                <Loader2 className="h-4 w-4 animate-spin mr-2" />
                <span className="text-xs">Loading…</span>
              </div>
            ) : filteredConversations.length === 0 ? (
              <div className="py-12 px-4 text-center">
                <MessageCircle className="h-8 w-8 mx-auto mb-3 text-muted-foreground/50" />
                <p className="text-sm font-medium text-foreground mb-1">No conversations</p>
                <p className="text-xs text-muted-foreground">
                  Start one with "New message".
                </p>
              </div>
            ) : (
              <ul className="p-2 space-y-1">
                {filteredConversations.map((summary) => {
                  const isActive =
                    summary.conversation.id === activeConversationId;
                  const hasUnread = summary.unreadCount > 0;
                  return (
                    <li key={summary.conversation.id}>
                      <button
                        type="button"
                        onClick={() =>
                          setActiveConversationId(summary.conversation.id)
                        }
                        className={cn(
                          "group flex w-full items-start gap-3 rounded-xl px-3 py-3 text-left transition-all duration-200 border-2 border-l-[2px]",
                          isActive
                            ? "bg-accent/15 border-accent/40 shadow-soft"
                            : "border-transparent hover:bg-[hsl(var(--muted)/0.6)] hover:border-l-emerald-500 hover:shadow-[0_0_0_1px_hsl(142_72%_45%/0.25),0_0_18px_hsl(142_72%_45%/0.35)]",
                        )}
                      >
                        <div className={cn(
                          "grid h-10 w-10 shrink-0 place-items-center rounded-full ring-2 transition-colors",
                          isActive ? "bg-accent/20 ring-accent/50" : "bg-muted ring-border",
                        )}>
                          <UserCircle2 className="h-5 w-5 text-foreground/70" strokeWidth={2} />
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between gap-2 mb-0.5">
                            <span className={cn(
                              "text-sm truncate text-foreground",
                              hasUnread ? "font-bold" : "font-semibold",
                            )}>
                              {conversationLabel(summary)}
                            </span>
                            <span className="text-[10px] font-medium text-muted-foreground tabular-nums shrink-0">
                              {formatTimestamp(
                                summary.conversation.last_message_at,
                              )}
                            </span>
                          </div>
                          <div className="flex items-center justify-between gap-2">
                            <p className={cn(
                              "text-xs truncate",
                              hasUnread ? "text-foreground/85 font-medium" : "text-muted-foreground",
                            )}>
                              {summary.conversation.last_message_preview ??
                                "No messages yet."}
                            </p>
                            {hasUnread && (
                              <Badge
                                className="bg-accent text-accent-foreground text-[10px] font-bold px-2 py-0 h-5 min-w-[20px] justify-center shadow-soft"
                              >
                                {summary.unreadCount}
                              </Badge>
                            )}
                          </div>
                        </div>
                      </button>
                    </li>
                  );
                })}
              </ul>
            )}
          </ScrollArea>
        </div>

        {/* Message thread */}
        <div className="flex flex-col min-h-[60vh] bg-background">
          {!activeConversationId ? (
            <div className="flex-1 flex flex-col items-center justify-center text-center p-8">
              <div className="grid h-16 w-16 place-items-center rounded-2xl border-2 border-border bg-gradient-to-br from-accent/15 to-transparent mb-4">
                <MessageCircle className="h-8 w-8 text-accent/70" strokeWidth={2} />
              </div>
              <h3 className="text-base font-bold text-foreground mb-1.5">
                Pick a conversation
              </h3>
              <p className="text-sm text-muted-foreground max-w-xs">
                Select a conversation on the left, or start a new one with a teammate.
              </p>
            </div>
          ) : (
            <>
              <header className="flex items-center gap-3 border-b-2 border-border px-4 sm:px-5 py-3 sm:py-4 bg-card">
                <div className="grid h-10 w-10 place-items-center rounded-full bg-accent/15 ring-2 ring-accent/40 shrink-0">
                  <UserCircle2 className="h-5 w-5 text-accent" strokeWidth={2.25} />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-base font-bold text-foreground truncate leading-tight">
                    {activeSummary
                      ? conversationLabel(activeSummary)
                      : "Conversation"}
                  </p>
                  <p className="text-[11px] text-muted-foreground mt-0.5">
                    Private to participants
                  </p>
                </div>
                {notifPermission !== "granted" && notifPermission !== "unsupported" && (
                  <Button
                    variant="outline"
                    size="sm"
                    className="gap-1.5 border-2 font-semibold"
                    onClick={() => void requestNotificationPermission()}
                    aria-label="Enable push notifications"
                  >
                    <Bell className="h-3.5 w-3.5" strokeWidth={2.25} />
                    <span className="hidden sm:inline">Enable alerts</span>
                  </Button>
                )}
                {notifPermission === "granted" && (
                  <span
                    className="hidden sm:inline-flex items-center gap-1.5 text-[11px] font-semibold text-emerald-600 dark:text-emerald-400"
                    title="Push notifications are on"
                  >
                    <Bell className="h-3.5 w-3.5" strokeWidth={2.25} />
                    Alerts on
                  </span>
                )}
                {notifPermission === "unsupported" && (
                  <span
                    className="hidden sm:inline-flex items-center gap-1.5 text-[11px] font-medium text-muted-foreground"
                    title="This browser does not support push notifications"
                  >
                    <BellOff className="h-3.5 w-3.5" strokeWidth={2} />
                    No alerts
                  </span>
                )}
                <Button
                  variant="outline"
                  size="sm"
                  className="gap-1.5 border-2 text-destructive hover:text-destructive hover:bg-destructive/10 hover:border-destructive/40 font-semibold"
                  onClick={() => void handleDeleteAllMine()}
                  disabled={messages.deletingAll || (messages.data ?? []).every((m) => m.sender_id !== user?.id)}
                  aria-label="Delete all of your messages in this conversation"
                >
                  {messages.deletingAll ? (
                    <Loader2 className="h-3.5 w-3.5 animate-spin" />
                  ) : (
                    <Trash2 className="h-3.5 w-3.5" strokeWidth={2.25} />
                  )}
                  <span className="hidden sm:inline">Delete mine</span>
                </Button>
              </header>

              <ScrollArea className="flex-1 bg-gradient-to-b from-muted/20 to-background">
                <div className="p-4 sm:p-5 space-y-3">
                  {messages.isLoading ? (
                    <div className="flex items-center justify-center py-8 text-muted-foreground">
                      <Loader2 className="h-4 w-4 animate-spin mr-2" />
                      <span className="text-xs">Loading messages…</span>
                    </div>
                  ) : (messages.data ?? []).length === 0 ? (
                    <p className="text-sm text-muted-foreground text-center py-8">
                      No messages yet — say hi! 👋
                    </p>
                  ) : (
                    (messages.data ?? []).map((m) => {
                      const mine = m.sender_id === user?.id;
                      return (
                        <motion.div
                          key={m.id}
                          initial={{ opacity: 0, y: 6 }}
                          animate={{ opacity: 1, y: 0 }}
                          transition={{ duration: 0.2 }}
                          className={cn(
                            "flex items-end gap-2",
                            mine ? "justify-end" : "justify-start",
                          )}
                        >
                          {!mine && (
                            <div className="grid h-8 w-8 shrink-0 place-items-center rounded-full bg-muted ring-2 ring-border mb-1">
                              <UserCircle2 className="h-4 w-4 text-foreground/70" strokeWidth={2} />
                            </div>
                          )}
                          <div
                            className={cn(
                              "group relative max-w-[85%] sm:max-w-[75%] rounded-2xl px-4 py-2.5 text-sm shadow-soft border-2",
                              mine
                                ? "bg-accent text-accent-foreground rounded-br-md border-accent"
                                : "bg-card text-foreground rounded-bl-md border-border",
                            )}
                          >
                            {mine && (
                              <button
                                type="button"
                                className={cn(
                                  "absolute -right-2 -top-2 inline-flex h-6 w-6 items-center justify-center rounded-full transition-opacity border-2 border-border bg-background text-destructive shadow-soft",
                                  "opacity-0 hover:bg-destructive hover:text-destructive-foreground hover:border-destructive group-hover:opacity-100 focus:opacity-100",
                                  deletingMessageId === m.id && "pointer-events-none opacity-100",
                                )}
                                onClick={() => void handleDeleteMessage(m.id)}
                                disabled={deletingMessageId === m.id || messages.deleting}
                                aria-label="Delete message"
                              >
                                {deletingMessageId === m.id ? (
                                  <Loader2 className="h-3 w-3 animate-spin" />
                                ) : (
                                  <Trash2 className="h-3 w-3" strokeWidth={2.5} />
                                )}
                              </button>
                            )}
                            {!mine && (
                              <p className="text-[10px] font-bold uppercase tracking-wider text-accent mb-1">
                                {profileMap.get(m.sender_id) ??
                                  `Member ${m.sender_id.slice(0, 8)}`}
                              </p>
                            )}
                            {m.image_url && (
                              <a
                                href={m.image_url}
                                target="_blank"
                                rel="noreferrer noopener"
                                className="block mb-1.5 overflow-hidden rounded-xl border-2 border-border/60 bg-muted/40"
                              >
                                <img
                                  src={m.image_url}
                                  alt={m.body?.trim() || "Shared photo"}
                                  loading="lazy"
                                  className="max-h-72 w-auto max-w-full object-cover"
                                />
                              </a>
                            )}
                            {m.body && m.body.trim().length > 0 && (
                              <p className="whitespace-pre-wrap leading-relaxed font-medium">
                                {m.body}
                              </p>
                            )}
                            <p
                              className={cn(
                                "text-[10px] mt-1 tabular-nums font-medium",
                                mine
                                  ? "text-accent-foreground/75"
                                  : "text-muted-foreground",
                              )}
                            >
                              {formatTimestamp(m.created_at)}
                            </p>
                          </div>
                        </motion.div>
                      );
                    })
                  )}
                  <div ref={messagesEndRef} />
                </div>
              </ScrollArea>
              <Separator className="bg-border h-[2px]" />
              <div className="p-3 sm:p-4 flex items-center gap-2 bg-card">
                <input
                  ref={imageInputRef}
                  type="file"
                  accept="image/png,image/jpeg,image/webp,image/gif,image/heic"
                  className="hidden"
                  onChange={(e) => void handleImageFileChange(e)}
                />
                <Button
                  type="button"
                  variant="outline"
                  size="icon"
                  className="h-11 w-11 shrink-0 border-2"
                  onClick={handlePickImage}
                  disabled={messages.sendingImage}
                  aria-label="Send a picture"
                  title="Send a picture"
                >
                  {messages.sendingImage ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    <ImagePlus className="h-4 w-4" strokeWidth={2.25} />
                  )}
                </Button>
                <Input
                  value={draft}
                  onChange={(e) => setDraft(e.target.value)}
                  placeholder="Type a message…"
                  onKeyDown={(e) => {
                    if (e.key === "Enter" && !e.shiftKey) {
                      e.preventDefault();
                      void handleSend();
                    }
                  }}
                  className="h-11 border-2 text-sm font-medium focus-visible:ring-2"
                />
                <Button
                  variant="gold"
                  size="icon"
                  className="h-11 w-11 shrink-0 shadow-soft"
                  onClick={() => void handleSend()}
                  disabled={messages.sending || !draft.trim()}
                  aria-label="Send message"
                >
                  {messages.sending ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    <Send className="h-4 w-4" strokeWidth={2.5} />
                  )}
                </Button>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
};

export default Messages;
