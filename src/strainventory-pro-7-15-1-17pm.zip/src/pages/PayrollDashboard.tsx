import { useMemo } from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import {
  DollarSign, Clock, FileText, Users, TrendingUp, CalendarDays, Loader2, PlayCircle,
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { useUserRoles } from "@/hooks/useUserRoles";
import { useProfileMap } from "@/hooks/useProfiles";
import { usePayPeriods, useMyPayslips, usePayslips } from "@/lib/payroll/payroll.api";
import PayrollSummaryCard from "@/components/payroll/PayrollSummaryCard";
import PayPeriodList from "@/components/payroll/PayPeriodList";
import MyPaystubsList from "@/components/payroll/MyPaystubsList";
import LatestPeriodBreakdown from "@/components/payroll/LatestPeriodBreakdown";
import PayrollExceptionsPanel from "@/components/payroll/PayrollExceptionsPanel";
import { formatCurrency } from "@/lib/payroll/payrollFormatters";

const PayrollDashboard = () => {
  const navigate = useNavigate();
  const { isAdmin } = useUserRoles();
  const profileMap = useProfileMap();
  const { data: payPeriods = [], isLoading: loadingPeriods } = usePayPeriods();
  const { data: myPayslips = [], isLoading: loadingMySlips } = useMyPayslips();
  const latestPeriod = payPeriods[0];
  const { data: latestSlips = [] } = usePayslips(latestPeriod?.id ?? "");

  const summaryStats = useMemo(() => {
    const totalPaid = payPeriods
      .filter((p) => p.status === "paid")
      .reduce((s, p) => s + (p.total_wages ?? 0), 0);
    const totalOT = payPeriods.reduce((s, p) => s + (p.total_ot_hours ?? 0), 0);
    const draftCount = payPeriods.filter((p) => p.status === "draft").length;
    return { totalPaid, totalOT, draftCount, periodCount: payPeriods.length };
  }, [payPeriods]);

  const isLoading = loadingPeriods || loadingMySlips;

  if (isLoading) {
    return (
      <div className="flex min-h-[400px] items-center justify-center">
        <Loader2 className="h-6 w-6 animate-spin text-accent" />
      </div>
    );
  }

  return (
    <div className="p-4 sm:p-6 lg:p-10 max-w-7xl mx-auto">
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-8">
        <div className="flex items-center gap-4">
          <div className="h-12 w-12 rounded-xl gold-gradient flex items-center justify-center shadow-gold shrink-0">
            <DollarSign className="h-6 w-6 text-accent-foreground" />
          </div>
          <div>
            <h1 className="text-display text-3xl sm:text-4xl font-semibold tracking-tight text-foreground flex items-center gap-2">
              Payroll
              <span className="h-2 w-2 rounded-full bg-success animate-pulse" />
            </h1>
            <p className="text-muted-foreground text-sm sm:text-base mt-1">
              {isAdmin
                ? "Manage payroll runs, view employee compensation, and export reports."
                : "View your paystubs and compensation history."}
            </p>
          </div>
        </div>
        {isAdmin && (
          <Button variant="gold" size="lg" className="gap-2 border-2 border-accent shadow-gold" onClick={() => navigate("/payroll/run")}>
            <PlayCircle className="h-4 w-4" />
            Run Payroll
          </Button>
        )}
      </motion.div>

      {isAdmin && (
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4 mb-8">
          <PayrollSummaryCard icon={DollarSign} label="Total Paid Out" value={formatCurrency(summaryStats.totalPaid)} accent="gold" delay={0.1} />
          <PayrollSummaryCard icon={Clock} label="Premium Hours" value={`${summaryStats.totalOT.toFixed(1)} hrs`} accent="default" delay={0.15} />
          <PayrollSummaryCard icon={CalendarDays} label="Pay Periods" value={String(summaryStats.periodCount)} accent="default" delay={0.2} />
          <PayrollSummaryCard icon={FileText} label="Pending Drafts" value={String(summaryStats.draftCount)} accent="gold" delay={0.25} />
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
        <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }} className="lg:col-span-3">
          <Card className="border-2 border-border bg-card shadow-elevated rounded-2xl">
            <CardHeader className="pb-3">
              <CardTitle className="text-base flex items-center gap-2">
                <CalendarDays className="h-4 w-4 text-accent" />
                {isAdmin ? "Pay Periods" : "My Paystubs"}
              </CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              {isAdmin ? <PayPeriodList payPeriods={payPeriods} /> : <MyPaystubsList payslips={myPayslips} />}
            </CardContent>
          </Card>
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }} className="lg:col-span-2">
          {isAdmin && latestPeriod ? (
            <Card className="border-2 border-border bg-card shadow-elevated rounded-2xl">
              <CardHeader className="pb-3">
                <CardTitle className="text-base flex items-center gap-2">
                  <Users className="h-4 w-4 text-accent" />
                  Latest Period Breakdown
                </CardTitle>
              </CardHeader>
              <CardContent className="p-0">
                <LatestPeriodBreakdown payslips={latestSlips} profileMap={profileMap} />
              </CardContent>
            </Card>
          ) : (
            <Card className="border-2 border-border bg-card shadow-elevated rounded-2xl">
              <CardHeader className="pb-3">
                <CardTitle className="text-base flex items-center gap-2">
                  <TrendingUp className="h-4 w-4 text-accent" />
                  Quick Stats
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-muted-foreground">Total Paystubs</span>
                    <span className="text-sm font-semibold text-foreground">{myPayslips.length}</span>
                  </div>
                  <Separator />
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-muted-foreground">Total Earned</span>
                    <span className="text-sm font-semibold text-accent tabular-nums">
                      {formatCurrency(myPayslips.reduce((s, p) => s + p.net_pay, 0))}
                    </span>
                  </div>
                  <Separator />
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-muted-foreground">Total Premium Hours</span>
                    <span className="text-sm font-semibold text-foreground tabular-nums">
                      {myPayslips.reduce((s, p) => s + p.ot_hours, 0).toFixed(1)}
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {isAdmin && latestPeriod && (
            <div className="mt-4">
              <PayrollExceptionsPanel payPeriodId={latestPeriod.id} />
            </div>
          )}

          <Card className="border-2 border-accent/40 bg-card shadow-elevated rounded-2xl mt-4">
            <CardContent className="p-4">
              <p className="text-xs font-semibold text-accent mb-1">California Compliance</p>
              <p className="text-xs text-muted-foreground leading-relaxed">
                All payroll calculations follow CA Labor Code: daily OT after 8 hrs, double-time after 12 hrs,
                and 7th consecutive workday premium rates. Payslips include itemized deductions as required
                by Labor Code §226.
              </p>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
};

export default PayrollDashboard;
