import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { AlertTriangle, ArrowLeft, DollarSign, FileSpreadsheet, Loader2 } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle,
} from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import { useUserRoles } from "@/hooks/useUserRoles";
import { usePayrollRun } from "@/hooks/usePayrollRun";
import { useCheckTemplates } from "@/hooks/useCheckTemplates";
import PayrollPeriodForm from "@/components/payroll/PayrollPeriodForm";
import PayrollTotalsCard from "@/components/payroll/PayrollTotalsCard";
import PayrollPreviewTable from "@/components/payroll/PayrollPreviewTable";
import PayrollActions from "@/components/payroll/PayrollActions";
import PayrollCsvImportDialog from "@/components/payroll/PayrollCsvImportDialog";
import { payrollStatusColors } from "@/lib/payroll/payrollFormatters";


const PayrollRun = () => {
  const navigate = useNavigate();
  const { isAdmin } = useUserRoles();
  const r = usePayrollRun();
  const { data: templates = [] } = useCheckTemplates();
  const activeTemplates = templates.filter((t) => t.is_active);
  const [checksDialogOpen, setChecksDialogOpen] = useState(false);
  const [selectedTemplateId, setSelectedTemplateId] = useState<string>("");
  const [csvOpen, setCsvOpen] = useState(false);

  const openChecksDialog = () => {
    if (activeTemplates.length === 0) {
      toast.error("Add a check template in Settings → Payroll first.");
      return;
    }
    const preferred = activeTemplates.find((t) => t.is_default) ?? activeTemplates[0];
    setSelectedTemplateId(preferred.id);
    setChecksDialogOpen(true);
  };

  const confirmPrintChecks = async () => {
    const tpl = activeTemplates.find((t) => t.id === selectedTemplateId);
    if (!tpl) return;
    setChecksDialogOpen(false);
    await r.handlePrintChecks(tpl);
  };

  if (!isAdmin) {
    return (
      <div className="p-6 lg:p-10 max-w-3xl">
        <Card className="border-2 border-border bg-card shadow-elevated rounded-2xl">
          <CardContent className="p-8 text-center">
            <AlertTriangle className="h-8 w-8 text-warning mx-auto mb-3" />
            <h2 className="text-lg font-semibold text-foreground mb-1">Admin Access Required</h2>
            <p className="text-sm text-muted-foreground">Only administrators can run payroll.</p>
            <Button variant="outline" className="mt-4" onClick={() => navigate("/payroll")}>
              Back to Payroll
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="p-4 sm:p-6 lg:p-10 max-w-7xl mx-auto">
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex items-center gap-3 mb-8">
        <Button variant="ghost" size="icon" className="border-2 border-border hover:border-accent rounded-xl h-10 w-10" onClick={() => navigate("/payroll")}>
          <ArrowLeft className="h-4 w-4" />
        </Button>
        <div className="h-11 w-11 rounded-xl gold-gradient flex items-center justify-center shadow-gold shrink-0">
          <DollarSign className="h-5 w-5 text-accent-foreground" />
        </div>
        <div className="flex-1 min-w-0">
          <h1 className="text-display text-2xl sm:text-3xl font-semibold tracking-tight text-foreground">Run Payroll</h1>
          <p className="text-sm text-muted-foreground">
            Select a pay period, preview calculations, then save, issue, or export.
          </p>
        </div>
        <Button
          variant="outline"
          size="sm"
          className="gap-1.5 ml-auto shrink-0"
          onClick={() => setCsvOpen(true)}
        >
          <FileSpreadsheet className="h-4 w-4" /> Import CSV
        </Button>
      </motion.div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} className="lg:col-span-1 space-y-4">
          <PayrollPeriodForm
            startDate={r.startDate}
            endDate={r.endDate}
            isCalculating={r.isCalculating}
            isLoading={r.isLoading}
            activeProfileCount={r.activeProfiles.length}
            onStartDateChange={r.handleStartDateChange}
            onEndDateChange={r.handleEndDateChange}
            onCalculate={r.handleCalculate}
          />

          {r.calculated && <PayrollTotalsCard totals={r.totals} />}

          {r.savedRunStatus && (
            <Card className="border-2 border-border bg-card shadow-elevated rounded-2xl">
              <CardHeader className="pb-2">
                <CardTitle className="text-base">Run Status</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Current status</span>
                  <Badge variant="secondary" className={cn("text-[10px] uppercase tracking-wider", payrollStatusColors[r.savedRunStatus])}>
                    {r.savedRunStatus}
                  </Badge>
                </div>
                <p className="text-xs text-muted-foreground leading-relaxed">
                  {r.savedRunStatus === "paid"
                    ? "This payroll run is saved and marked as paid. You can export the paycheck packet again at any time."
                    : "This payroll run is saved as processed. Issue paychecks when you are ready to mark the period paid and export the packet."}
                </p>
              </CardContent>
            </Card>
          )}
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="lg:col-span-2">
          <Card className="border-2 border-border bg-card shadow-elevated rounded-2xl overflow-hidden">
            <div className="flex items-center justify-between px-5 py-3 border-b border-border gap-3">
              <div className="flex items-center gap-2">
                <p className="text-sm font-semibold text-foreground flex items-center gap-2">
                  <DollarSign className="h-4 w-4 text-accent" />
                  Payroll Preview
                </p>
                {r.savedRunStatus && (
                  <Badge variant="secondary" className={cn("text-[10px] uppercase tracking-wider", payrollStatusColors[r.savedRunStatus])}>
                    {r.savedRunStatus}
                  </Badge>
                )}
              </div>
              {r.calculated && (
                <PayrollActions
                  hasPreviewResults={r.hasPreviewResults}
                  isProcessing={r.isProcessing}
                  isIssuing={r.isIssuing}
                  isExportingSummaryPdf={r.isExportingSummaryPdf}
                  isPrintingChecks={r.isPrintingChecks}
                  savedRunId={r.savedRunId}
                  issueButtonLabel={r.issueButtonLabel}
                  onExportCSV={r.handleExportCSV}
                  onExportSummaryPdf={r.handleExportSummaryPdf}
                  onProcess={r.handleProcess}
                  onIssuePaychecks={r.handleIssuePaychecks}
                  onPrintChecks={openChecksDialog}
                />
              )}
            </div>

            <PayrollPreviewTable
              calculated={r.calculated}
              breakdowns={r.breakdowns}
              profileMap={r.profileMap}
            />
          </Card>

          {r.hasPreviewResults && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.3 }}>
              <Card className="border-2 border-accent/40 bg-card shadow-elevated rounded-2xl mt-4">
                <CardContent className="p-4 flex items-start gap-3">
                  <Badge variant="secondary" className="text-[9px] uppercase tracking-wider bg-accent/15 text-accent-foreground mt-0.5 shrink-0">
                    CA
                  </Badge>
                  <p className="text-xs text-muted-foreground leading-relaxed">
                    Calculations include California daily overtime (1.5x after 8 hrs), double-time (2x after 12 hrs),
                    and 7th consecutive workday premium. Review the breakdown before saving or issuing paychecks.
                  </p>
                </CardContent>
              </Card>
            </motion.div>
          )}
        </motion.div>
      </div>

      <Dialog open={checksDialogOpen} onOpenChange={setChecksDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Print Payroll Checks</DialogTitle>
            <DialogDescription>
              Pick which check template to use. One check will be printed per employee with positive net pay,
              starting from the template's next check number.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-3">
            <Select value={selectedTemplateId} onValueChange={setSelectedTemplateId}>
              <SelectTrigger><SelectValue placeholder="Select check template" /></SelectTrigger>
              <SelectContent>
                {activeTemplates.map((t) => (
                  <SelectItem key={t.id} value={t.id}>
                    {t.name} — {t.bank_name} (next #{t.next_check_number})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <p className="text-xs text-muted-foreground">
              Printing {r.breakdowns.filter((b) => b.net_pay > 0).length} check(s).
            </p>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setChecksDialogOpen(false)}>Cancel</Button>
            <Button variant="gold" onClick={confirmPrintChecks} disabled={!selectedTemplateId || r.isPrintingChecks}>
              {r.isPrintingChecks && <Loader2 className="h-4 w-4 animate-spin mr-1.5" />}
              Print
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <PayrollCsvImportDialog
        open={csvOpen}
        onOpenChange={setCsvOpen}
        profileMap={r.profileMap}
      />
    </div>
  );
};

export default PayrollRun;
