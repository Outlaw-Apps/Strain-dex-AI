import { useState, useMemo, useCallback, useEffect } from "react";
import { Printer, ShoppingCart } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { useProducts, type Product } from "@/hooks/useProducts";
import { useCreateOrder } from "@/hooks/useOrders";
import type { Customer } from "@/hooks/useCustomers";
import { ProductGrid } from "@/components/pos/ProductGrid";
import { CartPanel } from "@/components/pos/CartPanel";
import { CustomerPanel } from "@/components/pos/CustomerPanel";
import { DailyLimitTracker } from "@/components/pos/DailyLimitTracker";
import { computeDailyLimits } from "@/lib/dailyLimits";
import { getCartLineTotal, getWeightedUnitPrice } from "@/lib/posPricing";
import {
  calculateCartPricing,
  DEFAULT_POS_TAX_RATE,
} from "@/lib/discounts/discountEngine";
import type { TicketPromotionSelection } from "@/lib/discounts/types";
import type { Json } from "@/integrations/supabase/types";
import { BOGO_DEFINITION_ID } from "@/lib/discounts/builtins";
import { useManagerOverride } from "@/hooks/useManagerOverride";
import { usePosDiscountPermissions } from "@/hooks/usePosDiscountPermissions";
import { CardTerminalModal, type CardTerminalStatus } from "@/components/pos/CardTerminalModal";
import { ReceiptPrint, type ReceiptData } from "@/components/pos/ReceiptPrint";
import { ReceiptSuccessDialog } from "@/components/pos/ReceiptSuccessDialog";
import { CheckoutConfirmDialog, type CheckoutConfirmData } from "@/components/pos/CheckoutConfirmDialog";
import { useAutoPrintReceipts } from "@/hooks/usePosLocalSettings";

export interface CartItem extends Product {
  qty: number;
  weight: string;
}

const TAX_RATE = DEFAULT_POS_TAX_RATE;

const PointOfSale = () => {
  const { data: products = [], isLoading } = useProducts();
  const createOrder = useCreateOrder();
  const managerOverride = useManagerOverride();
  const posDiscountPermissions = usePosDiscountPermissions();

  const employeePricingOk =
    managerOverride.overrideActive || posDiscountPermissions.applyEmployeeDiscountWithoutOverride;
  const [search, setSearch] = useState("");
  const [cart, setCart] = useState<CartItem[]>([]);
  const [processing, setProcessing] = useState(false);
  const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(null);
  const [cardTerminal, setCardTerminal] = useState<{ open: boolean; status: CardTerminalStatus }>({
    open: false,
    status: "awaiting",
  });
  const [ticketPromotion, setTicketPromotion] = useState<TicketPromotionSelection>({
    kind: "none",
  });
  const [receipt, setReceipt] = useState<ReceiptData | null>(null);
  const [receiptOpen, setReceiptOpen] = useState(false);
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [pendingMethod, setPendingMethod] = useState<string | null>(null);
  const [checkoutMeta, setCheckoutMeta] = useState<CheckoutConfirmData | null>(null);
  const { autoPrint, setAutoPrint } = useAutoPrintReceipts();

  useEffect(() => {
    if (cart.length === 0) setTicketPromotion({ kind: "none" });
  }, [cart.length]);

  const isOverLimit = useMemo(() => computeDailyLimits(cart).isOverLimit, [cart]);

  const publishedProducts = useMemo(
    () => products.filter((p) => p.status === "published"),
    [products],
  );

  const filtered = useMemo(
    () =>
      publishedProducts.filter(
        (p) =>
          p.name.toLowerCase().includes(search.toLowerCase()) ||
          p.brand.toLowerCase().includes(search.toLowerCase()) ||
          p.type.toLowerCase().includes(search.toLowerCase()),
      ),
    [publishedProducts, search],
  );

  const pricing = useMemo(
    () =>
      calculateCartPricing({
        cart,
        customer: selectedCustomer,
        taxRate: TAX_RATE,
        ticket: ticketPromotion,
        employeeDiscountManagerOk: employeePricingOk,
      }),
    [cart, selectedCustomer, ticketPromotion, employeePricingOk],
  );

  useEffect(() => {
    if (posDiscountPermissions.loading) return;
    if (ticketPromotion.kind === "bogo" && !posDiscountPermissions.applyBogoDiscount) {
      setTicketPromotion({ kind: "none" });
      return;
    }
    if (ticketPromotion.kind === "customer") {
      const id = ticketPromotion.definitionId;
      if (id === "cust-employee") {
        if (!employeePricingOk) setTicketPromotion({ kind: "none" });
      } else if (!posDiscountPermissions.applyStandardDiscount) {
        setTicketPromotion({ kind: "none" });
      }
    }
  }, [
    posDiscountPermissions.loading,
    posDiscountPermissions.applyBogoDiscount,
    posDiscountPermissions.applyStandardDiscount,
    employeePricingOk,
    ticketPromotion,
  ]);

  const addToCart = useCallback((product: Product) => {
    setCart((prev) => {
      const existing = prev.find((i) => i.id === product.id);
      if (existing) return prev.map((i) => (i.id === product.id ? { ...i, qty: i.qty + 1 } : i));
      return [...prev, { ...product, qty: 1, weight: "1g" }];
    });
    toast.success(`${product.name} added`);
  }, []);

  const updateQty = useCallback((id: string, delta: number) => {
    setCart((prev) =>
      prev.map((i) => (i.id === id ? { ...i, qty: Math.max(0, i.qty + delta) } : i)).filter((i) => i.qty > 0),
    );
  }, []);

  const removeFromCart = useCallback((id: string) => setCart((prev) => prev.filter((i) => i.id !== id)), []);
  const updateWeight = useCallback((id: string, weight: string) =>
    setCart((prev) => prev.map((i) => (i.id === id ? { ...i, weight } : i))), []);

  const validateCheckout = () => {
    if (cart.length === 0) { toast.error("Cart is empty"); return false; }
    if (isOverLimit) { toast.error("Daily legal limit exceeded. Remove items before checkout."); return false; }
    if (!posDiscountPermissions.loading) {
      if (ticketPromotion.kind === "bogo" && !posDiscountPermissions.applyBogoDiscount) {
        toast.error("Your role cannot apply BOGO promotions.");
        return false;
      }
      if (ticketPromotion.kind === "customer") {
        const id = ticketPromotion.definitionId;
        if (id === "cust-employee" && !employeePricingOk) {
          toast.error("Employee discount requires lead approval or Manager Override.");
          return false;
        }
        if (id !== "cust-employee" && !posDiscountPermissions.applyStandardDiscount) {
          toast.error("Your role cannot apply this customer discount.");
          return false;
        }
      }
    }
    return true;
  };

  const submitOrder = async (method: string, meta: CheckoutConfirmData | null) => {
    setProcessing(true);
    try {
      const order = await createOrder.mutateAsync({
        customer_id: selectedCustomer?.id ?? null,
        payment_method: method,
        subtotal: pricing.taxableSubtotal,
        tax: pricing.tax,
        total: pricing.grandTotal,
        discount_total: pricing.discountTotal,
        discount_summary: pricing.discountSummary,
        discount_snapshot_json: pricing.snapshot as unknown as Json,
        discount_manager_override_used:
          ticketPromotion.kind === "customer" &&
          ticketPromotion.definitionId === "cust-employee" &&
          managerOverride.overrideActive,
        customer_name_override: meta?.customerName ?? null,
        customer_age: meta?.customerAge ?? null,
        cashier_short_id: meta?.cashierShortId ?? null,
        items: cart.map((item) => {
          const ln = pricing.lines.find((l) => l.cartLineId === item.id);
          if (!ln) {
            throw new Error(`Missing pricing row for cart item ${item.id}`);
          }

          const listLine = getCartLineTotal(Number(item.price) || 0, item.weight, item.qty);
          const ids = [...ln.appliedAutomaticIds];
          if (ticketPromotion.kind === "customer") ids.push(ticketPromotion.definitionId);
          if (ticketPromotion.kind === "bogo") ids.push(BOGO_DEFINITION_ID);
          const applied_discount_ids = [...new Set(ids)];

          const rawDiscount = Number.isFinite(ln.lineTotalFinal)
            ? Math.round((listLine - ln.lineTotalFinal) * 100) / 100
            : 0;
          const discount_amount = Math.max(0, rawDiscount);

          const safeUnitPrice = Number.isFinite(ln.discountedUnitPrice) ? ln.discountedUnitPrice : 0;
          const safeTotalPrice = Number.isFinite(ln.lineTotalFinal) ? ln.lineTotalFinal : 0;
          const safeListUnitPrice = Number.isFinite(ln.listUnitPrice) ? ln.listUnitPrice : 0;

          return {
            product_id: item.id,
            product_name: item.name,
            weight: item.weight,
            quantity: item.qty,
            unit_price: safeUnitPrice,
            total_price: safeTotalPrice,
            base_unit_price: safeListUnitPrice,
            discounted_unit_price: safeUnitPrice,
            discount_amount,
            applied_discount_ids,
          };
        }),
      });
      toast.success(`Payment of $${pricing.grandTotal.toFixed(2)} processed via ${method}`);

      // Capture receipt snapshot BEFORE clearing cart
      const receiptData: ReceiptData = {
        transactionId: (order?.id ?? `T-${Date.now()}`).toString().slice(0, 12).toUpperCase(),
        dateISO: new Date().toISOString(),
        paymentMethod: method,
        customerName: meta?.customerName ?? selectedCustomer?.name ?? null,
        subtotal: pricing.taxableSubtotal,
        discountTotal: pricing.discountTotal,
        tax: pricing.tax,
        total: pricing.grandTotal,
        items: cart.map((item) => {
          const ln = pricing.lines.find((l) => l.cartLineId === item.id);
          const unit = ln?.discountedUnitPrice ?? getWeightedUnitPrice(Number(item.price) || 0, item.weight);
          const total = ln?.lineTotalFinal ?? unit * item.qty;
          return {
            name: item.name,
            weight: item.weight,
            qty: item.qty,
            unitPrice: unit,
            total,
          };
        }),
      };
      setReceipt(receiptData);
      setReceiptOpen(true);

      setCart([]);
      setSelectedCustomer(null);
      setTicketPromotion({ kind: "none" });
      setCheckoutMeta(null);
      return true;
    } catch (error) {
      console.error("Checkout error:", error);
      const message = error instanceof Error ? error.message : "Checkout failed";
      toast.error(message);
      return false;
    } finally {
      setProcessing(false);
    }
  };

  const handleCheckout = async (method: string) => {
    if (!validateCheckout()) return;
    setPendingMethod(method);
    setConfirmOpen(true);
  };

  const handleConfirmed = async (data: CheckoutConfirmData) => {
    setCheckoutMeta(data);
    setConfirmOpen(false);
    const method = pendingMethod ?? "Cash";
    if (method === "Card") {
      setCardTerminal({ open: true, status: "awaiting" });
      return;
    }
    await submitOrder(method, data);
    setPendingMethod(null);
  };

  const handleConfirmCancel = () => {
    setConfirmOpen(false);
    setPendingMethod(null);
  };

  const handleCardApproved = useCallback(async () => {
    setCardTerminal((s) => (s.status === "awaiting" ? { open: true, status: "approved" } : s));
    // Let the approval flash for a beat, then post the order.
    setTimeout(async () => {
      setCardTerminal({ open: true, status: "posting" });
      const ok = await submitOrder("Card", checkoutMeta);
      setCardTerminal({ open: false, status: "awaiting" });
      setPendingMethod(null);
      if (!ok) {
        // submitOrder already surfaced the toast
      }
    }, 1100);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [cart, pricing, selectedCustomer, ticketPromotion, checkoutMeta]);

  const handleCardCancel = useCallback(() => {
    setCardTerminal({ open: false, status: "awaiting" });
    setPendingMethod(null);
    toast.info("Card payment cancelled");
  }, []);

  return (
    <div className="flex flex-col lg:flex-row h-[calc(100vh-3.5rem)] lg:h-[calc(100vh-64px)] overflow-hidden bg-background">
      <h1 className="sr-only">Point of Sale</h1>
      {/* Product Grid */}
      <div className="flex-1 min-h-0 overflow-hidden flex flex-col">
        <ProductGrid
          products={filtered}
          isLoading={isLoading}
          search={search}
          onSearchChange={setSearch}
          onAddToCart={addToCart}
        />
      </div>
  
      {/* Right Sidebar - fixed width, full height, internal scrolling */}
      <div className="w-full lg:w-80 xl:w-96 flex-1 lg:flex-none min-h-0 flex flex-col overflow-y-auto bg-card border-t-2 lg:border-t-0 lg:border-l-2 border-border shadow-xl lg:shadow-none z-10">
        {/* Header */}
        <div className="p-4 border-b-2 border-border flex-shrink-0 bg-gradient-to-r from-card to-accent/[0.03]">
          <div className="flex items-center gap-2.5">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl gold-gradient ring-1 ring-border/60">
              <ShoppingCart className="h-4 w-4 text-accent-foreground" strokeWidth={2.5} />
            </div>
            <div className="flex-1 min-w-0">
              <h2 className="text-sm font-bold text-foreground tracking-tight">Current Order</h2>
              <p className="text-[10px] text-muted-foreground">{cart.length} items in cart</p>
            </div>
            <Badge variant="secondary" className="text-[11px] font-bold tabular-nums px-2.5 py-0.5">
              {cart.length}
            </Badge>
          </div>
          <div className="mt-2.5 flex items-center justify-between gap-2 rounded-lg border border-border/60 bg-muted/40 px-2.5 py-1.5">
            <Label
              htmlFor="auto-print-toggle"
              className="flex items-center gap-1.5 text-[11px] font-semibold text-foreground cursor-pointer"
            >
              <Printer className="h-3.5 w-3.5 text-muted-foreground" strokeWidth={2.5} />
              Auto-Print Receipts
            </Label>
            <Switch
              id="auto-print-toggle"
              checked={autoPrint}
              onCheckedChange={setAutoPrint}
            />
          </div>
        </div>
  
        <CustomerPanel
          selectedCustomer={selectedCustomer}
          onSelectCustomer={setSelectedCustomer}
          publishedProducts={publishedProducts}
          onAddToCart={addToCart}
        />
  
        <DailyLimitTracker cart={cart} />
  
        {/* Scrollable Cart Area */}
        <div className="flex-1 overflow-auto flex flex-col min-h-0">
          <CartPanel
            cart={cart}
            processing={processing}
            isOverLimit={isOverLimit}
            onUpdateQty={updateQty}
            onRemove={removeFromCart}
            onUpdateWeight={updateWeight}
            onCheckout={handleCheckout}
            pricing={pricing}
            taxRate={TAX_RATE}
            customer={selectedCustomer}
            ticketPromotion={ticketPromotion}
            onTicketPromotionChange={setTicketPromotion}
            managerOverride={managerOverride}
            posDiscountPermissions={posDiscountPermissions}
            employeePricingOk={employeePricingOk}
          />
        </div>
      </div>

      <CardTerminalModal
        open={cardTerminal.open}
        status={cardTerminal.status}
        amount={pricing.grandTotal}
        onSimulateTap={handleCardApproved}
        onCancel={handleCardCancel}
      />

      <ReceiptSuccessDialog
        open={receiptOpen}
        data={receipt}
        autoPrint={autoPrint}
        onClose={() => setReceiptOpen(false)}
      />

      <ReceiptPrint data={receipt} />

      <CheckoutConfirmDialog
        open={confirmOpen}
        paymentMethod={pendingMethod ?? "Cash"}
        amount={pricing.grandTotal}
        defaultCustomerName={selectedCustomer?.name ?? null}
        onCancel={handleConfirmCancel}
        onConfirm={handleConfirmed}
      />
    </div>
  );
};

export default PointOfSale;
