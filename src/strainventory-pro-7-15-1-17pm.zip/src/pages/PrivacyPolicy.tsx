import { Link } from "react-router-dom";
import { ArrowLeft, ShieldCheck } from "lucide-react";
import { Button } from "@/components/ui/button";
import Seo from "@/components/Seo";

const SUPPORT_EMAIL = "support@strainventory.com";
const EFFECTIVE_DATE = "June 22, 2026";

const PrivacyPolicy = () => (
  <div className="min-h-screen bg-background text-foreground">
    <Seo
      title="Privacy Policy | Strain-ventory"
      description="How Strain-ventory collects, uses, and protects data for cannabis dispensaries and their staff."
      path="/privacy"
    />
    <div className="max-w-3xl mx-auto px-6 py-12">
      <Button asChild variant="ghost" size="sm" className="mb-6 gap-1.5">
        <Link to="/">
          <ArrowLeft className="h-4 w-4" /> Back
        </Link>
      </Button>

      <div className="flex items-center gap-3 mb-6">
        <div className="h-12 w-12 rounded-xl gold-gradient flex items-center justify-center shadow-gold">
          <ShieldCheck className="h-6 w-6 text-accent-foreground" />
        </div>
        <div>
          <h1 className="text-display text-3xl sm:text-4xl font-semibold tracking-tight">
            Privacy Policy
          </h1>
          <p className="text-sm text-muted-foreground mt-1">
            Effective {EFFECTIVE_DATE}
          </p>
        </div>
      </div>

      <div className="prose prose-invert max-w-none space-y-6 text-sm leading-relaxed text-muted-foreground">
        <p>
          This page is maintained by Strain-ventory to explain how the
          Strain-ventory dispensary platform ("the Service") collects, uses, and
          protects information for the cannabis retailers and staff who use it.
        </p>

        <section>
          <h2 className="text-base font-semibold text-foreground">
            1. Information we collect
          </h2>
          <ul className="list-disc pl-5 space-y-1">
            <li>
              <strong>Account data</strong> — email, display name, short ID,
              role, and (for staff) hashed PIN credentials.
            </li>
            <li>
              <strong>Operational data</strong> — products, inventory, sales,
              orders, customers, time entries, schedules, and payroll records
              you enter into the platform.
            </li>
            <li>
              <strong>Device / session data</strong> — IP address, browser
              metadata, and timestamps required to keep your session secure.
            </li>
            <li>
              <strong>Location data</strong> — only when geofenced clock-in is
              enabled by your administrator, and only at the moment a clock
              event is recorded.
            </li>
          </ul>
        </section>

        <section>
          <h2 className="text-base font-semibold text-foreground">
            2. How we use information
          </h2>
          <p>
            We use the information above to operate the Service, authenticate
            users, generate AI product drafts, sync compliance data with
            Metrc-style state systems, and produce the reports and analytics
            you request. We do not sell personal information.
          </p>
        </section>

        <section>
          <h2 className="text-base font-semibold text-foreground">
            3. Sharing and subprocessors
          </h2>
          <p>
            The Service relies on managed infrastructure (database, storage,
            authentication, and AI model gateways) to function. These providers
            process data only on our behalf and are bound by their own data
            protection commitments. We share data with third parties you
            explicitly connect, such as your e-commerce storefront or state
            traceability system.
          </p>
        </section>

        <section>
          <h2 className="text-base font-semibold text-foreground">
            4. Retention and deletion
          </h2>
          <p>
            Operational records are retained for as long as your dispensary
            account is active or as required by applicable cannabis regulations.
            Administrators can adjust AI draft retention from Settings →
            Preferences. To request deletion of your individual account or a
            specific record, contact{" "}
            <a className="text-accent" href={`mailto:${SUPPORT_EMAIL}`}>
              {SUPPORT_EMAIL}
            </a>
            .
          </p>
        </section>

        <section>
          <h2 className="text-base font-semibold text-foreground">
            5. Security
          </h2>
          <p>
            Access is protected by authentication, row-level security policies,
            and role-based permissions. Staff PINs are stored hashed; passwords
            are never stored in plain text. No system is perfectly secure —
            report suspected vulnerabilities to{" "}
            <a className="text-accent" href={`mailto:${SUPPORT_EMAIL}`}>
              {SUPPORT_EMAIL}
            </a>
            .
          </p>
        </section>

        <section>
          <h2 className="text-base font-semibold text-foreground">
            6. Your choices
          </h2>
          <p>
            You can update your display name and password from Settings →
            Account. Administrators can manage staff accounts from Settings →
            User Accounts. To request a copy or deletion of your personal data,
            email us at{" "}
            <a className="text-accent" href={`mailto:${SUPPORT_EMAIL}`}>
              {SUPPORT_EMAIL}
            </a>
            .
          </p>
        </section>

        <section>
          <h2 className="text-base font-semibold text-foreground">
            7. Changes to this policy
          </h2>
          <p>
            We may update this policy as the Service evolves. Material changes
            will be communicated in-app or by email to administrators.
          </p>
        </section>

        <section>
          <h2 className="text-base font-semibold text-foreground">
            8. Contact
          </h2>
          <p>
            Questions or privacy requests:{" "}
            <a className="text-accent" href={`mailto:${SUPPORT_EMAIL}`}>
              {SUPPORT_EMAIL}
            </a>
            .
          </p>
        </section>
      </div>
    </div>
  </div>
);

export default PrivacyPolicy;
