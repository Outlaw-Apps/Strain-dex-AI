import { useState, useEffect, useRef, useMemo } from "react";
import type { Json } from "@/integrations/supabase/types";
import { useParams, useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import {
  ArrowLeft, Edit3, Save, X, Package, Leaf, Beaker,
  FileText, Image as ImageIcon, Tag, AlertTriangle, Loader2, Upload, Trash2, Sparkles,
  DollarSign,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { toast } from "sonner";
import { cn } from "@/lib/utils";
import { useProduct, useProducts, type Product } from "@/hooks/useProducts";
import { supabase } from "@/integrations/supabase/client";
import { useQueryClient } from "@tanstack/react-query";
import { useCatalogImageSearch } from "@/hooks/useCatalogImageSearch";
import { selectBestCatalogImage, syncCatalogImageToProduct } from "@/lib/catalogImages";
import { EDGE_FUNCTIONS, ENV } from "@/lib/constants";
import { buildCatalogAiUpdateFromDraft } from "@/lib/aiDraftTools";
import { datetimeLocalValueToIso, isoToDatetimeLocalValue } from "@/lib/datetimeLocal";

const statusStyles: Record<string, string> = {
  draft: "bg-muted text-muted-foreground",
  review: "bg-warning/15 text-warning",
  approved: "bg-accent/20 text-accent-foreground",
  published: "bg-success/15 text-success",
};

// Map DB snake_case to display labels
const detailFields: [keyof Product, string][] = [
  ["name", "Product Name"],
  ["brand", "Brand"],
  ["strain", "Strain"],
  ["type", "Product Type"],
  ["package_size", "Package Size"],
  ["sku", "SKU"],
  ["expiration_date", "Expiration Date"],
];

const cannabisFields: [keyof Product, string][] = [
  ["terpenes", "Dominant Terpenes"],
  ["aroma", "Aroma Profile"],
  ["taste", "Taste Profile"],
  ["effects", "Effects"],
  ["medical_uses", "Medical Uses"],
];

const statusOptions = ["draft", "review", "approved", "published"];

const ProductDetail = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { data: product, isLoading } = useProduct(id);
  const queryClient = useQueryClient();
  const [isEditing, setIsEditing] = useState(false);
  const [saving, setSaving] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [editData, setEditData] = useState<Product | null>(null);
  const [uploading, setUploading] = useState(false);
  const [aiRefreshing, setAiRefreshing] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const imageSearch = useCatalogImageSearch();

  useEffect(() => {
    if (product) {
      setEditData({
        ...product,
        clearance_active: product.clearance_active ?? false,
      });
    }
  }, [product]);

  if (isLoading) {
    return (
      <div className="flex justify-center items-center p-8 lg:p-12 min-h-[60vh]">
        <p className="text-muted-foreground text-sm">Loading product…</p>
      </div>
    );
  }

  if (!product || !editData) {
    return (
      <div className="flex flex-col justify-center items-center p-8 lg:p-12 min-h-[60vh]">
        <AlertTriangle className="mb-4 w-12 h-12 text-warning" />
        <h2 className="mb-2 font-semibold text-foreground text-xl">Product Not Found</h2>
        <p className="mb-6 text-muted-foreground">The product you're looking for doesn't exist.</p>
        <Button variant="outline" onClick={() => navigate("/catalog")}>
          <ArrowLeft className="mr-2 w-4 h-4" /> Back to Catalog
        </Button>
      </div>
    );
  }

  const handleSave = async () => {
    setSaving(true);
    const { id: _id, created_at: _ca, created_by: _cb, images, ...rest } = editData;
    const updates = {
      ...rest,
      expiration_date: rest.expiration_date ? rest.expiration_date : null,
      images: images as unknown as Json,
      updated_at: new Date().toISOString(),
    };
    const { error } = await supabase
      .from("products")
      .update(updates)
      .eq("id", editData.id);
    setSaving(false);
    if (error) {
      toast.error("Failed to save: " + error.message);
      return;
    }
    queryClient.invalidateQueries({ queryKey: ["products"] });
    setIsEditing(false);
    toast.success("Product details saved successfully.");
  };

  const handleCancel = () => {
    setEditData({ ...product });
    setIsEditing(false);
  };

  const updateField = (field: string, value: string) => {
    setEditData((prev) => prev ? { ...prev, [field]: value } : prev);
  };

  const handleDelete = async () => {
    setDeleting(true);
    const { error } = await supabase.from("products").delete().eq("id", editData.id);
    setDeleting(false);
    if (error) {
      toast.error("Failed to delete: " + error.message);
      return;
    }
    queryClient.invalidateQueries({ queryKey: ["products"] });
    toast.success("Product deleted.");
    navigate("/catalog");
  };

  const handleAiRefresh = async () => {
    if (!editData) return;

    setAiRefreshing(true);
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session?.access_token) {
        toast.error("Please sign in again to run the AI refresh.");
        return;
      }
      const response = await fetch(EDGE_FUNCTIONS.GENERATE_DRAFT, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          apikey: ENV.SUPABASE_PUBLISHABLE_KEY,
          Authorization: `Bearer ${session.access_token}`,
        },
        body: JSON.stringify({
          brand: editData.brand,
          strain: editData.strain || editData.name,
          productType: editData.product_type || editData.type,
          packageSize: editData.package_size,
          sku: editData.sku,
          notes: [
            editData.short_description,
            editData.long_description,
            editData.effects,
            editData.medical_uses,
          ]
            .filter(Boolean)
            .join("\n"),
        }),
      });

      const payload: unknown = await response.json().catch(() => ({}));
      const payloadObj = payload as Record<string, unknown>;
      if (!response.ok) {
        const message =
          typeof payloadObj.error === "string"
            ? payloadObj.error
            : `Catalog AI update failed (${response.status})`;
        throw new Error(message);
      }

      const draft =
        payloadObj.draft && typeof payloadObj.draft === "object"
          ? payloadObj.draft
          : undefined;
      if (!draft) {
        throw new Error("AI did not return any catalog updates.");
      }

      const update = buildCatalogAiUpdateFromDraft(draft);
      setEditData((prev) => {
        if (!prev) return prev;

        return {
          ...prev,
          name: update.name || prev.name,
          brand: update.brand || prev.brand,
          strain: update.strain || prev.strain,
          sku: update.sku || prev.sku,
          package_size: update.packageSize || prev.package_size,
          product_type: update.productType || prev.product_type,
          type: update.type || prev.type,
          thc: update.thc || prev.thc,
          cbd: update.cbd || prev.cbd,
          terpenes: update.terpenes || prev.terpenes,
          aroma: update.aroma || prev.aroma,
          taste: update.taste || prev.taste,
          effects: update.effects || prev.effects,
          medical_uses: update.medicalUses || prev.medical_uses,
          short_description: update.shortDescription || prev.short_description,
          long_description: update.longDescription || prev.long_description,
          confidence:
            typeof (draft as { overallConfidence?: unknown }).overallConfidence === "number"
              ? (draft as { overallConfidence: number }).overallConfidence
              : prev.confidence,
        };
      });
      setIsEditing(true);
      toast.success("AI refreshed the editable catalog fields. Review and save when ready.");
    } catch (error) {
      const message = error instanceof Error ? error.message : "Catalog AI update failed";
      toast.error(message);
    } finally {
      setAiRefreshing(false);
    }
  };

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0 || !editData) return;
    setUploading(true);

    const newImages = [...(editData.images || [])];
    for (const file of Array.from(files)) {
      const ext = file.name.split(".").pop() || "jpg";
      const path = `${crypto.randomUUID()}.${ext}`;
      const { error } = await supabase.storage.from("product-images").upload(path, file, { contentType: file.type });
      if (error) { toast.error(`Upload failed: ${error.message}`); continue; }
      const { data: urlData } = supabase.storage.from("product-images").getPublicUrl(path);
      newImages.push({ url: urlData.publicUrl, alt: file.name.replace(/\.[^.]+$/, ""), primary: newImages.length === 0 });
    }

    setEditData((prev) => prev ? { ...prev, images: newImages } : prev);
    setUploading(false);
    if (fileInputRef.current) fileInputRef.current.value = "";
    toast.success("Image(s) added. Save to persist.");
  };

  const removeImage = (index: number) => {
    if (!editData) return;
    const newImages = editData.images.filter((_, i) => i !== index);
    if (newImages.length > 0 && !newImages.some((img) => img.primary)) {
      newImages[0].primary = true;
    }
    setEditData((prev) => prev ? { ...prev, images: newImages } : prev);
  };

  const setPrimaryImage = (index: number) => {
    if (!editData) return;
    const newImages = editData.images.map((img, i) => ({ ...img, primary: i === index }));
    setEditData((prev) => prev ? { ...prev, images: newImages } : prev);
  };

  const handleAutoFetchRealImage = async () => {
    if (!editData) return;

    const input = {
      name: editData.strain || editData.name,
      brand: editData.brand,
      type: editData.type,
      packageSize: editData.package_size,
      sku: editData.sku,
    };

    try {
      const results = await imageSearch.mutateAsync(input);
      const best = selectBestCatalogImage(results, input);
      if (!best) {
        toast.info("No real product image could be verified for this product.");
        return;
      }

      const publicUrl = await syncCatalogImageToProduct({ supabase, productId: editData.id, candidate: best });
      queryClient.invalidateQueries({ queryKey: ["products"] });
      setEditData((prev) => prev ? {
        ...prev,
        images: [
          { url: publicUrl, alt: best.alt, primary: true },
          ...prev.images.map((image) => ({ ...image, primary: false })),
        ],
      } : prev);
      toast.success("Best verified real image synced to the catalog record.");
    } catch (error) {
      const message = error instanceof Error ? error.message : "Failed to fetch a real product image";
      toast.error(message);
    }
  };

  const primaryImage = editData.images?.find((img) => img.primary) || editData.images?.[0];

  return (
    <div className="p-4 sm:p-6 lg:p-10 max-w-6xl">
      {/* Header */}
      <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} className="flex sm:flex-row flex-col justify-between sm:items-center gap-4 mb-6 sm:mb-8">
        <div className="flex items-center gap-3 sm:gap-4 min-w-0">
          <Button variant="ghost" size="icon" className="shrink-0" onClick={() => navigate("/catalog")} aria-label="Back to catalog">
            <ArrowLeft className="w-4 h-4" />
          </Button>
          <div className="min-w-0">
            <div className="flex flex-wrap items-center gap-2 sm:gap-3">
              <h1 className="font-semibold text-display text-foreground text-lg sm:text-2xl truncate">{editData.name}</h1>
              {isEditing ? (
                <Select value={editData.status} onValueChange={(v) => setEditData((prev) => prev ? { ...prev, status: v } : prev)}>
                  <SelectTrigger className="w-[130px] h-7 text-[10px] uppercase tracking-wider">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {statusOptions.map((s) => (
                      <SelectItem key={s} value={s} className="text-xs capitalize">{s}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              ) : (
                <Badge variant="secondary" className={cn("font-medium text-[10px] uppercase tracking-wider shrink-0", statusStyles[editData.status])}>
                  {editData.status}
                </Badge>
              )}
            </div>
            <p className="mt-0.5 text-muted-foreground text-xs sm:text-sm truncate">{editData.brand} · SKU: {editData.sku}</p>
          </div>
        </div>
        <div className="flex items-center gap-2 pl-11 sm:pl-0">
          {isEditing ? (
            <>
              <Button variant="outline" size="sm" onClick={handleCancel} disabled={saving}><X className="mr-1.5 w-3.5 h-3.5" />Cancel</Button>
              <Button size="sm" onClick={handleSave} disabled={saving}>
                {saving ? <Loader2 className="mr-1.5 w-3.5 h-3.5 animate-spin" /> : <Save className="mr-1.5 w-3.5 h-3.5" />}
                Save
              </Button>
            </>
          ) : (
            <div className="flex items-center gap-2">
              <Button variant="outline" size="sm" onClick={() => void handleAiRefresh()} disabled={aiRefreshing}>
                {aiRefreshing ? <Loader2 className="mr-1.5 w-3.5 h-3.5 animate-spin" /> : <Sparkles className="mr-1.5 w-3.5 h-3.5" />}
                AI Update
              </Button>
              <AlertDialog>
                <AlertDialogTrigger asChild>
                  <Button variant="outline" size="sm" className="gap-1.5 text-destructive hover:text-destructive">
                    <Trash2 className="w-3.5 h-3.5" />Delete
                  </Button>
                </AlertDialogTrigger>
                <AlertDialogContent>
                  <AlertDialogHeader>
                    <AlertDialogTitle>Delete Product</AlertDialogTitle>
                    <AlertDialogDescription>
                      This will permanently delete <strong>{editData.name}</strong>. This action cannot be undone.
                    </AlertDialogDescription>
                  </AlertDialogHeader>
                  <AlertDialogFooter>
                    <AlertDialogCancel>Cancel</AlertDialogCancel>
                    <AlertDialogAction onClick={handleDelete} disabled={deleting} className="bg-destructive hover:bg-destructive/90 text-destructive-foreground">
                      {deleting ? <Loader2 className="mr-1.5 w-4 h-4 animate-spin" /> : null}Delete
                    </AlertDialogAction>
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialog>
              <Button variant="outline" size="sm" onClick={() => setIsEditing(true)}><Edit3 className="mr-1.5 w-3.5 h-3.5" />Edit</Button>
            </div>
          )}
        </div>
      </motion.div>

      {/* Content */}
      <div className="gap-6 grid grid-cols-1 lg:grid-cols-3">
        {/* Left — Images */}
        <motion.div initial={{ opacity: 0, x: -12 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.1 }}>
          <Card className="shadow-soft overflow-hidden">
            <CardContent className="p-0">
              {primaryImage && (
                <div className="relative bg-muted/30 aspect-square overflow-hidden">
                  <img src={primaryImage.url} alt={primaryImage.alt} className="w-full h-full object-cover" />
                  <Badge className="top-3 left-3 absolute bg-card/80 backdrop-blur-sm text-[10px] text-card-foreground">
                    <ImageIcon className="mr-1 w-2.5 h-2.5" />Primary
                  </Badge>
                </div>
              )}
              {editData.images && editData.images.length > 1 && (
                <div className="gap-2 grid grid-cols-3 p-3">
                  {editData.images.map((img, i) => (
                    <div key={i} className={cn("group/thumb relative border-2 rounded-lg aspect-square overflow-hidden transition-all cursor-pointer", img.primary ? "border-accent" : "border-transparent hover:border-border")}
                      onClick={() => isEditing && setPrimaryImage(i)}
                    >
                      <img src={img.url} alt={img.alt} className="w-full h-full object-cover" />
                      {isEditing && (
                        <button
                          type="button"
                          onClick={(e) => { e.stopPropagation(); removeImage(i); }}
                          className="top-1 right-1 absolute flex justify-center items-center bg-destructive/80 opacity-0 group-hover/thumb:opacity-100 rounded-full w-5 h-5 text-destructive-foreground transition-opacity"
                          aria-label={`Remove image ${i + 1}`}
                        >
                          <Trash2 className="w-3 h-3" />
                        </button>
                      )}
                    </div>
                  ))}
                </div>
              )}
              {isEditing && (
                <div className="p-3 border-border border-t">
                  <input ref={fileInputRef} type="file" accept="image/*" multiple className="hidden" onChange={handleImageUpload} />
                  <div className="flex flex-col gap-2">
                    <Button variant="outline" size="sm" className="gap-2 w-full" onClick={handleAutoFetchRealImage} disabled={imageSearch.isPending}>
                      {imageSearch.isPending ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Sparkles className="w-3.5 h-3.5" />}
                      Auto Fetch Real Image
                    </Button>
                    <Button variant="outline" size="sm" className="gap-2 w-full" onClick={() => fileInputRef.current?.click()} disabled={uploading}>
                      {uploading ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Upload className="w-3.5 h-3.5" />}
                      Upload Images
                    </Button>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Confidence */}
          <Card className="shadow-soft mt-4">
            <CardContent className="p-5">
              <div className="flex justify-between items-center mb-3">
                <span className="font-medium text-muted-foreground text-xs uppercase tracking-wider">Confidence Score</span>
                <span className="font-semibold tabular-nums text-foreground text-2xl">{editData.confidence}%</span>
              </div>
              <div className="bg-muted rounded-full h-2 overflow-hidden">
                <motion.div
                  initial={{ width: 0 }}
                  animate={{ width: `${editData.confidence}%` }}
                  transition={{ duration: 0.8, delay: 0.3 }}
                  className={cn("rounded-full h-full", editData.confidence >= 90 ? "bg-success" : editData.confidence >= 75 ? "bg-accent" : "bg-warning")}
                />
              </div>
            </CardContent>
          </Card>

          {/* Chemical Profile */}
          <Card className="shadow-soft mt-4">
            <CardContent className="p-5">
              <p className="mb-3 font-medium text-muted-foreground text-xs uppercase tracking-wider">Chemical Profile</p>
              <div className="gap-3 grid grid-cols-2">
                {[
                  { label: "THC", value: editData.thc || "—", color: "text-accent" },
                  { label: "CBD", value: editData.cbd || "—", color: "text-emerald" },
                ].map((m) => (
                  <div key={m.label} className="bg-muted/30 p-3 border border-border/50 rounded-lg">
                    <p className="mb-1 text-[10px] text-muted-foreground">{m.label}</p>
                    <p className={cn("font-bold tabular-nums text-xl", m.color)}>{m.value}</p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Terpene Breakdown */}
          {editData.terpenes && (
            <Card className="shadow-soft mt-4">
              <CardContent className="p-5">
                <p className="mb-3 font-medium text-muted-foreground text-xs uppercase tracking-wider">Terpene Breakdown</p>
                <div className="space-y-2.5">
                  {editData.terpenes.split(/,\s*/).filter(Boolean).map((terp, i) => {
                    const terpColors = ["bg-accent", "bg-emerald", "bg-warning", "bg-destructive"];
                    const widths = [85, 65, 50, 40]; // visual representation
                    return (
                      <div key={terp}>
                        <div className="flex justify-between mb-1 text-xs">
                          <span className="text-foreground">{terp.trim()}</span>
                        </div>
                        <div className="bg-muted rounded-full h-1.5 overflow-hidden">
                          <motion.div
                            initial={{ width: 0 }}
                            animate={{ width: `${widths[i % widths.length]}%` }}
                            transition={{ duration: 0.6, delay: 0.4 + i * 0.1 }}
                            className={cn("rounded-full h-full", terpColors[i % terpColors.length])}
                          />
                        </div>
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          )}

          {/* AI Insights */}
          <Card className="bg-accent/5 shadow-soft mt-4 border-accent/20">
            <CardContent className="p-5">
              <div className="flex items-center gap-2 mb-3">
                <Sparkles className="w-4 h-4 text-accent" />
                <p className="font-semibold text-accent text-xs uppercase tracking-wider">AI Insights</p>
              </div>
              <p className="mb-3 text-muted-foreground text-xs leading-relaxed">
                {editData.terpenes
                  ? `This product's terpene profile suggests it pairs well with similar ${editData.type} products. Consider bundling with complementary strains for a curated collection.`
                  : "Add terpene data to unlock AI-powered pairing and bundling recommendations."}
              </p>
              <Button variant="outline" size="sm" className="w-full text-xs" onClick={() => {
                const recommendationsSection = document.getElementById("recommended-products");
                if (recommendationsSection) {
                  recommendationsSection.scrollIntoView({ behavior: "smooth", block: "start" });
                } else {
                  toast.info("No recommendations available for this product.");
                }
              }}>
                View Recommendations
              </Button>
            </CardContent>
          </Card>
        </motion.div>

        {/* Right — Details */}
        <motion.div initial={{ opacity: 0, x: 12 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.15 }} className="lg:col-span-2">
          <Tabs defaultValue="details" className="w-full">
            <TabsList className="mb-4 flex-wrap">
              <TabsTrigger value="details" className="gap-1.5"><Package className="w-3.5 h-3.5" />Details</TabsTrigger>
              <TabsTrigger value="pricing" className="gap-1.5"><DollarSign className="w-3.5 h-3.5" />Pricing</TabsTrigger>
              <TabsTrigger value="cannabis" className="gap-1.5"><Leaf className="w-3.5 h-3.5" />Cannabis Info</TabsTrigger>
              <TabsTrigger value="descriptions" className="gap-1.5"><FileText className="w-3.5 h-3.5" />Descriptions</TabsTrigger>
            </TabsList>

            <TabsContent value="details">
              <Card className="shadow-soft">
                <CardHeader className="pb-3">
                  <CardTitle className="flex items-center gap-2 text-base"><Tag className="w-4 h-4 text-accent" />Product Information</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {detailFields.map(([key, label]) => {
                    const isDate = key === "expiration_date";
                    const raw = editData[key];
                    const displayValue = isDate && raw
                      ? new Date(String(raw)).toLocaleDateString()
                      : String(raw ?? "");
                    return (
                      <div key={key}>
                        <label className="block mb-1.5 font-medium text-muted-foreground text-xs">{label}</label>
                        {isEditing ? (
                          <Input
                            type={isDate ? "date" : "text"}
                            value={isDate ? (raw ? String(raw).slice(0, 10) : "") : String(raw ?? "")}
                            onChange={(e) => updateField(key, e.target.value)}
                            className="bg-background"
                          />
                        ) : (
                          <p className="bg-muted/30 px-3 py-2 border border-border/40 rounded-lg text-foreground text-sm">{displayValue || "—"}</p>
                        )}
                      </div>
                    );
                  })}
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="pricing">
              <Card className="shadow-soft">
                <CardHeader className="pb-3">
                  <CardTitle className="flex items-center gap-2 text-base">
                    <DollarSign className="w-4 h-4 text-accent" />
                    Retail &amp; promotions
                  </CardTitle>
                  <p className="text-xs text-muted-foreground">
                    List price is per gram. Clearance overrides sale and base list for POS. Sale windows limit promotional pricing.
                  </p>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div>
                    <label className="mb-1.5 block text-xs font-medium text-muted-foreground">Base list price ($ / g)</label>
                    {isEditing ? (
                      <Input
                        type="number"
                        min="0"
                        step="0.01"
                        className="bg-background max-w-[200px] tabular-nums"
                        value={editData.price ?? ""}
                        onChange={(e) => {
                          const v = e.target.value;
                          setEditData((prev) =>
                            prev
                              ? {
                                  ...prev,
                                  price: v === "" ? 0 : Math.max(0, Number.parseFloat(v) || 0),
                                }
                              : prev,
                          );
                        }}
                      />
                    ) : (
                      <p className="rounded-lg border border-border/40 bg-muted/30 px-3 py-2 text-sm tabular-nums text-foreground">
                        ${Number(editData.price ?? 0).toFixed(2)} / g
                      </p>
                    )}
                  </div>

                  <Separator />

                  <div className="space-y-3">
                    <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">Sale pricing</p>
                    <div className="gap-4 grid grid-cols-1 sm:grid-cols-2">
                      <div>
                        <label className="mb-1.5 block text-xs font-medium text-muted-foreground">Sale $ / g</label>
                        {isEditing ? (
                          <Input
                            type="number"
                            min="0"
                            step="0.01"
                            className="bg-background tabular-nums"
                            value={editData.sale_price ?? ""}
                            onChange={(e) => {
                              const v = e.target.value;
                              setEditData((prev) =>
                                prev
                                  ? {
                                      ...prev,
                                      sale_price: v === "" ? null : Math.max(0, Number.parseFloat(v) || 0),
                                    }
                                  : prev,
                              );
                            }}
                          />
                        ) : (
                          <p className="rounded-lg border border-border/40 bg-muted/30 px-3 py-2 text-sm tabular-nums">
                            {editData.sale_price != null ? `$${Number(editData.sale_price).toFixed(2)} / g` : "—"}
                          </p>
                        )}
                      </div>
                      <div>
                        <label className="mb-1.5 block text-xs font-medium text-muted-foreground">Sale label</label>
                        {isEditing ? (
                          <Input
                            value={editData.sale_label ?? ""}
                            onChange={(e) =>
                              setEditData((prev) =>
                                prev ? { ...prev, sale_label: e.target.value || null } : prev,
                              )
                            }
                            className="bg-background"
                            placeholder="e.g. Weekend special"
                          />
                        ) : (
                          <p className="rounded-lg border border-border/40 bg-muted/30 px-3 py-2 text-sm">
                            {editData.sale_label || "—"}
                          </p>
                        )}
                      </div>
                      <div className="sm:col-span-2 gap-4 grid grid-cols-1 sm:grid-cols-2">
                        <div>
                          <label className="mb-1.5 block text-xs font-medium text-muted-foreground">Sale starts</label>
                          {isEditing ? (
                            <Input
                              type="datetime-local"
                              className="bg-background"
                              value={isoToDatetimeLocalValue(editData.sale_starts_at)}
                              onChange={(e) =>
                                setEditData((prev) =>
                                  prev
                                    ? {
                                        ...prev,
                                        sale_starts_at: datetimeLocalValueToIso(e.target.value),
                                      }
                                    : prev,
                                )
                              }
                            />
                          ) : (
                            <p className="text-sm text-muted-foreground">
                              {editData.sale_starts_at
                                ? new Date(editData.sale_starts_at).toLocaleString()
                                : "—"}
                            </p>
                          )}
                        </div>
                        <div>
                          <label className="mb-1.5 block text-xs font-medium text-muted-foreground">Sale ends</label>
                          {isEditing ? (
                            <Input
                              type="datetime-local"
                              className="bg-background"
                              value={isoToDatetimeLocalValue(editData.sale_ends_at)}
                              onChange={(e) =>
                                setEditData((prev) =>
                                  prev
                                    ? {
                                        ...prev,
                                        sale_ends_at: datetimeLocalValueToIso(e.target.value),
                                      }
                                    : prev,
                                )
                              }
                            />
                          ) : (
                            <p className="text-sm text-muted-foreground">
                              {editData.sale_ends_at
                                ? new Date(editData.sale_ends_at).toLocaleString()
                                : "—"}
                            </p>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>

                  <Separator />

                  <div className="space-y-3">
                    <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">Clearance</p>
                    <div className="flex items-start gap-3">
                      {isEditing ? (
                        <div className="flex items-center gap-2 pt-0.5">
                          <Checkbox
                            id="pd-clearance-active"
                            checked={editData.clearance_active ?? false}
                            onCheckedChange={(c) =>
                              setEditData((prev) =>
                                prev ? { ...prev, clearance_active: c === true } : prev,
                              )
                            }
                          />
                          <label htmlFor="pd-clearance-active" className="text-sm leading-none cursor-pointer">
                            Clearance active
                          </label>
                        </div>
                      ) : (
                        <Badge variant={editData.clearance_active ? "destructive" : "secondary"} className="text-[10px]">
                          {editData.clearance_active ? "Clearance on" : "Clearance off"}
                        </Badge>
                      )}
                    </div>
                    <div className="gap-4 grid grid-cols-1 sm:grid-cols-2">
                      <div>
                        <label className="mb-1.5 block text-xs font-medium text-muted-foreground">Clearance $ / g</label>
                        {isEditing ? (
                          <Input
                            type="number"
                            min="0"
                            step="0.01"
                            className="bg-background tabular-nums"
                            value={editData.clearance_price ?? ""}
                            onChange={(e) => {
                              const v = e.target.value;
                              setEditData((prev) =>
                                prev
                                  ? {
                                      ...prev,
                                      clearance_price: v === "" ? null : Math.max(0, Number.parseFloat(v) || 0),
                                    }
                                  : prev,
                              );
                            }}
                          />
                        ) : (
                          <p className="rounded-lg border border-border/40 bg-muted/30 px-3 py-2 text-sm tabular-nums">
                            {editData.clearance_price != null ? `$${Number(editData.clearance_price).toFixed(2)} / g` : "—"}
                          </p>
                        )}
                      </div>
                      <div className="sm:col-span-2">
                        <label className="mb-1.5 block text-xs font-medium text-muted-foreground">Clearance reason</label>
                        {isEditing ? (
                          <Textarea
                            value={editData.clearance_reason ?? ""}
                            onChange={(e) =>
                              setEditData((prev) =>
                                prev ? { ...prev, clearance_reason: e.target.value || null } : prev,
                              )
                            }
                            className="bg-background min-h-[60px]"
                            placeholder="e.g. Near expiry, packaging change"
                          />
                        ) : (
                          <p className="rounded-lg border border-border/40 bg-muted/30 px-3 py-2.5 text-sm whitespace-pre-wrap">
                            {editData.clearance_reason || "—"}
                          </p>
                        )}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="cannabis">
              <Card className="shadow-soft">
                <CardHeader className="pb-3">
                  <CardTitle className="flex items-center gap-2 text-base"><Beaker className="w-4 h-4 text-accent" />Cannabis Profile</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="gap-4 grid grid-cols-2">
                    {(["thc", "cbd"] as (keyof Product)[]).map((key) => (
                      <div key={key}>
                        <label className="block mb-1.5 font-medium text-muted-foreground text-xs">{key.toUpperCase()}</label>
                        {isEditing ? (
                          <Input value={String(editData[key] ?? "")} onChange={(e) => updateField(key, e.target.value)} className="bg-background" />
                        ) : (
                          <p className="bg-muted/30 px-3 py-2 border border-border/40 rounded-lg font-medium tabular-nums text-foreground text-sm">{String(editData[key] ?? "")}</p>
                        )}
                      </div>
                    ))}
                  </div>
                  <Separator />
                  {cannabisFields.map(([key, label]) => (
                    <div key={key}>
                      <label className="block mb-1.5 font-medium text-muted-foreground text-xs">{label}</label>
                      {isEditing ? (
                        <Textarea value={String(editData[key] ?? "")} onChange={(e) => updateField(key, e.target.value)} className="bg-background min-h-[60px]" rows={2} />
                      ) : (
                        <p className="bg-muted/30 px-3 py-2.5 border border-border/40 rounded-lg text-foreground text-sm leading-relaxed">{String(editData[key] ?? "")}</p>
                      )}
                    </div>
                  ))}
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="descriptions">
              <Card className="shadow-soft">
                <CardHeader className="pb-3">
                  <CardTitle className="flex items-center gap-2 text-base"><FileText className="w-4 h-4 text-accent" />Product Descriptions</CardTitle>
                </CardHeader>
                <CardContent className="space-y-5">
                  {([["short_description", "Short Description", 3], ["long_description", "Long Description", 6]] as [keyof Product, string, number][]).map(([key, label, rows]) => (
                    <div key={key}>
                      <label className="block mb-1.5 font-medium text-muted-foreground text-xs">{label}</label>
                      {isEditing ? (
                        <Textarea value={String(editData[key] ?? "")} onChange={(e) => updateField(key, e.target.value)} className="bg-background" rows={rows} />
                      ) : (
                        <p className="bg-muted/30 px-3 py-2.5 border border-border/40 rounded-lg text-foreground text-sm leading-relaxed whitespace-pre-wrap">{String(editData[key] ?? "")}</p>
                      )}
                    </div>
                  ))}
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </motion.div>
      </div>
      {/* Recommendations */}
      <div id="recommended-products">
        <RecommendedProducts currentProduct={editData} />
      </div>
    </div>
  );
};

/* ---------- Recommended Products Widget ---------- */
const RecommendedProducts = ({ currentProduct }: { currentProduct: Product }) => {
  const navigate = useNavigate();
  const { data: allProducts = [] } = useProducts();

  const recommendations = useMemo(() => {
    if (!allProducts.length) return [];

    // Score products by similarity: same type, same brand, similar confidence
    const scored = allProducts
      .filter((p) => p.id !== currentProduct.id)
      .map((p) => {
        let score = 0;
        if (p.type === currentProduct.type) score += 3;
        if (p.brand === currentProduct.brand) score += 2;
        if (Math.abs(p.confidence - currentProduct.confidence) < 15) score += 1;
        // Shared terpenes
        const currentTerpenes = currentProduct.terpenes.toLowerCase().split(/,\s*/);
        const pTerpenes = p.terpenes.toLowerCase().split(/,\s*/);
        const sharedTerpenes = currentTerpenes.filter((t) => t && pTerpenes.includes(t)).length;
        score += sharedTerpenes;
        return { product: p, score };
      })
      .filter((s) => s.score > 0)
      .sort((a, b) => b.score - a.score)
      .slice(0, 4);

    return scored.map((s) => s.product);
  }, [allProducts, currentProduct]);

  if (recommendations.length === 0) return null;

  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.3 }}
      className="mt-8"
    >
      <div className="flex items-center gap-2 mb-4">
        <Sparkles className="w-4 h-4 text-accent" />
        <h2 className="font-semibold text-foreground text-sm uppercase tracking-wider">Recommended Products</h2>
        <span className="text-muted-foreground text-xs">Similar items you might want to review</span>
      </div>
      <div className="gap-3 sm:gap-4 grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-4">
        {recommendations.map((product) => {
          const img = product.images?.find((i) => i.primary) || product.images?.[0];
          return (
            <Card
              key={product.id}
              className="group shadow-soft hover:shadow-elevated overflow-hidden transition-shadow cursor-pointer"
              onClick={() => navigate(`/catalog/${product.id}`)}
            >
              {img && (
                <div className="bg-muted/30 aspect-video overflow-hidden">
                  <img src={img.url} alt={img.alt} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" />
                </div>
              )}
              <CardContent className="space-y-2 p-4">
                <p className="font-medium text-foreground text-sm truncate">{product.name}</p>
                <p className="text-muted-foreground text-xs">{product.brand} · {product.type}</p>
                <div className="flex justify-between items-center">
                  <Badge variant="secondary" className={cn("text-[9px] uppercase tracking-wider", statusStyles[product.status])}>
                    {product.status}
                  </Badge>
                  <span className="tabular-nums text-muted-foreground text-xs">{product.confidence}%</span>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>
    </motion.div>
  );
};

export default ProductDetail;
