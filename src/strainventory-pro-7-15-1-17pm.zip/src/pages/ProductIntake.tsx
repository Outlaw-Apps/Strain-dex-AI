import { BarcodeScanner } from "@/components/ui/BarcodeScanner";
import WorkflowStepper from "@/components/WorkflowStepper";
import AiDraftSplash from "@/components/AiDraftSplash";
import IntakeHeader from "@/components/productIntake/IntakeHeader";
import IntakeIdentityCard from "@/components/productIntake/IntakeIdentityCard";
import IntakeClassificationCard from "@/components/productIntake/IntakeClassificationCard";
import IntakeCannabisProfileCard from "@/components/productIntake/IntakeCannabisProfileCard";
import IntakeRetailCard from "@/components/productIntake/IntakeRetailCard";
import IntakeActions from "@/components/productIntake/IntakeActions";
import { useProductIntake } from "@/hooks/useProductIntake";

const ProductIntake = () => {
  const {
    form,
    set,
    submitting,
    generatingProfile,
    skuScannerOpen,
    setSkuScannerOpen,
    draftSplashOpen,
    draftProgress,
    managerOverride,
    missingRequired,
    hasAnyContent,
    handleSubmit,
    handleAutoGenerateProfile,
    handleGenerateAIDraft,
    handleFindImages,
    handleDownloadDraftReport,
    handleClearForm,
  } = useProductIntake();

  const canSearch = Boolean(form.name.trim() || form.brand.trim());

  return (
    <div className="p-4 sm:p-6 lg:p-10 max-w-6xl mx-auto">
      <WorkflowStepper currentStep="intake" />

      <IntakeHeader
        hasAnyContent={hasAnyContent}
        onDownload={handleDownloadDraftReport}
        managerOverride={managerOverride}
      />

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <IntakeIdentityCard
          form={form}
          set={set}
          onOpenScanner={() => setSkuScannerOpen(true)}
        />
        <IntakeClassificationCard form={form} set={set} />
        <IntakeCannabisProfileCard
          form={form}
          set={set}
          generatingProfile={generatingProfile}
          onAutoGenerate={() => void handleAutoGenerateProfile()}
        />
        <IntakeRetailCard form={form} set={set} />
      </div>

      <IntakeActions
        submitting={submitting}
        missingRequired={missingRequired}
        canSearch={canSearch}
        onClear={handleClearForm}
        onFindImages={handleFindImages}
        onGenerateAIDraft={() => void handleGenerateAIDraft()}
        onSubmit={() => void handleSubmit()}
      />

      <BarcodeScanner
        open={skuScannerOpen}
        onOpenChange={setSkuScannerOpen}
        onScan={(result) => set("sku", result.text.trim())}
        title="Scan SKU Barcode"
      />

      <AiDraftSplash
        open={draftSplashOpen}
        progress={draftProgress}
        productName={form.name || form.strain || form.brand}
      />
    </div>
  );
};

export default ProductIntake;
