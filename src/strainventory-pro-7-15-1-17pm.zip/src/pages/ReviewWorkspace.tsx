import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  ArrowLeft, Sparkles, Crown, Scissors, ShieldCheck, Heart,
  RotateCcw, Check, Copy, ChevronRight, Loader2,
} from "lucide-react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Separator } from "@/components/ui/separator";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import { toast } from "sonner";
import { useProductDraft } from "@/context/ProductDraftContext";
import WorkflowStepper from "@/components/WorkflowStepper";
import { useUserRoles } from "@/hooks/useUserRoles";
import { supabase } from "@/integrations/supabase/client";
import { useQueryClient } from "@tanstack/react-query";
import { enqueueProductUpsert } from "@/lib/offlineProductQueue";
import { buildCatalogImageSearchInput, selectBestCatalogImage } from "@/lib/catalogImages";
import { useCatalogImageSearch } from "@/hooks/useCatalogImageSearch";
import { reviewConfidenceConfig } from "@/lib/constants";
import { applyReviewRewrite, type ReviewRewriteActionId } from "@/lib/reviewRewrite";
import type { TablesInsert } from "@/integrations/supabase/types";

// ---------- types ----------
interface FieldEntry {
  label: string;
  generated: string;
  confidence: "verified" | "matched" | "inferred" | "review";
}

// ---------- build fields from context ----------
const buildFieldsFromDraft = (
  intake: ReturnType<typeof useProductDraft>["product"]["intake"],
  draft: ReturnType<typeof useProductDraft>["product"]["draft"],
): FieldEntry[] => {
  if (draft) {
    // Flatten draft sections into review fields
    const fields: FieldEntry[] = [];
    for (const section of draft.sections) {
      for (const f of section.fields) {
        fields.push({ label: f.label, generated: f.value, confidence: section.confidence });
      }
    }
    return fields;
  }

  // Fallback to intake values when no generated draft exists yet
  return [
    { label: "Brand Name", generated: intake.brand || "", confidence: "verified" },
    { label: "Strain Name", generated: intake.strain || "", confidence: "verified" },
    { label: "Product Title", generated: [intake.strain, intake.productType, intake.packageSize].filter(Boolean).join(" ").trim(), confidence: "matched" },
    { label: "Category", generated: intake.productType || "", confidence: "verified" },
    { label: "THC", generated: "", confidence: "review" },
    { label: "CBD", generated: "", confidence: "review" },
    { label: "Dominant Terpenes", generated: "", confidence: "review" },
    { label: "Aroma Profile", generated: "", confidence: "review" },
    { label: "Taste Profile", generated: "", confidence: "review" },
    { label: "Effects", generated: "", confidence: "review" },
    { label: "Medical Uses", generated: "", confidence: "review" },
  ];
};

// ---------- rewrite actions ----------
const rewriteActions = [
  { id: "premium", label: "Make More Premium", icon: Crown, description: "Elevate language and positioning" },
  { id: "shorten", label: "Shorten for Catalog", icon: Scissors, description: "Condense to essential details" },
  { id: "verify", label: "Verify Claims", icon: ShieldCheck, description: "Flag unverified health claims" },
  { id: "simplify", label: "Simplify Medical", icon: Heart, description: "Simplify medical wording" },
];

const buildEditableFieldMap = (fieldEntries: FieldEntry[], shortDescription: string, longDescription: string) => {
  const map: Record<string, string> = {};
  fieldEntries.forEach((field) => {
    map[field.label] = field.generated;
  });
  map["Short Description"] = shortDescription;
  map["Long Description"] = longDescription;
  return map;
};

// ---------- component ----------
const ReviewWorkspace = () => {
  const navigate = useNavigate();
  const { product, setAlternateImages, setCatalogId, setImageSearchResults, setPrimaryImage, setStatus } = useProductDraft();
  const { draft } = product;
  const { canPublish, isAdmin, isReviewer, roles } = useUserRoles();
  const queryClient = useQueryClient();
  const imageSearch = useCatalogImageSearch();
  const autoImageAttempted = useRef(false);
  const [saving, setSaving] = useState(false);

  const fields = useMemo(() => buildFieldsFromDraft(product.intake, draft), [draft, product.intake]);

  const shortDesc = draft?.descriptionShort ?? "";
  const longDesc = draft?.descriptionLong ?? "";
  const sourceEditedFields = useMemo(
    () => buildEditableFieldMap(fields, shortDesc, longDesc),
    [fields, longDesc, shortDesc],
  );
  const sourceFingerprint = useMemo(() => JSON.stringify(sourceEditedFields), [sourceEditedFields]);

  const [editedFields, setEditedFields] = useState<Record<string, string>>(() => sourceEditedFields);

  const [history, setHistory] = useState<Record<string, string>[]>([]);
  const [activeRewrite, setActiveRewrite] = useState<string | null>(null);
  const [copiedField, setCopiedField] = useState<string | null>(null);

  // Keep a ref that always points to the latest editedFields so that stable
  // callbacks (pushHistory, handleRewrite) can read the current value without
  // needing it in their dependency arrays.
  const editedFieldsRef = useRef(editedFields);
  useEffect(() => {
    editedFieldsRef.current = editedFields;
  }, [editedFields]);

  const intakeSearch = useMemo(() => buildCatalogImageSearchInput(product.intake), [product.intake]);

  // Reset the editable model whenever a different draft or intake payload is
  // loaded into the page.
  useEffect(() => {
    setEditedFields(sourceEditedFields);
    setHistory([]);
    setCopiedField(null);
    setActiveRewrite(null);
    setPendingRewrite(null);
  }, [sourceEditedFields, sourceFingerprint]);

  // Pending rewrite action: the effect reads the latest edited field snapshot
  // through the ref so rewrites operate on the current content.
  const [pendingRewrite, setPendingRewrite] = useState<ReviewRewriteActionId | null>(null);

  useEffect(() => {
    if (!pendingRewrite) return;
    const timerId = window.setTimeout(() => {
      const rewrite = applyReviewRewrite(pendingRewrite, editedFieldsRef.current);
      if (!rewrite.changed) {
        setActiveRewrite(null);
        setPendingRewrite(null);
        toast.info("Nothing in the current draft needed that rewrite.");
        return;
      }

      setEditedFields(rewrite.fields);
      setActiveRewrite(null);
      setPendingRewrite(null);
      toast.success(`Rewrite applied to ${rewrite.changedLabels.length} field${rewrite.changedLabels.length === 1 ? "" : "s"}.`);
    }, 900);

    return () => window.clearTimeout(timerId);
  }, [pendingRewrite]);

  // Clear copy indicator after a short delay, with proper cleanup.
  useEffect(() => {
    if (!copiedField) return;
    const timerId = window.setTimeout(() => setCopiedField(null), 1500);
    return () => window.clearTimeout(timerId);
  }, [copiedField]);

  // Stable callback — reads the current fields via ref so it doesn't need to
  // be recreated every time editedFields changes.
  const pushHistory = useCallback(() => {
    setHistory((h) => [...h, { ...editedFieldsRef.current }]);
  }, []);

  const undo = () => {
    if (history.length === 0) return;
    const prev = history[history.length - 1];
    setEditedFields(prev);
    setHistory((h) => h.slice(0, -1));
    toast.success("Reverted to previous version.");
  };

  const handleRewrite = useCallback((actionId: ReviewRewriteActionId) => {
    pushHistory();
    setActiveRewrite(actionId);
    setPendingRewrite(actionId);
  }, [pushHistory]);

  const copyField = (label: string) => {
    navigator.clipboard.writeText(editedFields[label] || "");
    setCopiedField(label);
  };

  const updateField = (label: string, value: string) => {
    pushHistory();
    setEditedFields((prev) => ({ ...prev, [label]: value }));
  };

  const buildProductRow = (status: string): TablesInsert<"products"> => {
    const { intake, primaryImage, alternateImages } = product;
    const images = [
      ...(primaryImage ? [{ url: primaryImage.url, alt: primaryImage.alt, primary: true }] : []),
      ...alternateImages.map((img) => ({ url: img.url, alt: img.alt, primary: false })),
    ];
    const id = product.catalogId ?? crypto.randomUUID();

    return {
      id,
      name: editedFields["Product Title"] || `${intake.strain || intake.brand} ${intake.productType || "Flower"}`,
      brand: editedFields["Brand Name"] || editedFields["Brand"] || intake.brand,
      type: intake.productType || editedFields["Category"] || "flower",
      status,
      confidence: draft?.overallConfidence ?? 0,
      thc: editedFields["THC"] || "",
      cbd: editedFields["CBD"] || "",
      strain: editedFields["Strain Name"] || intake.strain,
      sku: editedFields["SKU"] || intake.sku,
      package_size: editedFields["Package"] || intake.packageSize,
      terpenes: editedFields["Dominant Terpenes"] || editedFields["Dominant"] || "",
      aroma: editedFields["Aroma Profile"] || editedFields["Primary"] || "",
      taste: editedFields["Taste Profile"] || editedFields["Inhale"] || "",
      effects: editedFields["Effects"] || editedFields["Onset"] || "",
      medical_uses: editedFields["Medical Uses"] || editedFields["May Help With"] || "",
      short_description: editedFields["Short Description"] || "",
      long_description: editedFields["Long Description"] || "",
      images,
    };
  };

  const queueOfflineUpsert = (row: TablesInsert<"products">, mode: "draft" | "published") => {
    enqueueProductUpsert({
      id: crypto.randomUUID(),
      row,
      mode,
      queuedAt: new Date().toISOString(),
    });
    setCatalogId(row.id ?? null);
    setStatus(mode === "published" ? "published" : "reviewed");
    toast.success(mode === "published" ? "Publish queued for the next connection." : "Draft save queued for the next connection.");
  };

  const autoAttachBestImage = useCallback(async () => {
    const results = await imageSearch.mutateAsync(intakeSearch);
    if (results.length === 0) {
      toast.info("No real product images were found for this draft.");
      return;
    }

    const best = selectBestCatalogImage(results, intakeSearch);
    if (!best) {
      return;
    }

    setImageSearchResults(
      results.map((image) => ({
        id: image.id,
        url: image.url,
        alt: image.alt,
        primary: false,
        quality: image.width >= 1200 ? "high" : image.width >= 700 ? "medium" : "low",
        source: image.source,
        verificationConfidence: image.verification?.confidence,
      })),
    );
    setPrimaryImage({
      id: best.id,
      url: best.url,
      alt: best.alt,
      quality: best.width >= 1200 ? "high" : best.width >= 700 ? "medium" : "low",
      source: best.source,
    });
    setAlternateImages(
      results
        .filter((image) => image.id !== best.id)
        .slice(0, 3)
        .map((image) => ({
          id: image.id,
          url: image.url,
          alt: image.alt,
          quality: image.width >= 1200 ? "high" : image.width >= 700 ? "medium" : "low",
          source: image.source,
        })),
    );
    toast.success("Best verified real image attached to the draft.");
  }, [imageSearch, intakeSearch, setAlternateImages, setImageSearchResults, setPrimaryImage]);

  useEffect(() => {
    if (autoImageAttempted.current || product.primaryImage || (!product.intake.brand && !product.intake.strain)) {
      return;
    }

    autoImageAttempted.current = true;
    void autoAttachBestImage();
  }, [autoAttachBestImage, product.intake.brand, product.intake.strain, product.primaryImage]);

  const handlePublish = async () => {
    if (!canPublish) {
      toast.error("You don't have permission to publish. Ask an admin or reviewer.");
      return;
    }
    setSaving(true);
    const row = buildProductRow("published");
    setCatalogId(row.id ?? null);
    if (!navigator.onLine) {
      setSaving(false);
      queueOfflineUpsert(row, "published");
      return;
    }

    const { error } = await supabase.from("products").upsert(row);
    setSaving(false);
    if (error) {
      if (/network|fetch|offline/i.test(error.message)) {
        queueOfflineUpsert(row, "published");
        return;
      }
      toast.error(`Failed to publish: ${error.message}`);
      return;
    }
    queryClient.invalidateQueries({ queryKey: ["products"] });
    setCatalogId(row.id ?? null);
    setStatus("published");
    toast.success("Product published to catalog.");
    navigate("/catalog");
  };

  const handleSaveDraft = async () => {
    setSaving(true);
    const row = buildProductRow("draft");
    setCatalogId(row.id ?? null);
    if (!navigator.onLine) {
      setSaving(false);
      queueOfflineUpsert(row, "draft");
      return;
    }

    const { error } = await supabase.from("products").upsert(row);
    setSaving(false);
    if (error) {
      if (/network|fetch|offline/i.test(error.message)) {
        queueOfflineUpsert(row, "draft");
        return;
      }
      toast.error(`Failed to save draft: ${error.message}`);
      return;
    }
    queryClient.invalidateQueries({ queryKey: ["products"] });
    setCatalogId(row.id ?? null);
    setStatus("reviewed");
    toast.success("Draft saved to database.");
  };

  return (
    <div className="min-h-screen p-6 lg:p-8">
      <WorkflowStepper currentStep="reviewed" />
      {/* Header */}
      <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} className="flex items-center justify-between mb-8">
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="icon" onClick={() => navigate("/ai-draft")}>
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <div>
            <h1 className="text-display text-2xl font-semibold text-foreground">Review &amp; Edit</h1>
            <p className="text-sm text-muted-foreground mt-0.5">
              {product.intake.strain
                ? `Reviewing draft for ${product.intake.strain} by ${product.intake.brand || "Unknown"}`
                : "Compare AI-generated content with your approved catalog entry."}
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          {roles.length > 0 && (
            <Badge variant="secondary" className="text-[10px] uppercase tracking-wider bg-accent/20 text-accent-foreground">
              {roles[0]}
            </Badge>
          )}
          <Button variant="outline" size="sm" onClick={undo} disabled={history.length === 0}>
            <RotateCcw className="h-3.5 w-3.5 mr-1.5" />Undo
          </Button>
          <Button variant="outline" size="sm" onClick={() => void autoAttachBestImage()} disabled={imageSearch.isPending}>
            {imageSearch.isPending ? <Loader2 className="h-3.5 w-3.5 mr-1.5 animate-spin" /> : <Sparkles className="h-3.5 w-3.5 mr-1.5" />}
            Auto Fetch Real Image
          </Button>
          {(isAdmin || isReviewer) && (
            <Button variant="gold" size="sm" onClick={handleSaveDraft} disabled={saving}>
              {saving ? <Loader2 className="h-3.5 w-3.5 mr-1.5 animate-spin" /> : null}
              Approve Draft
            </Button>
          )}
        </div>
      </motion.div>

      {/* Rewrite Actions */}
      <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="mb-8">
        <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-3">Smart Rewrite Actions</p>
        <div className="flex flex-wrap gap-2">
          {rewriteActions.map((action) => (
            <Button
              key={action.id}
              variant="outline"
              size="sm"
              title={action.description}
              disabled={activeRewrite !== null}
              onClick={() => handleRewrite(action.id as ReviewRewriteActionId)}
              className="gap-2 transition-all hover:border-accent hover:shadow-gold"
            >
              {activeRewrite === action.id ? (
                <motion.div animate={{ rotate: 360 }} transition={{ repeat: Infinity, duration: 1, ease: "linear" }}>
                  <Sparkles className="h-3.5 w-3.5 text-accent" />
                </motion.div>
              ) : (
                <action.icon className="h-3.5 w-3.5" />
              )}
              {action.label}
            </Button>
          ))}
        </div>
      </motion.div>

      {/* Side-by-side panels */}
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
        {/* LEFT — Generated content */}
        <motion.div initial={{ opacity: 0, x: -16 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.15 }}>
          <Card className="shadow-soft h-full">
            <CardHeader className="pb-4">
              <div className="flex items-center gap-2">
                <div className="h-2 w-2 rounded-full bg-accent animate-pulse" />
                <CardTitle className="text-base">AI-Generated Draft</CardTitle>
              </div>
              <p className="text-xs text-muted-foreground">Content produced by Strain Vinny. Confidence labels indicate source reliability.</p>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-[calc(100vh-360px)]">
                <div className="space-y-4 pr-3">
                  {fields.map((field, idx) => {
                    const conf = reviewConfidenceConfig[field.confidence];
                    const ConfIcon = conf.icon;
                    return (
                      <motion.div key={field.label} initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 + idx * 0.03 }} className="group">
                        <div className="flex items-center justify-between mb-1">
                          <span className="text-xs font-medium text-muted-foreground">{field.label}</span>
                          <Badge variant="outline" className={`text-[10px] gap-1 ${conf.className}`}>
                            <ConfIcon className="h-2.5 w-2.5" />{conf.label}
                          </Badge>
                        </div>
                        <div className="rounded-lg bg-muted/50 border border-border/60 px-3 py-2.5 text-sm leading-relaxed">{field.generated}</div>
                      </motion.div>
                    );
                  })}

                  <Separator className="my-4" />

                  {[
                    { label: "Short Description", value: shortDesc },
                    { label: "Long Description", value: longDesc },
                  ].map((desc, idx) => (
                    <motion.div key={desc.label} initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.5 + idx * 0.05 }}>
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-xs font-medium text-muted-foreground">{desc.label}</span>
                        <Badge variant="outline" className="text-[10px] gap-1 bg-accent/20 text-accent-foreground border-accent/30">
                          <Sparkles className="h-2.5 w-2.5" />Generated
                        </Badge>
                      </div>
                      <div className="rounded-lg bg-muted/50 border border-border/60 px-3 py-2.5 text-sm leading-relaxed whitespace-pre-wrap">{desc.value}</div>
                    </motion.div>
                  ))}
                </div>
              </ScrollArea>
            </CardContent>
          </Card>
        </motion.div>

        {/* RIGHT — Editable approved entry */}
        <motion.div initial={{ opacity: 0, x: 16 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.2 }}>
          <Card className="shadow-soft h-full border-accent/20">
            <CardHeader className="pb-4">
              <div className="flex items-center gap-2">
                <div className="h-2 w-2 rounded-full bg-emerald" />
                <CardTitle className="text-base">Approved Catalog Entry</CardTitle>
              </div>
              <p className="text-xs text-muted-foreground">Edit freely — every change is tracked. Click a field to modify.</p>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-[calc(100vh-360px)]">
                <div className="space-y-4 pr-3">
                  {fields.map((field, idx) => (
                    <motion.div key={field.label} initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.25 + idx * 0.03 }}>
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-xs font-medium text-muted-foreground">{field.label}</span>
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <button onClick={() => copyField(field.label)} className="text-muted-foreground/50 hover:text-foreground transition-colors">
                              <AnimatePresence mode="wait">
                                {copiedField === field.label ? (
                                  <motion.div key="check" initial={{ scale: 0.8 }} animate={{ scale: 1 }} exit={{ scale: 0.8 }}><Check className="h-3 w-3 text-emerald" /></motion.div>
                                ) : (
                                  <motion.div key="copy" initial={{ scale: 0.8 }} animate={{ scale: 1 }} exit={{ scale: 0.8 }}><Copy className="h-3 w-3" /></motion.div>
                                )}
                              </AnimatePresence>
                            </button>
                          </TooltipTrigger>
                          <TooltipContent side="left" className="text-xs">Copy</TooltipContent>
                        </Tooltip>
                      </div>
                      <Input
                        value={editedFields[field.label] ?? ""}
                        onChange={(e) => updateField(field.label, e.target.value)}
                        className="text-sm bg-background"
                        disabled={activeRewrite !== null}
                      />
                    </motion.div>
                  ))}

                  <Separator className="my-4" />

                  {["Short Description", "Long Description"].map((label, idx) => (
                    <motion.div key={label} initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.55 + idx * 0.05 }}>
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-xs font-medium text-muted-foreground">{label}</span>
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <button onClick={() => copyField(label)} className="text-muted-foreground/50 hover:text-foreground transition-colors">
                              {copiedField === label ? <Check className="h-3 w-3 text-emerald" /> : <Copy className="h-3 w-3" />}
                            </button>
                          </TooltipTrigger>
                          <TooltipContent side="left" className="text-xs">Copy</TooltipContent>
                        </Tooltip>
                      </div>
                      <Textarea
                        value={editedFields[label] ?? ""}
                        onChange={(e) => updateField(label, e.target.value)}
                        className="text-sm bg-background min-h-[100px]"
                        rows={label === "Long Description" ? 6 : 3}
                        disabled={activeRewrite !== null}
                      />
                    </motion.div>
                  ))}

                  {/* Publish actions */}
                  <div className="pt-4 flex items-center gap-2 flex-wrap">
                    {canPublish ? (
                      <Button variant="gold" className="gap-2" onClick={handlePublish} disabled={saving}>
                        {saving ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : null}Publish Now<ChevronRight className="h-3.5 w-3.5" />
                      </Button>
                    ) : (
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <span>
                            <Button variant="gold" className="gap-2" disabled>
                              Publish Now<ChevronRight className="h-3.5 w-3.5" />
                            </Button>
                          </span>
                        </TooltipTrigger>
                        <TooltipContent>Only admins and reviewers can publish</TooltipContent>
                      </Tooltip>
                    )}
                    <Button variant="outline" onClick={handleSaveDraft} disabled={saving}>Save Draft</Button>
                    <Button variant="ghost" onClick={handleSaveDraft} disabled={saving}>Queue for Review</Button>
                  </div>
                </div>
              </ScrollArea>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
};

export default ReviewWorkspace;
