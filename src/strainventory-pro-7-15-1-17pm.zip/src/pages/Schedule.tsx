import { useMemo, useState } from "react";
import { motion } from "framer-motion";
import {
  Calendar as CalendarIcon,
  Plus,
  Trash2,
  ChevronLeft,
  ChevronRight,
  CheckCircle2,
  XCircle,
  Clock,
  Loader2,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { toast } from "sonner";
import { useUserRoles } from "@/hooks/useUserRoles";
import { useProfiles } from "@/hooks/useProfiles";
import {
  useShifts,
  usePendingShifts,
  useCreateShift,
  useUpdateShift,
  useDeleteShift,
  useApproveShift,
  useRejectShift,
  type EmployeeShift,
} from "@/hooks/useSchedules";
import {
  isoToDatetimeLocalValue,
  datetimeLocalValueToIso,
} from "@/lib/datetimeLocal";

const DAY_MS = 24 * 60 * 60 * 1000;

function startOfWeek(d: Date) {
  const x = new Date(d);
  x.setHours(0, 0, 0, 0);
  x.setDate(x.getDate() - x.getDay()); // Sunday start
  return x;
}

function fmtDay(d: Date) {
  return d.toLocaleDateString(undefined, { weekday: "short", month: "short", day: "numeric" });
}

function fmtTime(iso: string) {
  return new Date(iso).toLocaleTimeString(undefined, { hour: "numeric", minute: "2-digit" });
}

function hoursBetween(a: string, b: string) {
  return (new Date(b).getTime() - new Date(a).getTime()) / 36e5;
}

interface ShiftFormState {
  id?: string;
  user_id: string;
  starts_at: string;
  ends_at: string;
  position: string;
  notes: string;
  approval_status: "pending" | "approved" | "rejected";
  rejection_reason: string | null;
}

const emptyForm = (defaultDay: Date): ShiftFormState => {
  const start = new Date(defaultDay);
  start.setHours(9, 0, 0, 0);
  const end = new Date(defaultDay);
  end.setHours(17, 0, 0, 0);
  return {
    user_id: "",
    starts_at: isoToDatetimeLocalValue(start.toISOString()),
    ends_at: isoToDatetimeLocalValue(end.toISOString()),
    position: "",
    notes: "",
    approval_status: "pending",
    rejection_reason: null,
  };
};

function statusBadge(s: EmployeeShift) {
  if (s.approval_status === "approved") {
    return (
      <Badge className="text-[8px] uppercase tracking-wider bg-emerald-600 text-white hover:bg-emerald-600">
        Published
      </Badge>
    );
  }
  if (s.approval_status === "rejected") {
    return (
      <Badge variant="destructive" className="text-[8px] uppercase tracking-wider">
        Rejected
      </Badge>
    );
  }
  return (
    <Badge variant="outline" className="text-[8px] uppercase tracking-wider">
      Pending
    </Badge>
  );
}

const Schedule = () => {
  const { isAdmin } = useUserRoles();
  const { data: profiles = [] } = useProfiles();
  const profileMap = useMemo(() => {
    const m = new Map<string, string>();
    profiles.forEach((p) => m.set(p.id, p.full_name || "Unknown"));
    return m;
  }, [profiles]);

  const [weekStart, setWeekStart] = useState(() => startOfWeek(new Date()));
  const weekEnd = useMemo(() => new Date(weekStart.getTime() + 7 * DAY_MS), [weekStart]);
  const days = useMemo(
    () => Array.from({ length: 7 }, (_, i) => new Date(weekStart.getTime() + i * DAY_MS)),
    [weekStart],
  );

  const { data: shifts = [], isLoading } = useShifts(
    weekStart.toISOString(),
    weekEnd.toISOString(),
  );

  const createShift = useCreateShift();
  const updateShift = useUpdateShift();
  const deleteShift = useDeleteShift();
  const approveShift = useApproveShift();
  const rejectShift = useRejectShift();
  const { data: pendingShifts = [] } = usePendingShifts();

  const [dialogOpen, setDialogOpen] = useState(false);
  const [form, setForm] = useState<ShiftFormState>(() => emptyForm(new Date()));

  const openCreate = (day?: Date) => {
    setForm(emptyForm(day ?? new Date()));
    setDialogOpen(true);
  };

  const openEdit = (shift: EmployeeShift) => {
    setForm({
      id: shift.id,
      user_id: shift.user_id,
      starts_at: isoToDatetimeLocalValue(shift.starts_at),
      ends_at: isoToDatetimeLocalValue(shift.ends_at),
      position: shift.position ?? "",
      notes: shift.notes ?? "",
      approval_status: shift.approval_status,
      rejection_reason: shift.rejection_reason,
    });
    setDialogOpen(true);
  };

  const shiftsByDay = useMemo(() => {
    const map = new Map<string, EmployeeShift[]>();
    days.forEach((d) => map.set(d.toDateString(), []));
    shifts.forEach((s) => {
      const key = new Date(s.starts_at).toDateString();
      const arr = map.get(key);
      if (arr) arr.push(s);
    });
    return map;
  }, [days, shifts]);

  const totalHoursByEmployee = useMemo(() => {
    const map = new Map<string, number>();
    shifts.forEach((s) => {
      map.set(s.user_id, (map.get(s.user_id) ?? 0) + hoursBetween(s.starts_at, s.ends_at));
    });
    return map;
  }, [shifts]);

  const handleSave = async () => {
    const starts_at = datetimeLocalValueToIso(form.starts_at);
    const ends_at = datetimeLocalValueToIso(form.ends_at);
    if (!form.user_id) return toast.error("Pick an employee");
    if (!starts_at || !ends_at) return toast.error("Set start and end time");
    if (new Date(ends_at) <= new Date(starts_at)) return toast.error("End must be after start");

    const payload = {
      user_id: form.user_id,
      starts_at,
      ends_at,
      position: form.position.trim() || null,
      notes: form.notes.trim() || null,
    };
    try {
      if (form.id) {
        // Edits to an approved shift send it back to pending review.
        await updateShift.mutateAsync({
          id: form.id,
          ...payload,
          resetApproval: form.approval_status === "approved",
        });
        toast.success(
          form.approval_status === "approved"
            ? "Shift updated — sent back for approval"
            : "Shift updated",
        );
      } else {
        await createShift.mutateAsync(payload);
        toast.success("Shift drafted — awaiting approval");
      }
      setDialogOpen(false);
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Failed to save shift");
    }
  };

  const handleApprove = async (id: string) => {
    try {
      await approveShift.mutateAsync(id);
      toast.success("Shift approved & published");
      setDialogOpen(false);
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Failed to approve");
    }
  };

  const handleReject = async (id: string) => {
    const reason = window.prompt("Reason for rejection (optional)") ?? "";
    try {
      await rejectShift.mutateAsync({ id, reason });
      toast.success("Shift rejected");
      setDialogOpen(false);
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Failed to reject");
    }
  };

  const handleDelete = async () => {
    if (!form.id) return;
    if (!confirm("Delete this shift?")) return;
    try {
      await deleteShift.mutateAsync(form.id);
      toast.success("Shift removed");
      setDialogOpen(false);
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Failed to delete");
    }
  };

  const weekLabel = `${fmtDay(weekStart)} – ${fmtDay(new Date(weekEnd.getTime() - DAY_MS))}`;

  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.25 }}
      className="space-y-6 p-4 sm:p-6"
    >
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="font-display text-2xl sm:text-3xl font-semibold flex items-center gap-2">
            <CalendarIcon className="h-6 w-6 text-accent" />
            Schedule
          </h1>
          <p className="text-sm text-muted-foreground">
            {isAdmin ? "Plan and publish staff shifts." : "Your upcoming shifts for the week."}
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="icon"
            onClick={() => setWeekStart(new Date(weekStart.getTime() - 7 * DAY_MS))}
            aria-label="Previous week"
          >
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <div className="text-sm font-medium px-2 min-w-[180px] text-center">{weekLabel}</div>
          <Button
            variant="outline"
            size="icon"
            onClick={() => setWeekStart(new Date(weekStart.getTime() + 7 * DAY_MS))}
            aria-label="Next week"
          >
            <ChevronRight className="h-4 w-4" />
          </Button>
          <Button variant="outline" onClick={() => setWeekStart(startOfWeek(new Date()))}>
            Today
          </Button>
          {isAdmin && (
            <Button onClick={() => openCreate()}>
              <Plus className="h-4 w-4 mr-1" /> New Shift
            </Button>
          )}
        </div>
      </div>

      {isAdmin && pendingShifts.length > 0 && (
        <Card className="border-2 border-amber-400/60 rounded-2xl bg-amber-50/40 dark:bg-amber-950/10">
          <CardHeader className="pb-2">
            <CardTitle className="text-base flex items-center gap-2">
              <Clock className="h-4 w-4 text-amber-600" />
              Pending approvals
              <Badge variant="outline">{pendingShifts.length}</Badge>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            {pendingShifts.slice(0, 8).map((s) => (
              <div
                key={s.id}
                className="flex flex-wrap items-center gap-2 rounded-lg border border-border bg-background/60 px-3 py-2"
              >
                <button
                  className="flex-1 text-left min-w-[180px]"
                  onClick={() => openEdit(s)}
                >
                  <div className="text-sm font-semibold">{profileMap.get(s.user_id) ?? "Staff"}</div>
                  <div className="text-xs text-muted-foreground">
                    {new Date(s.starts_at).toLocaleDateString(undefined, { weekday: "short", month: "short", day: "numeric" })} · {fmtTime(s.starts_at)}–{fmtTime(s.ends_at)}
                    {s.position ? ` · ${s.position}` : ""}
                  </div>
                </button>
                <Button
                  size="sm"
                  variant="outline"
                  className="border-emerald-600 text-emerald-700 hover:bg-emerald-50"
                  onClick={() => handleApprove(s.id)}
                  disabled={approveShift.isPending}
                >
                  <CheckCircle2 className="h-3.5 w-3.5 mr-1" /> Approve
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => handleReject(s.id)}
                  disabled={rejectShift.isPending}
                >
                  <XCircle className="h-3.5 w-3.5 mr-1" /> Reject
                </Button>
              </div>
            ))}
            {pendingShifts.length > 8 && (
              <p className="text-xs text-muted-foreground">+ {pendingShifts.length - 8} more pending</p>
            )}
          </CardContent>
        </Card>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-7 gap-3">
        {days.map((day) => {
          const dayShifts = shiftsByDay.get(day.toDateString()) ?? [];
          const isToday = day.toDateString() === new Date().toDateString();
          return (
            <Card
              key={day.toISOString()}
              className={`border-2 ${isToday ? "border-accent" : "border-border"} rounded-2xl shadow-soft`}
            >
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-semibold flex items-center justify-between">
                  <span>{fmtDay(day)}</span>
                  {isAdmin && (
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-6 w-6"
                      onClick={() => openCreate(day)}
                    >
                      <Plus className="h-3.5 w-3.5" />
                    </Button>
                  )}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2 min-h-[120px]">
                {dayShifts.length === 0 ? (
                  <p className="text-xs text-muted-foreground italic">No shifts</p>
                ) : (
                  dayShifts
                    .sort((a, b) => a.starts_at.localeCompare(b.starts_at))
                    .map((s) => (
                      <button
                        key={s.id}
                        onClick={() => isAdmin && openEdit(s)}
                        disabled={!isAdmin}
                        className="w-full text-left rounded-lg border border-border bg-card/60 px-2.5 py-2 hover:bg-accent/10 transition-colors disabled:cursor-default"
                      >
                        <div className="flex items-center justify-between gap-1">
                          <span className="text-xs font-semibold truncate">
                            {profileMap.get(s.user_id) ?? "Staff"}
                          </span>
                          {statusBadge(s)}
                        </div>
                        <div className="text-[11px] text-muted-foreground mt-0.5">
                          {fmtTime(s.starts_at)} – {fmtTime(s.ends_at)}
                        </div>
                        {s.position && (
                          <div className="text-[10px] text-accent mt-0.5 truncate">{s.position}</div>
                        )}
                      </button>
                    ))
                )}
              </CardContent>
            </Card>
          );
        })}
      </div>

      {isAdmin && totalHoursByEmployee.size > 0 && (
        <Card className="border-2 border-border rounded-2xl">
          <CardHeader className="pb-2">
            <CardTitle className="text-base">Weekly hours</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="divide-y divide-border/60">
              {Array.from(totalHoursByEmployee.entries())
                .sort((a, b) => b[1] - a[1])
                .map(([uid, h]) => (
                  <div key={uid} className="flex items-center justify-between py-2 text-sm">
                    <span className="font-medium">{profileMap.get(uid) ?? "Staff"}</span>
                    <span className="text-muted-foreground tabular-nums">{h.toFixed(1)} h</span>
                  </div>
                ))}
            </div>
          </CardContent>
        </Card>
      )}

      {isLoading && (
        <p className="text-sm text-muted-foreground">Loading schedule…</p>
      )}

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>{form.id ? "Edit shift" : "New shift"}</DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <div>
              <Label>Employee</Label>
              <Select value={form.user_id} onValueChange={(v) => setForm((f) => ({ ...f, user_id: v }))}>
                <SelectTrigger>
                  <SelectValue placeholder="Select employee" />
                </SelectTrigger>
                <SelectContent>
                  {profiles.map((p) => (
                    <SelectItem key={p.id} value={p.id}>
                      {p.full_name || "Unknown"}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-2 gap-2">
              <div>
                <Label>Starts</Label>
                <Input
                  type="datetime-local"
                  value={form.starts_at}
                  onChange={(e) => setForm((f) => ({ ...f, starts_at: e.target.value }))}
                />
              </div>
              <div>
                <Label>Ends</Label>
                <Input
                  type="datetime-local"
                  value={form.ends_at}
                  onChange={(e) => setForm((f) => ({ ...f, ends_at: e.target.value }))}
                />
              </div>
            </div>
            <div>
              <Label>Position (optional)</Label>
              <Input
                value={form.position}
                placeholder="e.g. Budtender, Lead, Inventory"
                onChange={(e) => setForm((f) => ({ ...f, position: e.target.value }))}
              />
            </div>
            <div>
              <Label>Notes (optional)</Label>
              <Textarea
                value={form.notes}
                rows={2}
                onChange={(e) => setForm((f) => ({ ...f, notes: e.target.value }))}
              />
            </div>
            <div className="rounded-lg border border-border bg-muted/30 p-3 text-xs space-y-1">
              <div className="flex items-center justify-between">
                <span className="font-semibold uppercase tracking-wider text-muted-foreground">Approval</span>
                <span className="inline-flex items-center gap-1">
                  {form.approval_status === "approved" && <CheckCircle2 className="h-3.5 w-3.5 text-emerald-600" />}
                  {form.approval_status === "rejected" && <XCircle className="h-3.5 w-3.5 text-destructive" />}
                  {form.approval_status === "pending" && <Clock className="h-3.5 w-3.5 text-muted-foreground" />}
                  <span className="capitalize">{form.approval_status}</span>
                </span>
              </div>
              {form.approval_status === "rejected" && form.rejection_reason && (
                <p className="text-muted-foreground">Reason: {form.rejection_reason}</p>
              )}
              {form.id && form.approval_status === "approved" && (
                <p className="text-muted-foreground">Saving edits will send this back for approval.</p>
              )}
            </div>
          </div>
          <DialogFooter className="flex flex-wrap sm:justify-between gap-2">
            {form.id ? (
              <Button
                variant="destructive"
                onClick={handleDelete}
                disabled={deleteShift.isPending}
                className="sm:mr-auto"
              >
                {deleteShift.isPending ? (
                  <Loader2 className="h-4 w-4 mr-1 animate-spin" />
                ) : (
                  <Trash2 className="h-4 w-4 mr-1" />
                )}
                Delete
              </Button>
            ) : <span />}
            <div className="flex flex-wrap gap-2">
              {form.id && form.approval_status !== "approved" && (
                <Button
                  variant="outline"
                  onClick={() => handleApprove(form.id!)}
                  disabled={approveShift.isPending}
                  className="border-emerald-600 text-emerald-700 hover:bg-emerald-50"
                >
                  {approveShift.isPending ? (
                    <Loader2 className="h-4 w-4 mr-1 animate-spin" />
                  ) : (
                    <CheckCircle2 className="h-4 w-4 mr-1" />
                  )}
                  Approve & Publish
                </Button>
              )}
              {form.id && form.approval_status !== "rejected" && (
                <Button
                  variant="outline"
                  onClick={() => handleReject(form.id!)}
                  disabled={rejectShift.isPending}
                >
                  {rejectShift.isPending ? (
                    <Loader2 className="h-4 w-4 mr-1 animate-spin" />
                  ) : (
                    <XCircle className="h-4 w-4 mr-1" />
                  )}
                  Reject
                </Button>
              )}
              <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
              <Button
                onClick={handleSave}
                disabled={createShift.isPending || updateShift.isPending || !form.user_id}
              >
                {(createShift.isPending || updateShift.isPending) && (
                  <Loader2 className="h-4 w-4 mr-1 animate-spin" />
                )}
                {form.id ? "Save" : "Submit for Approval"}
              </Button>
            </div>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </motion.div>
  );
};

export default Schedule;
