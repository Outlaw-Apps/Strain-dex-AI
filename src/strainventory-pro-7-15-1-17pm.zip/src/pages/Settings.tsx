import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { Settings as SettingsIcon, Users, Clock, Sparkles, AlertTriangle, Loader2, Navigation, Globe, MapPin, UserCheck, KeyRound, ShieldCheck, Image as ImageIcon, Mail, Banknote } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { toast } from "sonner";
import { cn } from "@/lib/utils";
import { useAuth } from "@/context/AuthContext";
import { useUserRoles } from "@/hooks/useUserRoles";
import { EmployeeTimeClock } from "@/components/settings/EmployeeTimeClock";
import { AiSourcesSettings } from "@/components/settings/AiSourcesSettings";
import { MetrcSettingsPanel } from "@/components/settings/MetrcSettingsPanel";
import { WebsiteIntegrationPanel } from "@/components/settings/WebsiteIntegrationPanel";
import { BrandingSettings } from "@/components/settings/BrandingSettings";
import { EmailTemplatesSettings } from "@/components/settings/EmailTemplatesSettings";
import { ScheduledEmailsPanel } from "@/components/settings/ScheduledEmailsPanel";
import { useBusinessSettings } from "@/hooks/useBusinessSettings";
import { useGeofence } from "@/hooks/useGeofence";
import { PendingEmployeesPanel } from "@/components/settings/PendingEmployeesPanel";
import { UserAccountsPanel } from "@/components/settings/UserAccountsPanel";
import { AccountSecurityPanel } from "@/components/settings/AccountSecurityPanel";
import { ScannerPrinterSettingsPanel } from "@/components/settings/ScannerPrinterSettingsPanel";
import { AppearanceSettingsPanel } from "@/components/settings/AppearanceSettingsPanel";
import { CheckTemplatesPanel } from "@/components/settings/CheckTemplatesPanel";
import { Link } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";

const Settings = () => {
  const { user } = useAuth();
  const { isAdmin } = useUserRoles();
  const { settings, isLoading: loadingSettings, updateSettings } = useBusinessSettings();
  const { isInsideFence } = useGeofence();

  // Form state
  const [form, setForm] = useState({
    geofence_enabled: false,
    geofence_lat: 34.0522,
    geofence_lng: -118.2437,
    geofence_radius_meters: 150,
    autoLock: true,
    overtimeAlerts: true,
    shiftRounding: "15",
    aiSource: "leafly",
    autoDownload: true,
    retention: "90",
  });

  const [saving, setSaving] = useState(false);
  const [exportingLogs, setExportingLogs] = useState(false);
  const [lastAccuracyMeters, setLastAccuracyMeters] = useState<number | null>(null);
  const [testingGeofence, setTestingGeofence] = useState(false);
  const [lastGeofenceTest, setLastGeofenceTest] = useState<
    | {
        kind: string;
        inside: boolean;
        distanceMeters: number;
        accuracyMeters: number;
        effectiveRadiusMeters: number;
        message?: string;
      }
    | null
  >(null);

  // Sync database settings into form
  useEffect(() => {
    if (settings) {
      setForm((prev) => ({
        ...prev,
        geofence_enabled: settings.geofence_enabled,
        geofence_lat: settings.geofence_lat ?? 34.0522,
        geofence_lng: settings.geofence_lng ?? -118.2437,
        geofence_radius_meters: settings.geofence_radius_meters,
      }));
    }
  }, [settings]);

  const handleSave = async () => {
    setSaving(true);
    try {
      await updateSettings({
        geofence_enabled: form.geofence_enabled,
        geofence_lat: form.geofence_lat,
        geofence_lng: form.geofence_lng,
        geofence_radius_meters: form.geofence_radius_meters,
      });
    } finally {
      setSaving(false);
    }
  };

  const setCurrentLocation = async () => {
    try {
      const pos = await new Promise<GeolocationPosition>((resolve, reject) => {
        navigator.geolocation.getCurrentPosition(resolve, reject, {
          enableHighAccuracy: true,
          timeout: 10000,
        });
      });
      const accuracy = Math.round(pos.coords.accuracy ?? 0);
      const recommendedRadius = Math.max(
        form.geofence_radius_meters,
        Math.max(250, accuracy + 50),
      );
      setForm((prev) => ({
        ...prev,
        geofence_lat: pos.coords.latitude,
        geofence_lng: pos.coords.longitude,
        geofence_radius_meters: recommendedRadius,
      }));
      setLastAccuracyMeters(accuracy);
      // Persist immediately so operators don't have to remember to hit Save
      // after pinning the store location.
      try {
        await updateSettings({
          geofence_enabled: form.geofence_enabled,
          geofence_lat: pos.coords.latitude,
          geofence_lng: pos.coords.longitude,
          geofence_radius_meters: recommendedRadius,
        });
      } catch {
        // updateSettings already toasts on failure.
      }
    } catch {
      setLastAccuracyMeters(null);
      toast.error("Could not get location. Please enable location services.");
    }
  };

  const handleTestGeofence = async () => {
    setTestingGeofence(true);
    setLastGeofenceTest(null);
    try {
      const result = await isInsideFence();
      setLastGeofenceTest({
        kind: result.kind,
        inside: result.inside,
        distanceMeters: result.distanceMeters,
        accuracyMeters: result.accuracyMeters,
        effectiveRadiusMeters: result.effectiveRadiusMeters,
        message: result.message,
      });
      switch (result.kind) {
        case "disabled":
          toast("Geofence is disabled — clock-in is unrestricted.");
          break;
        case "inside":
          toast.success(
            `Inside fence (${result.distanceMeters}m / allowed ${result.effectiveRadiusMeters}m).`,
          );
          break;
        case "outside":
          toast.warning(
            `Outside fence by ${result.distanceMeters - result.effectiveRadiusMeters}m.`,
          );
          break;
        default:
          toast.error(result.message || `Geofence check: ${result.kind}`);
      }
    } finally {
      setTestingGeofence(false);
    }
  };

  const handleExportLogs = async () => {
    setExportingLogs(true);
    try {
      const [timeEntriesRes, ordersRes, customersRes] = await Promise.all([
        supabase
          .from("time_entries")
          .select("id,user_id,clock_in,clock_out,total_hours,notes,created_at")
          .order("created_at", { ascending: false })
          .limit(500),
        supabase
          .from("orders")
          .select("id,created_by,customer_id,payment_method,status,subtotal,tax,total,created_at")
          .order("created_at", { ascending: false })
          .limit(500),
        supabase
          .from("customers")
          .select("id,customer_number,name,last_age_verified_at,created_at")
          .order("created_at", { ascending: false })
          .limit(500),
      ]);

      if (timeEntriesRes.error) throw timeEntriesRes.error;
      if (ordersRes.error) throw ordersRes.error;
      if (customersRes.error) throw customersRes.error;

      const payload = {
        exported_at: new Date().toISOString(),
        exported_by: user?.email ?? "unknown",
        app: "StrainVentory",
        diagnostics: {
          time_entries: timeEntriesRes.data ?? [],
          orders: ordersRes.data ?? [],
          customers: customersRes.data ?? [],
          local_storage_keys: Object.keys(localStorage),
        },
      };

      const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" });
      const url = URL.createObjectURL(blob);
      const anchor = document.createElement("a");
      const stamp = new Date().toISOString().replace(/[:.]/g, "-");
      anchor.href = url;
      anchor.download = `strainventory-logs-${stamp}.json`;
      document.body.appendChild(anchor);
      anchor.click();
      anchor.remove();
      URL.revokeObjectURL(url);

      toast.success("Logs exported successfully.");
    } catch (error) {
      console.error("Failed to export logs", error);
      toast.error(error instanceof Error ? error.message : "Failed to export logs.");
    } finally {
      setExportingLogs(false);
    }
  };

  return (
    <div className="p-4 sm:p-6 lg:p-10 max-w-6xl mx-auto">
      {/* Header */}
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-8">
        <div className="flex items-center gap-4">
          <div className="h-12 w-12 rounded-xl gold-gradient flex items-center justify-center shadow-gold shrink-0">
            <SettingsIcon className="h-6 w-6 text-accent-foreground" />
          </div>
          <div>
            <h1 className="text-display text-3xl sm:text-4xl font-semibold tracking-tight text-foreground flex items-center gap-2">
              Settings
              <span className="h-2 w-2 rounded-full bg-success animate-pulse" />
            </h1>
            <p className="text-sm sm:text-base text-muted-foreground mt-1">Configure system preferences, time tracking, and AI defaults.</p>
          </div>
        </div>
        <div className="flex gap-2 w-full sm:w-auto">
          {isAdmin && (
            <Button variant="outline" size="sm" onClick={handleExportLogs} disabled={exportingLogs} className="gap-1.5 border-2 border-border font-semibold">
              {exportingLogs && <Loader2 className="h-3.5 w-3.5 animate-spin" />}
              Export Logs
            </Button>
          )}
          <Button variant="gold" size="sm" onClick={handleSave} disabled={saving || loadingSettings} className="gap-1.5 border-2 border-accent shadow-gold font-semibold">
            {saving && <Loader2 className="h-3.5 w-3.5 animate-spin" />}
            Save All Changes
          </Button>
        </div>
      </motion.div>

      <Tabs defaultValue="timeclock" className="space-y-6">
        <TabsList className="border-2 border-border bg-card p-1 h-auto flex-wrap gap-1 shadow-soft rounded-xl">
          <TabsTrigger value="timeclock" className="gap-1.5">
            <Clock className="h-3.5 w-3.5" /> Time Clock
          </TabsTrigger>
          {isAdmin && (
            <TabsTrigger value="branding" className="gap-1.5">
              <ImageIcon className="h-3.5 w-3.5" /> Branding
            </TabsTrigger>
          )}
          <TabsTrigger value="preferences" className="gap-1.5">
            <SettingsIcon className="h-3.5 w-3.5" /> Preferences
          </TabsTrigger>
          {isAdmin && (
            <TabsTrigger value="ai-sources" className="gap-1.5">
              <Globe className="h-3.5 w-3.5" /> AI Sources
            </TabsTrigger>
          )}
          {isAdmin && (
            <TabsTrigger value="employees" className="gap-1.5">
              <UserCheck className="h-3.5 w-3.5" /> Employees
            </TabsTrigger>
          )}
          {isAdmin && (
            <TabsTrigger value="users" className="gap-1.5">
              <KeyRound className="h-3.5 w-3.5" /> User Accounts
            </TabsTrigger>
          )}
          {isAdmin && (
            <TabsTrigger value="metrc" className="gap-1.5">
              <ShieldCheck className="h-3.5 w-3.5" /> Metrc
            </TabsTrigger>
          )}
          {isAdmin && (
            <TabsTrigger value="website" className="gap-1.5">
              <Globe className="h-3.5 w-3.5" /> Website
            </TabsTrigger>
          )}
          {isAdmin && (
            <TabsTrigger value="emails" className="gap-1.5">
              <Mail className="h-3.5 w-3.5" /> Emails
            </TabsTrigger>
          )}
          {isAdmin && (
            <TabsTrigger value="payroll" className="gap-1.5">
              <Banknote className="h-3.5 w-3.5" /> Payroll
            </TabsTrigger>
          )}
          <TabsTrigger value="account" className="gap-1.5">
            <Users className="h-3.5 w-3.5" /> Account
          </TabsTrigger>
        </TabsList>

        {/* Time Clock Tab */}
        <TabsContent value="timeclock">
          <EmployeeTimeClock />
        </TabsContent>

        {/* Branding Tab */}
        {isAdmin && (
          <TabsContent value="branding">
            <BrandingSettings />
          </TabsContent>
        )}

        {/* Email Templates Tab */}
        {isAdmin && (
          <TabsContent value="emails" className="space-y-6">
            <EmailTemplatesSettings />
            <ScheduledEmailsPanel />
          </TabsContent>
        )}

        {/* Payroll Tab — Check Templates */}
        {isAdmin && (
          <TabsContent value="payroll" className="space-y-6">
            <CheckTemplatesPanel />
          </TabsContent>
        )}

        {/* Preferences Tab */}
        <TabsContent value="preferences">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Time Clock Settings */}
            <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}>
              <Card className="border-2 border-border bg-card shadow-elevated rounded-2xl h-full">
                <CardHeader className="pb-3">
                  <CardTitle className="text-base flex items-center gap-2">
                    <Clock className="h-4 w-4 text-accent" />
                    Time Clock Rules
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-1">
                  <SettingRow label="Shift Rounding" description="Round clock-in to nearest interval">
                    <Select value={form.shiftRounding} onValueChange={(v) => setForm(p => ({ ...p, shiftRounding: v }))}>
                      <SelectTrigger className="w-[140px] h-8 text-xs"><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="0">None</SelectItem>
                        <SelectItem value="5">5 Minutes</SelectItem>
                        <SelectItem value="15">15 Minutes</SelectItem>
                        <SelectItem value="30">30 Minutes</SelectItem>
                      </SelectContent>
                    </Select>
                  </SettingRow>
                  <SettingRow label="Overtime Alerts" description="Notify admin when employee exceeds 40hrs/week">
                    <Switch checked={form.overtimeAlerts} onCheckedChange={(v) => setForm(p => ({ ...p, overtimeAlerts: v }))} />
                  </SettingRow>

                  {/* NEW: Real Geofence Section */}
                  <SettingRow label="Geofencing" description="Restrict clock-in to dispensary location">
                    <Switch checked={form.geofence_enabled} onCheckedChange={(v) => setForm(p => ({ ...p, geofence_enabled: v }))} />
                  </SettingRow>

                  {form.geofence_enabled && (
                    <div className="pl-6 border-l-2 border-accent/30 space-y-4 pt-3">
                      <div className="flex items-center gap-2 flex-wrap">
                        <Button variant="outline" size="sm" onClick={setCurrentLocation} className="gap-2">
                          <Navigation className="h-3 w-3" />
                          Use Current Location
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={handleTestGeofence}
                          disabled={testingGeofence}
                          className="gap-2"
                        >
                          {testingGeofence ? (
                            <Loader2 className="h-3 w-3 animate-spin" />
                          ) : (
                            <MapPin className="h-3 w-3" />
                          )}
                          Test Geofence Now
                        </Button>
                        {lastAccuracyMeters !== null && (
                          <span className="text-[10px] text-muted-foreground">
                            Last reading: ±{lastAccuracyMeters}m accuracy
                            {lastAccuracyMeters > form.geofence_radius_meters && (
                              <span className="text-warning ml-1">
                                (radius is smaller than accuracy — staff inside the building may be rejected)
                              </span>
                            )}
                          </span>
                        )}
                      </div>

                      {lastGeofenceTest && (
                        <div
                          className={cn(
                            "rounded-md border p-2 text-[11px] space-y-1",
                            lastGeofenceTest.kind === "inside"
                              ? "border-success/40 bg-success/10 text-success"
                              : lastGeofenceTest.kind === "outside"
                                ? "border-warning/40 bg-warning/10 text-warning"
                                : lastGeofenceTest.kind === "disabled"
                                  ? "border-border bg-muted/40 text-muted-foreground"
                                  : "border-destructive/40 bg-destructive/10 text-destructive",
                          )}
                        >
                          <div className="font-medium">
                            Result: {lastGeofenceTest.kind}
                          </div>
                          <div className="text-muted-foreground">
                            Distance {lastGeofenceTest.distanceMeters}m · GPS accuracy ±
                            {lastGeofenceTest.accuracyMeters}m · Allowed within{" "}
                            {lastGeofenceTest.effectiveRadiusMeters}m
                          </div>
                          {lastGeofenceTest.message && (
                            <div className="text-muted-foreground">{lastGeofenceTest.message}</div>
                          )}
                        </div>
                      )}

                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <Label className="text-xs">Latitude</Label>
                          <Input
                            type="number"
                            step="0.000001"
                            value={form.geofence_lat}
                            onChange={(e) => {
                              const v = parseFloat(e.target.value);
                              if (!Number.isNaN(v)) setForm(p => ({ ...p, geofence_lat: v }));
                            }}
                          />
                        </div>
                        <div>
                          <Label className="text-xs">Longitude</Label>
                          <Input
                            type="number"
                            step="0.000001"
                            value={form.geofence_lng}
                            onChange={(e) => {
                              const v = parseFloat(e.target.value);
                              if (!Number.isNaN(v)) setForm(p => ({ ...p, geofence_lng: v }));
                            }}
                          />
                        </div>
                      </div>

                      <div>
                        <Label className="text-xs">Radius (meters)</Label>
                        <Input
                          type="number"
                          min={1}
                          value={form.geofence_radius_meters}
                          onChange={(e) => {
                            const v = parseInt(e.target.value, 10);
                            if (!Number.isNaN(v) && v > 0) setForm(p => ({ ...p, geofence_radius_meters: v }));
                          }}
                          className="w-32"
                        />
                      </div>
                    </div>
                  )}

                  <SettingRow label="Auto-lock Terminal" description="Lock terminal after 5 minutes of inactivity">
                    <Switch checked={form.autoLock} onCheckedChange={(v) => setForm(p => ({ ...p, autoLock: v }))} />
                  </SettingRow>
                </CardContent>
              </Card>
            </motion.div>

            {/* AI Defaults (unchanged) */}
            <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.15 }}>
              <Card className="border-2 border-border bg-card shadow-elevated rounded-2xl h-full">
                <CardHeader className="pb-3">
                  <CardTitle className="text-base flex items-center gap-2">
                    <Sparkles className="h-4 w-4 text-accent" />
                    AI Generation Defaults
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-1">
                  {/* ... your existing AI settings rows (unchanged) ... */}
                  <SettingRow label="Default Strain Database" description="Primary source for AI strain research">
                    <Select value={form.aiSource} onValueChange={(v) => setForm(p => ({ ...p, aiSource: v }))}>
                      <SelectTrigger className="w-[180px] h-8 text-xs"><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="leafly">Leafly + Internal Lab</SelectItem>
                        <SelectItem value="seedfinder">Seedfinder</SelectItem>
                        <SelectItem value="all">All Sources</SelectItem>
                      </SelectContent>
                    </Select>
                  </SettingRow>
                  <SettingRow label="Auto-Download Assets" description="Automatically fetch hi-res terpene icons and strain photos">
                    <Switch checked={form.autoDownload} onCheckedChange={(v) => setForm(p => ({ ...p, autoDownload: v }))} />
                  </SettingRow>
                  <SettingRow label="Data Retention" description="How long to keep AI draft history">
                    <Select value={form.retention} onValueChange={(v) => setForm(p => ({ ...p, retention: v }))}>
                      <SelectTrigger className="w-[140px] h-8 text-xs"><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="30">30 Days</SelectItem>
                        <SelectItem value="90">90 Days</SelectItem>
                        <SelectItem value="365">1 Year</SelectItem>
                        <SelectItem value="0">Forever</SelectItem>
                      </SelectContent>
                    </Select>
                  </SettingRow>
                </CardContent>
              </Card>
            </motion.div>

            {/* Danger Zone (unchanged) */}
            {isAdmin && (
              <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.25 }}>
                <Card className="border-2 border-destructive/40 bg-card shadow-elevated rounded-2xl">
                  <CardHeader className="pb-3">
                    <CardTitle className="text-base flex items-center gap-2 text-destructive">
                      <AlertTriangle className="h-4 w-4" />
                      Danger Zone
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="p-4 rounded-lg bg-destructive/5 border border-destructive/20">
                      <p className="text-xs text-muted-foreground mb-3 leading-relaxed">
                        Resetting the system will erase all AI drafts, employee configurations, and sync settings. This cannot be undone.
                      </p>
                      <AlertDialog>
                        <AlertDialogTrigger asChild>
                          <Button variant="destructive" size="sm">Reset System</Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent>
                          <AlertDialogHeader>
                            <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
                            <AlertDialogDescription>
                              This action cannot be undone. This will permanently delete all drafts, configurations, and reset the system to factory defaults.
                            </AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel>Cancel</AlertDialogCancel>
                            <AlertDialogAction
                              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                              onClick={() => {
                                const preserve = new Set<string>();
                                // Preserve auth so the admin isn't logged out by the reset.
                                for (let i = 0; i < localStorage.length; i++) {
                                  const k = localStorage.key(i);
                                  if (k && k.startsWith("sb-")) preserve.add(k);
                                }
                                const keep: Record<string, string> = {};
                                preserve.forEach((k) => {
                                  const v = localStorage.getItem(k);
                                  if (v !== null) keep[k] = v;
                                });
                                localStorage.clear();
                                Object.entries(keep).forEach(([k, v]) => localStorage.setItem(k, v));
                                sessionStorage.clear();
                                window.dispatchEvent(new CustomEvent("website-integration-changed", { detail: { key: "*" } }));
                                toast.success("Local drafts, sync queue, and POS settings cleared.");
                                setTimeout(() => window.location.reload(), 600);
                              }}
                            >
                              Reset Everything
                            </AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            )}
          </div>
          <div className="mt-6">
            <AppearanceSettingsPanel />
          </div>
          <div className="mt-6">
            <ScannerPrinterSettingsPanel />
          </div>
        </TabsContent>


        {/* AI Sources Tab */}
        {isAdmin && (
          <TabsContent value="ai-sources">
            <AiSourcesSettings />
          </TabsContent>
        )}

        {/* Employees Tab (admin only) */}
        {isAdmin && (
          <TabsContent value="employees">
            <PendingEmployeesPanel />
          </TabsContent>
        )}

        {/* User Accounts Tab (admin only) */}
        {isAdmin && (
          <TabsContent value="users">
            <UserAccountsPanel />
          </TabsContent>
        )}

        {/* Metrc Tab (admin only) */}
        {isAdmin && (
          <TabsContent value="metrc">
            <MetrcSettingsPanel />
          </TabsContent>
        )}

        {/* Website Integration Tab (admin only) */}
        {isAdmin && (
          <TabsContent value="website">
            <WebsiteIntegrationPanel />
          </TabsContent>
        )}

        {/* Account Tab */}
        <TabsContent value="account" className="space-y-6">
          <AccountSecurityPanel />
          <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }}>
            <Card className="border-2 border-border bg-card shadow-elevated rounded-2xl max-w-lg">
              <CardHeader className="pb-3">
                <CardTitle className="text-base flex items-center gap-2">
                  <Users className="h-4 w-4 text-accent" />
                  Account Info
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-3 p-3 rounded-lg bg-muted/30 border border-border/50">
                  <div className="h-10 w-10 rounded-full bg-accent/20 flex items-center justify-center text-accent font-semibold text-sm">
                    {(user?.email?.[0] || "U").toUpperCase()}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-foreground truncate">{user?.email || "Unknown"}</p>
                    <p className="text-xs text-muted-foreground">
                      {isAdmin ? "Administrator" : "Staff Member"}
                    </p>
                  </div>
                  <Badge variant="secondary" className="text-[9px] uppercase tracking-wider bg-accent/15 text-accent-foreground">
                    {isAdmin ? "Admin" : "Staff"}
                  </Badge>
                </div>
                <div className="mt-4 flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-muted-foreground">
                  <Link to="/privacy" className="hover:text-accent transition-colors">Privacy Policy</Link>
                  <Link to="/terms" className="hover:text-accent transition-colors">Terms of Use</Link>
                  <a href="mailto:support@strainventory.com" className="hover:text-accent transition-colors">support@strainventory.com</a>
                </div>
                <p className="text-xs text-muted-foreground mt-3">
                  System Version 2.4.0-AI · Outlaw Tech
                </p>
              </CardContent>
            </Card>
          </motion.div>
        </TabsContent>
      </Tabs>
    </div>
  );
};

/* Setting Row Helper */
const SettingRow = ({
  label,
  description,
  children,
}: {
  label: string;
  description: string;
  children: React.ReactNode;
}) => (
  <div className="flex items-center justify-between py-3 border-b border-border/50 last:border-0">
    <div className="pr-4">
      <p className="text-sm text-foreground">{label}</p>
      <p className="text-xs text-muted-foreground">{description}</p>
    </div>
    {children}
  </div>
);

export default Settings;