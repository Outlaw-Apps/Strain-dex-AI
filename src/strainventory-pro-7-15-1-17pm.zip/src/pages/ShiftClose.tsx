import { useCallback, useMemo, useState } from "react";
import { format } from "date-fns";
import { ClipboardList, Download, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  aggregateOrdersForShift,
  expectedDrawerCash,
} from "@/lib/shiftReconciliation";
import {
  useOrdersInPeriod,
  useRecentShiftReports,
  useRecentAuditEvents,
  useCreateShiftReport,
  insertPosAuditEvent,
} from "@/hooks/useShiftReports";

function localDayBoundsISO(dateInput: string) {
  const start = new Date(`${dateInput}T00:00:00`);
  const end = new Date(`${dateInput}T23:59:59.999`);
  if (Number.isNaN(start.getTime()) || Number.isNaN(end.getTime())) {
    return { start: null, end: null };
  }
  return { start: start.toISOString(), end: end.toISOString() };
}

function downloadCsv(filename: string, rows: Record<string, string | number | null | undefined>[]) {
  if (rows.length === 0) {
    toast.error("Nothing to export.");
    return;
  }
  const keys = Object.keys(rows[0]);
  const esc = (v: unknown) => {
    const s = String(v ?? "");
    if (s.includes(",") || s.includes('"') || s.includes("\n")) return `"${s.replace(/"/g, '""')}"`;
    return s;
  };
  const lines = [keys.join(","), ...rows.map((r) => keys.map((k) => esc(r[k])).join(","))];
  const blob = new Blob([lines.join("\n")], { type: "text/csv;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

const ShiftClose = () => {
  const todayStr = format(new Date(), "yyyy-MM-dd");
  const [day, setDay] = useState(todayStr);
  const [openingFloat, setOpeningFloat] = useState("");
  const [countedCash, setCountedCash] = useState("");
  const [varianceNotes, setVarianceNotes] = useState("");
  const [notes, setNotes] = useState("");

  const { start: periodStart, end: periodEnd } = useMemo(() => localDayBoundsISO(day), [day]);

  const { data: orders = [], isLoading: ordersLoading } = useOrdersInPeriod(periodStart, periodEnd);
  const aggregates = useMemo(() => aggregateOrdersForShift(orders), [orders]);
  const expected = useMemo(() => {
    const open = openingFloat === "" ? null : Number.parseFloat(openingFloat);
    const validOpen = open != null && !Number.isNaN(open) ? open : null;
    return expectedDrawerCash(validOpen, aggregates.total_cash);
  }, [openingFloat, aggregates.total_cash]);

  const { data: recentReports = [] } = useRecentShiftReports(15);
  const { data: auditEvents = [] } = useRecentAuditEvents(80);
  const createReport = useCreateShiftReport();

  const handleSubmit = async () => {
    const counted =
      countedCash === "" ? null : Number.parseFloat(countedCash);
    const countedVal = counted != null && !Number.isNaN(counted) ? counted : null;
    const openVal =
      openingFloat === "" ? null : Number.parseFloat(openingFloat);
    const opening = openVal != null && !Number.isNaN(openVal) ? openVal : null;

    if (!periodStart || !periodEnd) {
      toast.error("Please select a valid date.");
      return;
    }

    try {
      await createReport.mutateAsync({
        period_start: periodStart,
        period_end: periodEnd,
        order_count: aggregates.order_count,
        total_sales: aggregates.total_sales,
        total_cash: aggregates.total_cash,
        total_card: aggregates.total_card,
        total_other: aggregates.total_other,
        opening_float: opening,
        counted_cash: countedVal,
        expected_cash: expected,
        variance_notes: varianceNotes.trim(),
        notes: notes.trim(),
      });
      toast.success("Shift report saved.");
      setVarianceNotes("");
      setNotes("");
    } catch (e) {
      console.error(e);
      toast.error(e instanceof Error ? e.message : "Could not save shift report.");
    }
  };

  const handleExportJournal = useCallback(async () => {
    try {
      await insertPosAuditEvent("journal_export", {
        day,
        audit_row_count: auditEvents.length,
        shift_report_row_count: recentReports.length,
      });
    } catch {
      // still offer CSV
    }

    const auditRows = auditEvents.map((e) => ({
      created_at: e.created_at,
      event_type: e.event_type,
      created_by: e.created_by ?? "",
      metadata: JSON.stringify(e.metadata),
    }));
    const reportRows = recentReports.map((r) => ({
      created_at: r.created_at,
      period_start: r.period_start,
      period_end: r.period_end,
      order_count: r.order_count,
      total_sales: r.total_sales,
      total_cash: r.total_cash,
      total_card: r.total_card,
      total_other: r.total_other,
      opening_float: r.opening_float ?? "",
      counted_cash: r.counted_cash ?? "",
      expected_cash: r.expected_cash ?? "",
      variance_notes: r.variance_notes,
    }));
    const stamp = format(new Date(), "yyyy-MM-dd-HHmm");
    downloadCsv(`strainventory-pos-audit-${stamp}.csv`, auditRows);
    downloadCsv(`strainventory-shift-reports-${stamp}.csv`, reportRows);
    toast.success("CSV files downloaded.");
  }, [auditEvents, recentReports, day]);

  return (
    <div className="p-4 sm:p-6 lg:p-10 max-w-5xl mx-auto space-y-6 sm:space-y-8">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center gap-4">
          <div className="gold-gradient flex h-12 w-12 items-center justify-center rounded-2xl shadow-gold">
            <ClipboardList className="h-6 w-6 text-accent-foreground" />
          </div>
          <div>
            <h1 className="text-display text-3xl sm:text-4xl font-semibold tracking-tight text-foreground flex items-center gap-3">
              Shift Close
              <span className="h-2 w-2 rounded-full bg-success animate-pulse" />
            </h1>
            <p className="mt-1 text-sm text-muted-foreground">
              Aggregate POS orders for a calendar day, record drawer counts, and export audit history.
            </p>
          </div>
        </div>
        <Button type="button" variant="outline" size="sm" className="border-2" onClick={handleExportJournal}>
          <Download className="mr-2 h-4 w-4" />
          Export journal CSV
        </Button>
      </div>

      <Card className="border-2 border-border bg-card shadow-elevated rounded-2xl">
        <CardHeader>
          <CardTitle>Reporting period</CardTitle>
          <CardDescription>Uses your local calendar day (store timezone).</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex flex-wrap items-end gap-4">
            <div className="space-y-2">
              <Label htmlFor="report-day">Day</Label>
              <Input
                id="report-day"
                type="date"
                value={day}
                onChange={(e) => setDay(e.target.value)}
                className="border-2"
              />
            </div>
            <Button type="button" variant="secondary" size="sm" onClick={() => setDay(todayStr)}>
              Today
            </Button>
          </div>

          {ordersLoading ? (
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <Loader2 className="h-4 w-4 animate-spin" />
              Loading orders…
            </div>
          ) : (
            <div className="grid gap-3 grid-cols-2 lg:grid-cols-4">
              <div className="rounded-2xl border-2 border-border bg-muted/30 p-4 shadow-soft">
                <p className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground">Orders</p>
                <p className="text-xl sm:text-2xl font-semibold mt-1">{aggregates.order_count}</p>
              </div>
              <div className="rounded-2xl border-2 border-accent/40 bg-card p-4 shadow-gold">
                <p className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground">Total sales</p>
                <p className="text-xl sm:text-2xl font-semibold mt-1 text-accent">${aggregates.total_sales.toFixed(2)}</p>
              </div>
              <div className="rounded-2xl border-2 border-border bg-muted/30 p-4 shadow-soft">
                <p className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground">Cash</p>
                <p className="text-lg sm:text-xl font-semibold mt-1">${aggregates.total_cash.toFixed(2)}</p>
              </div>
              <div className="rounded-2xl border-2 border-border bg-muted/30 p-4 shadow-soft">
                <p className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground">Card / tap</p>
                <p className="text-lg sm:text-xl font-semibold mt-1">${aggregates.total_card.toFixed(2)}</p>
              </div>
              <div className="rounded-2xl border-2 border-border bg-muted/30 p-4 shadow-soft col-span-2 lg:col-span-4">
                <p className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground">Other payments</p>
                <p className="text-lg sm:text-xl font-semibold mt-1">${aggregates.total_other.toFixed(2)}</p>
              </div>
            </div>
          )}
        </CardContent>
      </Card>


      <Card className="border-2 border-border bg-card shadow-elevated rounded-2xl">

        <CardHeader>
          <CardTitle>Drawer reconciliation</CardTitle>
          <CardDescription>Optional cash counts and notes for the safe / manager sign-off.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="opening-float">Opening float ($)</Label>
              <Input
                id="opening-float"
                inputMode="decimal"
                placeholder="e.g. 200"
                value={openingFloat}
                onChange={(e) => setOpeningFloat(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="counted-cash">Counted cash in drawer ($)</Label>
              <Input
                id="counted-cash"
                inputMode="decimal"
                placeholder="e.g. 415.50"
                value={countedCash}
                onChange={(e) => setCountedCash(e.target.value)}
              />
            </div>
          </div>
          {expected != null && (
            <p className="text-sm text-muted-foreground">
              Expected cash (float + cash sales): <span className="font-medium text-foreground">${expected.toFixed(2)}</span>
              {countedCash !== "" &&
              !Number.isNaN(Number.parseFloat(countedCash)) &&
              expected != null ? (
                <span className="ml-2">
                  · Variance:{" "}
                  <span className="font-medium text-foreground">
                    ${(Number.parseFloat(countedCash) - expected).toFixed(2)}
                  </span>
                </span>
              ) : null}
            </p>
          )}
          <div className="space-y-2">
            <Label htmlFor="variance-notes">Variance explanation</Label>
            <Textarea
              id="variance-notes"
              placeholder="Required if variance is non-zero or drawer is short."
              value={varianceNotes}
              onChange={(e) => setVarianceNotes(e.target.value)}
              rows={2}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="shift-notes">Shift notes</Label>
            <Textarea
              id="shift-notes"
              placeholder="Incidents, comps, training, etc."
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              rows={2}
            />
          </div>
          <Button
            type="button"
            onClick={handleSubmit}
            disabled={createReport.isPending || ordersLoading}
            className="border-2 border-accent shadow-gold"
            variant="gold"
          >
            {createReport.isPending ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Saving…
              </>
            ) : (
              "Save shift report"
            )}
          </Button>
        </CardContent>
      </Card>

      <Card className="border-2 border-border bg-card shadow-elevated rounded-2xl">

        <CardHeader>
          <CardTitle>Recent shift reports</CardTitle>
          <CardDescription>Latest closes in this database (newest first).</CardDescription>
        </CardHeader>
        <CardContent>
          {recentReports.length === 0 ? (
            <p className="text-sm text-muted-foreground">No saved reports yet.</p>
          ) : (
            <ul className="space-y-2 text-sm">
              {recentReports.map((r) => (
                <li
                  key={r.id}
                  className="flex flex-wrap items-baseline justify-between gap-2 border-b border-border pb-2 last:border-0"
                >
                  <span className="text-muted-foreground">
                    {format(new Date(r.period_start), "MMM d, yyyy")} · {r.order_count} orders
                  </span>
                  <span className="font-medium">${Number(r.total_sales).toFixed(2)} total</span>
                </li>
              ))}
            </ul>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default ShiftClose;
