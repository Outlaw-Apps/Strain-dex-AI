import { Link } from "react-router-dom";
import { ArrowLeft, ScrollText } from "lucide-react";
import { Button } from "@/components/ui/button";
import Seo from "@/components/Seo";

const SUPPORT_EMAIL = "support@strainventory.com";
const EFFECTIVE_DATE = "June 22, 2026";

const TermsOfUse = () => (
  <div className="min-h-screen bg-background text-foreground">
    <Seo
      title="Terms of Use | Strain-ventory"
      description="Terms governing access to and use of the Strain-ventory cannabis dispensary platform."
      path="/terms"
    />
    <div className="max-w-3xl mx-auto px-6 py-12">
      <Button asChild variant="ghost" size="sm" className="mb-6 gap-1.5">
        <Link to="/">
          <ArrowLeft className="h-4 w-4" /> Back
        </Link>
      </Button>

      <div className="flex items-center gap-3 mb-6">
        <div className="h-12 w-12 rounded-xl gold-gradient flex items-center justify-center shadow-gold">
          <ScrollText className="h-6 w-6 text-accent-foreground" />
        </div>
        <div>
          <h1 className="text-display text-3xl sm:text-4xl font-semibold tracking-tight">
            Terms of Use
          </h1>
          <p className="text-sm text-muted-foreground mt-1">
            Effective {EFFECTIVE_DATE}
          </p>
        </div>
      </div>

      <div className="prose prose-invert max-w-none space-y-6 text-sm leading-relaxed text-muted-foreground">
        <p>
          These Terms of Use ("Terms") govern access to and use of the
          Strain-ventory cannabis dispensary platform ("the Service"). By using
          the Service, you agree to these Terms on behalf of yourself and the
          dispensary that authorized your account.
        </p>

        <section>
          <h2 className="text-base font-semibold text-foreground">
            1. Eligibility and licensing
          </h2>
          <p>
            The Service is provided for use by licensed cannabis retailers and
            their staff. You represent that your dispensary holds all licenses
            required by its jurisdiction and that you are at least 21 years old
            or otherwise authorized by your employer to access the Service.
          </p>
        </section>

        <section>
          <h2 className="text-base font-semibold text-foreground">
            2. Accounts and credentials
          </h2>
          <p>
            You are responsible for keeping your password, PIN, and short ID
            confidential. Administrators are responsible for the staff accounts
            they create and for revoking access promptly when employees leave.
            Notify us at{" "}
            <a className="text-accent" href={`mailto:${SUPPORT_EMAIL}`}>
              {SUPPORT_EMAIL}
            </a>{" "}
            of any suspected unauthorized access.
          </p>
        </section>

        <section>
          <h2 className="text-base font-semibold text-foreground">
            3. Acceptable use
          </h2>
          <ul className="list-disc pl-5 space-y-1">
            <li>Do not use the Service to violate cannabis or other laws applicable to your dispensary.</li>
            <li>Do not attempt to bypass authentication, role permissions, or row-level security.</li>
            <li>Do not upload content you do not have rights to use.</li>
            <li>Do not use the Service to harass staff, customers, or third parties.</li>
          </ul>
        </section>

        <section>
          <h2 className="text-base font-semibold text-foreground">
            4. Compliance data
          </h2>
          <p>
            Features such as Metrc-style sync, age verification, and daily
            purchase limits are tools to assist with compliance. You remain
            solely responsible for the accuracy of records submitted to
            regulators and for verifying customer eligibility at point of sale.
          </p>
        </section>

        <section>
          <h2 className="text-base font-semibold text-foreground">
            5. AI-generated content
          </h2>
          <p>
            Product drafts, descriptions, and recommendations produced by the
            AI assistant ("Strain Vinny") are suggestions only. Always review
            AI output for accuracy, compliance, and dispensary tone before
            publishing.
          </p>
        </section>

        <section>
          <h2 className="text-base font-semibold text-foreground">
            6. Service availability
          </h2>
          <p>
            We work to keep the Service available but do not guarantee
            uninterrupted access. We may modify, suspend, or discontinue
            features with reasonable notice to administrators.
          </p>
        </section>

        <section>
          <h2 className="text-base font-semibold text-foreground">
            7. Disclaimer and liability
          </h2>
          <p>
            The Service is provided "as is" without warranties of any kind. To
            the maximum extent permitted by law, Strain-ventory is not liable
            for indirect, incidental, or consequential damages arising from
            your use of the Service, including lost profits, lost data, or
            regulatory penalties.
          </p>
        </section>

        <section>
          <h2 className="text-base font-semibold text-foreground">
            8. Termination
          </h2>
          <p>
            We may suspend or terminate access for violations of these Terms.
            You may stop using the Service at any time; administrators may
            request account closure by emailing{" "}
            <a className="text-accent" href={`mailto:${SUPPORT_EMAIL}`}>
              {SUPPORT_EMAIL}
            </a>
            .
          </p>
        </section>

        <section>
          <h2 className="text-base font-semibold text-foreground">
            9. Changes
          </h2>
          <p>
            We may update these Terms over time. Continued use of the Service
            after changes constitutes acceptance of the updated Terms.
          </p>
        </section>

        <section>
          <h2 className="text-base font-semibold text-foreground">
            10. Contact
          </h2>
          <p>
            Questions about these Terms:{" "}
            <a className="text-accent" href={`mailto:${SUPPORT_EMAIL}`}>
              {SUPPORT_EMAIL}
            </a>
            .
          </p>
        </section>
      </div>
    </div>
  </div>
);

export default TermsOfUse;
