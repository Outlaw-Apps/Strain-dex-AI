import { useEffect, useState } from "react";
import { useSearchParams } from "react-router-dom";
import { Loader2, Mail, CheckCircle2, XCircle } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { appConfig } from "@/lib/appConfig";

type State = "validating" | "valid" | "already" | "invalid" | "submitting" | "success" | "error";

const Unsubscribe = () => {
  const [params] = useSearchParams();
  const token = params.get("token");
  const [state, setState] = useState<State>("validating");
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!token) {
      setState("invalid");
      return;
    }
    (async () => {
      try {
        const res = await fetch(
          `${appConfig.edgeFunctionBaseUrl}/handle-email-unsubscribe?token=${encodeURIComponent(token)}`,
          { headers: { apikey: appConfig.supabasePublishableKey } },
        );
        const data = await res.json();
        if (data.valid) setState("valid");
        else if (data.reason === "already_unsubscribed") setState("already");
        else setState("invalid");
      } catch {
        setState("invalid");
      }
    })();
  }, [token]);

  const confirm = async () => {
    if (!token) return;
    setState("submitting");
    const { data, error } = await supabase.functions.invoke("handle-email-unsubscribe", {
      body: { token },
    });
    if (error) {
      setError(error.message);
      setState("error");
      return;
    }
    if ((data as { success?: boolean })?.success) setState("success");
    else setState("already");
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-6 bg-background">
      <Card className="w-full max-w-md border-2 border-border shadow-elevated rounded-2xl">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-display">
            <Mail className="h-5 w-5 text-accent" />
            Email preferences
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {state === "validating" && (
            <p className="text-sm text-muted-foreground flex items-center gap-2">
              <Loader2 className="h-4 w-4 animate-spin" /> Checking your link…
            </p>
          )}
          {state === "valid" && (
            <>
              <p className="text-sm">
                Are you sure you want to unsubscribe from all emails from us? You'll stop
                receiving notifications, receipts, and updates.
              </p>
              <Button variant="destructive" className="w-full" onClick={confirm}>
                Confirm unsubscribe
              </Button>
            </>
          )}
          {state === "submitting" && (
            <p className="text-sm text-muted-foreground flex items-center gap-2">
              <Loader2 className="h-4 w-4 animate-spin" /> Updating your preferences…
            </p>
          )}
          {state === "success" && (
            <p className="text-sm text-success flex items-center gap-2">
              <CheckCircle2 className="h-4 w-4" /> You've been unsubscribed.
            </p>
          )}
          {state === "already" && (
            <p className="text-sm text-muted-foreground flex items-center gap-2">
              <CheckCircle2 className="h-4 w-4" /> This email is already unsubscribed.
            </p>
          )}
          {state === "invalid" && (
            <p className="text-sm text-destructive flex items-center gap-2">
              <XCircle className="h-4 w-4" /> This unsubscribe link is invalid or expired.
            </p>
          )}
          {state === "error" && (
            <p className="text-sm text-destructive flex items-center gap-2">
              <XCircle className="h-4 w-4" /> {error || "Something went wrong."}
            </p>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default Unsubscribe;
