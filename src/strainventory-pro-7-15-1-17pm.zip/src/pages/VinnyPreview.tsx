import { Link } from "react-router-dom";
import { ArrowLeft } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import VinnyLegacy from "@/components/StrainVinnyAvatar";
import { VINNY_AVATAR_OPTION } from "@/components/StrainVinnyAvatar.constants";
import { VINNY_OPTIONS } from "@/components/StrainVinnyAvatar.config";

const VinnyPreview = () => {
  return (
    <div className="space-y-6 p-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold">Strain-Vinny Avatar Preview</h1>
          <p className="text-sm text-muted-foreground">
            Pick your favorite. The active option is highlighted. Switch the default by changing
            <code className="mx-1 rounded bg-muted px-1.5 py-0.5">VINNY_AVATAR_OPTION</code>
            in <code className="mx-1 rounded bg-muted px-1.5 py-0.5">src/components/StrainVinnyAvatar.tsx</code>.
          </p>
        </div>
        <Link
          to="/"
          className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground"
        >
          <ArrowLeft className="h-4 w-4" /> Back to dashboard
        </Link>
      </div>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {VINNY_OPTIONS.map(({ id, name, tagline, Component }) => {
          const isActive = id === VINNY_AVATAR_OPTION;
          return (
            <Card key={id} className={isActive ? "border-accent ring-2 ring-accent/40" : undefined}>
              <CardHeader className="flex flex-row items-center justify-between gap-2 pb-2">
                <CardTitle className="text-base">
                  Option {id} · {name}
                </CardTitle>
                {isActive ? <Badge variant="secondary">Active default</Badge> : null}
              </CardHeader>
              <CardContent className="flex flex-col items-center gap-3 pt-0">
                <Component size={120} title={`Strain-Vinny avatar option ${id}: ${name}`} />
                <div className="flex items-center gap-3 text-xs text-muted-foreground">
                  <Component size={48} />
                  <Component size={32} />
                  <Component size={20} />
                </div>
                <p className="text-center text-sm text-muted-foreground">{tagline}</p>
                <code className="rounded bg-muted px-2 py-1 text-xs">
                  VinnyOption{id}
                </code>
              </CardContent>
            </Card>
          );
        })}

        <Card>
          <CardHeader className="flex flex-row items-center justify-between gap-2 pb-2">
            <CardTitle className="text-base">Legacy · current robot</CardTitle>
            <Badge variant="outline">Rollback</Badge>
          </CardHeader>
          <CardContent className="flex flex-col items-center gap-3 pt-0">
            <VinnyLegacy size={120} title="Legacy Strain-Vinny avatar" />
            <div className="flex items-center gap-3 text-xs text-muted-foreground">
              <VinnyLegacy size={48} />
              <VinnyLegacy size={32} />
              <VinnyLegacy size={20} />
            </div>
            <p className="text-center text-sm text-muted-foreground">
              Kept as <code>VinnyLegacy</code> for instant rollback.
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default VinnyPreview;
