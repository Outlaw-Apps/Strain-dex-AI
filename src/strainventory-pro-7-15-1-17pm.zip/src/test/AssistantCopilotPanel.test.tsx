import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { fireEvent, render, screen, waitFor } from "@testing-library/react";
import { MemoryRouter } from "react-router-dom";
import { routerFuture } from "@/lib/routerFuture";
import AssistantCopilotPanel from "@/components/assistant/AssistantCopilotPanel";

const mocks = vi.hoisted(() => ({
  from: vi.fn(),
  toastError: vi.fn(),
  toastWarning: vi.fn(),
  setIntake: vi.fn(),
}));

vi.mock("@/context/AuthContext", () => ({
  useAuth: () => ({
    user: { id: "user-1" },
    session: { access_token: "session-token" },
  }),
}));

vi.mock("@/hooks/useUserRoles", () => ({
  useUserRoles: () => ({
    roles: ["admin"],
  }),
}));

vi.mock("@/context/ProductDraftContext", () => ({
  useProductDraft: () => ({
    product: {
      intake: {
        brand: "Pacific Stone",
        strain: "Blue Dream",
        productType: "Flower",
        packageSize: "3.5g",
        vendor: "Greenline",
        sku: "",
        notes: "",
      },
    },
    setIntake: mocks.setIntake,
  }),
}));

vi.mock("@/integrations/supabase/client", () => ({
  supabase: {
    from: mocks.from,
  },
}));

vi.mock("sonner", () => ({
  toast: {
    error: mocks.toastError,
    warning: mocks.toastWarning,
    success: vi.fn(),
  },
}));

const createLockError = () =>
  Object.assign(new Error('Timed out waiting for the Supabase auth lock "auth".'), {
    name: "SupabaseAuthLockAcquireTimeoutError",
    isAcquireTimeout: true,
  });

function createThreadsQuery(threadSelectCalls: { count: number }) {
  return {
    select: () => ({
      eq: () => ({
        order: () => ({
          limit: async () => {
            threadSelectCalls.count += 1;
            if (threadSelectCalls.count === 2) {
              throw createLockError();
            }
            return { data: [], error: null };
          },
        }),
      }),
    }),
  };
}

describe("AssistantCopilotPanel", () => {
  afterEach(() => {
    vi.restoreAllMocks();
  });

  beforeEach(() => {
    vi.clearAllMocks();
    vi.spyOn(console, "warn").mockImplementation(() => undefined);

    const threadSelectCalls = { count: 0 };
    mocks.from.mockImplementation((table: string) => {
      if (table === "assistant_threads") {
        return createThreadsQuery(threadSelectCalls);
      }
      return {
        select: () => ({
          eq: () => ({
            order: () => ({
              limit: async () => ({ data: [], error: null }),
            }),
          }),
        }),
        insert: async () => ({ error: null }),
      };
    });

    vi.stubGlobal(
      "fetch",
      vi.fn(async () =>
        new Response(
          JSON.stringify({
            thread_id: "thread-1",
            message_id: "assistant-1",
            reply: "Here is the sourced assistant answer.",
            actions: [],
            sources: [],
          }),
          { status: 200, headers: { "Content-Type": "application/json" } },
        ),
      ),
    );
  });

  it("keeps a successful assistant reply visible when Supabase history refresh hits lock contention", async () => {
    render(
      <MemoryRouter future={routerFuture}>
        <AssistantCopilotPanel />
      </MemoryRouter>,
    );

    await waitFor(() => expect(mocks.from).toHaveBeenCalledWith("assistant_threads"));

    fireEvent.change(
      screen.getByPlaceholderText(/ask for intake guidance/i),
      { target: { value: "Check sources for Blue Dream." } },
    );
    fireEvent.click(screen.getByRole("button", { name: /send to vinny/i }));

    expect(await screen.findByText("Here is the sourced assistant answer.")).toBeInTheDocument();
    await waitFor(() => expect(mocks.toastWarning).toHaveBeenCalled());

    expect(screen.getByText(/assistant history is busy syncing/i)).toBeInTheDocument();
    expect(screen.queryByText(/i hit an issue reaching the assistant service/i)).not.toBeInTheDocument();
    expect(mocks.toastError).not.toHaveBeenCalled();
  });
});
