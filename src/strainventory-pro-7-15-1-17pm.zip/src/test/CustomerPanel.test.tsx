import { describe, expect, it, vi } from "vitest";
import { fireEvent, render, screen } from "@testing-library/react";
import { MemoryRouter } from "react-router-dom";
import { routerFuture } from "@/lib/routerFuture";
import { CustomerPanel } from "@/components/pos/CustomerPanel";
import type { Customer } from "@/hooks/useCustomers";
import type { Order } from "@/hooks/useOrders";
import type { Product } from "@/hooks/useProducts";
import type { Json } from "@/integrations/supabase/types";

const mocks = vi.hoisted(() => ({
  useCustomerSearch: vi.fn(),
  useCustomerOrders: vi.fn(),
  useCreateCustomer: vi.fn(),
  invalidateQueries: vi.fn(),
}));

vi.mock("@tanstack/react-query", async () => {
  const actual = await vi.importActual<typeof import("@tanstack/react-query")>("@tanstack/react-query");
  return {
    ...actual,
    useQueryClient: () => ({ invalidateQueries: mocks.invalidateQueries }),
  };
});

vi.mock("@/hooks/useCustomers", () => ({
  useCustomerSearch: mocks.useCustomerSearch,
  useCreateCustomer: mocks.useCreateCustomer,
  useUpdateCustomerDiscountProfile: () => ({
    mutateAsync: vi.fn(),
    isPending: false,
  }),
}));

vi.mock("@/hooks/useOrders", () => ({
  useCustomerOrders: mocks.useCustomerOrders,
}));

vi.mock("@/integrations/supabase/client", () => ({
  supabase: {
    from: vi.fn(),
  },
}));

const selectedCustomer: Customer = {
  id: "customer-1",
  customer_number: "C-1001",
  name: "Jordan Lee",
  email: "",
  notes: "",
  phone: "555-0101",
  license_number: null,
  date_of_birth: null,
  last_age_verified_at: "2026-05-01T12:00:00.000Z",
  created_at: "2026-05-01T12:00:00.000Z",
  updated_at: "2026-05-01T12:00:00.000Z",
};

const favoriteProduct = {
  id: "product-1",
  name: "Blue Dream",
  brand: "Pacific Stone",
  type: "Flower",
  product_type: "Flower",
  status: "published",
  price: 12,
  quantity: 25,
  in_stock: true,
  images: [],
} as Product;

const matchingRecommendation = {
  ...favoriteProduct,
  id: "product-2",
  name: "Pineapple Express",
} as Product;

const recentOrders: Order[] = [
  {
    id: "order-1",
    customer_id: selectedCustomer.id,
    payment_method: "cash",
    subtotal: 12,
    tax: 1.8,
    total: 13.8,
    discount_total: 0,
    discount_summary: "",
    discount_snapshot_json: {} as Json,
    status: "completed",
    created_by: null,
    created_at: "2026-05-01T12:00:00.000Z",
    order_items: [
      {
        id: "item-1",
        order_id: "order-1",
        product_id: favoriteProduct.id,
        product_name: favoriteProduct.name,
        weight: "1g",
        quantity: 2,
        unit_price: 12,
        total_price: 24,
      },
    ],
  },
];

function renderPanel(onAddToCart = vi.fn()) {
  mocks.useCustomerSearch.mockReturnValue({ data: [] });
  mocks.useCustomerOrders.mockReturnValue({ data: recentOrders });
  mocks.useCreateCustomer.mockReturnValue({ mutateAsync: vi.fn(), isPending: false });

  render(
    <MemoryRouter future={routerFuture}>
      <CustomerPanel
        selectedCustomer={selectedCustomer}
        onSelectCustomer={vi.fn()}
        publishedProducts={[favoriteProduct, matchingRecommendation]}
        onAddToCart={onAddToCart}
      />
    </MemoryRouter>,
  );

  return onAddToCart;
}

describe("CustomerPanel POS favorites", () => {
  it("adds a customer favorite product to the cart instead of opening its product detail page", () => {
    const onAddToCart = renderPanel();

    fireEvent.click(screen.getByRole("button", { name: /add favorite blue dream to cart/i }));

    expect(onAddToCart).toHaveBeenCalledWith(favoriteProduct);
  });

  it("adds recommended products to the cart from the customer panel", () => {
    const onAddToCart = renderPanel();

    fireEvent.click(screen.getByRole("button", { name: /add recommended pineapple express to cart/i }));

    expect(onAddToCart).toHaveBeenCalledWith(matchingRecommendation);
  });
});
