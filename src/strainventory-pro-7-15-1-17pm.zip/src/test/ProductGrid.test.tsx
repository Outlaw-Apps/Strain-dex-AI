import { describe, expect, it, vi } from "vitest";
import { fireEvent, render, screen } from "@testing-library/react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { MemoryRouter } from "react-router-dom";
import { ProductGrid } from "@/components/pos/ProductGrid";
import type { Product } from "@/hooks/useProducts";

vi.mock("@/integrations/supabase/client", () => ({
  supabase: {
    from: vi.fn(),
  },
}));

vi.mock("sonner", () => ({
  toast: {
    error: vi.fn(),
    info: vi.fn(),
  },
}));

vi.mock("@/components/ui/BarcodeScanner", () => ({
  BarcodeScanner: () => null,
}));

const product = {
  id: "product-1",
  name: "Blue Dream",
  brand: "Pacific Stone",
  type: "Flower",
  product_type: "Flower",
  status: "published",
  price: 12,
  quantity: 25,
  in_stock: true,
  thc: "24%",
  images: [],
} as Product;

function renderGrid(onAddToCart = vi.fn()) {
  const queryClient = new QueryClient({
    defaultOptions: {
      queries: { retry: false },
      mutations: { retry: false },
    },
  });

  render(
    <MemoryRouter>
      <QueryClientProvider client={queryClient}>
        <ProductGrid
          products={[product]}
          isLoading={false}
          search=""
          onSearchChange={vi.fn()}
          onAddToCart={onAddToCart}
        />
      </QueryClientProvider>
    </MemoryRouter>,
  );

  return onAddToCart;
}

describe("ProductGrid", () => {
  it("exposes compact product cards as fast add-to-cart controls", () => {
    const onAddToCart = renderGrid();

    const card = screen.getByRole("button", { name: /add blue dream to cart/i });
    expect(card).toHaveClass("min-h-[132px]");

    fireEvent.click(card);

    expect(onAddToCart).toHaveBeenCalledWith(product);
  });
});
