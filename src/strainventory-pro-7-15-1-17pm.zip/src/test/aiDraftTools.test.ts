import { describe, expect, it } from "vitest";
import {
  buildCatalogAiUpdateFromDraft,
  buildIntakeAiSuggestionsFromDraft,
} from "@/lib/aiDraftTools";

const draft = {
  descriptionShort: "Blue Dream flower with a bright berry-forward profile.",
  descriptionLong: "Blue Dream flower with sweet berry flavor, a smooth herbal finish, and uplifting daytime effects.",
  sections: [
    {
      fields: [
        { label: "Brand Name", value: "Pacific Stone" },
        { label: "Strain Name", value: "Blue Dream" },
        { label: "Product Title", value: "Blue Dream Flower" },
        { label: "Category", value: "Flower" },
        { label: "SKU", value: "BD-001" },
        { label: "Vendor", value: "Greenline" },
      ],
    },
    {
      fields: [
        { label: "THC", value: "22%" },
        { label: "CBD", value: "0.4%" },
      ],
    },
    {
      fields: [
        { label: "Dominant Terpenes", value: "Myrcene, Pinene" },
        { label: "Supporting Terpenes", value: "Caryophyllene" },
      ],
    },
    {
      fields: [
        { label: "Aroma Profile", value: "Berry and pine" },
        { label: "Aroma Notes", value: "Sweet herbs" },
      ],
    },
    {
      fields: [
        { label: "Taste Profile", value: "Sweet berry" },
        { label: "Finish", value: "Soft herbal finish" },
      ],
    },
    {
      fields: [
        { label: "Effects", value: "Uplifting and focused" },
        { label: "Onset", value: "Fast" },
      ],
    },
    {
      fields: [
        { label: "Medical Uses", value: "Stress and low mood" },
      ],
    },
  ],
};

describe("aiDraftTools", () => {
  it("builds intake suggestions from a generated draft", () => {
    const suggestions = buildIntakeAiSuggestionsFromDraft(draft);

    expect(suggestions.name).toBe("Blue Dream Flower");
    expect(suggestions.strain).toBe("Blue Dream");
    expect(suggestions.productType).toBe("Flower");
    expect(suggestions.vendor).toBe("Greenline");
    expect(suggestions.thc).toBe("22%");
    expect(suggestions.cbd).toBe("0.4%");
    expect(suggestions.flavorProfile).toContain("Sweet berry");
    expect(suggestions.aromaProfile).toContain("Berry and pine");
    expect(suggestions.notes).toContain("Terpenes:");
    expect(suggestions.notes).toContain("Effects:");
  });

  it("builds catalog updates from a generated draft", () => {
    const update = buildCatalogAiUpdateFromDraft(draft);

    expect(update.name).toBe("Blue Dream Flower");
    expect(update.brand).toBe("Pacific Stone");
    expect(update.strain).toBe("Blue Dream");
    expect(update.sku).toBe("BD-001");
    expect(update.productType).toBe("Flower");
    expect(update.type).toBe("flower");
    expect(update.terpenes).toContain("Myrcene, Pinene");
    expect(update.aroma).toContain("Sweet herbs");
    expect(update.taste).toContain("Soft herbal finish");
    expect(update.effects).toContain("Fast");
    expect(update.medicalUses).toContain("Stress and low mood");
    expect(update.shortDescription).toContain("berry-forward");
    expect(update.longDescription).toContain("uplifting daytime effects");
  });
});
