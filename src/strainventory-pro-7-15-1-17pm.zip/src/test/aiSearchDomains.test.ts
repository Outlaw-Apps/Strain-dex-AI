import { describe, expect, it } from "vitest";
import {
  filterCandidateUrls,
  isUrlBlockedByEntries,
  parseDomainEntry,
  resolveSearchSources,
  TRUSTED_CANNABIS_RESEARCH_SOURCES,
  type AiSearchDomainEntry,
} from "../../supabase/functions/_shared/cannabisResearch";

describe("parseDomainEntry", () => {
  it("strips scheme and www prefix", () => {
    expect(parseDomainEntry("https://www.Leafly.com", "allow")).toEqual({
      raw: "leafly.com",
      host: "leafly.com",
      pathPrefix: "",
      mode: "allow",
    });
  });

  it("preserves a path prefix when present", () => {
    expect(parseDomainEntry("leafly.com/menu", "block")).toEqual({
      raw: "leafly.com/menu",
      host: "leafly.com",
      pathPrefix: "/menu",
      mode: "block",
    });
  });

  it("rejects empty input", () => {
    expect(parseDomainEntry("   ", "allow")).toBeNull();
    expect(parseDomainEntry("/foo", "allow")).toBeNull();
  });
});

describe("resolveSearchSources", () => {
  it("falls back to built-in trusted sources when no allow rows are enabled", () => {
    const policy = resolveSearchSources([]);
    expect(policy.allow).toHaveLength(0);
    expect(policy.block).toHaveLength(0);
    expect(policy.sources).toHaveLength(TRUSTED_CANNABIS_RESEARCH_SOURCES.length);
  });

  it("uses only allow entries when present", () => {
    const rows: AiSearchDomainEntry[] = [
      { domain: "leafly.com", mode: "allow", enabled: true },
      { domain: "allbud.com", mode: "allow", enabled: true },
    ];
    const policy = resolveSearchSources(rows);
    expect(policy.sources.map((s) => s.domains).flat()).toEqual([
      "leafly.com",
      "allbud.com",
    ]);
  });

  it("ignores disabled rows", () => {
    const rows: AiSearchDomainEntry[] = [
      { domain: "leafly.com", mode: "allow", enabled: true },
      { domain: "allbud.com", mode: "allow", enabled: false },
    ];
    const policy = resolveSearchSources(rows);
    expect(policy.sources.map((s) => s.domains).flat()).toEqual(["leafly.com"]);
  });

  it("collects block entries with their path prefix", () => {
    const rows: AiSearchDomainEntry[] = [
      { domain: "leafly.com", mode: "allow", enabled: true },
      { domain: "leafly.com/menu", mode: "block", enabled: true },
    ];
    const policy = resolveSearchSources(rows);
    expect(policy.block).toHaveLength(1);
    expect(policy.block[0]).toMatchObject({ host: "leafly.com", pathPrefix: "/menu" });
  });
});

describe("isUrlBlockedByEntries", () => {
  const policy = resolveSearchSources([
    { domain: "leafly.com/menu", mode: "block", enabled: true },
    { domain: "weedmaps.com", mode: "block", enabled: true },
  ]);

  it("blocks an exact host with no path scope", () => {
    expect(isUrlBlockedByEntries("https://www.weedmaps.com/strains/blue-dream", policy.block)).toBe(true);
  });

  it("blocks subdomains of a host entry", () => {
    expect(isUrlBlockedByEntries("https://shop.weedmaps.com/foo", policy.block)).toBe(true);
  });

  it("blocks paths that match a path-scoped entry", () => {
    expect(isUrlBlockedByEntries("https://www.leafly.com/menu/sf/foo", policy.block)).toBe(true);
    expect(isUrlBlockedByEntries("https://www.leafly.com/menu", policy.block)).toBe(true);
  });

  it("does not block sibling paths on a path-scoped entry", () => {
    expect(isUrlBlockedByEntries("https://www.leafly.com/strains/blue-dream", policy.block)).toBe(false);
    expect(isUrlBlockedByEntries("https://www.leafly.com/menus", policy.block)).toBe(false);
  });

  it("returns false for invalid URLs", () => {
    expect(isUrlBlockedByEntries("not a url", policy.block)).toBe(false);
  });
});

describe("filterCandidateUrls", () => {
  it("with no allow entries, only blocks are removed", () => {
    const policy = resolveSearchSources([
      { domain: "weedmaps.com", mode: "block", enabled: true },
    ]);
    const urls = [
      "https://leafly.com/strains/x",
      "https://weedmaps.com/foo",
    ];
    expect(filterCandidateUrls(urls, policy)).toEqual(["https://leafly.com/strains/x"]);
  });

  it("with allow entries, only allowed hosts survive (and blocks still apply)", () => {
    const policy = resolveSearchSources([
      { domain: "leafly.com", mode: "allow", enabled: true },
      { domain: "leafly.com/menu", mode: "block", enabled: true },
    ]);
    const urls = [
      "https://www.leafly.com/strains/blue-dream",
      "https://www.leafly.com/menu/sf",
      "https://allbud.com/strains/foo",
    ];
    expect(filterCandidateUrls(urls, policy)).toEqual([
      "https://www.leafly.com/strains/blue-dream",
    ]);
  });
});
