import { afterEach, describe, expect, it, vi } from "vitest";

const importFreshConfig = async () => {
  vi.resetModules();
  return import("@/lib/appConfig");
};

describe("appConfig", () => {
  afterEach(() => {
    window.STRAINVENTORY_CONFIG = undefined;
  });

  it("uses Vite Supabase values and defaults the edge function base URL", async () => {
    const { appConfig } = await importFreshConfig();

    expect(appConfig.supabaseUrl).toBe("http://127.0.0.1:54321");
    expect(appConfig.supabasePublishableKey).toBe("public-anon-key");
    expect(appConfig.edgeFunctionBaseUrl).toBe("http://127.0.0.1:54321/functions/v1");
  });

  it("prefers runtime config for self-hosted deployments", async () => {
    window.STRAINVENTORY_CONFIG = {
      supabaseUrl: "https://db.example.test/",
      supabasePublishableKey: "runtime-key",
      edgeFunctionBaseUrl: "https://functions.example.test/functions/v1/",
    };

    const { appConfig } = await importFreshConfig();

    expect(appConfig).toMatchObject({
      supabaseUrl: "https://db.example.test",
      supabasePublishableKey: "runtime-key",
      edgeFunctionBaseUrl: "https://functions.example.test/functions/v1",
    });
  });

  it("derives environment flags and default buckets", async () => {
    const { appConfig } = await importFreshConfig();
    expect(["development", "staging", "production"]).toContain(appConfig.environment);
    expect(appConfig.productImagesBucket).toBeTruthy();
    expect(appConfig.avatarsBucket).toBeTruthy();
  });
});
