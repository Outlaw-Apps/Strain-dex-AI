import { describe, expect, it } from "vitest";
import {
  createDownloadFromPayload,
  resolveAssistantActionRoute,
  resolveAssistantRoute,
  safeExternalUrl,
} from "@/lib/assistantActions";

describe("assistant action routing", () => {
  it("maps consent and authorization aliases to existing routes", () => {
    expect(resolveAssistantRoute("/consent")).toBe("/settings");
    expect(resolveAssistantRoute("/authorize")).toBe("/settings");
    expect(resolveAssistantActionRoute("REQUEST_AUTHORIZATION", {})).toBe("/settings");
  });

  it("maps approval actions to the review workspace", () => {
    expect(resolveAssistantRoute("/approve")).toBe("/review");
    expect(resolveAssistantActionRoute("APPROVE_PRODUCT_DETAILS", {})).toBe("/review");
  });

  it("supports catalog product aliases with ids", () => {
    expect(resolveAssistantRoute("/products/product-1")).toBe("/catalog/product-1");
    expect(resolveAssistantRoute("/product", { product_id: "product-2" })).toBe("/catalog/product-2");
  });

  it("normalizes catalog detail route casing", () => {
    expect(resolveAssistantRoute("/Catalog/ABC-123")).toBe("/catalog/abc-123");
  });

  it("rejects unknown internal routes so they do not navigate to the 404 page", () => {
    expect(resolveAssistantRoute("/definitely-missing")).toBeNull();
  });
});

describe("assistant external links", () => {
  it("accepts http and https URLs only", () => {
    expect(safeExternalUrl("https://leafly.com/strains/berry-runtz")).toBe("https://leafly.com/strains/berry-runtz");
    expect(safeExternalUrl("http://example.com/report")).toBe("http://example.com/report");
    expect(safeExternalUrl("javascript:alert(1)")).toBeNull();
    expect(safeExternalUrl("/catalog")).toBeNull();
  });
});

describe("assistant file downloads", () => {
  it("does not treat generic top-level content as a file download", () => {
    expect(createDownloadFromPayload({ route: "/catalog", content: "Product details" })).toBe(false);
  });
});
