import { describe, expect, it } from "vitest";
import { resolveAssistantPageContext } from "@/lib/assistantContext";

describe("resolveAssistantPageContext", () => {
  it("maps product intake route to product_intake context", () => {
    const context = resolveAssistantPageContext("/product-intake");
    expect(context.id).toBe("product_intake");
    expect(context.title).toBe("Product Intake");
  });

  it("maps review route to review workspace context", () => {
    const context = resolveAssistantPageContext("/review");
    expect(context.id).toBe("review_workspace");
  });

  it("falls back to general context for unknown routes", () => {
    const context = resolveAssistantPageContext("/something-else");
    expect(context.id).toBe("general");
  });
});

