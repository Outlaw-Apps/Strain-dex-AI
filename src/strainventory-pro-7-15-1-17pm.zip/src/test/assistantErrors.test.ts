import { describe, expect, it } from "vitest";
import {
  describeAssistantError,
  isSupabaseLockAcquireError,
} from "@/lib/assistantErrors";

const createDesktopLockError = () =>
  Object.assign(new Error('Timed out waiting for the Supabase auth lock "auth".'), {
    name: "SupabaseAuthLockAcquireTimeoutError",
    isAcquireTimeout: true,
  });

describe("assistant error helpers", () => {
  it("recognizes desktop Supabase auth lock contention", () => {
    expect(isSupabaseLockAcquireError(createDesktopLockError())).toBe(true);
  });

  it("recognizes browser navigator lock-acquire timeouts", () => {
    const error = new Error("LockAcquireTimeoutError: navigator.locks request timed out");
    error.name = "LockAcquireTimeoutError";

    expect(isSupabaseLockAcquireError(error)).toBe(true);
  });

  it("uses lock-specific copy instead of the generic assistant service failure", () => {
    const failure = describeAssistantError(createDesktopLockError(), {
      assistantReplyReceived: false,
      isAuthError: false,
    });

    expect(failure.kind).toBe("lock_contention");
    expect(failure.toastMessage).toContain("history");
    expect(failure.recoveryMessage).not.toContain("assistant service");
    expect(failure.shouldAttemptHistoryRecovery).toBe(false);
  });

  it("keeps true generation failures on the assistant service path", () => {
    const failure = describeAssistantError(new Error("DeepSeek is temporarily unavailable."), {
      assistantReplyReceived: false,
      isAuthError: false,
    });

    expect(failure.kind).toBe("generation_failure");
    expect(failure.recoveryMessage).toContain("assistant service");
    expect(failure.shouldAttemptHistoryRecovery).toBe(true);
  });
});
