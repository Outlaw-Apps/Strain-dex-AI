import { describe, expect, it } from "vitest";
import {
  createWelcomeAssistantMessage,
  mapStoredAssistantMessages,
  toAssistantThreadOption,
} from "@/lib/assistantHistory";
import type { AssistantMessageRecord, AssistantThreadRecord } from "@/types/assistant";

describe("assistant history helpers", () => {
  it("creates the default welcome message", () => {
    const message = createWelcomeAssistantMessage();

    expect(message.role).toBe("assistant");
    expect(message.content.toLowerCase()).toContain("strain vinny");
  });

  it("restores stored assistant actions from message context", () => {
    const storedMessages: AssistantMessageRecord[] = [
      {
        id: "assistant-1",
        thread_id: "thread-1",
        user_id: "user-1",
        role: "assistant",
        content: "Use the review workspace next.",
        context: {
          actions: [
            {
              intent: "open_review",
              summary: "Open review",
              proposed_changes: ["Move to the review workspace"],
              requires_confirmation: true,
              execution_payload: { route: "/review" },
            },
          ],
        },
        created_at: "2026-04-15T20:00:00.000Z",
      },
    ];

    const restored = mapStoredAssistantMessages(storedMessages);

    expect(restored).toHaveLength(1);
    expect(restored[0].actions).toHaveLength(1);
    expect(restored[0].actions?.[0].intent).toBe("open_review");
  });

  it("falls back to page context when a thread title is blank", () => {
    const thread: AssistantThreadRecord = {
      id: "thread-1",
      user_id: "user-1",
      title: "",
      audience_role: "management",
      page_context: {
        title: "Point of Sale",
      },
      created_at: "2026-04-15T19:58:00.000Z",
      updated_at: "2026-04-15T20:00:00.000Z",
    };

    const option = toAssistantThreadOption(thread);

    expect(option.title).toBe("Point of Sale");
    expect(option.audienceRole).toBe("management");
  });
});
