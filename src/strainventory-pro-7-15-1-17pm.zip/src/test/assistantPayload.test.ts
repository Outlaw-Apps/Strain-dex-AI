import { describe, expect, it } from "vitest";
import {
  buildPersonaPrompt,
  parseAssistantResponse,
  sanitizeActionEnvelope,
} from "../../supabase/functions/_shared/assistantPayload";

function makeSourceResponse(url: string): string {
  return JSON.stringify({
    reply: "Here are some sources.",
    actions: [],
    sources: [
      {
        source: "Leafly",
        domain: "leafly.com",
        url,
        title: "Blue Dream Strain",
      },
    ],
  });
}

describe("assistant payload parsing", () => {
  it("forces confirm-gated actions even if model returns false", () => {
    const action = sanitizeActionEnvelope({
      intent: "fill_intake_fields",
      summary: "Fill missing intake fields",
      proposed_changes: ["Set strain to Blue Dream"],
      requires_confirmation: false,
      execution_payload: { route: "/product-intake" },
    });

    expect(action).toBeTruthy();
    expect(action?.requires_confirmation).toBe(true);
  });

  it("parses fenced JSON responses and action arrays", () => {
    const parsed = parseAssistantResponse(`\`\`\`json
{
  "reply": "Use this guided intake flow.",
  "actions": [
    {
      "intent": "navigate_product_intake",
      "summary": "Open intake and apply suggestions",
      "proposed_changes": ["Route to intake"],
      "requires_confirmation": true,
      "execution_payload": { "route": "/product-intake" }
    }
  ]
}
\`\`\``);

    expect(parsed.reply).toContain("guided intake");
    expect(parsed.actions).toHaveLength(1);
    expect(parsed.actions[0].intent).toBe("navigate_product_intake");
    expect(parsed.actions[0].requires_confirmation).toBe(true);
  });

  it("normalizes broken approve and consent action routes", () => {
    const approval = sanitizeActionEnvelope({
      intent: "APPROVE_PRODUCT_DETAILS",
      summary: "Approve product changes",
      proposed_changes: ["Open approval workspace"],
      requires_confirmation: true,
      execution_payload: { route: "/approve" },
    });
    const consent = sanitizeActionEnvelope({
      intent: "AUTHORIZE_DATA_ACCESS",
      summary: "Authorize assistant access",
      proposed_changes: ["Open authorization settings"],
      requires_confirmation: true,
      execution_payload: { route: "/consent" },
    });

    expect(approval?.execution_payload).toMatchObject({ route: "/review" });
    expect(consent?.execution_payload).toMatchObject({ route: "/settings" });
  });
});

describe("sanitizeSourceCitation URL validation", () => {
  it("preserves a valid https:// citation", () => {
    const result = parseAssistantResponse(
      makeSourceResponse("https://leafly.com/strains/blue-dream"),
    );
    expect(result.sources).toHaveLength(1);
    expect(result.sources[0].url).toBe("https://leafly.com/strains/blue-dream");
  });

  it("preserves a valid http:// citation", () => {
    const result = parseAssistantResponse(
      makeSourceResponse("http://leafly.com/strains/blue-dream"),
    );
    expect(result.sources).toHaveLength(1);
    expect(result.sources[0].url).toBe("http://leafly.com/strains/blue-dream");
  });

  it("drops citations with a ftp:// scheme", () => {
    const result = parseAssistantResponse(
      makeSourceResponse("ftp://leafly.com/strains/blue-dream"),
    );
    expect(result.sources).toHaveLength(0);
  });

  it("drops citations with a javascript: scheme", () => {
    const result = parseAssistantResponse(
      makeSourceResponse("javascript:alert(1)"),
    );
    expect(result.sources).toHaveLength(0);
  });

  it("drops citations with a relative URL", () => {
    const result = parseAssistantResponse(
      makeSourceResponse("/strains/blue-dream"),
    );
    expect(result.sources).toHaveLength(0);
  });

  it("drops citations with a protocol-relative URL", () => {
    const result = parseAssistantResponse(
      makeSourceResponse("//leafly.com/strains/blue-dream"),
    );
    expect(result.sources).toHaveLength(0);
  });
});

describe("assistant role persona prompt", () => {
  it("uses vendor-specific tone guidance", () => {
    const prompt = buildPersonaPrompt("vendor");
    expect(prompt.toLowerCase()).toContain("vendor-facing");
  });

  it("uses management-specific tone guidance", () => {
    const prompt = buildPersonaPrompt("management");
    expect(prompt.toLowerCase()).toContain("management");
    expect(prompt.toLowerCase()).toContain("executive");
  });
});
