import { describe, expect, it } from "vitest";
import {
  getEmailActionState,
  getPasswordStrength,
  normalizeAuthEmail,
} from "@/lib/authAccess";

describe("authAccess helpers", () => {
  it("normalizes auth emails before submission", () => {
    expect(normalizeAuthEmail("  Manager@Example.COM  ")).toBe("manager@example.com");
  });

  it("enables recovery actions only for valid email addresses", () => {
    expect(getEmailActionState("")).toEqual({
      canSubmit: false,
      helperText: "Enter your email address to continue.",
    });

    expect(getEmailActionState("bad-email")).toEqual({
      canSubmit: false,
      helperText: "Enter a valid email address.",
    });

    expect(getEmailActionState("lead@shop.com")).toEqual({
      canSubmit: true,
      helperText: "We'll use this email for sign-in or recovery.",
    });
  });

  it("scores stronger passwords above weak ones", () => {
    expect(getPasswordStrength("abc")).toMatchObject({
      label: "Weak",
      score: 1,
    });

    expect(getPasswordStrength("Garden42!Bloom")).toMatchObject({
      label: "Strong",
      score: 4,
    });
  });
});
