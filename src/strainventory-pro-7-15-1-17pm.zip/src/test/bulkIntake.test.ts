import { describe, expect, it } from "vitest";
import { buildCatalogDraftRow, parseBulkIntakeText } from "@/lib/bulkIntake";

describe("bulkIntake", () => {
  it("parses CSV rows with a header and infers draft metadata", () => {
    const products = parseBulkIntakeText([
      "Strain,Brand,Details",
      "Blue Dream,Pacific Stone,3.5g Flower",
      "Gelato 41,Stiiizy,1g Vape Cart",
    ].join("\n"));

    expect(products).toEqual([
      {
        strain: "Blue Dream",
        brand: "Pacific Stone",
        details: "3.5g Flower",
        productType: "flower",
        packageSize: "3.5g",
      },
      {
        strain: "Gelato 41",
        brand: "Stiiizy",
        details: "1g Vape Cart",
        productType: "vape-cartridge",
        packageSize: "1g",
      },
    ]);
  });

  it("keeps the first row when the input does not include a header", () => {
    const products = parseBulkIntakeText("Blue Dream,Pacific Stone,3.5g Flower");

    expect(products).toHaveLength(1);
    expect(products[0]?.strain).toBe("Blue Dream");
  });

  it("parses the new bulk intake CSV template columns", () => {
    const products = parseBulkIntakeText([
      "product_name,brand,product_type,THC%,CBD%,description",
      "Blue Dream 3.5g Jar,Pacific Stone,Flower,27%,0.3%,Sweet berry aroma with a mellow finish",
    ].join("\n"));

    expect(products).toEqual([
      {
        productName: "Blue Dream 3.5g Jar",
        strain: "Blue Dream 3.5g Jar",
        brand: "Pacific Stone",
        description: "Sweet berry aroma with a mellow finish",
        details: "Sweet berry aroma with a mellow finish · THC 27% · CBD 0.3%",
        productType: "flower",
        packageSize: "3.5g",
        thc: "27%",
        cbd: "0.3%",
      },
    ]);
  });

  it("builds catalog draft rows that can be inserted directly", () => {
    const row = buildCatalogDraftRow({
      strain: "Blue Dream",
      brand: "Pacific Stone",
      details: "3.5g Flower",
      productType: "flower",
      packageSize: "3.5g",
    });

    expect(row.status).toBe("draft");
    expect(row.name).toBe("Blue Dream 3.5g Flower");
    expect(row.short_description).toBe("3.5g Flower");
    expect(row.brand).toBe("Pacific Stone");
    expect(row.type).toBe("flower");
  });

  it("preserves explicit product names from the new CSV template", () => {
    const row = buildCatalogDraftRow({
      productName: "Blue Dream 3.5g Jar",
      strain: "Blue Dream 3.5g Jar",
      brand: "Pacific Stone",
      description: "Sweet berry aroma with a mellow finish",
      details: "Sweet berry aroma with a mellow finish · THC 27% · CBD 0.3%",
      productType: "flower",
      packageSize: "3.5g",
      thc: "27%",
      cbd: "0.3%",
    });

    expect(row.name).toBe("Blue Dream 3.5g Jar");
    expect(row.short_description).toBe("Sweet berry aroma with a mellow finish · THC 27% · CBD 0.3%");
    expect(row.long_description).toBe("Sweet berry aroma with a mellow finish · THC 27% · CBD 0.3%.");
  });
});
