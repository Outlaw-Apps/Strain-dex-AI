import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import {
  selectBestCatalogImage,
  syncCatalogImageToProduct,
  type CatalogImageCandidate,
} from "@/lib/catalogImages";
import { clearStoredDraft, loadStoredDraft, saveStoredDraft } from "@/lib/productDraftStorage";
import type { ProductDraft } from "@/context/ProductDraftContext";
import type { SupabaseClient } from "@supabase/supabase-js";
import type { Database } from "@/integrations/supabase/types";

const baseDraft: ProductDraft = {
  catalogId: "draft-1",
  intake: {
    brand: "Pacific Stone",
    strain: "Blue Dream",
    productType: "flower",
    packageSize: "3.5g",
    sku: "PS-BD-35",
    vendor: "GreenLine",
    notes: "",
  },
  draft: null,
  primaryImage: null,
  alternateImages: [],
  imageSearchResults: [],
  status: "intake",
};

describe("catalog image ranking", () => {
  beforeEach(() => {
    clearStoredDraft();
  });

  afterEach(() => {
    vi.restoreAllMocks();
    vi.unstubAllGlobals();
  });

  it("prefers the most verified and product-specific image", () => {
    const images: CatalogImageCandidate[] = [
      {
        id: "generic",
        url: "https://example.com/generic.jpg",
        alt: "Blue Dream cannabis plant",
        width: 1600,
        height: 1200,
        fileSize: "320 KB",
        thumbnailUrl: "https://example.com/generic-thumb.jpg",
        source: "example.com",
        verification: { isMatch: false, confidence: 24, reason: "Generic strain photo" },
      },
      {
        id: "product",
        url: "https://example.com/product.jpg",
        alt: "Pacific Stone Blue Dream 3.5g jar",
        width: 1600,
        height: 1200,
        fileSize: "280 KB",
        thumbnailUrl: "https://example.com/product-thumb.jpg",
        source: "official-brand.example",
        pageUrl: "https://leafly.com/brands/pacific-stone",
        verification: { isMatch: true, confidence: 91, reason: "Exact branded product shot" },
      },
    ];

    const best = selectBestCatalogImage(images, {
      brand: "Pacific Stone",
      name: "Blue Dream",
      type: "flower",
    });

    expect(best?.id).toBe("product");
  });

  it("persists and reloads the draft state", () => {
    saveStoredDraft(baseDraft);
    expect(loadStoredDraft()).toEqual(baseDraft);
  });

  it("links the verified remote image when browser fetch blocks storage sync", async () => {
    const candidate: CatalogImageCandidate = {
      id: "candidate-1",
      url: "https://images.example.com/blue-dream.jpg",
      alt: "Pacific Stone Blue Dream jar",
      width: 1200,
      height: 1200,
      fileSize: "280 KB",
      thumbnailUrl: "https://images.example.com/blue-dream-thumb.jpg",
      source: "trusted catalog",
    };
    const updateEq = vi.fn().mockResolvedValue({ error: null });
    const update = vi.fn().mockReturnValue({ eq: updateEq });
    const maybeSingle = vi.fn().mockResolvedValue({
      data: {
        images: [{ url: "https://old.example.com/old.jpg", alt: "Old image", primary: true }],
      },
      error: null,
    });
    const selectEq = vi.fn().mockReturnValue({ maybeSingle });
    const select = vi.fn().mockReturnValue({ eq: selectEq });
    const supabase = {
      from: vi.fn().mockReturnValue({ select, update }),
      storage: {
        from: vi.fn(),
      },
    } as unknown as SupabaseClient<Database>;

    vi.stubGlobal("fetch", vi.fn().mockRejectedValue(new TypeError("Failed to fetch")));
    const warn = vi.spyOn(console, "warn").mockImplementation(() => undefined);

    const url = await syncCatalogImageToProduct({
      supabase,
      productId: "product-1",
      candidate,
    });

    expect(url).toBe(candidate.url);
    expect(update).toHaveBeenCalledWith({
      images: [
        { url: candidate.url, alt: candidate.alt, primary: true },
        { url: "https://old.example.com/old.jpg", alt: "Old image", primary: false },
      ],
      updated_at: expect.any(String),
    });
    expect(updateEq).toHaveBeenCalledWith("id", "product-1");
    expect(warn).toHaveBeenCalledWith(
      "[catalogImages] Remote image fetch blocked; linking source URL instead.",
      expect.any(TypeError),
    );
  });
});
