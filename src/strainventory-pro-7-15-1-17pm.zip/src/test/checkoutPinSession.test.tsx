import { describe, expect, it, vi, beforeEach } from "vitest";
import { fireEvent, render, screen, waitFor } from "@testing-library/react";

/**
 * Regression: PIN checkout must NOT sign out the cashier globally.
 * A previous bug called `verifierClient.auth.signOut()` (default scope = "global"),
 * which revoked the cashier's active session and bounced them to /auth.
 * The fix scopes the throwaway verifier signOut to { scope: "local" }.
 * This test guards that contract by mocking @supabase/supabase-js and asserting:
 *   - signOut was called with { scope: "local" }
 *   - signOut was NEVER called without arguments or with scope "global"
 *   - The active `supabase` client's signOut was never invoked
 *   - onConfirm fires (i.e., the session-preserving flow completes without redirect)
 */

const mocks = vi.hoisted(() => ({
  verifierSignOut: vi.fn().mockResolvedValue({ error: null }),
  verifierSignIn: vi.fn().mockResolvedValue({ data: {}, error: null }),
  activeSignOut: vi.fn(),

  getUser: vi.fn().mockResolvedValue({
    data: { user: { email: "abc123@pin.strainventory.local" } },
    error: null,
  }),
}));

vi.mock("@supabase/supabase-js", () => ({
  createClient: () => ({
    auth: {
      signInWithPassword: mocks.verifierSignIn,
      signOut: mocks.verifierSignOut,
    },
  }),
}));

vi.mock("@/integrations/supabase/client", () => ({
  supabase: {
    auth: {
      getUser: mocks.getUser,
      signOut: mocks.activeSignOut,
    },
  },
}));

vi.mock("@/lib/pinAuth", () => ({
  isShortIdEmail: () => true,
  shortIdFromEmail: () => "abc123",
  pinToPassword: (pin: string) => `pw:${pin}`,
}));

vi.mock("sonner", () => ({
  toast: { error: vi.fn(), success: vi.fn() },
}));


import { CheckoutConfirmDialog } from "@/components/pos/CheckoutConfirmDialog";

describe("CheckoutConfirmDialog PIN verification", () => {
  beforeEach(() => {
    mocks.verifierSignOut.mockClear();
    mocks.verifierSignIn.mockClear();
    mocks.activeSignOut.mockClear();
  });

  it("keeps the cashier session alive after PIN verification", async () => {
    const onConfirm = vi.fn();
    const onCancel = vi.fn();

    render(
      <CheckoutConfirmDialog
        open
        paymentMethod="Card"
        amount={42.5}
        onCancel={onCancel}
        onConfirm={onConfirm}
      />,
    );

    fireEvent.change(screen.getByLabelText(/Customer Name/i), {
      target: { value: "Jane Doe" },
    });
    fireEvent.change(screen.getByLabelText(/Customer Age/i), {
      target: { value: "30" },
    });
    fireEvent.change(screen.getByLabelText(/Employee PIN/i), {
      target: { value: "1234" },
    });

    fireEvent.click(screen.getByRole("button", { name: /Verify.*Continue/i }));

    await waitFor(() => expect(onConfirm).toHaveBeenCalledTimes(1));

    // Verifier signOut must be scoped local — never global (which would kick
    // the cashier to /auth by revoking all refresh tokens for the user).
    expect(mocks.verifierSignOut).toHaveBeenCalledTimes(1);
    expect(mocks.verifierSignOut).toHaveBeenCalledWith({ scope: "local" });

    for (const call of mocks.verifierSignOut.mock.calls) {
      const arg = call[0];
      expect(arg).toBeDefined();
      expect(arg?.scope).toBe("local");
      expect(arg?.scope).not.toBe("global");
    }

    // The active app-wide supabase client's signOut must NOT be touched.
    expect(mocks.activeSignOut).not.toHaveBeenCalled();

    // Cashier is identified and passed through to the sale.
    expect(onConfirm).toHaveBeenCalledWith(
      expect.objectContaining({
        customerName: "Jane Doe",
        customerAge: 30,
        cashierShortId: "abc123",
      }),
    );
  });

  it("never invokes signOut with global scope or on the active client", async () => {
    const onConfirm = vi.fn();
    const onCancel = vi.fn();

    render(
      <CheckoutConfirmDialog
        open
        paymentMethod="Cash"
        amount={10}
        onCancel={onCancel}
        onConfirm={onConfirm}
      />,
    );

    fireEvent.change(screen.getByLabelText(/Customer Name/i), {
      target: { value: "John Smith" },
    });
    fireEvent.change(screen.getByLabelText(/Customer Age/i), {
      target: { value: "25" },
    });
    fireEvent.change(screen.getByLabelText(/Employee PIN/i), {
      target: { value: "9999" },
    });
    fireEvent.click(screen.getByRole("button", { name: /Verify.*Continue/i }));

    await waitFor(() => expect(onConfirm).toHaveBeenCalledTimes(1));

    // Verifier signIn happened on the throwaway client only.
    expect(mocks.verifierSignIn).toHaveBeenCalledTimes(1);

    // Every signOut call on the verifier must be explicitly scoped local.
    // A bare signOut() (default global) OR { scope: "global" } would revoke
    // ALL refresh tokens for the cashier user and kick them to /auth.
    expect(mocks.verifierSignOut).toHaveBeenCalled();
    for (const call of mocks.verifierSignOut.mock.calls) {
      expect(call.length).toBeGreaterThan(0);
      const [opts] = call;
      expect(opts).toEqual({ scope: "local" });
      expect(opts?.scope).not.toBe("global");
      expect(opts?.scope).not.toBe("others");
    }

    // The app-wide supabase client's signOut must NEVER be called from
    // the PIN verification flow — that would nuke the cashier session.
    expect(mocks.activeSignOut).not.toHaveBeenCalled();
  });

});
