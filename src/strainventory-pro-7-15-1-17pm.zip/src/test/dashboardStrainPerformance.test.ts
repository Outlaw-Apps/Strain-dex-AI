import { describe, expect, it } from "vitest";
import { buildWeeklyStrainPerformance } from "@/lib/dashboardStrainPerformance";

describe("buildWeeklyStrainPerformance", () => {
  it("summarizes weekly strain sales, type mix, daily revenue, and week-over-week momentum", () => {
    const result = buildWeeklyStrainPerformance({
      now: new Date("2026-04-22T12:00:00.000Z"),
      orders: [
        {
          id: "order-1",
          created_at: "2026-04-20T14:00:00.000Z",
          total: 82,
          items: [
            {
              product_id: "p-1",
              product_name: "Blue Dream",
              quantity: 2,
              total_price: 56,
              product: {
                brand: "Pacific Stone",
                strain_type: "Hybrid",
                type: "Flower",
                effects: "Creative, uplifted, focused",
                thc: "24%",
                cbd: "0.3%",
                terpenes: "Myrcene, Pinene",
                quantity: 8,
              },
            },
            {
              product_id: "p-2",
              product_name: "Granddaddy Purple",
              quantity: 1,
              total_price: 26,
              product: {
                brand: "Emerald Farms",
                strain_type: "Indica",
                type: "Flower",
                effects: "Relaxed, sleepy",
                thc: "21%",
                cbd: "0.1%",
                terpenes: "Linalool",
                quantity: 3,
              },
            },
          ],
        },
        {
          id: "order-2",
          created_at: "2026-04-21T18:00:00.000Z",
          total: 28,
          items: [
            {
              product_id: "p-1",
              product_name: "Blue Dream",
              quantity: 1,
              total_price: 28,
              product: {
                brand: "Pacific Stone",
                strain_type: "Hybrid",
                type: "Flower",
                effects: "Creative, uplifted, focused",
                thc: "24%",
                cbd: "0.3%",
                terpenes: "Myrcene, Pinene",
                quantity: 8,
              },
            },
          ],
        },
        {
          id: "order-3",
          created_at: "2026-04-15T16:00:00.000Z",
          total: 40,
          items: [
            {
              product_id: "p-3",
              product_name: "Sour Diesel",
              quantity: 2,
              total_price: 40,
              product: {
                brand: "North Coast",
                strain_type: "Sativa",
                type: "Flower",
                effects: "Energetic",
                thc: "23%",
                cbd: "0.2%",
                terpenes: "Limonene",
                quantity: 12,
              },
            },
          ],
        },
      ],
    });

    expect(result.totalRevenue).toBe(110);
    expect(result.totalUnits).toBe(4);
    expect(result.orderCount).toBe(2);
    expect(result.momentumPercent).toBe(175);
    expect(result.leadingType).toBe("Hybrid");

    expect(result.topStrains[0]).toMatchObject({
      name: "Blue Dream",
      brand: "Pacific Stone",
      strainType: "Hybrid",
      revenue: 84,
      units: 3,
      sharePercent: 76,
      stockLeft: 8,
      status: "Trending",
    });

    expect(result.topStrains[1]).toMatchObject({
      name: "Granddaddy Purple",
      strainType: "Indica",
      revenue: 26,
      units: 1,
      stockLeft: 3,
      status: "Restock watch",
    });

    expect(result.dailyRevenue.map((day) => day.revenue)).toEqual([82, 28, 0, 0, 0, 0, 0]);
    expect(result.typeMix).toEqual([
      { type: "Hybrid", revenue: 84, units: 3, sharePercent: 76 },
      { type: "Indica", revenue: 26, units: 1, sharePercent: 24 },
    ]);
  });
});
