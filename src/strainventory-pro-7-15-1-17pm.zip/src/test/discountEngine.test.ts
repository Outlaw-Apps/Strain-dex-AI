import { describe, expect, it } from "vitest";
import { calculateCartPricing, isCustomerDiscountEligible } from "@/lib/discounts/discountEngine";
import type { CartItem } from "@/pages/PointOfSale";
import type { Customer } from "@/hooks/useCustomers";

const FIX_NOW = new Date("2026-05-12T12:00:00.000Z");

function line(overrides: Partial<CartItem> = {}): CartItem {
  return {
    id: "flower-1",
    name: "Test Flower",
    brand: "Brand",
    type: "flower",
    product_type: "Flower",
    status: "published",
    price: 10,
    qty: 1,
    weight: "3.5g",
    quantity: 100,
    in_stock: true,
    clearance_active: false,
    images: [],
    ...overrides,
  } as CartItem;
}

function customer(overrides: Partial<Customer> = {}): Customer {
  return {
    id: "c-1",
    customer_number: "C-001",
    name: "Patron",
    email: "",
    notes: "",
    phone: "555",
    license_number: null,
    date_of_birth: null,
    last_age_verified_at: FIX_NOW.toISOString(),
    created_at: FIX_NOW.toISOString(),
    updated_at: FIX_NOW.toISOString(),
    ...overrides,
  };
}

describe("calculateCartPricing", () => {
  it("applies sale_price when window is open", () => {
    const res = calculateCartPricing({
      cart: [
        line({
          sale_price: 5,
          sale_starts_at: "2026-01-01T00:00:00.000Z",
          sale_ends_at: "2026-12-31T23:59:59.000Z",
        }),
      ],
      customer: null,
      ticket: { kind: "none" },
      employeeDiscountManagerOk: false,
      now: FIX_NOW,
      taxRate: 0.15,
    });
    expect(res.taxableSubtotal).toBeCloseTo(17.5);
    expect(res.listSubtotal).toBeCloseTo(35);
    expect(res.discountTotal).toBeCloseTo(17.5);
    expect(res.tax).toBeCloseTo(2.625);
    expect(res.grandTotal).toBeCloseTo(20.125);
  });

  it("prefers clearance pricing over sale pricing", () => {
    const res = calculateCartPricing({
      cart: [
        line({
          sale_price: 5,
          sale_starts_at: "2026-01-01T00:00:00.000Z",
          sale_ends_at: "2026-12-31T23:59:59.000Z",
          clearance_active: true,
          clearance_price: 2,
        }),
      ],
      customer: null,
      ticket: { kind: "none" },
      employeeDiscountManagerOk: false,
      now: FIX_NOW,
      taxRate: 0.1,
    });
    expect(res.lines[0]?.clearanceApplied).toBe(true);
    expect(res.lines[0]?.saleApplied).toBe(false);
    expect(res.taxableSubtotal).toBeCloseTo(7);
    expect(res.tax).toBeCloseTo(0.7);
    expect(res.grandTotal).toBeCloseTo(7.7);
  });

  it("applies senior 10% only to non-clearance merchandise", () => {
    const patron = customer({
      date_of_birth: "1950-06-01",
    });
    const res = calculateCartPricing({
      cart: [
        line({ id: "a", qty: 1, weight: "1g", price: 20, clearance_active: false }),
        line({
          id: "b",
          qty: 1,
          weight: "1g",
          price: 40,
          clearance_active: true,
          clearance_price: 10,
        }),
      ],
      customer: patron,
      ticket: { kind: "customer", definitionId: "cust-senior" },
      employeeDiscountManagerOk: false,
      now: FIX_NOW,
      taxRate: 0.15,
    });
    /** First line $20 loses $2 senior credit; clearance line unaffected */
    expect(res.taxableSubtotal).toBeCloseTo(18 + 10);
    const normal = res.lines.find((r) => r.productId === "a");
    const clear = res.lines.find((r) => r.productId === "b");
    expect(normal?.customerDiscountShare).toBeCloseTo(2);
    expect(clear?.customerDiscountShare).toBeCloseTo(0);
  });

  it("implements buy-one-get-one free on matching SKUs excluding clearance rows", () => {
    const res = calculateCartPricing({
      cart: [
        line({ id: "same", qty: 2, weight: "1g", price: 10 }),
        line({
          id: "sale-item",
          qty: 1,
          weight: "1g",
          price: 10,
          clearance_active: true,
          clearance_price: 2,
        }),
      ],
      customer: null,
      ticket: { kind: "bogo", mode: "buy1_get1_free" },
      employeeDiscountManagerOk: false,
      now: FIX_NOW,
      taxRate: 0,
    });

    /** Pair across qty=2 wipes one $10 weighed gram */
    const pairLine = res.lines.find((r) => r.productId === "same");
    expect(pairLine?.lineTotalFinal).toBeCloseTo(10);
    const clearanceLine = res.lines.find((r) => r.productId === "sale-item");
    expect(clearanceLine?.lineTotalFinal).toBeCloseTo(2);
  });
});

describe("isCustomerDiscountEligible", () => {
  const patron = customer({ is_employee: true });

  it("blocks employee discounts until manager override is engaged", () => {
    expect(isCustomerDiscountEligible(patron, "cust-employee", FIX_NOW, false)).toBe(false);
    expect(isCustomerDiscountEligible(patron, "cust-employee", FIX_NOW, true)).toBe(true);
  });
});
