import { describe, expect, it } from "vitest";
import {
  buildFallbackDraft,
  normalizeDraftPayload,
  parseDraftContent,
} from "../../supabase/functions/_shared/draftPayload";

describe("draftPayload", () => {
  const request = {
    brand: "Pacific Stone",
    strain: "Blue Dream",
    productType: "Flower",
    packageSize: "3.5g",
    sku: "BD-35",
    vendor: "Greenline",
  };

  it("builds a deterministic fallback draft from intake data", () => {
    const fallback = buildFallbackDraft(request);

    expect(fallback.descriptionShort).toBe("Blue Dream 3.5g Flower");
    expect(fallback.sections[0].fields).toEqual(
      expect.arrayContaining([
        { label: "Brand Name", value: "Pacific Stone" },
        { label: "Strain Name", value: "Blue Dream" },
        { label: "Product Title", value: "Blue Dream 3.5g Flower" },
        { label: "Category", value: "Flower" },
        { label: "Package", value: "3.5g" },
        { label: "SKU", value: "BD-35" },
        { label: "Vendor", value: "Greenline" },
      ]),
    );
  });

  it("normalizes loose AI payloads onto canonical section and field labels", () => {
    const draft = normalizeDraftPayload(
      {
        overallConfidence: 91,
        descriptionShort: "Blue Dream 3.5g Flower",
        descriptionLong: "Blue Dream 3.5g Flower",
        sections: [
          {
            title: "Vendor details",
            icon: "FileText",
            confidence: "verified",
            fields: [
              { label: "Brand", value: "Pacific Stone" },
              { label: "Strain", value: "Blue Dream" },
              { label: "Product Name", value: "Blue Dream 3.5g Flower" },
              { label: "Product Type", value: "Flower" },
              { label: "Package Size", value: "3.5g" },
              { label: "SKU", value: "BD-35" },
            ],
          },
          {
            title: "Flavor profile",
            icon: "Leaf",
            confidence: "matched",
            fields: [
              { label: "Inhale", value: "Berry" },
              { label: "Exhale", value: "Earthy" },
            ],
          },
          {
            title: "Medical",
            icon: "Heart",
            confidence: "inferred",
            fields: [
              { label: "May Help With", value: "unknown" },
            ],
          },
        ],
      },
      request,
    );

    expect(draft.overallConfidence).toBe(91);
    expect(draft.sections.find((section) => section.title === "Vendor Information")?.fields).toEqual(
      expect.arrayContaining([
        { label: "Brand Name", value: "Pacific Stone" },
        { label: "Strain Name", value: "Blue Dream" },
        { label: "Product Title", value: "Blue Dream 3.5g Flower" },
        { label: "Category", value: "Flower" },
        { label: "Package", value: "3.5g" },
        { label: "SKU", value: "BD-35" },
      ]),
    );
    expect(draft.sections.find((section) => section.title === "Taste Profile")?.fields).toEqual([
      { label: "Taste Profile", value: "Berry" },
      { label: "Finish", value: "Earthy" },
    ]);
    expect(draft.sections.find((section) => section.title === "Medical Uses")?.fields).toEqual([
      { label: "Medical Uses", value: "" },
      { label: "May Help With", value: "" },
    ]);
  });

  it("parses fenced JSON responses from the provider", () => {
    const draft = parseDraftContent(
      `\`\`\`json
      {
        "overallConfidence": 77,
        "descriptionShort": "Blue Dream 3.5g Flower",
        "descriptionLong": "Blue Dream 3.5g Flower",
        "sections": []
      }
      \`\`\``,
      request,
    );

    expect(draft.overallConfidence).toBe(77);
    expect(draft.sections).toHaveLength(7);
    expect(draft.sections[0].fields[0]).toEqual({ label: "Brand Name", value: "Pacific Stone" });
  });
});
