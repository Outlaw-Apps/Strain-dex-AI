import { beforeEach, describe, expect, it, vi } from "vitest";
import {
  TRUSTED_CANNABIS_RESEARCH_SOURCES,
  __resetResearchPolicyCacheForTest,
  buildTrustedSourceQueries,
  extractDuckDuckGoResultUrls,
  extractResearchSnippetFromHtml,
  loadResearchPolicy,
} from "../../supabase/functions/_shared/cannabisResearch";
import {
  describeProviderFailure,
  resolveProviderConfig,
} from "../../supabase/functions/_shared/generateDraft";

const request = {
  brand: "Pacific Stone",
  strain: "Blue Dream",
  productType: "Flower",
  packageSize: "3.5g",
  vendor: "Greenline",
};

const envFrom = (values: Record<string, string>) => (key: string) => values[key];

describe("cannabisResearch", () => {
  beforeEach(() => {
    __resetResearchPolicyCacheForTest();
  });

  it("builds site-filtered queries for trusted sources", () => {
    const haven = TRUSTED_CANNABIS_RESEARCH_SOURCES.find((source) => source.name === "Haven");
    expect(haven).toBeDefined();

    const queries = buildTrustedSourceQueries(haven!, request);

    expect(queries.some((query) => query.includes("site:content.myhavenstores.com"))).toBe(true);
    expect(queries.some((query) => query.includes("site:shopphaven.com"))).toBe(true);
    expect(queries.some((query) => query.includes("Pacific Stone Blue Dream"))).toBe(true);
  });

  it("decodes DuckDuckGo redirect links into source URLs", () => {
    const html = `
      <div class="result">
        <a class="result__a" href="//duckduckgo.com/l/?uddg=https%3A%2F%2Fallbud.com%2Fmarijuana-strains%2Fsativa-dominant-hybrid%2Fblue-dream">
          Blue Dream
        </a>
      </div>
    `;

    expect(extractDuckDuckGoResultUrls(html)).toEqual([
      "https://allbud.com/marijuana-strains/sativa-dominant-hybrid/blue-dream",
    ]);
  });

  it("extracts the most relevant research snippet from product content", () => {
    const html = `
      <html>
        <head>
          <title>Blue Dream | AllBud</title>
          <meta
            name="description"
            content="Blue Dream delivers sweet berry aroma with 18-24% THC and dominant myrcene, pinene, and caryophyllene."
          />
        </head>
        <body>
          <article>
            <p>Blue Dream is a balanced hybrid with sweet berry flavor and creative, uplifting effects.</p>
            <p>Reported to assist with stress, discomfort, and low mood.</p>
          </article>
        </body>
      </html>
    `;

    const extracted = extractResearchSnippetFromHtml(html, request);

    expect(extracted.title).toContain("Blue Dream");
    expect(extracted.snippet).toContain("18-24% THC");
    expect(extracted.snippet).toContain("uplifting effects");
  });

  it("refreshes the admin source policy on consecutive loads", async () => {
    const rows = [
      [{ domain: "leafly.com", mode: "allow" as const, enabled: true }],
      [{ domain: "allbud.com", mode: "allow" as const, enabled: true }],
    ];
    const eq = vi.fn(async () => ({
      data: rows.shift() ?? [],
      error: null,
    }));
    const client = {
      from: vi.fn(() => ({
        select: vi.fn(() => ({
          eq,
        })),
      })),
    };

    const first = await loadResearchPolicy(client, () => 1000);
    const second = await loadResearchPolicy(client, () => 1001);

    expect(first.sources.flatMap((source) => source.domains)).toEqual(["leafly.com"]);
    expect(second.sources.flatMap((source) => source.domains)).toEqual(["allbud.com"]);
    expect(eq).toHaveBeenCalledTimes(2);
  });
});

describe("resolveProviderConfig", () => {
  it("resolves DeepSeek when DEEPSEEK_API_KEY is set", () => {
    const config = resolveProviderConfig(
      envFrom({
        DEEPSEEK_API_KEY: "deepseek-key",
      }),
    );

    expect(config.provider).toBe("deepseek");
    expect(config.model).toBe("deepseek-v4-pro");
    expect(config.apiKey).toBe("deepseek-key");
  });

  it("falls back to AI_API_KEY when DEEPSEEK_API_KEY is missing", () => {
    const config = resolveProviderConfig(
      envFrom({
        AI_API_KEY: "shared-key",
      }),
    );

    expect(config.provider).toBe("deepseek");
    expect(config.apiKey).toBe("shared-key");
    expect(config.model).toBe("deepseek-v4-pro");
  });

  it("respects DEEPSEEK_MODEL override", () => {
    const config = resolveProviderConfig(
      envFrom({
        DEEPSEEK_API_KEY: "deepseek-key",
        DEEPSEEK_MODEL: "deepseek-reasoner",
      }),
    );

    expect(config.provider).toBe("deepseek");
    expect(config.model).toBe("deepseek-reasoner");
  });

  it("resolves OpenAI when only OPENAI_API_KEY is set", () => {
    const config = resolveProviderConfig(
      envFrom({
        OPENAI_API_KEY: "openai-key",
      }),
    );

    expect(config.provider).toBe("openai");
    expect(config.apiKey).toBe("openai-key");
    expect(config.model).toBe("gpt-4o-mini");
  });

  it("uses the shared AI_API_KEY when AI_PROVIDER=openai", () => {
    const config = resolveProviderConfig(
      envFrom({
        AI_PROVIDER: "openai",
        AI_API_KEY: "shared-key",
        AI_MODEL: "gpt-4.1-mini",
      }),
    );

    expect(config.provider).toBe("openai");
    expect(config.apiKey).toBe("shared-key");
    expect(config.model).toBe("gpt-4.1-mini");
  });

  it("throws when no API key is configured", () => {
    expect(() => resolveProviderConfig(envFrom({}))).toThrow(
      "DEEPSEEK_API_KEY is not configured",
    );
  });
});

describe("describeProviderFailure", () => {
  it("returns a friendly authentication message", () => {
    expect(describeProviderFailure("openai", 401)).toContain("authentication failed");
  });

  it("falls back to the provider message for non-special statuses", () => {
    expect(describeProviderFailure("deepseek", 400, "Invalid request body")).toBe(
      "Invalid request body",
    );
  });
});
