import { describe, expect, it } from "vitest";
import { buildEmployeeLookup, guessColumn, mapCsvRows, parseCsv } from "@/lib/payroll/csvImport";

describe("csvImport.parseCsv", () => {
  it("parses simple CSV with header", () => {
    const rows = parseCsv("name,amount\nAlice,100\nBob,200");
    expect(rows).toEqual([["name", "amount"], ["Alice", "100"], ["Bob", "200"]]);
  });

  it("handles quoted fields with commas and escaped quotes", () => {
    const rows = parseCsv(`name,memo\n"Doe, Jane","She said ""hi"""\nBob,ok`);
    expect(rows).toEqual([
      ["name", "memo"],
      ["Doe, Jane", 'She said "hi"'],
      ["Bob", "ok"],
    ]);
  });

  it("strips BOM and supports CRLF", () => {
    const rows = parseCsv("\uFEFFa,b\r\n1,2\r\n");
    expect(rows).toEqual([["a", "b"], ["1", "2"]]);
  });
});

describe("csvImport.mapCsvRows", () => {
  const profileMap = new Map<string, string>([
    ["11111111-1111-1111-1111-111111111111", "Alice Adams"],
    ["22222222-2222-2222-2222-222222222222", "Bob Brown"],
  ]);

  it("matches employees by name (case-insensitive) and parses amounts", () => {
    const csv = parseCsv('name,amount\nalice adams,"$1,250.00"\nbob brown,500\n');
    const result = mapCsvRows(csv, { employee: 0, amount: 1, memo: null, date: null, checkNumber: null }, profileMap, true);
    expect(result).toHaveLength(2);
    expect(result[0]).toMatchObject({
      employeeId: "11111111-1111-1111-1111-111111111111",
      amount: 1250,
      status: "matched",
    });
    expect(result[1]).toMatchObject({ employeeId: "22222222-2222-2222-2222-222222222222", amount: 500 });
  });

  it("flags unmatched employees and invalid amounts", () => {
    const csv = parseCsv("name,amount\nGhost User,100\nAlice Adams,not-a-number\n");
    const result = mapCsvRows(csv, { employee: 0, amount: 1, memo: null, date: null, checkNumber: null }, profileMap, true);
    expect(result[0].status).toBe("unmatched");
    expect(result[1].status).toBe("invalid_amount");
  });

  it("marks second appearance of the same employee as duplicate", () => {
    const csv = parseCsv("name,amount\nAlice Adams,100\nAlice Adams,200\n");
    const result = mapCsvRows(csv, { employee: 0, amount: 1, memo: null, date: null, checkNumber: null }, profileMap, true);
    expect(result[0].status).toBe("matched");
    expect(result[1].status).toBe("duplicate");
  });

  it("accepts UUID directly in the employee column", () => {
    const csv = parseCsv("id,amount\n22222222-2222-2222-2222-222222222222,42\n");
    const result = mapCsvRows(csv, { employee: 0, amount: 1, memo: null, date: null, checkNumber: null }, profileMap, true);
    expect(result[0]).toMatchObject({
      employeeId: "22222222-2222-2222-2222-222222222222",
      employeeName: "Bob Brown",
      status: "matched",
    });
  });
});

describe("csvImport.guessColumn", () => {
  it("returns the first exact then fuzzy header match", () => {
    const headers = ["Employee Name", "Net Pay", "Memo"];
    expect(guessColumn(headers, ["employee name"])).toBe(0);
    expect(guessColumn(headers, ["amount", "net pay"])).toBe(1);
    expect(guessColumn(headers, ["missing"])).toBeNull();
  });
});

describe("csvImport.buildEmployeeLookup", () => {
  it("indexes by id and lowercased name", () => {
    const lookup = buildEmployeeLookup(new Map([["id-1", "Jane Doe"]]));
    expect(lookup.get("id-1")).toBe("id-1");
    expect(lookup.get("jane doe")).toBe("id-1");
  });
});
