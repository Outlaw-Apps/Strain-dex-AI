import { describe, expect, it } from "vitest";
import { calculatePayroll, payrollToCSV, type TimeEntryInput } from "@/lib/payroll/payroll.engine";
import type { EmployeePayrollProfile } from "@/lib/payroll/payroll.types";

const profile: EmployeePayrollProfile = {
  id: "prof-1",
  employee_id: "emp-1",
  hourly_rate: 20,
  overtime_multiplier: 1.5,
  doubletime_multiplier: 2,
  tax_filing_status: "single",
  deductions: 0,
  direct_deposit_account: null,
  direct_deposit_routing: null,
  is_active: true,
  created_at: "2025-01-01",
  updated_at: "2025-01-01",
};

function makeEntry(clockIn: string, clockOut: string): TimeEntryInput {
  return { id: `te-${clockIn}`, user_id: "emp-1", clock_in: clockIn, clock_out: clockOut };
}

describe("payroll engine", () => {
  const periodStart = new Date(2025, 0, 6);
  const periodEnd = new Date(2025, 0, 12, 23, 59, 59);

  it("calculates a standard 8h day as regular time", () => {
    const entries = [makeEntry("2025-01-06T08:00:00", "2025-01-06T16:00:00")];
    const result = calculatePayroll(entries, profile, periodStart, periodEnd);

    expect(result.regular_hours).toBe(8);
    expect(result.ot_hours).toBe(0);
    expect(result.doubletime_hours).toBe(0);
    expect(result.regular_pay).toBe(160);
    expect(result.net_pay).toBe(160);
  });

  it("applies CA daily OT after 8h and DT after 12h", () => {
    const entries = [makeEntry("2025-01-06T06:00:00", "2025-01-06T20:00:00")]; // 14h
    const result = calculatePayroll(entries, profile, periodStart, periodEnd);

    expect(result.regular_hours).toBe(8);
    expect(result.ot_hours).toBe(4);
    expect(result.doubletime_hours).toBe(2);
    expect(result.regular_pay).toBe(160);
    expect(result.ot_pay).toBe(120);
    expect(result.doubletime_pay).toBe(80);
    expect(result.gross_pay).toBe(360);
  });

  it("splits overnight shifts at midnight boundaries", () => {
    const entries = [makeEntry("2025-01-06T20:00:00", "2025-01-07T06:00:00")]; // 10h across midnight
    const result = calculatePayroll(entries, profile, periodStart, periodEnd);

    expect(result.daily_details).toHaveLength(2);
    const day1 = result.daily_details.find((d) => d.date === "2025-01-06");
    const day2 = result.daily_details.find((d) => d.date === "2025-01-07");
    expect(day1?.total_hours).toBe(4); // 20:00-00:00
    expect(day2?.total_hours).toBe(6); // 00:00-06:00
    expect(result.regular_hours).toBe(10);
    expect(result.ot_hours).toBe(0);
  });

  it("caps deductions at gross pay to prevent negative net", () => {
    const highDeduction = { ...profile, deductions: 9999 };
    const entries = [makeEntry("2025-01-06T08:00:00", "2025-01-06T09:00:00")]; // 1h
    const result = calculatePayroll(entries, highDeduction, periodStart, periodEnd);

    expect(result.gross_pay).toBe(20);
    expect(result.deductions).toBe(20);
    expect(result.net_pay).toBe(0);
  });

  it("filters entries by employee_id and date range", () => {
    const entries: TimeEntryInput[] = [
      { id: "other", user_id: "emp-other", clock_in: "2025-01-06T08:00:00", clock_out: "2025-01-06T16:00:00" },
      makeEntry("2025-01-05T08:00:00", "2025-01-05T16:00:00"), // before period
      makeEntry("2025-01-06T08:00:00", "2025-01-06T12:00:00"), // in period
    ];
    const result = calculatePayroll(entries, profile, periodStart, periodEnd);

    expect(result.regular_hours).toBe(4);
    expect(result.daily_details).toHaveLength(1);
  });

  it("skips entries without clock_out", () => {
    const entries: TimeEntryInput[] = [
      { id: "open", user_id: "emp-1", clock_in: "2025-01-06T08:00:00", clock_out: null },
    ];
    const result = calculatePayroll(entries, profile, periodStart, periodEnd);

    expect(result.regular_hours).toBe(0);
    expect(result.daily_details).toHaveLength(0);
  });

  it("handles 7th consecutive workday with OT/DT rules", () => {
    // Jan 5 2025 is Sunday; Sun–Sat = one full workweek
    const weekStart = new Date(2025, 0, 5);
    const weekEnd = new Date(2025, 0, 11, 23, 59, 59);
    const entries = Array.from({ length: 7 }, (_, i) => {
      const day = String(5 + i).padStart(2, "0");
      return makeEntry(`2025-01-${day}T08:00:00`, `2025-01-${day}T18:00:00`); // 10h each
    });
    const result = calculatePayroll(entries, profile, weekStart, weekEnd);

    const seventh = result.daily_details.find((d) => d.date === "2025-01-11");
    expect(seventh).toBeDefined();
    expect(seventh!.regular).toBe(0);
    expect(seventh!.overtime).toBe(8);
    expect(seventh!.doubletime).toBe(2);
  });

  it("generates valid CSV output", () => {
    const entries = [makeEntry("2025-01-06T08:00:00", "2025-01-06T16:00:00")];
    const result = calculatePayroll(entries, profile, periodStart, periodEnd);
    const nameMap = new Map([["emp-1", "Jane Doe"]]);
    const csv = payrollToCSV([result], nameMap);

    expect(csv).toContain("Employee,Regular Hrs");
    expect(csv).toContain('"Jane Doe"');
    expect(csv.split("\n")).toHaveLength(2);
  });
});
