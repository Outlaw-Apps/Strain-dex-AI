import { describe, expect, it } from "vitest";
import type { PayrollBreakdown } from "@/lib/payroll/payroll.types";
import { buildPayrollPdfInput } from "@/lib/payroll/payrollExport";

describe("buildPayrollPdfInput", () => {
  it("creates a reusable payload for payroll PDF exports", () => {
    const employeeNames = new Map([["emp-1", "Morgan Lee"]]);
    const breakdowns: PayrollBreakdown[] = [
      {
        employee_id: "emp-1",
        regular_hours: 32,
        ot_hours: 4,
        doubletime_hours: 0,
        regular_pay: 640,
        ot_pay: 120,
        doubletime_pay: 0,
        gross_pay: 760,
        deductions: 120,
        net_pay: 640,
        daily_details: [],
      },
    ];

    expect(
      buildPayrollPdfInput({
        startDate: "2026-04-01",
        endDate: "2026-04-14",
        employeeNames,
        breakdowns,
      }),
    ).toEqual({
      businessName: "StrainVentory",
      startDate: "2026-04-01",
      endDate: "2026-04-14",
      employeeNames,
      breakdowns,
    });
  });
});
