import { describe, expect, it } from "vitest";
import {
  buildPayrollSummaryPdf,
  buildPayslipPacketPdf,
} from "@/lib/payroll/payrollPdf";
import type { PayrollBreakdown } from "@/lib/payroll/payroll.types";

const employeeNames = new Map([
  ["emp-1", "Avery Johnson"],
]);

const breakdowns: PayrollBreakdown[] = [
  {
    employee_id: "emp-1",
    regular_hours: 32,
    ot_hours: 4,
    doubletime_hours: 0,
    regular_pay: 640,
    ot_pay: 120,
    doubletime_pay: 0,
    gross_pay: 760,
    deductions: 60,
    net_pay: 700,
    daily_details: [
      {
        date: "2026-04-14",
        total_hours: 8,
        regular: 8,
        overtime: 0,
        doubletime: 0,
      },
    ],
  },
];

describe("payrollPdf", () => {
  it("creates a payroll summary PDF payload", () => {
    const bytes = buildPayrollSummaryPdf({
      startDate: "2026-04-01",
      endDate: "2026-04-14",
      employeeNames,
      breakdowns,
    });

    const text = new TextDecoder().decode(bytes);
    expect(text.startsWith("%PDF-1.4")).toBe(true);
    expect(text).toContain("Payroll Summary");
    expect(text).toContain("Avery Johnson");
  });

  it("creates a payslip packet PDF payload", () => {
    const bytes = buildPayslipPacketPdf({
      startDate: "2026-04-01",
      endDate: "2026-04-14",
      employeeNames,
      breakdowns,
    });

    const text = new TextDecoder().decode(bytes);
    expect(text.startsWith("%PDF-1.4")).toBe(true);
    expect(text).toContain("Payslip - Avery Johnson");
    expect(text).toContain("Net pay:");
  });
});
