import { beforeEach, describe, expect, it, vi } from "vitest";
import { fireEvent, render, screen, waitFor } from "@testing-library/react";
import { MemoryRouter } from "react-router-dom";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { routerFuture } from "@/lib/routerFuture";
import PayrollRun from "@/pages/PayrollRun";
import type { PayrollBreakdown } from "@/lib/payroll/payroll.types";

const mocks = vi.hoisted(() => ({
  calculatePayroll: vi.fn(),
  buildPayrollSummaryPdf: vi.fn(),
  buildPayslipPacketPdf: vi.fn(),
  createPeriodMutateAsync: vi.fn(),
  updatePeriodMutateAsync: vi.fn(),
  bulkInsertMutateAsync: vi.fn(),
  toastSuccess: vi.fn(),
  toastError: vi.fn(),
  deleteEq: vi.fn(),
}));

const employeeNames = new Map([["emp-1", "Avery Johnson"]]);

const breakdown: PayrollBreakdown = {
  employee_id: "emp-1",
  regular_hours: 32,
  ot_hours: 4,
  doubletime_hours: 0,
  regular_pay: 640,
  ot_pay: 120,
  doubletime_pay: 0,
  gross_pay: 760,
  deductions: 60,
  net_pay: 700,
  daily_details: [
    {
      date: "2026-04-14",
      total_hours: 8,
      regular: 8,
      overtime: 0,
      doubletime: 0,
    },
  ],
};

vi.mock("@/hooks/useUserRoles", () => ({
  useUserRoles: () => ({
    isAdmin: true,
  }),
}));

vi.mock("@/hooks/useProfiles", () => ({
  useProfileMap: () => employeeNames,
}));

vi.mock("@/hooks/useTimeEntries", () => ({
  usePayrollTimeEntries: () => ({
    data: [],
    isLoading: false,
  }),
}));

vi.mock("@/lib/payroll/payroll.api", () => ({
  usePayrollProfiles: () => ({
    data: [{ employee_id: "emp-1", is_active: true }],
    isLoading: false,
  }),
  useCreatePayPeriod: () => ({
    mutateAsync: mocks.createPeriodMutateAsync,
  }),
  useUpdatePayPeriod: () => ({
    mutateAsync: mocks.updatePeriodMutateAsync,
  }),
  useBulkInsertPayslips: () => ({
    mutateAsync: mocks.bulkInsertMutateAsync,
  }),
}));

vi.mock("@/lib/payroll/payroll.engine", () => ({
  calculatePayroll: mocks.calculatePayroll,
  payrollToCSV: vi.fn(() => "employee,gross\nAvery Johnson,760"),
}));

vi.mock("@/lib/payroll/payrollPdf", () => ({
  buildPayrollSummaryPdf: mocks.buildPayrollSummaryPdf,
  buildPayslipPacketPdf: mocks.buildPayslipPacketPdf,
}));

vi.mock("@/integrations/supabase/client", () => ({
  supabase: {
    from: () => ({
      delete: () => ({
        eq: mocks.deleteEq,
      }),
    }),
  },
}));

vi.mock("sonner", () => ({
  toast: {
    success: mocks.toastSuccess,
    error: mocks.toastError,
  },
}));

function renderPage() {
  const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } });
  return render(
    <QueryClientProvider client={qc}>
      <MemoryRouter future={routerFuture}>
        <PayrollRun />
      </MemoryRouter>
    </QueryClientProvider>,
  );
}

async function calculatePreview() {
  fireEvent.click(screen.getByRole("button", { name: /calculate payroll/i }));
  await screen.findByRole("button", { name: /summary pdf/i });
}

describe("PayrollRun", () => {
  beforeEach(() => {
    vi.clearAllMocks();

    mocks.calculatePayroll.mockReturnValue(breakdown);
    mocks.buildPayrollSummaryPdf.mockReturnValue(new Uint8Array([1, 2, 3]));
    mocks.buildPayslipPacketPdf.mockReturnValue(new Uint8Array([4, 5, 6]));
    mocks.createPeriodMutateAsync.mockResolvedValue({ id: "period-1" });
    mocks.updatePeriodMutateAsync.mockImplementation(async ({ id, status }) => ({
      id,
      status,
    }));
    mocks.bulkInsertMutateAsync.mockResolvedValue([]);

    vi.stubGlobal(
      "URL",
      Object.assign(globalThis.URL, {
        createObjectURL: vi.fn(() => "blob:payroll"),
        revokeObjectURL: vi.fn(),
      }),
    );
    HTMLAnchorElement.prototype.click = vi.fn();
  });

  it("builds the payroll summary PDF from the current preview payload", async () => {
    renderPage();
    await calculatePreview();

    fireEvent.click(screen.getByRole("button", { name: /summary pdf/i }));

    await waitFor(() => expect(mocks.buildPayrollSummaryPdf).toHaveBeenCalledTimes(1));

    const [input] = mocks.buildPayrollSummaryPdf.mock.calls[0];
    expect(input).toMatchObject({
      businessName: "StrainVentory",
      startDate: expect.any(String),
      endDate: expect.any(String),
      breakdowns: [breakdown],
      generatedAt: expect.any(Date),
    });
    expect(input.employeeNames).toBe(employeeNames);
    expect(mocks.toastError).not.toHaveBeenCalled();
  });

  it("builds the paycheck packet PDF before marking the run paid", async () => {
    renderPage();
    await calculatePreview();

    fireEvent.click(screen.getByRole("button", { name: /issue & export paychecks/i }));

    await waitFor(() => expect(mocks.buildPayslipPacketPdf).toHaveBeenCalledTimes(1));
    await waitFor(() => expect(mocks.createPeriodMutateAsync).toHaveBeenCalledTimes(1));
    await waitFor(() => expect(mocks.bulkInsertMutateAsync).toHaveBeenCalledTimes(1));
    await waitFor(() =>
      expect(mocks.updatePeriodMutateAsync).toHaveBeenCalledWith(
        expect.objectContaining({
          id: "period-1",
          status: "paid",
        }),
      ),
    );

    const [input] = mocks.buildPayslipPacketPdf.mock.calls[0];
    expect(input).toMatchObject({
      businessName: "StrainVentory",
      startDate: expect.any(String),
      endDate: expect.any(String),
      breakdowns: [breakdown],
      generatedAt: expect.any(Date),
    });
    expect(input.employeeNames).toBe(employeeNames);
    expect(mocks.toastError).not.toHaveBeenCalled();
  });
});
