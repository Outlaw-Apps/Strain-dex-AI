import { describe, expect, it } from "vitest";
import { derivePosDiscountPermissions } from "@/hooks/usePosDiscountPermissions";

describe("derivePosDiscountPermissions", () => {
  it("returns all false while loading", () => {
    const p = derivePosDiscountPermissions(["staff"], true);
    expect(p.loading).toBe(true);
    expect(p.applyStandardDiscount).toBe(false);
    expect(p.applyBogoDiscount).toBe(false);
  });

  it("staff: standard + BOGO, not employee without override", () => {
    const p = derivePosDiscountPermissions(["staff"], false);
    expect(p.applyStandardDiscount).toBe(true);
    expect(p.applyEmployeeDiscountWithoutOverride).toBe(false);
    expect(p.applyBogoDiscount).toBe(true);
    expect(p.overrideDiscountRules).toBe(false);
  });

  it("reviewer: all discounts except override rules", () => {
    const p = derivePosDiscountPermissions(["reviewer"], false);
    expect(p.applyEmployeeDiscountWithoutOverride).toBe(true);
    expect(p.overrideDiscountRules).toBe(false);
  });

  it("admin: full override", () => {
    const p = derivePosDiscountPermissions(["admin"], false);
    expect(p.overrideDiscountRules).toBe(true);
    expect(p.applyEmployeeDiscountWithoutOverride).toBe(true);
  });
});
