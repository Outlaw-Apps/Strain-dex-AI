import { describe, expect, it } from "vitest";
import {
  formatDisplayNumber,
  getCartLineTotal,
  getWeightedUnitPrice,
  parseWeightGrams,
} from "@/lib/posPricing";

describe("posPricing", () => {
  it("parses grams from a weight option", () => {
    expect(parseWeightGrams("3.5g")).toBe(3.5);
    expect(parseWeightGrams("28g")).toBe(28);
  });

  it("multiplies price-per-gram by the selected weight", () => {
    expect(getWeightedUnitPrice(10, "1g")).toBe(10);
    expect(getWeightedUnitPrice(10, "3.5g")).toBe(35);
    expect(getWeightedUnitPrice(10, "7g")).toBe(70);
  });

  it("calculates the full line total from weight and quantity", () => {
    expect(getCartLineTotal(12, "3.5g", 2)).toBe(84);
  });

  it("formats decimal quantities cleanly", () => {
    expect(formatDisplayNumber(12)).toBe("12");
    expect(formatDisplayNumber(12.5)).toBe("12.5");
    expect(formatDisplayNumber(12.25)).toBe("12.25");
  });
});
