import { describe, expect, it } from "vitest";
import { buildDraftReportMarkdown } from "@/lib/productIntake/draftReport";
import { EMPTY_INTAKE_FORM, type IntakeForm } from "@/lib/productIntake/types";
import type { GeneratedDraft } from "@/context/ProductDraftContext";

function makeForm(overrides: Partial<IntakeForm> = {}): IntakeForm {
  return { ...EMPTY_INTAKE_FORM, ...overrides };
}

describe("buildDraftReportMarkdown", () => {
  it("renders all identity, classification, lab, retail, and notes sections", () => {
    const form = makeForm({
      name: "Blue Dream 3.5g",
      brand: "Pacific Stone",
      strain: "Blue Dream",
      batchNumber: "BD-001",
      sku: "BD-35",
      strainType: "Hybrid",
      limitCategory: "Flower",
      productType: "Flower",
      genetics: "Blueberry x Haze",
      vendor: "Greenline",
      thc: "22%",
      cbd: "0.5%",
      listPricePerGram: "12",
      salePricePerGram: "10",
      saleStartsLocal: "2026-06-01T00:00",
      saleEndsLocal: "2026-06-30T00:00",
      saleLabel: "Summer Sale",
      flavorProfile: "Berry",
      aromaProfile: "Pine",
      notes: "Top shelf",
    });

    const { content, filename } = buildDraftReportMarkdown(form);

    expect(content).toContain("# Product Intake Draft Report");
    expect(content).toContain("- Name: Blue Dream 3.5g");
    expect(content).toContain("- Brand: Pacific Stone");
    expect(content).toContain("- Strain Type: Hybrid");
    expect(content).toContain("- THC: 22%");
    expect(content).toContain("- List $/g: 12");
    expect(content).toContain("- Shelf Label: Summer Sale");
    expect(content).toContain("- Clearance Active: No");
    expect(content).toContain("Top shelf");
    expect(filename).toMatch(/^intake-draft-blue-dream-3-5g-\d{4}-\d{2}-\d{2}\.md$/);
  });

  it("includes clearance fields only when clearance is active", () => {
    const inactive = buildDraftReportMarkdown(makeForm({ name: "X" }));
    expect(inactive.content).not.toContain("Clearance $/g");

    const active = buildDraftReportMarkdown(
      makeForm({
        name: "X",
        clearanceActive: true,
        clearancePricePerGram: "5",
        clearanceReason: "Aging stock",
      }),
    );
    expect(active.content).toContain("- Clearance Active: Yes");
    expect(active.content).toContain("- Clearance $/g: 5");
    expect(active.content).toContain("- Clearance Reason: Aging stock");
  });

  it("substitutes em-dashes for blank fields", () => {
    const { content } = buildDraftReportMarkdown(makeForm());
    expect(content).toContain("- Name: —");
    expect(content).toContain("- Strain Type: —");
    expect(content).toContain("- THC: —");
  });

  it("appends AI Draft section when a draft is provided", () => {
    const draft: GeneratedDraft = {
      overallConfidence: 90,
      sections: [],
      descriptionShort: "Short blurb",
      descriptionLong: "Longer description",
    };
    const { content } = buildDraftReportMarkdown(makeForm({ name: "X" }), draft);
    expect(content).toContain("## AI Draft");
    expect(content).toContain("- Short: Short blurb");
    expect(content).toContain("- Long: Longer description");
  });

  it("falls back to 'draft' slug when name, strain, and brand are empty", () => {
    const { filename } = buildDraftReportMarkdown(makeForm());
    expect(filename).toMatch(/^intake-draft-draft-\d{4}-\d{2}-\d{2}\.md$/);
  });
});
