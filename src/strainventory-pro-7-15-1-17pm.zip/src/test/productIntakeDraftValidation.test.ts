import { describe, expect, it } from "vitest";
import {
  extractDraftCandidate,
  extractErrorMessage,
  isGeneratedDraft,
} from "@/lib/productIntake/draftValidation";

describe("productIntake/draftValidation", () => {
  describe("isGeneratedDraft", () => {
    it("accepts a valid GeneratedDraft shape", () => {
      expect(
        isGeneratedDraft({
          overallConfidence: 80,
          sections: [],
          descriptionShort: "short",
          descriptionLong: "long",
        }),
      ).toBe(true);
    });

    it.each([
      ["null", null],
      ["undefined", undefined],
      ["array", []],
      ["primitive", "draft"],
      ["missing sections", { overallConfidence: 1, descriptionShort: "", descriptionLong: "" }],
      [
        "wrong types",
        {
          overallConfidence: "high",
          sections: [],
          descriptionShort: "",
          descriptionLong: "",
        },
      ],
      [
        "sections not an array",
        {
          overallConfidence: 1,
          sections: {},
          descriptionShort: "",
          descriptionLong: "",
        },
      ],
    ])("rejects %s", (_label, value) => {
      expect(isGeneratedDraft(value)).toBe(false);
    });
  });

  describe("extractErrorMessage", () => {
    it("returns the error string when present", () => {
      expect(extractErrorMessage({ error: "Boom" }, "fallback")).toBe("Boom");
    });

    it("returns the fallback when error is missing or blank", () => {
      expect(extractErrorMessage({}, "fallback")).toBe("fallback");
      expect(extractErrorMessage({ error: "   " }, "fallback")).toBe("fallback");
      expect(extractErrorMessage(null, "fallback")).toBe("fallback");
      expect(extractErrorMessage("string", "fallback")).toBe("fallback");
    });
  });

  describe("extractDraftCandidate", () => {
    it("returns the draft value from a record", () => {
      const draft = { hello: "world" };
      expect(extractDraftCandidate({ draft })).toBe(draft);
    });

    it("returns undefined for non-record inputs", () => {
      expect(extractDraftCandidate(null)).toBeUndefined();
      expect(extractDraftCandidate("nope")).toBeUndefined();
      expect(extractDraftCandidate([])).toBeUndefined();
    });
  });
});
