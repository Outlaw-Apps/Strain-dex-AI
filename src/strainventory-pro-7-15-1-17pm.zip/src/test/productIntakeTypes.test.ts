import { describe, expect, it } from "vitest";
import {
  EMPTY_INTAKE_FORM,
  inferLimitCategory,
  isValidProductType,
  mergeDistinctLines,
} from "@/lib/productIntake/types";

describe("productIntake/types", () => {
  describe("inferLimitCategory", () => {
    it("returns empty string for empty input", () => {
      expect(inferLimitCategory("")).toBe("");
    });

    it("identifies flower products", () => {
      expect(inferLimitCategory("Flower")).toBe("Flower");
      expect(inferLimitCategory("Pre roll")).toBe("Flower");
    });

    it("identifies concentrate-family products", () => {
      expect(inferLimitCategory("Wax")).toBe("Concentrate");
      expect(inferLimitCategory("Live Resin")).toBe("Concentrate");
      expect(inferLimitCategory("Vape Cartridge")).toBe("Concentrate");
      expect(inferLimitCategory("Tincture")).toBe("Concentrate");
    });

    it("returns empty string for unknown product types", () => {
      expect(inferLimitCategory("Edible")).toBe("");
      expect(inferLimitCategory("nonsense")).toBe("");
    });
  });

  describe("mergeDistinctLines", () => {
    it("deduplicates case-insensitively and trims whitespace", () => {
      const result = mergeDistinctLines([
        "Sweet citrus\nEarthy",
        "  earthy  \nPine",
        "EARTHY",
      ]);
      expect(result.split("\n")).toEqual(["Sweet citrus", "Earthy", "Pine"]);
    });

    it("ignores empty and whitespace-only lines", () => {
      expect(mergeDistinctLines(["", "   ", "\n\n"])).toBe("");
    });

    it("preserves first-seen casing", () => {
      expect(mergeDistinctLines(["Berry", "berry", "BERRY"])).toBe("Berry");
    });
  });

  describe("isValidProductType", () => {
    it("accepts known product types", () => {
      expect(isValidProductType("Flower")).toBe(true);
      expect(isValidProductType("Wax")).toBe(true);
    });

    it("rejects unknown values", () => {
      expect(isValidProductType("")).toBe(false);
      expect(isValidProductType("Mystery")).toBe(false);
    });
  });

  describe("EMPTY_INTAKE_FORM", () => {
    it("has clearance disabled and all string fields blank", () => {
      expect(EMPTY_INTAKE_FORM.clearanceActive).toBe(false);
      expect(EMPTY_INTAKE_FORM.name).toBe("");
      expect(EMPTY_INTAKE_FORM.strainType).toBe("");
      expect(EMPTY_INTAKE_FORM.limitCategory).toBe("");
      expect(EMPTY_INTAKE_FORM.productType).toBe("");
    });
  });
});
