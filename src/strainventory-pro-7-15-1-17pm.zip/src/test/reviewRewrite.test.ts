import { describe, expect, it } from "vitest";
import { applyReviewRewrite } from "@/lib/reviewRewrite";

describe("reviewRewrite", () => {
  it("shortens catalog descriptions without dropping the whole value", () => {
    const result = applyReviewRewrite("shorten", {
      "Short Description": "Blue Dream flower with bright berry notes, balanced effects, and a long, descriptive sentence that should be trimmed down for the catalog view because it currently spills past the preferred card limit.",
      "Long Description": "Blue Dream flower with bright berry notes, balanced effects, and a long, descriptive sentence that should be trimmed down for the catalog view because it currently spills past the preferred card limit. It keeps going so the helper has to clamp it cleanly. There is an extra trailing sentence here to make sure the long-form limit is exercised.",
    });

    expect(result.changed).toBe(true);
    expect(result.fields["Short Description"].length).toBeLessThanOrEqual(140);
    expect(result.fields["Long Description"].endsWith("...")).toBe(true);
  });

  it("removes unverified medical claims when verifying content", () => {
    const result = applyReviewRewrite("verify", {
      "Medical Uses": "May help with stress relief.",
      "May Help With": "unknown",
      Effects: "Calming and focused.",
    });

    expect(result.fields["Medical Uses"]).toBe("");
    expect(result.fields["May Help With"]).toBe("");
    expect(result.fields.Effects).toBe("Calming and focused.");
  });

  it("simplifies narrative fields by removing parenthetical detail", () => {
    const result = applyReviewRewrite("simplify", {
      "Medical Uses": "Stress relief (customer-reported only); evening unwind",
    });

    expect(result.fields["Medical Uses"]).toBe("Stress relief, evening unwind.");
  });
});
