import { describe, expect, it } from "vitest";
import fs from "node:fs";
import path from "node:path";

const migration = fs.readFileSync(
  path.resolve("supabase/migrations/20260516000000_development_full_access_rls.sql"),
  "utf8",
);

const migrationV2 = fs.readFileSync(
  path.resolve(
    "supabase/migrations/20260529230000_development_rls_v2_and_selfhost_prep.sql",
  ),
  "utf8",
);

describe("development RLS migration", () => {
  it("grants authenticated full access across app tables", () => {
    expect(migration).toContain('"Development authenticated full access"');
    expect(migration).toContain("FOR ALL TO authenticated USING (true) WITH CHECK (true)");

    for (const tableName of [
      "products",
      "employees",
      "time_entries",
      "payslips",
      "business_settings",
      "conversation_messages",
      "user_roles",
    ]) {
      expect(migration).toContain(`'${tableName}'`);
    }
  });

  it("keeps product images public and opens development storage writes", () => {
    expect(migration).toContain('"Development authenticated product image access"');
    expect(migration).toContain('"Development authenticated employee document access"');
    expect(migration).toContain('"Public read access to product images"');
  });
});

describe("development RLS v2 migration", () => {
  it("uses dynamic pg_tables sweep to cover ALL public tables", () => {
    expect(migrationV2).toContain("pg_tables");
    expect(migrationV2).toContain('"Development full access"');
    expect(migrationV2).toContain(
      "FOR ALL TO authenticated USING (true) WITH CHECK (true)",
    );
  });

  it("opens storage buckets for development", () => {
    expect(migrationV2).toContain('"Dev full access product images"');
    expect(migrationV2).toContain('"Dev full access employee documents"');
    expect(migrationV2).toContain('"Public read product images"');
  });

  it("ensures auth triggers for self-hosted user provisioning", () => {
    expect(migrationV2).toContain("handle_new_user_profile");
    expect(migrationV2).toContain("handle_new_user_role");
    expect(migrationV2).toContain("on_auth_user_created_profile");
    expect(migrationV2).toContain("on_auth_user_created_assign_role");
  });

  it("backfills missing profiles and roles for existing users", () => {
    expect(migrationV2).toContain("INSERT INTO public.profiles");
    expect(migrationV2).toContain("INSERT INTO public.user_roles");
  });

  it("promotes oldest user to admin if none exists", () => {
    expect(migrationV2).toContain("ORDER BY created_at ASC");
    expect(migrationV2).toContain("'admin'");
  });
});
