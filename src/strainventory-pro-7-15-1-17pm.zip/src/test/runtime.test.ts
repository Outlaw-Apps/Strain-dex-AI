import { shouldUseHashRouter } from "@/lib/runtime";

describe("shouldUseHashRouter", () => {
  const originalDesktopShell = window.__STRAINVENTORY_DESKTOP_SHELL__;

  afterEach(() => {
    window.__STRAINVENTORY_DESKTOP_SHELL__ = originalDesktopShell;
  });

  it("defaults to browser routing outside the desktop shell", () => {
    window.__STRAINVENTORY_DESKTOP_SHELL__ = false;
    expect(shouldUseHashRouter()).toBe(false);
  });

  it("enables hash routing inside the WinUI desktop shell", () => {
    window.__STRAINVENTORY_DESKTOP_SHELL__ = true;
    expect(shouldUseHashRouter()).toBe(true);
  });
});
