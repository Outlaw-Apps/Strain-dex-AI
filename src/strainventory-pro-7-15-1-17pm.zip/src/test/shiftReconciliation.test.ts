import { describe, expect, it } from "vitest";
import {
  aggregateOrdersForShift,
  bucketPaymentMethod,
  expectedDrawerCash,
} from "@/lib/shiftReconciliation";

describe("bucketPaymentMethod", () => {
  it("classifies cash", () => {
    expect(bucketPaymentMethod("Cash")).toBe("cash");
    expect(bucketPaymentMethod("CASH")).toBe("cash");
  });

  it("classifies card-like methods", () => {
    expect(bucketPaymentMethod("Card")).toBe("card");
    expect(bucketPaymentMethod("Debit")).toBe("card");
    expect(bucketPaymentMethod("Apple Tap")).toBe("card");
  });

  it("classifies other", () => {
    expect(bucketPaymentMethod("Gift")).toBe("other");
    expect(bucketPaymentMethod("")).toBe("other");
  });
});

describe("aggregateOrdersForShift", () => {
  it("aggregates totals by bucket", () => {
    const r = aggregateOrdersForShift([
      { payment_method: "cash", total: 10 },
      { payment_method: "Cash", total: 5 },
      { payment_method: "card", total: 20 },
      { payment_method: "gift", total: 3 },
    ]);
    expect(r.order_count).toBe(4);
    expect(r.total_sales).toBeCloseTo(38);
    expect(r.total_cash).toBeCloseTo(15);
    expect(r.total_card).toBeCloseTo(20);
    expect(r.total_other).toBeCloseTo(3);
  });

  it("handles empty list", () => {
    const r = aggregateOrdersForShift([]);
    expect(r).toEqual({
      order_count: 0,
      total_sales: 0,
      total_cash: 0,
      total_card: 0,
      total_other: 0,
    });
  });
});

describe("expectedDrawerCash", () => {
  it("returns null when opening float missing", () => {
    expect(expectedDrawerCash(undefined, 100)).toBeNull();
    expect(expectedDrawerCash(null, 100)).toBeNull();
  });

  it("sums opening float and cash sales", () => {
    expect(expectedDrawerCash(50, 120.5)).toBeCloseTo(170.5);
  });
});
