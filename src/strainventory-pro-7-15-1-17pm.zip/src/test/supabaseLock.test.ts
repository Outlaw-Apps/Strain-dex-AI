import { describe, expect, it } from "vitest";
import { inProcessSupabaseLock } from "@/lib/supabaseLock";

const wait = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

describe("inProcessSupabaseLock", () => {
  it("serializes work for the same lock name", async () => {
    const events: string[] = [];

    const first = inProcessSupabaseLock("auth", 100, async () => {
      events.push("first:start");
      await wait(20);
      events.push("first:end");
    });

    const second = inProcessSupabaseLock("auth", 100, async () => {
      events.push("second:start");
      events.push("second:end");
    });

    await Promise.all([first, second]);

    expect(events).toEqual([
      "first:start",
      "first:end",
      "second:start",
      "second:end",
    ]);
  });

  it("marks timeout failures with the expected acquire-timeout flag", async () => {
    const first = inProcessSupabaseLock("auth", -1, async () => {
      await wait(25);
    });

    await expect(
      inProcessSupabaseLock("auth", 5, async () => {
        throw new Error("should not execute");
      }),
    ).rejects.toMatchObject({
      isAcquireTimeout: true,
      name: "SupabaseAuthLockAcquireTimeoutError",
    });

    await first;
  });
});
