import { describe, expect, it } from "vitest";
import fs from "node:fs";
import path from "node:path";

const readText = (relativePath: string) =>
  fs.readFileSync(path.resolve(relativePath), "utf8");

describe("Supabase repair coverage", () => {
  it("documents no-verify-jwt deployment for every app edge function", () => {
    const readme = readText("README.md");

    for (const functionName of [
      "assistant-chat",
      "generate-draft",
      "generate-product-draft",
      "fetch-product-images",
      "provision-pin-user",
      "admin-users",
      "ai-diagnostics",
      "sync-strain-knowledge",
      "dynamic-service",
      "pos-webhook",
    ]) {
      expect(readme).toContain(
        `npx supabase functions deploy ${functionName} --no-verify-jwt`,
      );
    }
  });

  it("disables gateway JWT verification for every local edge function", () => {
    const config = readText("supabase/config.toml");
    const functionsDir = path.resolve("supabase/functions");
    // These functions are intentionally invoked with a service-role bearer
    // (cron / queue dispatchers / transactional email pipeline) and must keep
    // JWT verification enabled at the gateway.
    const JWT_VERIFIED_ALLOWLIST = new Set([
      "process-email-queue",
      "send-transactional-email",
      "dispatch-scheduled-emails",
    ]);
    const functionNames = fs
      .readdirSync(functionsDir, { withFileTypes: true })
      .filter((entry) => entry.isDirectory() && !entry.name.startsWith("_"))
      .map((entry) => entry.name);

    for (const functionName of functionNames) {
      expect(config).toContain(`[functions.${functionName}]`);
      const expectedVerify = JWT_VERIFIED_ALLOWLIST.has(functionName)
        ? "true"
        : "false";
      expect(config).toMatch(
        new RegExp(
          `\\[functions\\.${functionName}\\]\\s+verify_jwt = ${expectedVerify}`,
        ),
      );
    }
  });

  it("ships database objects required by the POS webhook", () => {
    const migrations = fs
      .readdirSync(path.resolve("supabase/migrations"))
      .filter((name) => name.endsWith(".sql"))
      .map((name) => readText(`supabase/migrations/${name}`))
      .join("\n");

    expect(migrations).toContain("CREATE TABLE IF NOT EXISTS public.pos_sales");
    expect(migrations).toContain("CREATE OR REPLACE FUNCTION public.decrement_inventory");
    expect(migrations).toContain("CREATE OR REPLACE FUNCTION public.process_pos_sale");
    expect(migrations).toContain('DROP POLICY IF EXISTS "Development authenticated full access"');
    expect(migrations).toContain(
      "REVOKE EXECUTE ON FUNCTION public.decrement_inventory(UUID, INTEGER) FROM PUBLIC, anon, authenticated",
    );
    expect(migrations).toContain(
      "GRANT EXECUTE ON FUNCTION public.decrement_inventory(UUID, INTEGER) TO service_role",
    );
    expect(migrations).toContain("CREATE OR REPLACE FUNCTION public.prevent_last_admin_role_removal");
    expect(migrations).toContain("CREATE TRIGGER prevent_last_admin_role_delete");
    expect(migrations).toContain("RETURNS INTEGER");
    expect(migrations).toContain("ADD COLUMN IF NOT EXISTS external_pos_id");
    expect(migrations).toContain("ADD COLUMN IF NOT EXISTS last_synced_at");
  });

  it("does not fail admin-created staff users on duplicate default roles", () => {
    const adminUsersFunction = readText("supabase/functions/admin-users/index.ts");

    expect(adminUsersFunction).toContain("onConflict: \"user_id,role\"");
    expect(adminUsersFunction).toContain("Cannot remove the last admin role.");
  });

  it("rejects replay-prone POS sale payloads and checks database writes", () => {
    const posWebhookFunction = readText("supabase/functions/pos-webhook/index.ts");

    expect(posWebhookFunction).toContain("sale.created requires payload.data.id");
    expect(posWebhookFunction).toContain("Duplicate POS sale ignored.");
    expect(posWebhookFunction).toContain("process_pos_sale");
    expect(posWebhookFunction).not.toContain(".from(\"pos_sales\").insert");
    expect(posWebhookFunction).toContain("in_stock: stock > 0");
    expect(posWebhookFunction).toContain("orderRows");
  });
});
