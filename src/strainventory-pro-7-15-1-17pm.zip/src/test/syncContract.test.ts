import { describe, expect, it } from "vitest";
import { buildSyncPlan, shouldUpsertRecord } from "../../supabase/functions/_shared/strainKnowledgeSync";

describe("strain knowledge sync contract", () => {
  it("upserts when no existing record is present", () => {
    const shouldUpsert = shouldUpsertRecord(undefined, {
      stable_key: "blue-dream",
      source_updated_at: "2026-04-10T00:00:00.000Z",
    });

    expect(shouldUpsert).toBe(true);
  });

  it("skips idempotent payloads with same source_updated_at", () => {
    const plan = buildSyncPlan(
      [{ stable_key: "blue-dream", source_updated_at: "2026-04-10T00:00:00.000Z" }],
      [{ stable_key: "blue-dream", source_updated_at: "2026-04-10T00:00:00.000Z" }],
    );

    expect(plan.toUpsert).toHaveLength(0);
    expect(plan.skipped).toBe(1);
  });

  it("prefers newer source_updated_at values", () => {
    const plan = buildSyncPlan(
      [{ stable_key: "blue-dream", source_updated_at: "2026-04-10T00:00:00.000Z" }],
      [{ stable_key: "blue-dream", source_updated_at: "2026-04-11T00:00:00.000Z" }],
    );

    expect(plan.toUpsert).toHaveLength(1);
    expect(plan.toUpsert[0].stable_key).toBe("blue-dream");
    expect(plan.skipped).toBe(0);
  });
});

