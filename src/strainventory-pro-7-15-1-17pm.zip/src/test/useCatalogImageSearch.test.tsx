import { afterEach, describe, expect, it, vi } from "vitest";
import { renderHook, waitFor } from "@testing-library/react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { useCatalogImageSearch } from "@/hooks/useCatalogImageSearch";

const mocks = vi.hoisted(() => ({
  getSession: vi.fn(),
}));

vi.mock("@/integrations/supabase/client", () => ({
  supabase: {
    auth: {
      getSession: mocks.getSession,
    },
  },
}));

function wrapper({ children }: { children: React.ReactNode }) {
  const queryClient = new QueryClient({
    defaultOptions: {
      queries: { retry: false },
      mutations: { retry: false },
    },
  });

  return <QueryClientProvider client={queryClient}>{children}</QueryClientProvider>;
}

describe("useCatalogImageSearch", () => {
  afterEach(() => {
    vi.restoreAllMocks();
    vi.unstubAllGlobals();
  });

  it("turns fetch-level image search failures into a clear POS/catalog error", async () => {
    mocks.getSession.mockResolvedValue({
      data: { session: { access_token: "session-token" } },
    });
    vi.stubGlobal("fetch", vi.fn().mockRejectedValue(new TypeError("Failed to fetch")));

    const { result } = renderHook(() => useCatalogImageSearch(), { wrapper });

    result.current.mutate({
      name: "Blue Dream",
      brand: "Pacific Stone",
      type: "Flower",
    });

    await waitFor(() => expect(result.current.isError).toBe(true));

    expect(result.current.error?.message).toMatch(/image search service could not be reached/i);
    expect(result.current.error?.message).not.toMatch(/^failed to fetch$/i);
  });
});
