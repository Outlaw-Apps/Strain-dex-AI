import { describe, expect, it } from "vitest";
import { computeEffectiveRadius } from "../hooks/useGeofence";

describe("computeEffectiveRadius", () => {
  it("returns the configured radius when accuracy is zero", () => {
    expect(computeEffectiveRadius(250, 0)).toBe(250);
  });

  it("adds the GPS accuracy reading to the configured radius", () => {
    expect(computeEffectiveRadius(250, 100)).toBe(350);
  });

  it("caps the buffer at MAX_ACCURACY_BUFFER_M (400m)", () => {
    expect(computeEffectiveRadius(250, 1000)).toBe(650);
    expect(computeEffectiveRadius(250, 400)).toBe(650);
  });

  it("ignores negative accuracy", () => {
    expect(computeEffectiveRadius(250, -50)).toBe(250);
  });
});
