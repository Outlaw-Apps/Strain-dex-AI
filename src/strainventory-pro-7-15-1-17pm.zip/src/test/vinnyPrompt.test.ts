import { describe, it, expect } from "vitest";
import {
  buildStrainVinnyPrompt,
  type StrainVinnyPromptContext,
} from "@/lib/vinnyPrompt";

const persona = "You are Strain-Vinny";

describe("buildStrainVinnyPrompt", () => {
  it("returns persona + reasoning footer for an empty context", () => {
    const prompt = buildStrainVinnyPrompt({ userQuery: "" });
    expect(prompt).toContain(persona);
    expect(prompt).toContain("Reasoning style:");
    expect(prompt).not.toContain("[WEB CONTEXT]");
    expect(prompt).not.toContain("[CONVERSATION HISTORY]");
    expect(prompt).not.toContain("[PAGE CONTEXT]");
    expect(prompt).not.toContain("[USER PREFERENCES]");
    expect(prompt).not.toContain("[ACTIVE USER QUERY]");
  });

  it("injects [WEB CONTEXT] when webResults are provided", () => {
    const ctx: StrainVinnyPromptContext = {
      userQuery: "What terpenes are in Blue Dream?",
      webResults: [
        {
          title: "Blue Dream Terpene Profile",
          url: "https://example.com/blue-dream",
          snippet: "Dominant terpene: myrcene. Also high in pinene.",
        },
        {
          title: "Strain Lab Report",
          url: "https://lab.example.com/bd",
          snippet: "21% THC, <1% CBD.",
        },
      ],
    };

    const prompt = buildStrainVinnyPrompt(ctx);
    expect(prompt).toContain("[WEB CONTEXT]");
    expect(prompt).toContain("[W1] Blue Dream Terpene Profile");
    expect(prompt).toContain("https://example.com/blue-dream");
    expect(prompt).toContain("[W2] Strain Lab Report");
    expect(prompt).toContain("[ACTIVE USER QUERY]");
    expect(prompt).toContain("What terpenes are in Blue Dream?");
  });

  it("uses expert mode preferences (terse, industry shorthand)", () => {
    const prompt = buildStrainVinnyPrompt({
      userQuery: "COA notes for batch 12?",
      userPreferences: { experienceLevel: "expert", preferredTone: "professional" },
    });
    expect(prompt).toContain("[USER PREFERENCES]");
    expect(prompt).toContain("EXPERT");
    expect(prompt).toContain("industry shorthand");
    expect(prompt).toContain("professional");
    expect(prompt).not.toContain("NOVICE");
  });

  it("uses novice mode preferences (explain terms, friendly tone)", () => {
    const prompt = buildStrainVinnyPrompt({
      userQuery: "What's a terpene?",
      userPreferences: { experienceLevel: "novice", preferredTone: "casual" },
    });
    expect(prompt).toContain("NOVICE");
    expect(prompt).toContain("Briefly explain industry terms");
    expect(prompt).toContain("casual");
    expect(prompt).not.toContain("EXPERT");
  });

  it("respects historyTurnLimit and orders turns oldest → newest", () => {
    const history = Array.from({ length: 10 }, (_, i) => ({
      role: (i % 2 === 0 ? "user" : "assistant") as "user" | "assistant",
      content: `turn-${i}`,
    }));
    const prompt = buildStrainVinnyPrompt({
      userQuery: "next?",
      conversationHistory: history,
      historyTurnLimit: 4,
    });
    expect(prompt).toContain("[CONVERSATION HISTORY]");
    // Last 4 turns kept
    expect(prompt).toContain("turn-6");
    expect(prompt).toContain("turn-7");
    expect(prompt).toContain("turn-8");
    expect(prompt).toContain("turn-9");
    // Earlier turns dropped
    expect(prompt).not.toContain("turn-0");
    expect(prompt).not.toContain("turn-5");
    // Oldest of the kept window appears before newest
    const idxOld = prompt.indexOf("turn-6");
    const idxNew = prompt.indexOf("turn-9");
    expect(idxOld).toBeLessThan(idxNew);
  });

  it("formats page context when provided", () => {
    const prompt = buildStrainVinnyPrompt({
      userQuery: "summarize",
      currentPage: {
        id: "ai_draft",
        title: "AI Draft",
        description: "Generate a product draft",
        route: "/ai-draft",
      },
    });
    expect(prompt).toContain("[PAGE CONTEXT]");
    expect(prompt).toContain("Page: AI Draft");
    expect(prompt).toContain("Context id: ai_draft");
    expect(prompt).toContain("Route: /ai-draft");
    expect(prompt).toContain("Goal: Generate a product draft");
  });

  it("omits empty webResults array entirely (no [WEB CONTEXT] header)", () => {
    const prompt = buildStrainVinnyPrompt({
      userQuery: "hi",
      webResults: [],
    });
    expect(prompt).not.toContain("[WEB CONTEXT]");
  });
});
