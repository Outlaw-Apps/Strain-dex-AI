import type { Database, Json } from "@/integrations/supabase/types";

export type AssistantAudienceRole = "employee" | "vendor" | "management";

export interface AssistantPageContext {
  id: string;
  title: string;
  description: string;
}

export interface AssistantActionEnvelope {
  intent: string;
  summary: string;
  proposed_changes: Json;
  requires_confirmation: boolean;
  execution_payload: Json;
}

export interface AssistantSourceCitation {
  source: string;
  domain: string;
  url: string;
  title: string;
  snippet?: string;
}

export interface AssistantChatRequest {
  thread_id?: string;
  message: string;
  audience_role: AssistantAudienceRole;
  page_context: AssistantPageContext;
  /** Optional profile so Vinny can use the user's name and role. */
  user_profile?: {
    display_name?: string;
    role?: string;
  };
}

export interface AssistantChatResponse {
  thread_id: string;
  message_id?: string;
  reply: string;
  actions: AssistantActionEnvelope[];
  sources?: AssistantSourceCitation[];
  retrieval?: {
    business_hits: number;
    knowledge_hits: number;
    external_fallback_used: boolean;
    external_match_count?: number;
  };
}

export interface AssistantMessage {
  id: string;
  role: "user" | "assistant";
  content: string;
  createdAt: string;
  actions?: AssistantActionEnvelope[];
  sources?: AssistantSourceCitation[];
}

export type AssistantThreadRecord = Database["public"]["Tables"]["assistant_threads"]["Row"];
export type AssistantMessageRecord = Database["public"]["Tables"]["assistant_messages"]["Row"];

