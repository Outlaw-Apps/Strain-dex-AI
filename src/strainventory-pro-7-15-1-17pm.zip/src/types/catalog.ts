export interface ProductImage {
  url: string;
  alt: string;
  primary: boolean;
}

export interface ProductSearchDraft {
  brand: string;
  strain: string;
  productType: string;
  packageSize: string;
  sku: string;
  vendor: string;
  notes: string;
}

