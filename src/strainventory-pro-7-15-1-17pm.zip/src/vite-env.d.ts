/// <reference types="vite/client" />

interface ElectronAPI {
  isElectron: boolean;
  platform?: string;
}

interface Window {
  electronAPI?: ElectronAPI;
  __STRAINVENTORY_DESKTOP_SHELL__?: boolean;
}
