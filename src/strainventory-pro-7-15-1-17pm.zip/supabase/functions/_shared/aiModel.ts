// Single source-of-truth for the DeepSeek model identifier used across
// edge functions and the AI test harness. Update here to roll out a new
// model everywhere at once.
export const DEFAULT_DEEPSEEK_MODEL = "deepseek-v4-pro";
