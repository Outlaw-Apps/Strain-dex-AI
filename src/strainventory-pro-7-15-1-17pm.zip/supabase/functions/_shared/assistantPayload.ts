export type AssistantAudienceRole = "employee" | "vendor" | "management";

export interface AssistantActionEnvelope {
  intent: string;
  summary: string;
  proposed_changes: string[];
  requires_confirmation: boolean;
  execution_payload: Record<string, unknown>;
}

export interface AssistantSourceCitation {
  source: string;
  domain: string;
  url: string;
  title: string;
  snippet?: string;
}

export interface AssistantResponsePayload {
  reply: string;
  actions: AssistantActionEnvelope[];
  sources: AssistantSourceCitation[];
}

const DEFAULT_REPLY =
  "I can help with this workflow. I have a recommendation ready once you confirm.";

function stripMarkdownFence(value: string): string {
  const trimmed = value.trim();
  const match = trimmed.match(/^```(?:json)?\s*([\s\S]*?)\s*```$/i);
  return match ? match[1].trim() : trimmed;
}

function parseLooseJson(value: string): Record<string, unknown> {
  const cleaned = stripMarkdownFence(value);
  try {
    return JSON.parse(cleaned) as Record<string, unknown>;
  } catch {
    const start = cleaned.indexOf("{");
    const end = cleaned.lastIndexOf("}");
    if (start >= 0 && end > start) {
      return JSON.parse(cleaned.slice(start, end + 1)) as Record<string, unknown>;
    }
    throw new Error("Assistant output was not valid JSON");
  }
}

function toStringArray(value: unknown): string[] {
  if (!Array.isArray(value)) return [];
  return value.map((item) => String(item)).filter(Boolean);
}

function toObject(value: unknown): Record<string, unknown> {
  return value && typeof value === "object" && !Array.isArray(value)
    ? (value as Record<string, unknown>)
    : {};
}

function sanitizeSourceCitation(value: unknown): AssistantSourceCitation | null {
  if (!value || typeof value !== "object" || Array.isArray(value)) return null;
  const obj = value as Record<string, unknown>;
  const source = typeof obj.source === "string" ? obj.source.trim() : "";
  const domain = typeof obj.domain === "string" ? obj.domain.trim() : "";
  const url = typeof obj.url === "string" ? obj.url.trim() : "";
  if (url && !/^https?:\/\//i.test(url)) return null;
  const title = typeof obj.title === "string" ? obj.title.trim() : "";
  const snippet = typeof obj.snippet === "string" ? obj.snippet.trim() : "";
  if (!source || !domain || !url || !title) return null;
  return { source, domain, url, title, ...(snippet ? { snippet } : {}) };
}

export function sanitizeActionEnvelope(value: unknown): AssistantActionEnvelope | null {
  if (!value || typeof value !== "object" || Array.isArray(value)) return null;
  const obj = value as Record<string, unknown>;
  const intent = typeof obj.intent === "string" ? obj.intent.trim() : "";
  const summary = typeof obj.summary === "string" ? obj.summary.trim() : "";

  if (!intent || !summary) return null;

  return {
    intent,
    summary,
    proposed_changes: toStringArray(obj.proposed_changes),
    requires_confirmation: true,
    execution_payload: normalizeExecutionPayload(intent, toObject(obj.execution_payload)),
  };
}

function normalizeExecutionPayload(
  intent: string,
  payload: Record<string, unknown>,
): Record<string, unknown> {
  const next = { ...payload };
  const lowerIntent = intent.toLowerCase();
  const rawRoute = typeof next.route === "string" ? next.route.trim().toLowerCase() : "";

  if (rawRoute === "/authorize" || rawRoute === "/authorization" || rawRoute === "/consent") {
    next.route = "/settings";
  } else if (rawRoute === "/approve" || rawRoute === "/approval" || rawRoute === "/approvals") {
    next.route = "/review";
  } else if (rawRoute === "/product" || rawRoute === "/products" || rawRoute === "/inventory" || rawRoute === "/vault") {
    next.route = "/catalog";
  } else if (rawRoute === "/sales" || rawRoute === "/sales-report" || rawRoute === "/reports" || rawRoute === "/performance") {
    next.route = "/shift-close";
  } else if (!rawRoute && (lowerIntent.includes("authorize") || lowerIntent.includes("consent"))) {
    next.route = "/settings";
  } else if (!rawRoute && lowerIntent.includes("approve")) {
    next.route = "/review";
  }

  return next;
}

export function parseAssistantResponse(content: string): AssistantResponsePayload {
  const parsed = parseLooseJson(content);
  const reply = typeof parsed.reply === "string" && parsed.reply.trim()
    ? parsed.reply.trim()
    : DEFAULT_REPLY;
  const rawActions = Array.isArray(parsed.actions) ? parsed.actions : [];
  const actions = rawActions
    .map((action) => sanitizeActionEnvelope(action))
    .filter((action): action is AssistantActionEnvelope => !!action);
  const rawSources = Array.isArray(parsed.sources) ? parsed.sources : [];
  const sources = rawSources
    .map((source) => sanitizeSourceCitation(source))
    .filter((source): source is AssistantSourceCitation => !!source);

  return {
    reply,
    actions,
    sources,
  };
}

export function buildAssistantOutputInstructions(): string {
  return [
    "Your first priority is to understand the user's goal and propose THE SINGLE MOST LIKELY NEXT STEP.",
    "If the goal requires multiple steps (e.g. intake -> draft -> review), lay out the journey as a simple numbered list, then start executing step 1 right away.",
    "In the `reply` field, always include the full multi-step plan as a numbered list when the user is starting a new workflow. The first action will correspond to step 1. After the user confirms an action, you don't need to repeat the whole plan - just move to the next step.",
    "Only ask clarifying questions when the user’s goal is genuinely ambiguous. Otherwise, assume the most common intent.",
    "For every action you recommend, explain WHY it’s the right move in one sentence, then present the button.",
    "Before providing the plan in your reply, always include one short sentence explaining your thinking (e.g., 'Since you mentioned a pre-roll, I pre-filled the product type.'). This builds trust.",
    "Respond with strict JSON only (no markdown).",
    "You are powered by DeepSeek-V4-Pro. Use deep reasoning to understand the user's goal, choose the most direct path, and craft replies that feel personal and helpful.",
    "You may reason extensively internally, but your final message must be the JSON object exactly - no extra commentary, no thinking tags, no markdown.",
    "Use this exact shape:",
    "{",
    '  "reply": "string",',
    '  "actions": [',
    "    {",
    '      "intent": "string_snake_case",',
    '      "summary": "short action summary",',
    '      "proposed_changes": ["bullet 1", "bullet 2"],',
    '      "requires_confirmation": true,',
    '      "execution_payload": { "route": "/optional-route", "url": "https://optional-link", "file": { "filename": "optional.txt", "mime_type": "text/plain", "content": "optional file text" }, "intake_patch": { "...": "..." } }',
    "    }",
    "  ],",
    '  "sources": [',
    "    {",
    '      "source": "Leafly",',
    '      "domain": "leafly.com",',
    '      "url": "https://...",',
    '      "title": "Blue Dream Strain",',
    '      "snippet": "optional evidence excerpt"',
    "    }",
    "  ]",
    "}",
    "Never execute actions. Only recommend actions that require user confirmation.",
    "Only use valid internal routes: /, /product-intake, /ai-draft, /image-finder, /catalog, /catalog/:id, /bulk-intake, /review, /assistant, /messages, /pos, /shift-close, /settings, /onboarding, /payroll, /payroll/run.",
    "For intake actions, prefer one action with intent update_intake. Include execution_payload.intake_patch with brand and strain when available, and set execution_payload.autofill to true so the client can run AI web-grounded autofill.",
    "When the user provides only brand+name or only strain, still propose update_intake with the available values and autofill enabled.",
    "Use /settings for authorize/authorization/consent actions and /review for approve/approval actions.",
    "Use execution_payload.url for external links and execution_payload.file for text/CSV/JSON/Markdown files.",
    "When no external web sources were needed, return an empty sources array.",
  ].join("\n");
}

export function buildPersonaPrompt(role: AssistantAudienceRole): string {
  if (role === "vendor") {
    return [
      "You are Refined Strain Vinny, a premium cannabis operations assistant.",
      "Tone for vendor-facing communication: courteous, concise, and collaborative.",
      "Prioritize clean data requests, compliance-safe phrasing, and clear follow-ups.",
    ].join("\n");
  }

  if (role === "management") {
    return [
      "You are Refined Strain Vinny, a premium cannabis operations assistant.",
      "Tone for management: executive-level clarity, concise tradeoffs, and compliance awareness.",
      "Prioritize operational impact, quality control, and decision support.",
    ].join("\n");
  }

  return [
    "You are Refined Strain Vinny, a premium cannabis operations assistant.",
    "Tone for employees: supportive, calm, practical, and confidence-building.",
    "Prioritize actionable step-by-step help and friendly guidance.",
  ].join("\n");
}
