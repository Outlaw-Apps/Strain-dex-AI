import { createClient, type SupabaseClient } from "https://esm.sh/@supabase/supabase-js@2.57.4";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

export interface AuthenticatedUser {
  id: string;
  email?: string;
}

export interface AuthSuccess {
  user: AuthenticatedUser;
  token: string;
  admin: ReturnType<typeof createClient>;
}

/**
 * Verifies the incoming request carries a valid, non-anonymous Supabase user
 * session and returns the resolved user. Returns a 401 Response if the caller
 * is unauthenticated, has only supplied the public anon key, or carries an
 * invalid/expired token.
 *
 * This is the replacement for the gateway-level `verify_jwt` check: the
 * gateway only supports HS256 legacy tokens, but the Supabase Auth service
 * now issues ES256 asymmetric tokens. Calling `auth.getUser(token)` works
 * against either algorithm, so each function performs its own verification.
 */
export async function requireAuthenticatedUser(req: Request): Promise<AuthSuccess | Response> {
  const supabaseUrl = Deno.env.get("SUPABASE_URL");
  const serviceRole = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
  const anonKey = Deno.env.get("SUPABASE_ANON_KEY") ?? "";

  if (!supabaseUrl || !serviceRole) {
    return respond({ error: "Auth not configured on the edge function." }, 500);
  }

  const authHeader = req.headers.get("Authorization");
  if (!authHeader) {
    return respond({ error: "Sign in required." }, 401);
  }

  const token = authHeader.replace(/^Bearer\s+/i, "").trim();
  if (!token) {
    return respond({ error: "Sign in required." }, 401);
  }

  // Reject requests that are only carrying the public anon key — those are
  // effectively unauthenticated and should not be allowed to trigger paid
  // AI completions or image searches.
  if (anonKey && token === anonKey) {
    return respond({ error: "Sign in required." }, 401);
  }

  const admin = createClient(supabaseUrl, serviceRole, { auth: { persistSession: false } });
  const { data, error } = await admin.auth.getUser(token);
  if (error || !data?.user) {
    return respond({ error: "Invalid or expired session. Please sign in again." }, 401);
  }

  return {
    user: { id: data.user.id, email: data.user.email ?? undefined },
    token,
    admin,
  };
}

function respond(body: Record<string, unknown>, status: number) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}
