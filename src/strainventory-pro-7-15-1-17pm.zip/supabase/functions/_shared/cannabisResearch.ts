import type { DraftRequest } from "./draftPayload.ts";

export interface TrustedResearchSource {
  name: string;
  domains: readonly string[];
  keywords: readonly string[];
}

export interface ResearchMatch {
  source: string;
  domain: string;
  url: string;
  title: string;
  snippet: string;
}

export interface DraftResearchContext {
  matches: ResearchMatch[];
  promptText: string;
  warnings: string[];
}

const DUCKDUCKGO_HTML_ORIGIN = "https://html.duckduckgo.com/html/";
const MAX_SOURCE_MATCHES = 5;
const MAX_TEXT_BLOCKS = 36;
const MAX_SNIPPET_LENGTH = 900;

const USER_AGENTS = [
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
  "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
  "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:125.0) Gecko/20100101 Firefox/125.0",
] as const;

const RESEARCH_HINT_TERMS = [
  "thc",
  "cbd",
  "terpene",
  "terpenes",
  "myrcene",
  "limonene",
  "caryophyllene",
  "pinene",
  "linalool",
  "humulene",
  "ocimene",
  "terpinolene",
  "aroma",
  "flavor",
  "flavour",
  "taste",
  "effects",
  "effect",
  "relief",
  "strain",
  "dominant",
  "product",
  "cannabis",
  "indica",
  "sativa",
  "hybrid",
  "potency",
  "percentage",
  "earthy",
  "citrus",
  "pine",
  "diesel",
  "sweet",
  "fruity",
  "pungent",
  "floral",
] as const;

export const TRUSTED_CANNABIS_RESEARCH_SOURCES: readonly TrustedResearchSource[] = [
  {
    name: "AllBud",
    domains: ["allbud.com"],
    keywords: ["strain", "review"],
  },
  {
    name: "Leafly",
    domains: ["leafly.com"],
    keywords: ["brands", "products"],
  },
  {
    name: "Haven",
    domains: ["content.myhavenstores.com", "shopphaven.com"],
    keywords: ["menu", "product"],
  },
  {
    name: "Chronic Guru",
    domains: ["chronicguru.com"],
    keywords: ["strain", "product"],
  },
  {
    name: "Corona Culture",
    domains: ["coronaculture.com", "culturecannabisclub.com"],
    keywords: ["menu", "product"],
  },
] as const;

export type AiSearchDomainMode = "allow" | "block";

export interface AiSearchDomainEntry {
  domain: string;
  mode: AiSearchDomainMode;
  enabled?: boolean | null;
  label?: string | null;
}

export interface ParsedDomainEntry {
  raw: string;
  host: string;
  /** "" when no path scope (host-wide); otherwise begins with "/". */
  pathPrefix: string;
  mode: AiSearchDomainMode;
}

export interface ResolvedSearchPolicy {
  /** Parsed allow entries (path component is informational only). */
  allow: ParsedDomainEntry[];
  /** Parsed block entries; path scope is honored when present. */
  block: ParsedDomainEntry[];
  /** Sources to query (one TrustedResearchSource per allowed host, or the fallback when allow is empty). */
  sources: TrustedResearchSource[];
}

export const parseDomainEntry = (
  raw: string,
  mode: AiSearchDomainMode,
): ParsedDomainEntry | null => {
  const cleaned = raw
    .trim()
    .toLowerCase()
    .replace(/^https?:\/\//, "")
    .replace(/^www\./, "");
  if (!cleaned) return null;

  const slashIdx = cleaned.indexOf("/");
  if (slashIdx === -1) {
    return { raw: cleaned, host: cleaned, pathPrefix: "", mode };
  }

  const host = cleaned.slice(0, slashIdx);
  const pathPrefix = cleaned.slice(slashIdx); // includes leading "/"
  if (!host) return null;
  return { raw: cleaned, host, pathPrefix, mode };
};

export const resolveSearchSources = (
  rows: AiSearchDomainEntry[],
  fallback: readonly TrustedResearchSource[] = TRUSTED_CANNABIS_RESEARCH_SOURCES,
): ResolvedSearchPolicy => {
  const enabled = rows.filter((row) => row.enabled !== false);
  const parsed: ParsedDomainEntry[] = [];
  for (const row of enabled) {
    const entry = parseDomainEntry(row.domain, row.mode);
    if (entry) parsed.push(entry);
  }

  const allow = parsed.filter((entry) => entry.mode === "allow");
  const block = parsed.filter((entry) => entry.mode === "block");

  let sources: TrustedResearchSource[];
  if (allow.length === 0) {
    sources = fallback.map((source) => ({ ...source, domains: [...source.domains], keywords: [...source.keywords] }));
  } else {
    const byHost = new Map<string, TrustedResearchSource>();
    for (const entry of allow) {
      // For allow entries the path is ignored — the allowlist gates which sites
      // the AI may visit, not which pages it must visit.
      if (!byHost.has(entry.host)) {
        byHost.set(entry.host, {
          name: entry.host,
          domains: [entry.host],
          keywords: ["product", "menu"],
        });
      }
    }
    sources = Array.from(byHost.values());
  }

  return { allow, block, sources };
};

export const isUrlBlockedByEntries = (
  url: string,
  blocks: ParsedDomainEntry[],
): boolean => {
  let parsed: URL;
  try {
    parsed = new URL(url);
  } catch {
    return false;
  }
  const host = parsed.hostname.replace(/^www\./, "").toLowerCase();
  const path = parsed.pathname || "/";

  return blocks.some((entry) => {
    const hostMatches = host === entry.host || host.endsWith(`.${entry.host}`);
    if (!hostMatches) return false;
    if (!entry.pathPrefix) return true;

    // Match if the URL path equals the prefix or extends it at a path
    // boundary. So /menu/foo matches /menu but /menus does not.
    if (path === entry.pathPrefix) return true;
    const boundary = entry.pathPrefix.endsWith("/")
      ? entry.pathPrefix
      : `${entry.pathPrefix}/`;
    return path.startsWith(boundary);
  });
};

export const filterCandidateUrls = (
  urls: string[],
  policy: ResolvedSearchPolicy,
): string[] => {
  const allowHosts = policy.allow.map((entry) => entry.host);
  return urls.filter((url) => {
    if (allowHosts.length > 0 && !isTrustedSourceUrl(url, allowHosts)) {
      return false;
    }
    return !isUrlBlockedByEntries(url, policy.block);
  });
};

interface PolicyClient {
  from(table: string): {
    select(columns: string): {
      eq(column: string, value: unknown): Promise<{
        data: AiSearchDomainEntry[] | null;
        error: { message: string } | null;
      }>;
    };
  };
}

interface PolicyCache {
  policy: ResolvedSearchPolicy;
  expiresAt: number;
}

// Settings edits must affect the next AI request. Keep the cache hook in place
// for tests/future tuning, but default to an immediate refresh.
const POLICY_CACHE_TTL_MS = 0;
let cachedPolicy: PolicyCache | null = null;

export const __resetResearchPolicyCacheForTest = () => {
  cachedPolicy = null;
};

export const loadResearchPolicy = async (
  client: PolicyClient,
  now: () => number = Date.now,
): Promise<ResolvedSearchPolicy> => {
  const currentTime = now();
  if (cachedPolicy && cachedPolicy.expiresAt > currentTime) {
    return cachedPolicy.policy;
  }

  try {
    const { data, error } = await client
      .from("ai_search_domains")
      .select("domain, mode, enabled, label")
      .eq("enabled", true);
    if (error) {
      throw new Error(error.message);
    }
    const policy = resolveSearchSources(data ?? []);
    cachedPolicy = { policy, expiresAt: currentTime + POLICY_CACHE_TTL_MS };
    return policy;
  } catch (error) {
    console.warn(
      "[cannabisResearch] Failed to load ai_search_domains; using built-in defaults.",
      error instanceof Error ? error.message : error,
    );
    return resolveSearchSources([]);
  }
};

const normalize = (value?: string) => value?.trim() ?? "";

const normalizeLower = (value?: string) => normalize(value).toLowerCase();

const collapseWhitespace = (value: string) => value.replace(/\s+/g, " ").trim();

const truncate = (value: string, maxLength: number) => {
  const text = collapseWhitespace(value);
  if (text.length <= maxLength) {
    return text;
  }

  const truncated = text.slice(0, maxLength).trim();
  const punctuationIndex = Math.max(
    truncated.lastIndexOf(". "),
    truncated.lastIndexOf("! "),
    truncated.lastIndexOf("? "),
    truncated.lastIndexOf("; "),
  );

  return punctuationIndex > 120
    ? truncated.slice(0, punctuationIndex + 1).trim()
    : `${truncated}...`;
};

const splitTerms = (value?: string) =>
  normalizeLower(value)
    .split(/[^a-z0-9]+/g)
    .filter((term) => term.length >= 2);

const unique = (values: string[]) => Array.from(new Set(values.map(collapseWhitespace).filter(Boolean)));

const pickUserAgent = () => USER_AGENTS[Math.floor(Math.random() * USER_AGENTS.length)];

const getRequestKeywords = (request: DraftRequest) =>
  unique([
    ...splitTerms(request.brand),
    ...splitTerms(request.strain),
    ...splitTerms(request.productType),
    ...splitTerms(request.packageSize),
    ...splitTerms(request.vendor),
  ]);

const typeHint = (value?: string) => {
  const productType = normalize(value);
  if (!productType) {
    return "cannabis product";
  }
  if (/vape/i.test(productType)) {
    return "vape cartridge";
  }
  if (/pre[- ]?roll/i.test(productType)) {
    return "pre-roll";
  }
  if (/edible/i.test(productType)) {
    return "edible";
  }
  return productType;
};

const getSourceSearchTerms = (source: TrustedResearchSource, request: DraftRequest) => {
  const brand = normalize(request.brand);
  const strain = normalize(request.strain);
  const packageSize = normalize(request.packageSize);
  const productType = typeHint(request.productType);
  const vendor = normalize(request.vendor);

  return unique([
    [brand, strain, productType, packageSize].filter(Boolean).join(" "),
    [brand, strain, source.keywords[0] ?? "cannabis"].filter(Boolean).join(" "),
    [strain, productType, source.keywords[1] ?? source.keywords[0] ?? "cannabis"].filter(Boolean).join(" "),
    [vendor, brand, strain, productType].filter(Boolean).join(" "),
  ]);
};

export const buildTrustedSourceQueries = (
  source: TrustedResearchSource,
  request: DraftRequest,
) => {
  const searchTerms = getSourceSearchTerms(source, request);
  const queries: string[] = [];

  for (const domain of source.domains) {
    for (const term of searchTerms) {
      queries.push(`${term} site:${domain}`);
    }
  }

  return unique(queries).slice(0, 6);
};

const getUrlHost = (value: string) => {
  try {
    return new URL(value).hostname.replace(/^www\./, "").toLowerCase();
  } catch {
    return "";
  }
};

export const isTrustedSourceUrl = (value: string, domains: readonly string[]) => {
  const host = getUrlHost(value);
  if (!host) {
    return false;
  }

  return domains.some((domain) => host === domain || host.endsWith(`.${domain}`));
};

export const decodeDuckDuckGoHref = (href: string | null) => {
  if (!href) {
    return null;
  }

  try {
    const absoluteUrl = new URL(href, DUCKDUCKGO_HTML_ORIGIN);
    const redirected = absoluteUrl.searchParams.get("uddg");
    if (redirected) {
      return decodeURIComponent(redirected);
    }

    if (absoluteUrl.protocol === "http:" || absoluteUrl.protocol === "https:") {
      return absoluteUrl.toString();
    }
  } catch {
    return null;
  }

  return null;
};

const parseHtmlDocument = (html: string) => {
  try {
    return new DOMParser().parseFromString(html, "text/html");
  } catch {
    return null;
  }
};

export const extractDuckDuckGoResultUrls = (html: string) => {
  const urls = new Set<string>();
  const document = parseHtmlDocument(html);

  if (document) {
    for (const link of Array.from(document.querySelectorAll("a.result__a, a[data-testid='result-title-a']"))) {
      const decoded = decodeDuckDuckGoHref(link.getAttribute("href"));
      if (decoded) {
        urls.add(decoded);
      }
    }
  }

  if (urls.size === 0) {
    const matches = html.matchAll(/<a[^>]+href="([^"]+)"[^>]+class="[^"]*(?:result__a|result-link)[^"]*"/gi);
    for (const match of matches) {
      const decoded = decodeDuckDuckGoHref(match[1]);
      if (decoded) {
        urls.add(decoded);
      }
    }
  }

  return Array.from(urls);
};

const extractPageBlocks = (document: Document) => {
  const textBlocks: string[] = [];
  const metaDescription =
    document.querySelector('meta[name="description"]')?.getAttribute("content") ??
    document.querySelector('meta[property="og:description"]')?.getAttribute("content") ??
    "";

  const heading =
    document.querySelector("h1")?.textContent ??
    document.querySelector("title")?.textContent ??
    "";

  for (const seed of [metaDescription, heading]) {
    const cleaned = collapseWhitespace(seed);
    if (cleaned) {
      textBlocks.push(cleaned);
    }
  }

  for (const node of Array.from(document.querySelectorAll("article p, main p, section p, p, li")).slice(0, MAX_TEXT_BLOCKS)) {
    const cleaned = collapseWhitespace(node.textContent ?? "");
    if (cleaned.length >= 45) {
      textBlocks.push(cleaned);
    }
  }

  return unique(textBlocks);
};

const scorePageBlock = (text: string, requestKeywords: string[]) => {
  const haystack = normalizeLower(text);
  let score = Math.min(text.length / 120, 6);

  for (const keyword of requestKeywords) {
    if (haystack.includes(keyword)) {
      score += 6;
    }
  }

  for (const hint of RESEARCH_HINT_TERMS) {
    if (haystack.includes(hint)) {
      score += 2;
    }
  }

  // Heavily prioritize blocks with THC/CBD percentages
  if (/\b(thc|cbd)\b.*\d{1,2}(?:\.\d+)?\s*%/i.test(text)) {
    score += 15;
  }

  // Prioritize blocks with any percentage (likely potency data)
  if (/\b\d{1,2}(?:\.\d+)?\s*%/.test(text)) {
    score += 3;
  }

  // Prioritize blocks mentioning specific terpenes
  const terpeneNames = ["myrcene", "limonene", "caryophyllene", "pinene", "linalool", "humulene", "ocimene", "terpinolene"];
  for (const terpene of terpeneNames) {
    if (haystack.includes(terpene)) {
      score += 8;
    }
  }

  // Prioritize blocks with aroma/flavor descriptors
  if (/\b(aroma|flavor|flavour|taste|scent|smell)\b/i.test(text)) {
    score += 5;
  }

  return score;
};

export const extractResearchSnippetFromHtml = (html: string, request: DraftRequest) => {
  const document = parseHtmlDocument(html);
  if (!document) {
    return { title: "", snippet: "" };
  }

  const requestKeywords = getRequestKeywords(request);
  const title = collapseWhitespace(
    document.querySelector("title")?.textContent ??
    document.querySelector("h1")?.textContent ??
    "",
  );

  const scoredBlocks = extractPageBlocks(document)
    .map((block) => ({ block, score: scorePageBlock(block, requestKeywords) }))
    .sort((left, right) => right.score - left.score)
    .slice(0, 5)
    .map(({ block }) => block);

  return {
    title,
    snippet: truncate(scoredBlocks.join(" "), MAX_SNIPPET_LENGTH),
  };
};

const getDefaultHeaders = () => ({
  "Accept-Language": "en-US,en;q=0.9",
  "User-Agent": pickUserAgent(),
});

const fetchHtml = async (fetchImpl: typeof fetch, url: string) => {
  const response = await fetchImpl(url, {
    headers: getDefaultHeaders(),
  });

  if (!response.ok) {
    throw new Error(`Request failed with status ${response.status}`);
  }

  const contentType = response.headers.get("content-type") ?? "";
  if (contentType && !/text\/html|application\/xhtml\+xml/i.test(contentType)) {
    throw new Error(`Unsupported content type: ${contentType}`);
  }

  return response.text();
};

const findSourceMatch = async (
  source: TrustedResearchSource,
  request: DraftRequest,
  fetchImpl: typeof fetch,
  blocks: ParsedDomainEntry[],
): Promise<ResearchMatch | null> => {
  const queries = buildTrustedSourceQueries(source, request);

  for (const query of queries) {
    let searchHtml = "";
    try {
      const searchUrl = `${DUCKDUCKGO_HTML_ORIGIN}?q=${encodeURIComponent(query)}&kl=us-en`;
      searchHtml = await fetchHtml(fetchImpl, searchUrl);
    } catch {
      continue;
    }

    const candidateUrls = extractDuckDuckGoResultUrls(searchHtml)
      .filter((url) => isTrustedSourceUrl(url, source.domains))
      .filter((url) => !isUrlBlockedByEntries(url, blocks))
      .slice(0, 2);

    for (const url of candidateUrls) {
      try {
        const pageHtml = await fetchHtml(fetchImpl, url);
        const extracted = extractResearchSnippetFromHtml(pageHtml, request);
        if (!extracted.snippet) {
          continue;
        }

        return {
          source: source.name,
          domain: getUrlHost(url),
          url,
          title: extracted.title,
          snippet: extracted.snippet,
        };
      } catch {
        continue;
      }
    }
  }

  return null;
};

export const formatResearchContext = (matches: ResearchMatch[]) =>
  matches.length === 0
    ? ""
    : [
        "Below are details retrieved in real time from trusted cannabis databases. Use them to enrich the product draft.",
        ...matches.map(
          (match, index) =>
            `${index + 1}. Source: ${match.source}\nURL: ${match.url}\nTitle: ${match.title || "Untitled"}\nExcerpt: ${match.snippet}`,
        ),
      ].join("\n\n");

export interface GatherDraftResearchOptions {
  fetchImpl?: typeof fetch;
  /** Pre-resolved policy. If omitted, falls back to built-in trusted sources with no blocks. */
  policy?: ResolvedSearchPolicy;
}

export const gatherDraftResearch = async (
  request: DraftRequest,
  optionsOrFetch: GatherDraftResearchOptions | typeof fetch = {},
): Promise<DraftResearchContext> => {
  // Backward compat: prior signature was gatherDraftResearch(request, fetchImpl).
  const options: GatherDraftResearchOptions =
    typeof optionsOrFetch === "function" ? { fetchImpl: optionsOrFetch } : optionsOrFetch;
  const fetchImpl = options.fetchImpl ?? fetch;
  const policy = options.policy ?? resolveSearchSources([]);

  const matches: ResearchMatch[] = [];
  const warnings: string[] = [];

  for (const source of policy.sources) {
    try {
      const match = await findSourceMatch(source, request, fetchImpl, policy.block);
      if (match) {
        matches.push(match);
      }
    } catch (error) {
      const message = error instanceof Error ? error.message : "Unknown search failure";
      warnings.push(`${source.name}: ${message}`);
    }

    if (matches.length >= MAX_SOURCE_MATCHES) {
      break;
    }
  }

  return {
    matches,
    promptText: formatResearchContext(matches),
    warnings,
  };
};
