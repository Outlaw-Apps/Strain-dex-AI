export interface DraftRequest {
  brand?: string;
  strain?: string;
  productType?: string;
  packageSize?: string;
  sku?: string;
  vendor?: string;
  notes?: string;
}

export type DraftIcon =
  | "FileText"
  | "FlaskConical"
  | "Droplets"
  | "Wind"
  | "Leaf"
  | "Sparkles"
  | "Heart";

export type DraftConfidence = "verified" | "matched" | "inferred" | "review";

export interface DraftField {
  label: string;
  value: string;
}

export interface DraftSection {
  title: string;
  icon: DraftIcon;
  confidence: DraftConfidence;
  fields: DraftField[];
}

export interface GeneratedDraft {
  overallConfidence: number;
  sections: DraftSection[];
  descriptionShort: string;
  descriptionLong: string;
  sources?: DraftSourceCitation[];
}

export interface DraftSourceCitation {
  source: string;
  domain: string;
  url: string;
  title: string;
  snippet?: string;
}

interface SectionTemplate {
  key: string;
  title: string;
  icon: DraftIcon;
  defaultConfidence: DraftConfidence;
  fieldLabels: string[];
  keywords: string[];
  aliases: Record<string, string>;
}

const uncertainMarkers = [
  "unknown",
  "not provided",
  "n/a",
  "coa",
  "requires verification",
  "needs verification",
  "unverified",
  "anecdotal",
  "may help",
  "might",
  "could",
  "likely",
  "possibly",
  "consult",
];

const slugify = (value: string) =>
  value
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, " ")
    .trim();

const appendPeriod = (value: string) => {
  const trimmed = value.trim();
  if (!trimmed) return "";
  return /[.!?]$/.test(trimmed) ? trimmed : `${trimmed}.`;
};

const coerceString = (value: unknown) => (typeof value === "string" ? value.trim() : "");

const isRecord = (value: unknown): value is Record<string, unknown> =>
  typeof value === "object" && value !== null && !Array.isArray(value);

const sanitizeValue = (value: string) => {
  const trimmed = value.trim();
  if (!trimmed) return "";
  const normalized = trimmed.toLowerCase();
  return uncertainMarkers.some((marker) => new RegExp(`\\b${marker.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}\\b`, "i").test(normalized)) ? "" : trimmed;
};

const normalizeConfidence = (value: unknown, fallback: DraftConfidence): DraftConfidence => {
  if (value === "verified" || value === "matched" || value === "inferred" || value === "review") {
    return value;
  }
  return fallback;
};

const normalizeIcon = (value: unknown, fallback: DraftIcon): DraftIcon => {
  switch (value) {
    case "FileText":
    case "FlaskConical":
    case "Droplets":
    case "Wind":
    case "Leaf":
    case "Sparkles":
    case "Heart":
      return value;
    default:
      return fallback;
  }
};

const clampConfidenceScore = (value: unknown, fallback: number) => {
  const numericValue = typeof value === "number" ? value : Number(value);
  return Number.isFinite(numericValue)
    ? Math.max(0, Math.min(100, Math.round(numericValue)))
    : fallback;
};

export const draftSectionTemplates: readonly SectionTemplate[] = [
  {
    key: "vendor",
    title: "Vendor Information",
    icon: "FileText",
    defaultConfidence: "verified",
    fieldLabels: ["Brand Name", "Strain Name", "Product Title", "Category", "Package", "SKU", "Vendor"],
    keywords: ["vendor", "brand", "product"],
    aliases: {
      brand: "Brand Name",
      "brand name": "Brand Name",
      strain: "Strain Name",
      "strain name": "Strain Name",
      "product title": "Product Title",
      "product name": "Product Title",
      name: "Product Title",
      category: "Category",
      type: "Category",
      "product type": "Category",
      package: "Package",
      "package size": "Package",
      size: "Package",
      sku: "SKU",
      vendor: "Vendor",
    },
  },
  {
    key: "cannabinoid",
    title: "Cannabinoid Profile",
    icon: "FlaskConical",
    defaultConfidence: "review",
    fieldLabels: ["THC", "CBD"],
    keywords: ["cannabinoid", "thc", "cbd"],
    aliases: {
      thc: "THC",
      cbd: "CBD",
    },
  },
  {
    key: "terpene",
    title: "Terpene Profile",
    icon: "Droplets",
    defaultConfidence: "review",
    fieldLabels: ["Dominant Terpenes", "Supporting Terpenes"],
    keywords: ["terpene"],
    aliases: {
      "dominant terpenes": "Dominant Terpenes",
      dominant: "Dominant Terpenes",
      terpenes: "Dominant Terpenes",
      "supporting terpenes": "Supporting Terpenes",
      secondary: "Supporting Terpenes",
      "secondary terpenes": "Supporting Terpenes",
      complementary: "Supporting Terpenes",
    },
  },
  {
    key: "aroma",
    title: "Aroma Profile",
    icon: "Wind",
    defaultConfidence: "review",
    fieldLabels: ["Aroma Profile", "Aroma Notes"],
    keywords: ["aroma", "nose"],
    aliases: {
      aroma: "Aroma Profile",
      "aroma profile": "Aroma Profile",
      "aroma notes": "Aroma Notes",
      notes: "Aroma Notes",
      primary: "Aroma Profile",
    },
  },
  {
    key: "taste",
    title: "Taste Profile",
    icon: "Leaf",
    defaultConfidence: "review",
    fieldLabels: ["Taste Profile", "Finish"],
    keywords: ["taste", "flavor"],
    aliases: {
      taste: "Taste Profile",
      "taste profile": "Taste Profile",
      flavor: "Taste Profile",
      "flavor profile": "Taste Profile",
      inhale: "Taste Profile",
      finish: "Finish",
      exhale: "Finish",
      aftertaste: "Finish",
    },
  },
  {
    key: "effects",
    title: "Effects Profile",
    icon: "Sparkles",
    defaultConfidence: "review",
    fieldLabels: ["Effects", "Onset"],
    keywords: ["effect", "experience"],
    aliases: {
      effects: "Effects",
      effect: "Effects",
      onset: "Onset",
      feel: "Effects",
    },
  },
  {
    key: "medical",
    title: "Medical Uses",
    icon: "Heart",
    defaultConfidence: "review",
    fieldLabels: ["Medical Uses", "May Help With"],
    keywords: ["medical", "relief", "wellness"],
    aliases: {
      medical: "Medical Uses",
      "medical uses": "Medical Uses",
      "may help with": "May Help With",
      "potential support": "May Help With",
    },
  },
] as const;

const getTemplateForTitle = (title: string) => {
  const normalized = slugify(title);
  return draftSectionTemplates.find((template) =>
    normalized === slugify(template.title) ||
    template.keywords.some((keyword) => normalized.includes(keyword)),
  );
};

const getFieldLabelForTemplate = (template: SectionTemplate, label: string) => {
  const normalized = slugify(label);
  if (!normalized) return null;

  for (const fieldLabel of template.fieldLabels) {
    if (slugify(fieldLabel) === normalized) {
      return fieldLabel;
    }
  }

  for (const [alias, fieldLabel] of Object.entries(template.aliases)) {
    if (slugify(alias) === normalized) {
      return fieldLabel;
    }
  }

  return null;
};

const buildProductTitle = (request: DraftRequest) =>
  sanitizeValue(
    [request.strain, request.packageSize, request.productType]
      .map((part) => coerceString(part))
      .filter(Boolean)
      .join(" "),
  );

const buildFallbackDescriptions = (request: DraftRequest) => {
  const vendorLine = sanitizeValue(coerceString(request.vendor));
  const brand = sanitizeValue(coerceString(request.brand));
  const strain = sanitizeValue(coerceString(request.strain));
  const productTitle = buildProductTitle(request);

  const descriptionShort = productTitle || sanitizeValue([brand, strain].filter(Boolean).join(" "));
  const longDescriptionParts = [
    descriptionShort,
    vendorLine ? `Vendor: ${vendorLine}` : "",
  ].filter(Boolean);

  return {
    descriptionShort,
    descriptionLong: appendPeriod(longDescriptionParts.join(". ")),
  };
};

const buildFallbackConfidence = (request: DraftRequest) => {
  const inputs = [
    request.brand,
    request.strain,
    request.productType,
    request.packageSize,
    request.sku,
    request.vendor,
    request.notes,
  ].map((value) => sanitizeValue(coerceString(value)));
  const filled = inputs.filter(Boolean).length;
  if (filled === 0) return 0;
  return Math.max(25, Math.min(100, Math.round((filled / inputs.length) * 100)));
};

export const buildFallbackDraft = (request: DraftRequest): GeneratedDraft => {
  const productTitle = buildProductTitle(request);
  const fallbackDescriptions = buildFallbackDescriptions(request);
  const vendorValues: Record<string, string> = {
    "Brand Name": sanitizeValue(coerceString(request.brand)),
    "Strain Name": sanitizeValue(coerceString(request.strain)),
    "Product Title": productTitle,
    Category: sanitizeValue(coerceString(request.productType)),
    Package: sanitizeValue(coerceString(request.packageSize)),
    SKU: sanitizeValue(coerceString(request.sku)),
    Vendor: sanitizeValue(coerceString(request.vendor)),
  };

  return {
    overallConfidence: buildFallbackConfidence(request),
    descriptionShort: fallbackDescriptions.descriptionShort,
    descriptionLong: fallbackDescriptions.descriptionLong,
    sources: [],
    sections: draftSectionTemplates.map((template) => ({
      title: template.title,
      icon: template.icon,
      confidence:
        template.key === "vendor" &&
        Object.values(vendorValues).some(Boolean)
          ? "verified"
          : template.defaultConfidence,
      fields: template.fieldLabels.map((label) => ({
        label,
        value: template.key === "vendor" ? vendorValues[label] ?? "" : "",
      })),
    })),
  };
};

const extractJsonBody = (content: string) => {
  const trimmed = content.trim();
  const fencedMatch = trimmed.match(/^```(?:json)?\s*([\s\S]*?)\s*```$/i);
  if (fencedMatch?.[1]) {
    return fencedMatch[1].trim();
  }
  const firstBrace = trimmed.indexOf("{");
  const lastBrace = trimmed.lastIndexOf("}");
  if (firstBrace !== -1 && lastBrace > firstBrace) {
    return trimmed.slice(firstBrace, lastBrace + 1).trim();
  }
  return trimmed;
};

export const normalizeDraftPayload = (payload: unknown, request: DraftRequest): GeneratedDraft => {
  const fallback = buildFallbackDraft(request);
  if (!isRecord(payload)) {
    return fallback;
  }

  const sectionsByKey = new Map<
    string,
    {
      icon: DraftIcon;
      confidence: DraftConfidence;
      fields: Map<string, string>;
    }
  >();

  const rawSections = Array.isArray(payload.sections) ? payload.sections : [];
  for (const rawSection of rawSections) {
    if (!isRecord(rawSection)) continue;

    const template = getTemplateForTitle(coerceString(rawSection.title));
    if (!template) continue;

    const existing = sectionsByKey.get(template.key) ?? {
      icon: template.icon,
      confidence: template.defaultConfidence,
      fields: new Map<string, string>(),
    };

    existing.icon = normalizeIcon(rawSection.icon, existing.icon);
    existing.confidence = normalizeConfidence(rawSection.confidence, existing.confidence);

    const rawFields = Array.isArray(rawSection.fields) ? rawSection.fields : [];
    for (const rawField of rawFields) {
      if (!isRecord(rawField)) continue;
      const normalizedLabel = getFieldLabelForTemplate(template, coerceString(rawField.label));
      if (!normalizedLabel) continue;
      const sanitized = sanitizeValue(coerceString(rawField.value));
      if (sanitized || !existing.fields.has(normalizedLabel)) {
        existing.fields.set(normalizedLabel, sanitized);
      }
    }

    sectionsByKey.set(template.key, existing);
  }

  return {
    overallConfidence: clampConfidenceScore(payload.overallConfidence, fallback.overallConfidence),
    descriptionShort: sanitizeValue(coerceString(payload.descriptionShort)) || fallback.descriptionShort,
    descriptionLong: sanitizeValue(coerceString(payload.descriptionLong)) || fallback.descriptionLong,
    sources: [],
    sections: draftSectionTemplates.map((template, index) => {
      const fallbackSection = fallback.sections[index];
      const normalizedSection = sectionsByKey.get(template.key);
      return {
        title: template.title,
        icon: normalizedSection?.icon ?? fallbackSection.icon,
        confidence: normalizedSection?.confidence ?? fallbackSection.confidence,
        fields: template.fieldLabels.map((label) => ({
          label,
          value: normalizedSection?.fields.get(label) ?? fallbackSection.fields.find((field) => field.label === label)?.value ?? "",
        })),
      };
    }),
  };
};

export const parseDraftContent = (content: string, request: DraftRequest): GeneratedDraft => {
  const jsonBody = extractJsonBody(content);
  try {
    return normalizeDraftPayload(JSON.parse(jsonBody) as unknown, request);
  } catch {
    return buildFallbackDraft(request);
  }
};

export const buildDraftOutputInstructions = () => {
  const sections = draftSectionTemplates
    .map((template) => `- ${template.title}: ${template.fieldLabels.join(", ")}`)
    .join("\n");

  return [
    "You are Strain-Vinny, the same knowledgeable cannabis copilot who already interacts with the crew. You now need to fill out a product draft.",
    "Powered by DeepSeek-V4-Pro, you can think carefully about the strain, cross-reference public sources, and produce a polished, friendly listing.",
    "Return strictly one JSON object. No markdown, no code fences, no extra text.",
    "Use these exact section titles and field labels in the sections array:",
    sections,
    'Each section has a "confidence" field. Use "verified" for data from intake fields, "matched" for data matched from a known database, "inferred" for values based on strain/brand knowledge, and "review" only when you truly cannot determine a value.',
    "Fill in every field you can. For well-known strains, provide THC/CBD ranges, terpene profiles, aroma notes, taste notes, effects, and medical uses.",
    "If a value is truly unknown even after research, use an empty string.",
    "Tone for the `descriptionShort` and `descriptionLong`: friendly, direct, and helpful. Imagine you're a budtender explaining the product to a customer. Avoid marketing fluff; focus on what matters.",
    "Before writing the JSON, reason internally about the best answer for each field. Then output the JSON only.",
  ].join("\n");
};

/** JSON schema describing the expected draft output shape (used for documentation/validation). */
export const draftJsonSchema = {
  type: "object",
  additionalProperties: false,
  properties: {
    overallConfidence: { type: "number" },
    descriptionShort: { type: "string" },
    descriptionLong: { type: "string" },
    sections: {
      type: "array",
      minItems: 7,
      maxItems: 7,
      items: {
        type: "object",
        additionalProperties: false,
        properties: {
          title: { type: "string" },
          icon: {
            type: "string",
            enum: ["FileText", "FlaskConical", "Droplets", "Wind", "Leaf", "Sparkles", "Heart"],
          },
          confidence: {
            type: "string",
            enum: ["verified", "matched", "inferred", "review"],
          },
          fields: {
            type: "array",
            minItems: 2,
            maxItems: 7,
            items: {
              type: "object",
              additionalProperties: false,
              properties: {
                label: { type: "string" },
                value: { type: "string" },
              },
              required: ["label", "value"],
            },
          },
        },
        required: ["title", "icon", "confidence", "fields"],
      },
    },
  },
  required: ["overallConfidence", "descriptionShort", "descriptionLong", "sections"],
} as const;
