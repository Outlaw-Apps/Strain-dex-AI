// eslint-disable-next-line @typescript-eslint/ban-ts-comment
// @ts-nocheck
import {
  buildDraftOutputInstructions,
  parseDraftContent,
  type DraftRequest,
} from "./draftPayload.ts";
import { gatherDraftResearch, loadResearchPolicy } from "./cannabisResearch.ts";
import { DEFAULT_DEEPSEEK_MODEL } from "./aiModel.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

interface ProviderErrorPayload {
  error?: {
    message?: string;
  };
}

interface ChatChoice {
  finish_reason?: string | null;
  message?: {
    content?: string | null;
    refusal?: string;
  };
}

interface ChatCompletionPayload extends ProviderErrorPayload {
  choices?: ChatChoice[];
}

interface ProviderConfig {
  provider: "deepseek" | "openai";
  apiKey: string;
  apiUrl: string;
  model: string;
}

const DEFAULT_DEEPSEEK_API_URL = "https://api.deepseek.com/chat/completions";
const DEFAULT_OPENAI_API_URL = "https://api.openai.com/v1/chat/completions";
const DEFAULT_OPENAI_MODEL = "gpt-4o-mini";
type ReadEnv = (key: string) => string | undefined;

const jsonResponse = (body: Record<string, unknown>, status = 200) =>
  new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });

const readEnvValue = (readEnv: ReadEnv, key: string) => (readEnv(key) || "").trim();

const buildUserPrompt = (request: DraftRequest, researchContext: string) =>
  [
    `Brand: ${request.brand || "Unknown"}`,
    `Strain: ${request.strain || "Unknown"}`,
    `Product Type: ${request.productType || "Unknown"}`,
    `Package Size: ${request.packageSize || "Unknown"}`,
    `SKU: ${request.sku || "Unknown"}`,
    `Vendor: ${request.vendor || "Unknown"}`,
    `Notes: ${request.notes || "None provided"}`,
    "",
    "Trusted public research context:",
    researchContext || "No trusted source matches were retrieved from AllBud, Leafly, Haven, Weedmaps, Chronic Guru, or Corona Culture.",
    "",
    "CRITICAL REQUIREMENTS:",
    "1. CANNABINOID PROFILE (THC & CBD): Extract exact percentages or ranges. Look for patterns like '20% THC', 'THC: 18-22%', 'CBD <1%'. If found in research context, use 'matched' confidence. If inferring from strain knowledge, use 'inferred' confidence.",
    "2. TERPENE PROFILE: Extract ALL terpenes mentioned. Look for terms like myrcene, limonene, caryophyllene, pinene, linalool, humulene, etc. Separate into 'Dominant Terpenes' (top 2-3) and 'Supporting Terpenes' (others).",
    "3. AROMA PROFILE: Extract descriptive aroma terms like earthy, citrus, pine, diesel, sweet, fruity, pungent, floral, etc.",
    "4. TASTE/FLAVOR PROFILE: Extract flavor descriptors for both initial taste and finish/aftertaste.",
    "",
    "Fill in ALL available fields including THC%, CBD%, dominant terpenes, supporting terpenes, aroma profile, aroma notes, taste profile, finish, effects, onset, and medical uses.",
    "You must strictly use the provided trusted public research context. If a product in the research context shares any single descriptive word or strain name with the intake data, treat it as a match and use that data. DO NOT use your general knowledge or guess any product details.",
    "IMPORTANT: Do NOT use the words 'may help', 'might', 'could', 'likely', or 'possibly' in any field values. These words will be filtered out. Instead use direct phrasing like 'Reported to assist with...', 'Commonly used for...', or simply list the items.",
  ].join("\n");

export const resolveProviderConfig = (
  readEnv: ReadEnv = (key) => Deno.env.get(key),
): ProviderConfig => {
  const requestedProvider = readEnvValue(readEnv, "AI_PROVIDER").toLowerCase();
  const sharedApiKey = readEnvValue(readEnv, "AI_API_KEY");
  const deepseekApiKey = readEnvValue(readEnv, "DEEPSEEK_API_KEY");
  const openAiApiKey = readEnvValue(readEnv, "OPENAI_API_KEY");

  if (requestedProvider === "openai" && (openAiApiKey || sharedApiKey)) {
    return {
      provider: "openai",
      apiKey: openAiApiKey || sharedApiKey,
      apiUrl:
        readEnvValue(readEnv, "OPENAI_API_URL") ||
        readEnvValue(readEnv, "AI_API_URL") ||
        DEFAULT_OPENAI_API_URL,
      model:
        readEnvValue(readEnv, "OPENAI_MODEL") ||
        readEnvValue(readEnv, "AI_MODEL") ||
        DEFAULT_OPENAI_MODEL,
    };
  }

  if (requestedProvider === "deepseek" && (deepseekApiKey || sharedApiKey)) {
    return {
      provider: "deepseek",
      apiKey: deepseekApiKey || sharedApiKey,
      apiUrl:
        readEnvValue(readEnv, "DEEPSEEK_API_URL") ||
        readEnvValue(readEnv, "AI_API_URL") ||
        DEFAULT_DEEPSEEK_API_URL,
      model:
        readEnvValue(readEnv, "DEEPSEEK_MODEL") ||
        readEnvValue(readEnv, "AI_MODEL") ||
        DEFAULT_DEEPSEEK_MODEL,
    };
  }

  if (deepseekApiKey || sharedApiKey) {
    return {
      provider: "deepseek",
      apiKey: deepseekApiKey || sharedApiKey,
      apiUrl:
        readEnvValue(readEnv, "DEEPSEEK_API_URL") ||
        readEnvValue(readEnv, "AI_API_URL") ||
        DEFAULT_DEEPSEEK_API_URL,
      model:
        readEnvValue(readEnv, "DEEPSEEK_MODEL") ||
        readEnvValue(readEnv, "AI_MODEL") ||
        DEFAULT_DEEPSEEK_MODEL,
    };
  }

  if (openAiApiKey) {
    return {
      provider: "openai",
      apiKey: openAiApiKey,
      apiUrl:
        readEnvValue(readEnv, "OPENAI_API_URL") ||
        readEnvValue(readEnv, "AI_API_URL") ||
        DEFAULT_OPENAI_API_URL,
      model:
        readEnvValue(readEnv, "OPENAI_MODEL") ||
        readEnvValue(readEnv, "AI_MODEL") ||
        DEFAULT_OPENAI_MODEL,
    };
  }

  // Fall back to any available key — prefer the shared key with a
  // reasonable default provider.
  if (sharedApiKey) {
    return {
      provider: "deepseek",
      apiKey: sharedApiKey,
      apiUrl:
        readEnvValue(readEnv, "DEEPSEEK_API_URL") ||
        readEnvValue(readEnv, "AI_API_URL") ||
        DEFAULT_DEEPSEEK_API_URL,
      model:
        readEnvValue(readEnv, "DEEPSEEK_MODEL") ||
        readEnvValue(readEnv, "AI_MODEL") ||
        DEFAULT_DEEPSEEK_MODEL,
    };
  }

  throw new Error(
    "DEEPSEEK_API_KEY is not configured and no compatible OPENAI_API_KEY or AI_API_KEY fallback was found.",
  );
};

const getProviderConfig = (): ProviderConfig => resolveProviderConfig();

export const describeProviderFailure = (
  provider: ProviderConfig["provider"],
  status: number,
  providerMessage?: string,
) => {
  const providerLabel = provider === "openai" ? "OpenAI" : "DeepSeek";

  if (status === 401 || status === 403) {
    return `${providerLabel} authentication failed. Check the configured API key and provider settings.`;
  }

  if (status === 404) {
    return `${providerLabel} could not find the configured endpoint or model. Check the API URL and model name.`;
  }

  if (status === 429) {
    return `${providerLabel} is rate limiting requests right now. Please retry in a moment.`;
  }

  if (status >= 500) {
    return `${providerLabel} is temporarily unavailable. Please retry shortly.`;
  }

  if (providerMessage?.trim()) {
    return providerMessage.trim();
  }

  return `${providerLabel} request failed (${status}).`;
};

// Lazily resolve the Supabase admin client. The dynamic import keeps the
// `https://esm.sh/...` URL out of module-load so this file is still importable
// from Vitest (which only resolves file: and data: schemes).
const buildPolicyClient = async () => {
  const url = Deno.env.get("SUPABASE_URL");
  const serviceRole = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
  if (!url || !serviceRole) return null;
  const { createClient } = await import("https://esm.sh/@supabase/supabase-js@2.57.4");
  return createClient(url, serviceRole, { auth: { persistSession: false } });
};

const fetchDraft = async (request: DraftRequest) => {
  const provider = getProviderConfig();
  const policyClient = await buildPolicyClient();
  const policy = policyClient ? await loadResearchPolicy(policyClient) : undefined;
  const research = await gatherDraftResearch(request, { policy });
  if (research.warnings.length > 0) {
    console.warn("Draft research warnings:", research.warnings);
  }

  const requestBody: Record<string, unknown> = {
    model: provider.model,
    response_format: { type: "json_object" },
    messages: [
      {
        role: "system",
        content: [
          "You are Strain-Vinny, a knowledgeable, friendly cannabis industry co-pilot with years of budtender experience. You now generate detailed retail catalog drafts.",
          "Powered by DeepSeek-V4-Pro, you can carefully reason about the strain, cross-reference the provided research, and produce a polished, human-friendly listing.",
          "",
          "YOUR PRIMARY GOAL is to extract and populate:",
          "- THC and CBD percentages (exact values or ranges like '18-22% THC')",
          "- Terpene profiles (all terpenes mentioned, separated into dominant and supporting)",
          "- Aroma descriptors (earthy, citrus, pine, diesel, sweet, fruity, etc.)",
          "- Flavor/taste profiles (initial taste and finish)",
          "- Effects and onset timing",
          "",
          "When a section is supported by the trusted public research context, mark it as 'matched'.",
          "You are strictly forbidden from using outside knowledge or guessing. All data must come from the intake fields or the provided research context.",
          "If the research context has no partial or exact matches, do not guess. Mark those fields with 'review' confidence so the user knows manual input is required.",
          "For medical uses, state them as reported uses without hedging words like 'may help', 'might', 'could', 'likely', or 'possibly'. Instead say 'Reported to assist with...' or 'Commonly used for...' or simply list the conditions.",
          "",
          buildDraftOutputInstructions(),
        ].join("\n\n"),
      },
      {
        role: "user",
        content: [
          buildUserPrompt(request, research.promptText),
          buildDraftOutputInstructions(),
        ].join("\n\n"),
      },
    ],
  };

  if (!provider.model.includes("reasoner")) {
    requestBody.temperature = 0.2;
  }

  const response = await fetch(provider.apiUrl, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${provider.apiKey}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify(requestBody),
  });

  const payload = (await response.json().catch(() => ({}))) as ChatCompletionPayload;
  if (!response.ok) {
    throw new Error(
      describeProviderFailure(provider.provider, response.status, payload.error?.message),
    );
  }

  const choice = payload.choices?.[0];
  if (!choice) {
    throw new Error("AI provider did not return any choices");
  }

  if (choice.message?.refusal) {
    throw new Error(choice.message.refusal);
  }

  if (choice.finish_reason === "length") {
    throw new Error("AI response was truncated before the draft was complete");
  }

  if (choice.finish_reason === "content_filter") {
    throw new Error("AI provider blocked the draft response");
  }

  if (choice.finish_reason === "insufficient_system_resource") {
    throw new Error("AI provider ran out of capacity before finishing the draft");
  }

  if (typeof choice.message?.content !== "string") {
    throw new Error("AI provider did not return a draft payload");
  }

  const draft = parseDraftContent(choice.message.content, request);
  return {
    ...draft,
    sources: research.matches,
  };
};

export const handleDraftRequest = async (req: Request, functionName: string) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const request = (await req.json()) as DraftRequest;
    if (!request.brand && !request.strain) {
      return jsonResponse({ error: "At least one of 'brand' or 'strain' is required" }, 400);
    }

    const draft = await fetchDraft(request);
    return jsonResponse({ draft });
  } catch (error: unknown) {
    console.error(`${functionName} error:`, error);
    const message = error instanceof Error ? error.message : "Unknown server error";
    return jsonResponse({ error: message }, 500);
  }
};
