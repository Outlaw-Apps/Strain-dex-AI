export interface ExistingKnowledgeRow {
  stable_key: string;
  source_updated_at: string;
}

export interface IncomingKnowledgeRow {
  stable_key: string;
  source_updated_at: string;
}

export const toIso = (value: string) => new Date(value).toISOString();

export function shouldUpsertRecord(
  existing: ExistingKnowledgeRow | undefined,
  incoming: IncomingKnowledgeRow,
): boolean {
  if (!existing) return true;
  return toIso(incoming.source_updated_at) > toIso(existing.source_updated_at);
}

export function buildSyncPlan(
  existingRows: ExistingKnowledgeRow[],
  incomingRows: IncomingKnowledgeRow[],
) {
  const existingMap = new Map(existingRows.map((row) => [row.stable_key, row]));
  const toUpsert: IncomingKnowledgeRow[] = [];
  let skipped = 0;

  for (const incoming of incomingRows) {
    const existing = existingMap.get(incoming.stable_key);
    if (shouldUpsertRecord(existing, incoming)) {
      toUpsert.push(incoming);
    } else {
      skipped += 1;
    }
  }

  return {
    toUpsert,
    skipped,
  };
}

