/* eslint-disable react-refresh/only-export-components -- Deno edge template, not subject to Fast Refresh */
/// <reference types="npm:@types/react@18.3.1" />
import * as React from 'npm:react@18.3.1'
import {
  Body,
  Container,
  Head,
  Html,
  Preview,
  Section,
} from 'npm:@react-email/components@0.0.22'

interface Props {
  subjectPreview?: string
  bodyHtml?: string
  siteName?: string
}

// Renders the admin-edited body HTML inside a branded shell. The body comes
// from the email_templates table (already variable-interpolated server-side).
const Generic = ({ subjectPreview, bodyHtml, siteName }: Props) => (
  <Html lang="en" dir="ltr">
    <Head />
    <Preview>{subjectPreview || siteName || 'Notification'}</Preview>
    <Body style={main}>
      <Container style={container}>
        <Section
          style={content}
          // bodyHtml is admin-authored and stored server-side; rendered as-is.
          dangerouslySetInnerHTML={{ __html: bodyHtml || '' }}
        />
        <Section style={footer}>
          <p style={footerText}>
            Sent by {siteName || 'Strain-ventory'}.
          </p>
        </Section>
      </Container>
    </Body>
  </Html>
)

export const template = {
  component: Generic,
  subject: (data: Record<string, unknown>) =>
    (data?.subjectPreview as string) || 'Notification',
  previewData: {
    subjectPreview: 'Sample subject',
    bodyHtml: '<h1>Hello</h1><p>This is a preview.</p>',
    siteName: 'Strain-ventory',
  },
}

const main = {
  backgroundColor: '#ffffff',
  fontFamily:
    '"DM Sans", -apple-system, BlinkMacSystemFont, "Segoe UI", Arial, sans-serif',
  color: '#0a0a0a',
}
const container = {
  maxWidth: '560px',
  margin: '0 auto',
  padding: '32px 24px',
}
const content = { lineHeight: '1.6', fontSize: '15px' }
const footer = {
  marginTop: '32px',
  paddingTop: '16px',
  borderTop: '1px solid #e5e5e5',
}
const footerText = {
  color: '#737373',
  fontSize: '12px',
  margin: 0,
}
