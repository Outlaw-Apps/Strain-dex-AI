/// <reference types="npm:@types/react@18.3.1" />
import { template as genericTemplate } from './generic.tsx'

export interface TemplateEntry {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  component: (props: any) => unknown
  subject: string | ((data: Record<string, unknown>) => string)
  displayName?: string
  previewData?: Record<string, unknown>
  to?: string
}

// All reusable templates render through the same generic component;
// subject/body content is sourced from the `email_templates` table so
// admins can edit copy without redeploying.
export const TEMPLATES: Record<string, TemplateEntry> = {
  welcome: { ...genericTemplate, displayName: 'Welcome Email' },
  notification: { ...genericTemplate, displayName: 'General Notification' },
  order_receipt: { ...genericTemplate, displayName: 'Order Receipt' },
}
