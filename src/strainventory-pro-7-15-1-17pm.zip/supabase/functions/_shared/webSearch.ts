// Lightweight web-search adapter for Strain-Vinny grounding.
//
// Supports Serper.dev and Tavily. Provider selection via env:
//   SEARCH_PROVIDER  = "serper" | "tavily"   (default: "serper")
//   SEARCH_API_KEY   = provider API key
//   SEARCH_TIMEOUT_MS = optional override (default 3000)
//
// Returns up to `limit` results (default 5). On any failure (missing key,
// timeout, non-2xx, malformed payload) returns an empty array AND logs a
// warning — the assistant must continue without web context, never throw.

import type { WebSearchResult } from "./vinnyPrompt.ts";

export interface WebSearchOptions {
  limit?: number;
  timeoutMs?: number;
  provider?: "serper" | "tavily";
  apiKey?: string;
  fetchImpl?: typeof fetch;
}

const DEFAULT_TIMEOUT_MS = 3000;
const DEFAULT_LIMIT = 5;

const readEnv = (key: string): string | undefined => {
  try {
    // @ts-expect-error — Deno is provided in the Edge Function runtime.
    if (typeof Deno !== "undefined") return Deno.env.get(key) ?? undefined;
  } catch {
    /* ignore */
  }
  return undefined;
};

const resolveProvider = (override?: WebSearchOptions["provider"]): "serper" | "tavily" => {
  const raw = override ?? (readEnv("SEARCH_PROVIDER") || "").toLowerCase();
  if (raw === "tavily") return "tavily";
  return "serper";
};

const resolveTimeout = (override?: number): number => {
  if (typeof override === "number" && override > 0) return override;
  const envValue = Number(readEnv("SEARCH_TIMEOUT_MS"));
  return Number.isFinite(envValue) && envValue > 0 ? envValue : DEFAULT_TIMEOUT_MS;
};

interface SerperOrganic {
  title?: string;
  link?: string;
  snippet?: string;
}

interface SerperResponse {
  organic?: SerperOrganic[];
}

interface TavilyResult {
  title?: string;
  url?: string;
  content?: string;
}

interface TavilyResponse {
  results?: TavilyResult[];
}

const callSerper = async (
  query: string,
  apiKey: string,
  limit: number,
  signal: AbortSignal,
  fetchImpl: typeof fetch,
): Promise<WebSearchResult[]> => {
  const response = await fetchImpl("https://google.serper.dev/search", {
    method: "POST",
    headers: {
      "X-API-KEY": apiKey,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ q: query, num: limit }),
    signal,
  });
  if (!response.ok) {
    throw new Error(`Serper search failed (${response.status})`);
  }
  const payload = (await response.json()) as SerperResponse;
  return (payload.organic ?? []).slice(0, limit).map((item) => ({
    title: item.title ?? "",
    url: item.link ?? "",
    snippet: item.snippet ?? "",
  }));
};

const callTavily = async (
  query: string,
  apiKey: string,
  limit: number,
  signal: AbortSignal,
  fetchImpl: typeof fetch,
): Promise<WebSearchResult[]> => {
  const response = await fetchImpl("https://api.tavily.com/search", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      api_key: apiKey,
      query,
      max_results: limit,
      include_answer: false,
    }),
    signal,
  });
  if (!response.ok) {
    throw new Error(`Tavily search failed (${response.status})`);
  }
  const payload = (await response.json()) as TavilyResponse;
  return (payload.results ?? []).slice(0, limit).map((item) => ({
    title: item.title ?? "",
    url: item.url ?? "",
    snippet: item.content ?? "",
  }));
};

/**
 * Run a single web search. Always resolves; never throws. Returns [] on any
 * failure and logs a warning describing the cause.
 */
export async function runWebSearch(
  query: string,
  options: WebSearchOptions = {},
): Promise<WebSearchResult[]> {
  const trimmed = query?.trim();
  if (!trimmed) return [];

  const provider = resolveProvider(options.provider);
  const apiKey = options.apiKey ?? readEnv("SEARCH_API_KEY") ?? "";
  if (!apiKey) {
    console.warn(`[webSearch] Skipping: no SEARCH_API_KEY configured for provider=${provider}.`);
    return [];
  }

  const limit = options.limit ?? DEFAULT_LIMIT;
  const timeoutMs = resolveTimeout(options.timeoutMs);
  const fetchImpl = options.fetchImpl ?? fetch;

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);

  try {
    if (provider === "tavily") {
      return await callTavily(trimmed, apiKey, limit, controller.signal, fetchImpl);
    }
    return await callSerper(trimmed, apiKey, limit, controller.signal, fetchImpl);
  } catch (error) {
    if (controller.signal.aborted) {
      console.warn(`[webSearch] timed out after ${timeoutMs}ms (provider=${provider}).`);
    } else {
      const reason = error instanceof Error ? error.message : String(error);
      console.warn(`[webSearch] failed (provider=${provider}): ${reason}`);
    }
    return [];
  } finally {
    clearTimeout(timer);
  }
}

/**
 * Resolve whether web search should run for this request. Order:
 *   1. explicit per-request override (if provided)
 *   2. ASSISTANT_WEB_SEARCH_ENABLED env var (default: true)
 */
export function isWebSearchEnabled(perRequestOverride?: boolean): boolean {
  if (typeof perRequestOverride === "boolean") return perRequestOverride;
  const raw = (readEnv("ASSISTANT_WEB_SEARCH_ENABLED") ?? "true").toLowerCase();
  return raw !== "false" && raw !== "0" && raw !== "off";
}
