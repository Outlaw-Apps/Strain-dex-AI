import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const serviceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

    // Verify the caller is an admin
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(JSON.stringify({ error: "No authorization header" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const anonClient = createClient(supabaseUrl, Deno.env.get("SUPABASE_ANON_KEY")!, {
      global: { headers: { Authorization: authHeader } },
    });
    const { data: { user: caller } } = await anonClient.auth.getUser();
    if (!caller) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const adminClient = createClient(supabaseUrl, serviceRoleKey);
    const { data: roleCheck, error: roleCheckError } = await adminClient.rpc("has_role", {
      _user_id: caller.id,
      _role: "admin",
    });
    if (roleCheckError) throw roleCheckError;
    if (!roleCheck) {
      return new Response(JSON.stringify({ error: "Admin access required" }), {
        status: 403,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const url = new URL(req.url);
    const method = req.method;
    const validRoles = new Set(["admin", "reviewer", "staff"]);

    if (method === "GET") {
      // List all users with their roles
      const { data: authUsers, error: usersError } = await adminClient.auth.admin.listUsers();
      if (usersError) throw usersError;

      const { data: allRoles } = await adminClient.from("user_roles").select("*");

      const users = authUsers.users.map((u) => ({
        id: u.id,
        email: u.email,
        created_at: u.created_at,
        last_sign_in_at: u.last_sign_in_at,
        roles: (allRoles || []).filter((r) => r.user_id === u.id).map((r) => r.role),
      }));

      return new Response(JSON.stringify({ users }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    if (method === "POST") {
      const { action, user_id, role, email, password } = await req.json();

      if (action === "add_role") {
        if (!validRoles.has(role)) {
          return new Response(JSON.stringify({ error: "Invalid role supplied." }), {
            status: 400,
            headers: { ...corsHeaders, "Content-Type": "application/json" },
          });
        }
        const { error } = await adminClient
          .from("user_roles")
          .upsert({ user_id, role }, { onConflict: "user_id,role" });
        if (error) throw error;
        return new Response(JSON.stringify({ success: true }), {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      if (action === "remove_role") {
        if (!validRoles.has(role)) {
          return new Response(JSON.stringify({ error: "Invalid role supplied." }), {
            status: 400,
            headers: { ...corsHeaders, "Content-Type": "application/json" },
          });
        }
        if (role === "admin") {
          const { data: adminRoles, error: adminRolesError } = await adminClient
            .from("user_roles")
            .select("user_id")
            .eq("role", "admin");
          if (adminRolesError) throw adminRolesError;
          const adminUserIds = new Set((adminRoles ?? []).map((row) => row.user_id));
          if (adminUserIds.size <= 1 && adminUserIds.has(user_id)) {
            return new Response(JSON.stringify({ error: "Cannot remove the last admin role." }), {
              status: 400,
              headers: { ...corsHeaders, "Content-Type": "application/json" },
            });
          }
        }
        const { error } = await adminClient.from("user_roles").delete().eq("user_id", user_id).eq("role", role);
        if (error) throw error;
        return new Response(JSON.stringify({ success: true }), {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      if (action === "create_user") {
        const cleanEmail = typeof email === "string" ? email.trim().toLowerCase() : "";
        const cleanPassword = typeof password === "string" ? password : "";
        const requestedRole = typeof role === "string" ? role : "staff";

        if (!cleanEmail || !cleanPassword) {
          return new Response(JSON.stringify({ error: "Email and password are required" }), {
            status: 400,
            headers: { ...corsHeaders, "Content-Type": "application/json" },
          });
        }
        if (cleanPassword.length < 6) {
          return new Response(JSON.stringify({ error: "Password must be at least 6 characters." }), {
            status: 400,
            headers: { ...corsHeaders, "Content-Type": "application/json" },
          });
        }

        if (!validRoles.has(requestedRole)) {
          return new Response(JSON.stringify({ error: "Invalid role supplied." }), {
            status: 400,
            headers: { ...corsHeaders, "Content-Type": "application/json" },
          });
        }

        const { data: newUser, error: createError } = await adminClient.auth.admin.createUser({
          email: cleanEmail,
          password: cleanPassword,
          email_confirm: true,
        });
        if (createError) throw createError;
        if (newUser.user) {
          const { error: roleError } = await adminClient
            .from("user_roles")
            .upsert(
              { user_id: newUser.user.id, role: requestedRole },
              { onConflict: "user_id,role" },
            );
          if (roleError) {
            await adminClient.auth.admin.deleteUser(newUser.user.id);
            throw new Error(`Failed to assign role: ${roleError.message}`);
          }
        }
        return new Response(JSON.stringify({ success: true, user: { id: newUser.user?.id, email: cleanEmail } }), {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      return new Response(JSON.stringify({ error: "Unknown action" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    return new Response(JSON.stringify({ error: "Method not allowed" }), {
      status: 405,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (err: unknown) {
    return new Response(JSON.stringify({ error: err instanceof Error ? err.message : "Unknown error" }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
