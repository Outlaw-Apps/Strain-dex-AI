import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.57.4";
import { resolveProviderConfig } from "../_shared/generateDraft.ts";

// Read-only diagnostics endpoint. Admins can hit this to figure out *why*
// AI features are failing without guessing from vague error toasts.
//
// Returns which provider is selected, whether the API key is present, and
// a "preflight" result against the provider's chat completions endpoint.
// No user-supplied input is ever forwarded to the provider.

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
};

interface ProviderProbeResult {
  ok: boolean;
  status: number | null;
  latencyMs: number | null;
  hint?: string;
}

const json = (body: Record<string, unknown>, status = 200) =>
  new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });

const probeProvider = async (
  apiUrl: string,
  apiKey: string,
  model: string,
): Promise<ProviderProbeResult> => {
  const start = Date.now();
  try {
    const response = await fetch(apiUrl, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model,
        max_tokens: 1,
        messages: [
          { role: "system", content: "You are a ping probe." },
          { role: "user", content: "ping" },
        ],
      }),
    });
    const latencyMs = Date.now() - start;
    if (response.ok) {
      return { ok: true, status: response.status, latencyMs };
    }
    let hint = `Provider returned HTTP ${response.status}.`;
    if (response.status === 401 || response.status === 403) {
      hint =
        "Provider rejected the API key (401/403). Verify the key matches the selected provider and is not expired.";
    } else if (response.status === 404) {
      hint = `Provider could not find model "${model}" or the endpoint. Check the model name and API URL.`;
    } else if (response.status === 429) {
      hint = "Provider is currently rate-limiting requests.";
    } else if (response.status >= 500) {
      hint = "Provider is temporarily unavailable.";
    }
    return { ok: false, status: response.status, latencyMs, hint };
  } catch (error) {
    return {
      ok: false,
      status: null,
      latencyMs: Date.now() - start,
      hint: `Network error reaching provider: ${
        error instanceof Error ? error.message : "unknown"
      }`,
    };
  }
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const serviceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
    const anonKey = Deno.env.get("SUPABASE_ANON_KEY");

    if (!supabaseUrl || !serviceRoleKey || !anonKey) {
      return json(
        {
          error:
            "Diagnostics not configured: SUPABASE_URL / SUPABASE_SERVICE_ROLE_KEY / SUPABASE_ANON_KEY missing on the edge function.",
        },
        500,
      );
    }

    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return json({ error: "No authorization header" }, 401);
    }
    const anonClient = createClient(supabaseUrl, anonKey, {
      global: { headers: { Authorization: authHeader } },
    });
    const {
      data: { user: caller },
    } = await anonClient.auth.getUser();
    if (!caller) return json({ error: "Unauthorized" }, 401);

    const adminClient = createClient(supabaseUrl, serviceRoleKey);
    const { data: isAdmin } = await adminClient.rpc("has_role", {
      _user_id: caller.id,
      _role: "admin",
    });
    if (!isAdmin) return json({ error: "Admin access required" }, 403);

    const envPresence = {
      DEEPSEEK_API_KEY: Boolean(Deno.env.get("DEEPSEEK_API_KEY")),
      OPENAI_API_KEY: Boolean(Deno.env.get("OPENAI_API_KEY")),
      AI_API_KEY: Boolean(Deno.env.get("AI_API_KEY")),
      AI_PROVIDER: Deno.env.get("AI_PROVIDER") || null,
      AI_MODEL: Deno.env.get("AI_MODEL") || null,
      DEEPSEEK_MODEL: Deno.env.get("DEEPSEEK_MODEL") || null,
      OPENAI_MODEL: Deno.env.get("OPENAI_MODEL") || null,
    };

    let provider: ReturnType<typeof resolveProviderConfig> | null = null;
    let resolveError: string | null = null;
    try {
      provider = resolveProviderConfig();
    } catch (error) {
      resolveError = error instanceof Error ? error.message : "Unknown error";
    }

    let probe: ProviderProbeResult | null = null;
    if (provider) {
      probe = await probeProvider(provider.apiUrl, provider.apiKey, provider.model);
    }

    return json({
      caller: { id: caller.id, email: caller.email ?? null },
      env: envPresence,
      resolvedProvider: provider
        ? {
            provider: provider.provider,
            apiUrl: provider.apiUrl,
            model: provider.model,
            apiKeyPreview: provider.apiKey
              ? `${provider.apiKey.slice(0, 4)}…${provider.apiKey.slice(-4)}`
              : null,
          }
        : null,
      resolveError,
      probe,
      recommendations: buildRecommendations(envPresence, resolveError, probe),
    });
  } catch (error) {
    return json(
      { error: error instanceof Error ? error.message : "Unknown error" },
      500,
    );
  }
});

const buildRecommendations = (
  env: Record<string, unknown>,
  resolveError: string | null,
  probe: ProviderProbeResult | null,
): string[] => {
  const recs: string[] = [];
  const anyKey = env.DEEPSEEK_API_KEY || env.OPENAI_API_KEY || env.AI_API_KEY;
  if (!anyKey) {
    recs.push(
      "Set a provider key in Supabase: `supabase secrets set DEEPSEEK_API_KEY=...` (or OPENAI_API_KEY / AI_API_KEY).",
    );
  }
  if (resolveError) {
    recs.push(`Provider config error: ${resolveError}`);
  }
  if (probe && !probe.ok && probe.hint) {
    recs.push(probe.hint);
  }
  if (recs.length === 0) {
    recs.push("All checks passed. If users still see errors, capture the exact toast text and re-run diagnostics.");
  }
  return recs;
};
