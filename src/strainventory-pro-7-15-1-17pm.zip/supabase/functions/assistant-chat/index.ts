import { serve } from "std/http/server.ts";
import { createClient } from "@supabase/supabase-js";
import {
  buildAssistantOutputInstructions,
  buildPersonaPrompt,
  parseAssistantResponse,
  type AssistantAudienceRole,
} from "../_shared/assistantPayload.ts";
import {
  gatherDraftResearch,
  loadResearchPolicy,
  type ResearchMatch,
} from "../_shared/cannabisResearch.ts";
import { describeProviderFailure, resolveProviderConfig } from "../_shared/generateDraft.ts";
import { isWebSearchEnabled, runWebSearch } from "../_shared/webSearch.ts";
import { buildStrainVinnyPrompt, type WebSearchResult } from "../_shared/vinnyPrompt.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

interface AssistantChatRequest {
  thread_id?: string;
  message?: string;
  audience_role?: AssistantAudienceRole;
  page_context?: {
    id?: string;
    title?: string;
    description?: string;
  };
  user_profile?: {
    display_name?: string;
    role?: string;
  };
  workspace_snapshot?: {
    intake?: {
      brand?: string;
      strain?: string;
      productType?: string;
      packageSize?: string;
      vendor?: string;
    };
    route?: string;
  };
  web_search_enabled?: boolean;
  user_preferences?: {
    experience_level?: "novice" | "expert";
    preferred_tone?: "casual" | "professional";
  };
}

interface ProviderErrorPayload {
  error?: {
    message?: string;
  };
}

interface ChatChoice {
  finish_reason?: string | null;
  message?: {
    content?: string | null;
    refusal?: string;
  };
}

interface ChatCompletionPayload extends ProviderErrorPayload {
  choices?: ChatChoice[];
}

const jsonResponse = (body: Record<string, unknown>, status = 200) =>
  new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });

const toRole = (value?: string): AssistantAudienceRole =>
  value === "vendor" || value === "management" ? value : "employee";

const extractTerms = (value: string) =>
  Array.from(
    new Set(
      value
        .toLowerCase()
        .split(/[^a-z0-9]+/g)
        .filter((term) => term.length >= 3),
    ),
  ).slice(0, 5);

const trim = (value?: string) => value?.trim() ?? "";

const WEB_RESEARCH_HINTS = [
  "source",
  "sources",
  "citation",
  "citations",
  "evidence",
  "verify",
  "fact check",
  "web",
  "online",
  "research",
  "terpene",
  "thc",
  "cbd",
  "effects",
] as const;

const shouldRunWebResearch = (message: string, pageContextId: string, knowledgeRowsCount: number) => {
  const normalized = message.toLowerCase();
  if (WEB_RESEARCH_HINTS.some((hint) => normalized.includes(hint))) {
    return true;
  }
  // Keep responses useful in catalog/draft flows even when the user does not
  // explicitly ask for citations.
  if (pageContextId === "product_intake" || pageContextId === "ai_draft") {
    return true;
  }
  // If local knowledge is thin, enrich with trusted public sources.
  return knowledgeRowsCount < 2;
};

type SourceCitation = Pick<ResearchMatch, "source" | "domain" | "url" | "title"> & {
  snippet?: string;
};

const dedupeResearchMatches = (matches: ResearchMatch[]): SourceCitation[] => {
  const byUrl = new Map<string, SourceCitation>();
  for (const match of matches) {
    if (!byUrl.has(match.url)) {
      byUrl.set(match.url, match);
    }
  }
  return Array.from(byUrl.values());
};

const buildThreadTitle = (pageTitle: string, message: string) => {
  const normalized = message.replace(/\s+/g, " ").trim();
  if (!normalized) {
    return `${pageTitle} conversation`;
  }

  const teaser = normalized.length > 52 ? `${normalized.slice(0, 49)}...` : normalized;
  return `${pageTitle}: ${teaser}`;
};

const BUSINESS_TIME_ZONE = "America/Los_Angeles";

const getTimeZoneOffsetMs = (date: Date, timeZone: string) => {
  const parts = new Intl.DateTimeFormat("en-US", {
    timeZone,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hour12: false,
  }).formatToParts(date);
  const values = new Map(parts.map((part) => [part.type, part.value]));
  const zonedAsUtc = Date.UTC(
    Number(values.get("year")),
    Number(values.get("month")) - 1,
    Number(values.get("day")),
    Number(values.get("hour")),
    Number(values.get("minute")),
    Number(values.get("second")),
  );
  return zonedAsUtc - date.getTime();
};

const zonedStartOfDayIso = (timeZone = BUSINESS_TIME_ZONE) => {
  const now = new Date();
  const parts = new Intl.DateTimeFormat("en-US", {
    timeZone,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).formatToParts(now);
  const values = new Map(parts.map((part) => [part.type, part.value]));
  const utcMidnight = Date.UTC(
    Number(values.get("year")),
    Number(values.get("month")) - 1,
    Number(values.get("day")),
  );
  const candidate = new Date(utcMidnight - getTimeZoneOffsetMs(new Date(utcMidnight), timeZone));
  const offsetDelta = getTimeZoneOffsetMs(candidate, timeZone) - getTimeZoneOffsetMs(new Date(utcMidnight), timeZone);
  return new Date(candidate.getTime() - offsetDelta).toISOString();
};

const startOfPeriodIso = (days: number) => {
  const date = new Date();
  date.setDate(date.getDate() - days);
  return date.toISOString();
};

const numberValue = (value: unknown) => {
  const numeric = Number(value ?? 0);
  return Number.isFinite(numeric) ? numeric : 0;
};

const textValue = (value: unknown) => (typeof value === "string" && value.trim() ? value.trim() : "Unknown");

const formatCurrency = (value: number) => `$${value.toFixed(2)}`;

interface SalesSummaryItem {
  product_id: string;
  product_name: string;
  units: number;
  revenue: number;
}

interface SalespersonSummaryItem {
  user_id: string;
  orders: number;
  revenue: number;
}

interface AssistantDataContext {
  contextText: string;
  salesRecordCount: number;
  leadingProductCount: number;
  salespersonPerformanceCount: number;
}

type AssistantDataContextScope = "general" | "management";

const ASSISTANT_DATA_CONTEXT_TTL_MS = 60_000;
const assistantDataContextCache = new Map<
  AssistantDataContextScope,
  { expiresAt: number; value: AssistantDataContext }
>();

const buildAssistantDataContext = async (
  admin: ReturnType<typeof createClient>,
  scope: AssistantDataContextScope,
): Promise<AssistantDataContext> => {
  const shouldIncludeManagementData = scope === "management";
  const [salesResult, leadingProductsResult, salespersonResult, employeeResult] = await Promise.all([
    admin
      .from("orders")
      .select(
        shouldIncludeManagementData
          ? "id, created_at, payment_method, status, subtotal, tax, total, created_by, order_items(product_id, product_name, quantity, total_price)"
          : "id, created_at, status, total, order_items(product_id, product_name, quantity, total_price)",
      )
      .gte("created_at", zonedStartOfDayIso())
      .order("created_at", { ascending: false })
      .limit(25),
    admin
      .from("order_items")
      .select("product_id, product_name, quantity, total_price, products(brand, type, status, quantity, thc, cbd, terpenes, aroma, taste, effects, medical_uses)")
      .gte("created_at", startOfPeriodIso(30))
      .limit(200),
    shouldIncludeManagementData
      ? admin
          .from("orders")
          .select("created_by, total")
          .gte("created_at", startOfPeriodIso(30))
          .limit(250)
      : Promise.resolve({ data: [], error: null }),
    shouldIncludeManagementData
      ? admin
          .from("employees")
          .select("user_id, full_name, role, assigned_role, status")
          .limit(250)
      : Promise.resolve({ data: [], error: null }),
  ]);

  for (const result of [salesResult, leadingProductsResult, salespersonResult, employeeResult]) {
    if (result.error) {
      console.warn("assistant data context load failed", result.error.message);
    }
  }

  const employeeNames = new Map<string, string>();
  for (const employee of employeeResult.data ?? []) {
    if (employee.user_id) {
      employeeNames.set(
        String(employee.user_id),
        `${employee.full_name ?? "Unknown"} (${employee.assigned_role ?? employee.role ?? "staff"})`,
      );
    }
  }

  const salesLines = (salesResult.data ?? []).slice(0, 8).map((order) => {
    const items = Array.isArray(order.order_items)
      ? order.order_items
          .slice(0, 3)
          .map((item) => `${item.product_name ?? "Unknown"} x${item.quantity ?? 0}`)
          .join(", ")
      : "No items";
    const salesperson = order.created_by
      ? employeeNames.get(String(order.created_by)) ?? String(order.created_by)
      : "Unassigned";
    if (!shouldIncludeManagementData) {
      return `- ${order.id} | ${formatCurrency(numberValue(order.total))} | ${order.status ?? "n/a"} | ${items}`;
    }
    return `- ${order.id} | ${formatCurrency(numberValue(order.total))} | ${order.payment_method ?? "n/a"} | ${salesperson} | ${items}`;
  });

  const productSummary = new Map<string, SalesSummaryItem>();
  for (const item of leadingProductsResult.data ?? []) {
    const productId = String(item.product_id ?? item.product_name ?? "unknown");
    const existing =
      productSummary.get(productId) ??
      {
        product_id: productId,
        product_name: textValue(item.product_name),
        units: 0,
        revenue: 0,
      };
    existing.units += numberValue(item.quantity);
    existing.revenue += numberValue(item.total_price);
    productSummary.set(productId, existing);
  }
  const leadingProducts = Array.from(productSummary.values())
    .sort((a, b) => b.revenue - a.revenue || b.units - a.units)
    .slice(0, 8);
  const leadingProductLines = leadingProducts.map(
    (item) =>
      `- ${item.product_name} | Units: ${item.units} | Revenue: ${formatCurrency(item.revenue)} | Product ID: ${item.product_id}`,
  );

  const salespersonSummary = new Map<string, SalespersonSummaryItem>();
  for (const order of salespersonResult.data ?? []) {
    const userId = String(order.created_by ?? "unassigned");
    const existing = salespersonSummary.get(userId) ?? { user_id: userId, orders: 0, revenue: 0 };
    existing.orders += 1;
    existing.revenue += numberValue(order.total);
    salespersonSummary.set(userId, existing);
  }
  const salespersonPerformance = Array.from(salespersonSummary.values())
    .sort((a, b) => b.revenue - a.revenue || b.orders - a.orders)
    .slice(0, 8);
  const salespersonLines = salespersonPerformance.map((item) => {
    const label =
      item.user_id === "unassigned"
        ? "Unassigned"
        : employeeNames.get(item.user_id) ?? item.user_id;
    return `- ${label} | Orders: ${item.orders} | Revenue: ${formatCurrency(item.revenue)}`;
  });

  const contextText = [
    "Sales records today:",
    salesLines.length > 0 ? salesLines.join("\n") : "No sales records found for today.",
    "",
    "Leading products from the last 30 days:",
    leadingProductLines.length > 0 ? leadingProductLines.join("\n") : "No product sales found in the last 30 days.",
    "",
    shouldIncludeManagementData
      ? "Salesperson performance from the last 30 days:"
      : "Salesperson performance from the last 30 days: restricted to management users.",
    shouldIncludeManagementData
      ? salespersonLines.length > 0
        ? salespersonLines.join("\n")
        : "No salesperson performance found in the last 30 days."
      : "",
  ].join("\n");

  return {
    contextText,
    salesRecordCount: salesResult.data?.length ?? 0,
    leadingProductCount: leadingProducts.length,
    salespersonPerformanceCount: salespersonPerformance.length,
  };
};

const getAssistantDataContext = async (
  admin: ReturnType<typeof createClient>,
  scope: AssistantDataContextScope,
): Promise<AssistantDataContext> => {
  const now = Date.now();
  const cached = assistantDataContextCache.get(scope);
  if (cached && cached.expiresAt > now) {
    return cached.value;
  }

  const value = await buildAssistantDataContext(admin, scope);
  assistantDataContextCache.set(scope, {
    expiresAt: now + ASSISTANT_DATA_CONTEXT_TTL_MS,
    value,
  });
  return value;
};

const getUserRoles = async (
  admin: ReturnType<typeof createClient>,
  userId: string,
): Promise<{ roles: string[]; error: string | null }> => {
  const { data, error } = await admin.rpc("get_user_roles", { _user_id: userId });
  if (error) {
    console.warn("assistant user roles load failed", error.message);
    return { roles: [], error: error.message };
  }
  return { roles: Array.isArray(data) ? data.map((role) => String(role)) : [], error: null };
};

const resolveAuthorizedAudienceRole = async (
  admin: ReturnType<typeof createClient>,
  userId: string,
  requestedRole: AssistantAudienceRole,
): Promise<{ audienceRole: AssistantAudienceRole; authorizationNotice: string | null }> => {
  const { roles, error } = await getUserRoles(admin, userId);
  if (error) {
    if (requestedRole === "management") {
      throw new Error("Unable to verify management role for assistant data access. Please try again.");
    }
    return { audienceRole: requestedRole, authorizationNotice: "Role verification is temporarily unavailable." };
  }

  const canUseManagementContext = roles.includes("admin") || roles.includes("reviewer");
  if (requestedRole === "management" && !canUseManagementContext) {
    return {
      audienceRole: "employee",
      authorizationNotice: "Management data was not included because this account is not authorized for management context.",
    };
  }
  return { audienceRole: requestedRole, authorizationNotice: null };
};


const getSupabaseEnv = () => {
  const url = Deno.env.get("SUPABASE_URL");
  const serviceRole = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");

  if (!url || !serviceRole) {
    throw new Error("Supabase environment variables are not fully configured.");
  }

  return { url, serviceRole };
};

serve(async (req) => {
  const reqStart = performance.now();
  const reqId = crypto.randomUUID().slice(0, 8);
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const tParse = performance.now();
    const body = (await req.json()) as AssistantChatRequest;
    const parseMs = Math.round(performance.now() - tParse);
    const message = trim(body.message);
    if (!message) {
      return jsonResponse({ error: "message is required" }, 400);
    }

    const pageContext = {
      id: trim(body.page_context?.id) || "general",
      title: trim(body.page_context?.title) || "General Workspace",
      description: trim(body.page_context?.description) || "General operations support context",
    };
    const requestedAudienceRole = toRole(body.audience_role);

    const { url, serviceRole } = getSupabaseEnv();

    const admin = createClient(url, serviceRole, {
      auth: { persistSession: false },
    });

    // Require a real authenticated user. The Edge Functions gateway no
    // longer verifies JWTs for this function (see supabase/config.toml),
    // so we must verify here. Rejecting anonymous or anon-key-only callers
    // also prevents abuse of the DeepSeek/OpenAI completion endpoint.
    const anonKey = Deno.env.get("SUPABASE_ANON_KEY") ?? "";
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return jsonResponse({ error: "Sign in required." }, 401);
    }
    const bearerToken = authHeader.replace(/^Bearer\s+/i, "").trim();
    if (!bearerToken || (anonKey && bearerToken === anonKey)) {
      return jsonResponse({ error: "Sign in required." }, 401);
    }
    const tAuth = performance.now();
    const { data: authData, error: authError } = await admin.auth.getUser(bearerToken);
    if (authError || !authData?.user) {
      return jsonResponse({ error: "Invalid or expired session. Please sign in again." }, 401);
    }
    const userId = authData.user.id;
    const authMs = Math.round(performance.now() - tAuth);
    const { audienceRole, authorizationNotice } = await resolveAuthorizedAudienceRole(
      admin,
      userId,
      requestedAudienceRole,
    );
    const metadataFullName =
      typeof authData.user.user_metadata?.full_name === "string"
        ? trim(authData.user.user_metadata.full_name)
        : "";
    const emailHandle = trim(authData.user.email?.split("@")[0]);
    const userProfile = {
      displayName:
        trim(body.user_profile?.display_name) ||
        metadataFullName ||
        emailHandle ||
        undefined,
      role: trim(body.user_profile?.role) || audienceRole,
    };

    const requestedThreadId = trim(body.thread_id);
    const threadId = requestedThreadId || crypto.randomUUID();
    const nowIso = new Date().toISOString();

    if (requestedThreadId) {
      const { error: updateThreadError } = await admin
        .from("assistant_threads")
        .update({
          audience_role: audienceRole,
          page_context: pageContext,
          updated_at: nowIso,
        })
        .eq("id", threadId)
        .eq("user_id", userId);

      if (updateThreadError) {
        throw new Error(`Failed to update assistant thread: ${updateThreadError.message}`);
      }
    } else {
      const { error: createThreadError } = await admin.from("assistant_threads").upsert(
        {
          id: threadId,
          user_id: userId,
          audience_role: audienceRole,
          page_context: pageContext,
          title: buildThreadTitle(pageContext.title, message),
          updated_at: nowIso,
        },
        { onConflict: "id" },
      );

      if (createThreadError) {
        throw new Error(`Failed to create assistant thread: ${createThreadError.message}`);
      }
    }

    const { error: userMessageInsertError } = await admin.from("assistant_messages").insert({
      thread_id: threadId,
      user_id: userId,
      role: "user",
      content: message,
      context: {
        page_context: pageContext,
        workspace_snapshot: body.workspace_snapshot ?? {},
      },
    });

    if (userMessageInsertError) {
      throw new Error(`Failed to record user message: ${userMessageInsertError.message}`);
    }

    const { data: recentThreadMessages, error: recentThreadMessagesError } = await admin
      .from("assistant_messages")
      .select("role, content")
      .eq("thread_id", threadId)
      .eq("user_id", userId)
      .order("created_at", { ascending: false })
      .limit(8);

    if (recentThreadMessagesError) {
      console.warn("assistant recent thread messages load failed", recentThreadMessagesError.message);
    }

    const conversationContext =
      recentThreadMessages && recentThreadMessages.length > 0
        ? recentThreadMessages
            .slice()
            .reverse()
            .map((row) => ({
              role: row.role === "assistant" ? "assistant" : "user",
              content: row.content,
            }))
        : [
            {
              role: "user",
              content: `Audience role: ${audienceRole}\nUser message: ${message}`,
            },
          ];

    const { data: recentProducts } = await admin
      .from("products")
      .select("id, name, brand, type, product_type, strain, thc, cbd, terpenes, aroma, taste, effects, medical_uses, status, price, quantity, in_stock, updated_at")
      .order("updated_at", { ascending: false })
      .limit(10);

    const terms = extractTerms(message);
    let knowledgeRows: Array<Record<string, unknown>> = [];

    for (const term of terms) {
      const { data } = await admin
        .from("strain_knowledge_entries")
        .select("stable_key, name, type, thc, cbd, aromas, effects, terpenes, source_updated_at")
        .ilike("name", `%${term}%`)
        .limit(4);
      if (data && data.length > 0) {
        const next = [...knowledgeRows, ...data];
        const dedup = new Map<string, Record<string, unknown>>();
        for (const row of next) {
          const key = String(row.stable_key ?? row.name ?? crypto.randomUUID());
          if (!dedup.has(key)) dedup.set(key, row);
        }
        knowledgeRows = Array.from(dedup.values());
      }
      if (knowledgeRows.length >= 6) break;
    }

    const assistantDataContext = await getAssistantDataContext(
      admin,
      audienceRole === "management" ? "management" : "general",
    );

    const intake = body.workspace_snapshot?.intake;
    const runWebResearch = shouldRunWebResearch(message, pageContext.id, knowledgeRows.length);
    const policy = runWebResearch ? await loadResearchPolicy(admin) : undefined;
    const draftResearch = runWebResearch
      ? await gatherDraftResearch(
          {
            brand: trim(intake?.brand),
            strain: trim(intake?.strain) || message,
            productType: trim(intake?.productType),
            packageSize: trim(intake?.packageSize),
            vendor: trim(intake?.vendor),
          },
          { policy },
        )
      : { matches: [], promptText: "", warnings: [] };
    const webMatches = dedupeResearchMatches(draftResearch.matches);
    if (draftResearch.warnings.length > 0) {
      console.warn("assistant web research warnings:", draftResearch.warnings);
    }
    const externalFallback = draftResearch.promptText;

    const businessContext = (recentProducts ?? [])
      .map(
        (row) =>
          [
            `- ${row.name ?? "Unknown"} (${row.brand ?? "Unknown brand"})`,
            `Type: ${row.product_type ?? row.type ?? "n/a"}`,
            `Strain: ${row.strain ?? "n/a"}`,
            `THC: ${row.thc ?? "n/a"}`,
            `CBD: ${row.cbd ?? "n/a"}`,
            `Terpenes: ${row.terpenes ?? "n/a"}`,
            `Aroma: ${row.aroma ?? "n/a"}`,
            `Taste: ${row.taste ?? "n/a"}`,
            `Effects: ${row.effects ?? "n/a"}`,
            `Medical uses: ${row.medical_uses ?? "n/a"}`,
            `Price: ${row.price ?? "n/a"}`,
            `Qty: ${row.quantity ?? "n/a"}`,
            `ID: ${row.id}`,
            `Status: ${row.status ?? "n/a"}`,
          ].join(" | "),
      )
      .join("\n");

    const knowledgeContext = knowledgeRows
      .map((row) => {
        const aromas = Array.isArray(row.aromas) ? row.aromas.join(", ") : "";
        const effects = Array.isArray(row.effects) ? row.effects.join(", ") : "";
        const terpenes = Array.isArray(row.terpenes) ? row.terpenes.join(", ") : "";
        return `- ${row.name ?? "Unknown"} (${row.type ?? "n/a"}) | THC: ${row.thc ?? "n/a"} | CBD: ${row.cbd ?? "n/a"} | Aromas: ${aromas || "n/a"} | Effects: ${effects || "n/a"} | Terpenes: ${terpenes || "n/a"}`;
      })
      .join("\n");

    const provider = resolveProviderConfig();

    // ── Web search grounding ────────────────────────────────────────────────
    // Runs before the DeepSeek call so fresh top-N results can be injected as
    // [WEB CONTEXT] in the system prompt. Falls back to empty array on
    // timeout / failure / disabled-by-flag (never blocks the response).
    const webSearchEnabled = isWebSearchEnabled(body.web_search_enabled);
    let webResults: WebSearchResult[] = [];
    let webMs = 0;
    if (webSearchEnabled) {
      const tWeb = performance.now();
      webResults = await runWebSearch(message, { limit: 5 });
      webMs = Math.round(performance.now() - tWeb);
    }

    const dynamicPrompt = buildStrainVinnyPrompt({
      userQuery: message,
      webResults,
      currentPage: {
        id: pageContext.id,
        title: pageContext.title,
        description: pageContext.description,
        route: body.workspace_snapshot?.route,
      },
      userPreferences: body.user_preferences
        ? {
            experienceLevel: body.user_preferences.experience_level,
            preferredTone: body.user_preferences.preferred_tone,
          }
        : undefined,
      conversationHistory: conversationContext.map((turn) => ({
        role: turn.role === "assistant" ? "assistant" : "user",
        content: typeof turn.content === "string" ? turn.content : "",
      })),
      userProfile,
    });
    const assistantExample = `
[EXAMPLE OF IDEAL INTERACTION]
User: "I need to intake a new Blue Dream pre-roll from Green Leaf Farms."
Vinny: {
  "reply": "Hey ${userProfile.displayName || "buddy"}, let's get that Blue Dream into the system. I've already pre-filled the brand and product type. First step: confirm the package size, and we're off to the races.",
  "actions": [
    {
      "intent": "update_intake",
      "summary": "Pre-fill intake form with Blue Dream pre-roll",
      "proposed_changes": [
        "Set brand to Green Leaf Farms",
        "Set product type to Pre-roll",
        "Open /product-intake for review"
      ],
      "requires_confirmation": true,
      "execution_payload": {
        "route": "/product-intake",
        "intake_patch": {
          "brand": "Green Leaf Farms",
          "strain": "Blue Dream",
          "productType": "Pre-roll"
        }
      }
    }
  ],
  "sources": []
}`.trim();

    const requestBody: Record<string, unknown> = {
      model: provider.model,
      messages: [
        {
          role: "system",
          content: [
            dynamicPrompt,
            assistantExample,
            buildPersonaPrompt(audienceRole),
            `Current page context: ${pageContext.title} (${pageContext.id})`,
            `Context goal: ${pageContext.description}`,
            authorizationNotice ? `Authorization note: ${authorizationNotice}` : "",
            "When external sources are used, list them in the structured 'sources' array of your JSON response. Do not include a 'Sources checked:' block or inline [S1] markers in the reply text — the client renders sources separately.",
            "Retrieval priority order:",
            "1) Strain-ventory business data",
            "2) Synced Straindex strain knowledge",
            "3) External research fallback only when prior sources are insufficient",
            "For product information, search local product records and Straindex knowledge first. If key lab/product details are missing, use the external fallback context and cite sources.",
            "",
            "Business data:",
            businessContext || "No recent business product records found.",
            "",
            "Sales and performance data:",
            assistantDataContext.contextText,
            "",
            "Synced strain knowledge:",
            knowledgeContext || "No synced strain knowledge matches found.",
            "",
            externalFallback
              ? `External fallback context:\n${externalFallback}`
              : "External fallback context: not required for this response.",
            "",
            "Action policy: You must only recommend actions. Never imply automatic execution.",
            "Every action must require user confirmation before execution.",
            `Available internal routes: /, /product-intake, /ai-draft, /image-finder, /catalog, /catalog/:id, /bulk-intake, /review, /assistant, /messages, /pos, /shift-close, /settings, /onboarding, /payroll, /payroll/run.`,
            "When sending a link, use execution_payload.url with a full http(s) URL. When sharing a file, use execution_payload.file = { filename, mime_type, content }. When asked for a screenshot, use an action intent containing 'screenshot'.",
            "",
            "--- POS COPILOT DIRECTIVES ---",
            "If the user is in the 'Point of Sale' context and asking for a product recommendation:",
            "1. Analyze their request and the provided business data (live inventory).",
            "2. Recommend a substitute or complementary product.",
            "3. Format the action intent EXACTLY as 'RECOMMEND_AND_ADD_TO_CART'.",
            "4. The execution_payload MUST include 'product_id', 'weight' (e.g., '3.5g', '1g'), and 'qty'.",
            "5. The product_id MUST perfectly match an ID from the provided business data.",
            "For sales report, leading product, or salesperson performance requests, answer from Sales and performance data and recommend navigation to /shift-close when a dashboard route is useful.",
            "------------------------------",
            buildAssistantOutputInstructions(),
          ].join("\n"),
        },
        ...conversationContext,
      ],
      response_format: { type: "json_object" }, // <-- Your JSON lock is already here!
    };
    if (provider.model.includes("deepseek")) {
      requestBody.reasoning_effort = "medium";
    }

    if (!provider.model.includes("reasoner")) {
      requestBody.temperature = 0.2;
    }

    const tAi = performance.now();
    const aiResponse = await fetch(provider.apiUrl, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${provider.apiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify(requestBody),
    });
    const completion = (await aiResponse.json().catch(() => ({}))) as ChatCompletionPayload;
    const aiMs = Math.round(performance.now() - tAi);
    if (!aiResponse.ok) {
      throw new Error(
        describeProviderFailure(provider.provider, aiResponse.status, completion.error?.message),
      );
    }

    const choice = completion.choices?.[0];
    if (!choice) {
      throw new Error("AI provider did not return any choices");
    }
    if (choice.message?.refusal) {
      throw new Error(choice.message.refusal);
    }
    if (choice.finish_reason === "length") {
      throw new Error("AI response was truncated before the assistant reply finished.");
    }
    if (choice.finish_reason === "content_filter") {
      throw new Error("AI provider blocked this assistant response.");
    }
    if (choice.finish_reason === "insufficient_system_resource") {
      throw new Error("AI provider ran out of capacity before finishing the response.");
    }
    if (typeof choice.message?.content !== "string") {
      throw new Error("AI provider returned an empty response");
    }

    const parsed = parseAssistantResponse(choice.message.content);
    const resolvedSources = parsed.sources.length > 0 ? parsed.sources : webMatches;
    // Sources render as a dedicated UI block on the client; we do not append a
    // "Sources checked:" text block to the reply content (would duplicate).

    const tAssistantInsert = performance.now();
    const { data: assistantMessageRow, error: insertAssistantError } = await admin
      .from("assistant_messages")
      .insert({
        thread_id: threadId,
        user_id: userId,
        role: "assistant",
        content: parsed.reply,
        context: {
          actions: parsed.actions,
          sources: resolvedSources,
          page_context: pageContext,
          retrieval: {
            business_hits:
              (recentProducts?.length ?? 0) +
              assistantDataContext.salesRecordCount +
              assistantDataContext.leadingProductCount +
              assistantDataContext.salespersonPerformanceCount,
            knowledge_hits: knowledgeRows.length,
            external_fallback_used: runWebResearch,
            external_match_count: resolvedSources.length,
          },
        },
      })
      .select("id")
      .single();
    const assistantInsertMs = Math.round(performance.now() - tAssistantInsert);

    if (insertAssistantError) {
      console.warn("assistant message insert failed", insertAssistantError.message);
    }

    const totalMs = Math.round(performance.now() - reqStart);
    console.log(
      JSON.stringify({
        reqId,
        route: "assistant-chat",
        parseMs,
        authMs,
        aiMs,
        webMs,
        assistantInsertMs,
        totalMs,
        knowledgeHits: knowledgeRows.length,
        businessHits:
          (recentProducts?.length ?? 0) +
          assistantDataContext.salesRecordCount +
          assistantDataContext.leadingProductCount +
          assistantDataContext.salespersonPerformanceCount,
        webResearch: runWebResearch,
        webSearchEnabled,
        webSearchHits: webResults.length,
      }),
    );
    return jsonResponse({
      thread_id: threadId,
      message_id: assistantMessageRow?.id ?? null,
      reply: parsed.reply,
      actions: parsed.actions,
      sources: resolvedSources,
      retrieval: {
        business_hits:
          (recentProducts?.length ?? 0) +
          assistantDataContext.salesRecordCount +
          assistantDataContext.leadingProductCount +
          assistantDataContext.salespersonPerformanceCount,
        knowledge_hits: knowledgeRows.length,
        external_fallback_used: runWebResearch,
        external_match_count: resolvedSources.length,
      },
    });
  } catch (error: unknown) {
    console.error(
      JSON.stringify({
        reqId,
        route: "assistant-chat",
        totalMs: Math.round(performance.now() - reqStart),
        error: error instanceof Error ? error.message : String(error),
      }),
    );
    let message = "Unknown assistant-chat error";
    if (error instanceof Error) {
      message = error.message;
    } else if (error && typeof error === "object") {
      const err = error as { message?: unknown; details?: unknown; hint?: unknown; code?: unknown };
      if (typeof err.message === "string" && err.message.length > 0) {
        message = err.message;
      } else {
        try {
          message = JSON.stringify(error);
        } catch {
          message = String(error);
        }
      }
    }
    return jsonResponse({ error: message }, 500);
  }
});
