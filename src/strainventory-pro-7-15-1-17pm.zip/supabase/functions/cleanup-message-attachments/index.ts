import { createClient } from 'npm:@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers':
    'authorization, x-client-info, apikey, content-type, x-internal-job-token',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
}

const BUCKET = 'message-attachments'
const MAX_DELETE_PER_RUN = 100
const LIST_LIMIT = 1000

type JsonRecord = Record<string, unknown>
type StorageEntry = { name: string; id?: string | null; metadata?: JsonRecord | null }
// Supabase's Deno client currently infers incompatible generic defaults across
// helper boundaries for storage calls, so keep the local admin client structural.
// deno-lint-ignore no-explicit-any
type AdminClient = any

function jsonResponse(body: JsonRecord, status = 200): Response {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, 'Content-Type': 'application/json' },
  })
}

function parseJwtClaims(token: string): JsonRecord | null {
  const parts = token.split('.')
  if (parts.length < 2) return null
  try {
    const payload = parts[1]
      .replaceAll('-', '+')
      .replaceAll('_', '/')
      .padEnd(Math.ceil(parts[1].length / 4) * 4, '=')
    return JSON.parse(atob(payload)) as JsonRecord
  } catch {
    return null
  }
}

async function readJson(req: Request): Promise<JsonRecord> {
  if (req.method !== 'POST') return {}
  const contentType = req.headers.get('content-type') ?? ''
  if (!contentType.includes('application/json')) return {}
  try {
    return (await req.json()) as JsonRecord
  } catch {
    return {}
  }
}

async function ensureBucket(admin: AdminClient) {
  const { data, error } = await admin.storage.getBucket(BUCKET)
  if (!error && data) return { created: false }

  const notFound = error?.message?.toLowerCase().includes('not found') || error?.statusCode === '404'
  if (!notFound) throw error

  const { error: createError } = await admin.storage.createBucket(BUCKET, {
    public: false,
    allowedMimeTypes: ['image/jpeg', 'image/png', 'image/webp', 'image/gif', 'image/heic'],
    fileSizeLimit: 8 * 1024 * 1024,
  })
  if (createError) throw createError
  return { created: true }
}

async function listFilesRecursive(
  admin: AdminClient,
  prefix = '',
): Promise<string[]> {
  const paths: string[] = []
  let offset = 0

  while (true) {
    const { data, error } = await admin.storage.from(BUCKET).list(prefix, {
      limit: LIST_LIMIT,
      offset,
      sortBy: { column: 'name', order: 'asc' },
    })
    if (error) throw error
    const entries = (data ?? []) as StorageEntry[]
    if (entries.length === 0) break

    for (const entry of entries) {
      const fullPath = prefix ? `${prefix}/${entry.name}` : entry.name
      const isFolder = !entry.id && !entry.metadata
      if (isFolder) {
        paths.push(...(await listFilesRecursive(admin, fullPath)))
      } else {
        paths.push(fullPath)
      }
    }

    if (entries.length < LIST_LIMIT) break
    offset += LIST_LIMIT
  }

  return paths
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }
  if (req.method !== 'POST') {
    return jsonResponse({ error: 'Method not allowed' }, 405)
  }

  const supabaseUrl = Deno.env.get('SUPABASE_URL')
  const serviceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')
  const anonKey = Deno.env.get('SUPABASE_ANON_KEY') ?? Deno.env.get('SUPABASE_PUBLISHABLE_KEY')
  if (!supabaseUrl || !serviceRoleKey || !anonKey) {
    return jsonResponse({ error: 'Server misconfigured' }, 500)
  }

  const admin = createClient(supabaseUrl, serviceRoleKey, { auth: { persistSession: false } })
  const body = await readJson(req)
  const mode = typeof body.mode === 'string' ? body.mode : 'cleanup'

  if (mode === 'ensure') {
    const authHeader = req.headers.get('Authorization')
    if (!authHeader?.startsWith('Bearer ')) {
      return jsonResponse({ error: 'Unauthorized' }, 401)
    }
    const userClient = createClient(supabaseUrl, anonKey, {
      global: { headers: { Authorization: authHeader } },
      auth: { persistSession: false },
    })
    const { data: { user }, error: userError } = await userClient.auth.getUser()
    if (userError || !user) return jsonResponse({ error: 'Unauthorized' }, 401)

    try {
      const ensured = await ensureBucket(admin)
      return jsonResponse({ ok: true, bucket: BUCKET, ...ensured })
    } catch (error) {
      console.error('Failed to ensure message attachment bucket', error)
      return jsonResponse({ error: 'Bucket repair failed' }, 500)
    }
  }

  const authHeader = req.headers.get('Authorization')
  const token = authHeader?.startsWith('Bearer ') ? authHeader.slice('Bearer '.length).trim() : ''
  const claims = token ? parseJwtClaims(token) : null
  const isServiceRole = claims?.role === 'service_role'

  if (!isServiceRole) {
    const suppliedToken = req.headers.get('x-internal-job-token')
    const { data: secret, error: secretError } = await admin
      .from('internal_job_secrets')
      .select('token')
      .eq('name', 'message_attachment_cleanup')
      .maybeSingle()

    if (secretError || !secret?.token || suppliedToken !== secret.token) {
      return jsonResponse({ error: 'Forbidden' }, 403)
    }
  }

  try {
    const ensured = await ensureBucket(admin)
    const allPaths = await listFilesRecursive(admin)
    if (allPaths.length === 0) {
      return jsonResponse({ ok: true, bucket: BUCKET, scanned: 0, deleted: 0, orphaned: 0, ...ensured })
    }

    const referenced = new Set<string>()
    for (let start = 0; start < allPaths.length; start += LIST_LIMIT) {
      const chunk = allPaths.slice(start, start + LIST_LIMIT)
      const { data, error } = await admin
        .from('conversation_messages')
        .select('attachment_path')
        .in('attachment_path', chunk)
      if (error) throw error
      for (const row of data ?? []) {
        if (typeof row.attachment_path === 'string') referenced.add(row.attachment_path)
      }
    }

    const orphaned = allPaths.filter((path) => !referenced.has(path))
    const deleteTargets = orphaned.slice(0, MAX_DELETE_PER_RUN)
    let deleted = 0

    if (deleteTargets.length > 0) {
      const { data, error } = await admin.storage.from(BUCKET).remove(deleteTargets)
      if (error) throw error
      deleted = data?.length ?? deleteTargets.length
    }

    return jsonResponse({
      ok: true,
      bucket: BUCKET,
      scanned: allPaths.length,
      orphaned: orphaned.length,
      deleted,
      remaining: Math.max(orphaned.length - deleted, 0),
      ...ensured,
    })
  } catch (error) {
    console.error('Message attachment cleanup failed', error)
    return jsonResponse({ error: 'Cleanup failed' }, 500)
  }
})