import { createClient } from 'npm:@supabase/supabase-js@2'
import { corsHeaders } from 'npm:@supabase/supabase-js@2/cors'

// Dispatches scheduled emails whose scheduled_at <= now() onto the
// `transactional_emails` pgmq queue. Invoked every minute via pg_cron.
// Auth: relies on verify_jwt=true + service_role token from the cron job.

function parseJwtClaims(token: string): Record<string, unknown> | null {
  const parts = token.split('.')
  if (parts.length < 2) return null
  try {
    const payload = parts[1]
      .replaceAll('-', '+')
      .replaceAll('_', '/')
      .padEnd(Math.ceil(parts[1].length / 4) * 4, '=')
    return JSON.parse(atob(payload)) as Record<string, unknown>
  } catch {
    return null
  }
}

const BATCH_SIZE = 50

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders })
  }

  const supabaseUrl = Deno.env.get('SUPABASE_URL')
  const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')
  if (!supabaseUrl || !supabaseServiceKey) {
    return new Response(JSON.stringify({ error: 'Server misconfigured' }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    })
  }

  const auth = req.headers.get('Authorization')
  if (!auth?.startsWith('Bearer ')) {
    return new Response(JSON.stringify({ error: 'Unauthorized' }), {
      status: 401,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    })
  }
  const claims = parseJwtClaims(auth.slice('Bearer '.length).trim())
  if (claims?.role !== 'service_role') {
    return new Response(JSON.stringify({ error: 'Forbidden' }), {
      status: 403,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    })
  }

  const supabase = createClient(supabaseUrl, supabaseServiceKey)

  // Claim due rows. We update->returning to avoid double-dispatch from concurrent runs.
  const nowIso = new Date().toISOString()
  const { data: due, error: dueError } = await supabase
    .from('scheduled_emails')
    .select('id, message_id, template_name, recipient_email, payload')
    .eq('status', 'pending')
    .lte('scheduled_at', nowIso)
    .order('scheduled_at', { ascending: true })
    .limit(BATCH_SIZE)

  if (dueError) {
    console.error('Failed to read due scheduled emails', dueError)
    return new Response(JSON.stringify({ error: 'Read failed' }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    })
  }

  if (!due?.length) {
    return new Response(JSON.stringify({ dispatched: 0 }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    })
  }

  let dispatched = 0
  for (const row of due) {
    // Atomic claim: only proceed if still pending.
    const { data: claimed, error: claimError } = await supabase
      .from('scheduled_emails')
      .update({ status: 'dispatched', dispatched_at: new Date().toISOString() })
      .eq('id', row.id)
      .eq('status', 'pending')
      .select('id')
      .maybeSingle()

    if (claimError || !claimed) continue

    const payload = {
      ...(row.payload as Record<string, unknown>),
      queued_at: new Date().toISOString(),
    }

    const { error: enqueueError } = await supabase.rpc('enqueue_email', {
      queue_name: 'transactional_emails',
      payload,
    })

    if (enqueueError) {
      console.error('Failed to enqueue scheduled email', {
        id: row.id,
        error: enqueueError,
      })
      await supabase
        .from('scheduled_emails')
        .update({
          status: 'failed',
          error_message: enqueueError.message?.slice(0, 1000) ?? 'enqueue failed',
        })
        .eq('id', row.id)
      await supabase.from('email_send_log').insert({
        message_id: row.message_id,
        template_name: row.template_name,
        recipient_email: row.recipient_email,
        status: 'failed',
        error_message: 'Scheduled dispatch enqueue failed',
      })
      continue
    }

    await supabase.from('email_send_log').insert({
      message_id: row.message_id,
      template_name: row.template_name,
      recipient_email: row.recipient_email,
      status: 'pending',
    })
    dispatched++
  }

  return new Response(JSON.stringify({ dispatched, considered: due.length }), {
    headers: { ...corsHeaders, 'Content-Type': 'application/json' },
  })
})
