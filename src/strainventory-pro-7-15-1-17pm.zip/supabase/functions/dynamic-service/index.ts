import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { requireAuthenticatedUser } from "../_shared/auth.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

interface GoogleCustomSearchItem {
  link?: string;
  title?: string;
  displayLink?: string;
  image?: {
    width?: number;
    height?: number;
    byteSize?: number;
    thumbnailLink?: string;
  };
}

interface GoogleCustomSearchResponse {
  items?: GoogleCustomSearchItem[];
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const authResult = await requireAuthenticatedUser(req);
    if (authResult instanceof Response) {
      return authResult;
    }

    const GOOGLE_CSE_API_KEY = Deno.env.get("GOOGLE_CSE_API_KEY");
    if (!GOOGLE_CSE_API_KEY) throw new Error("GOOGLE_CSE_API_KEY is not configured");

    const GOOGLE_CSE_CX = Deno.env.get("GOOGLE_CSE_CX");
    if (!GOOGLE_CSE_CX) throw new Error("GOOGLE_CSE_CX is not configured");

    const GEMINI_API_KEY = Deno.env.get("GEMINI_API_KEY");
    if (!GEMINI_API_KEY) throw new Error("GEMINI_API_KEY is not configured");

    const { name, brand, type } = await req.json();
    if (!name && !brand) {
      return new Response(
        JSON.stringify({ error: "At least one of 'name' or 'brand' is required" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // 1. Google Custom Search
    const query = [name, brand, "product image high resolution"].filter(Boolean).join(" ");
    const params = new URLSearchParams({
      key: GOOGLE_CSE_API_KEY,
      cx: GOOGLE_CSE_CX,
      q: query,
      searchType: "image",
      num: "3",
      imgSize: "xlarge",
      safe: "off",
    });

    const googleRes = await fetch(`https://www.googleapis.com/customsearch/v1?${params.toString()}`);
    const googleData = await googleRes.json() as GoogleCustomSearchResponse;

    if (!googleRes.ok) {
      throw new Error(`Google API error [${googleRes.status}]: ${JSON.stringify(googleData)}`);
    }

    const rawImages = (googleData.items || []).map((item: GoogleCustomSearchItem, index: number) => ({
      id: `gcs-${Date.now()}-${index}`,
      url: item.link,
      alt: item.title || `${name} ${brand} image`,
      width: item.image?.width || 0,
      height: item.image?.height || 0,
      fileSize: item.image?.byteSize ? `${Math.round(item.image.byteSize / 1024)} KB` : "Unknown",
      thumbnailUrl: item.image?.thumbnailLink || item.link,
      source: item.displayLink || "web",
    }));

    // 2. Vision validation on each returned image
    const images = [];
    for (const img of rawImages) {
      let verification = { isMatch: false, reason: "Validation skipped" };

      try {
        const visionRes = await fetch(`https://generativelanguage.googleapis.com/v1beta/openai/chat/completions`, {
          method: "POST",
          headers: {
            Authorization: `Bearer ${GEMINI_API_KEY}`,
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            model: "gemini-1.5-flash",
            messages: [
              {
                role: "system",
                content: `You are a cannabis catalog auditor. Look at this image and determine if it visually matches the provided product details: Brand: ${brand || "Unknown"}, Name: ${name || "Unknown"}, Type: ${type || "Unknown"}. Respond with ONLY a valid JSON object with two fields: isMatch (boolean) and reason (a 1-sentence explanation). No other text.`,
              },
              {
                role: "user",
                content: [
                  { type: "text", text: `Does this image match the product "${name}" by "${brand}" (type: ${type || "Unknown"})?` },
                  { type: "image_url", image_url: { url: img.url } },
                ],
              },
            ],
            response_format: { type: "json_object" },
          }),
        });

        if (visionRes.ok) {
          const visionData = await visionRes.json();
          const content = visionData.choices?.[0]?.message?.content;
          if (content) {
            verification = JSON.parse(content);
          }
        } else {
          const errText = await visionRes.text();
          console.error("Vision API error:", visionRes.status, errText);
        }
      } catch (vErr) {
        console.error("Vision validation failed for image:", img.id, vErr);
      }

      images.push({ ...img, verification });
    }

    return new Response(JSON.stringify({ images }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (err) {
    console.error("fetch-product-images error:", err);
    return new Response(
      JSON.stringify({ error: err.message }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
