import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { requireAuthenticatedUser } from "../_shared/auth.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

interface SearchRequest {
  name?: string;
  brand?: string;
  type?: string;
  packageSize?: string;
  sku?: string;
  vendor?: string;
}

interface DuckDuckGoImageResult {
  image?: string;
  title?: string;
  thumbnail?: string;
  url?: string;
  width?: number;
  height?: number;
}

interface DuckDuckGoImageResponse {
  results?: DuckDuckGoImageResult[];
}

interface VerificationResult {
  isMatch: boolean;
  confidence: number;
  reason: string;
}

interface ImageCandidate {
  id: string;
  url: string;
  alt: string;
  width: number;
  height: number;
  fileSize: string;
  thumbnailUrl: string;
  source: string;
  pageUrl?: string;
  verification?: VerificationResult;
}

const DUCKDUCKGO_ORIGIN = "https://duckduckgo.com";

// Rotate through several realistic user-agents to reduce rate-limiting
const USER_AGENTS = [
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
  "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
  "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:125.0) Gecko/20100101 Firefox/125.0",
] as const;

const TRUSTED_CANNABIS_DOMAINS = [
  "allbud",
  "weedmaps",
  "myhavenstores",
  "shopphaven",
  "chronicguru",
  "coronaculture",
  "culturecannabisclub",
  "leafly",
  "iheartjane",
  "dutchie",
  "dispense",
  "jane",
] as const;

const pickUserAgent = () => USER_AGENTS[Math.floor(Math.random() * USER_AGENTS.length)];

const normalize = (value?: string) => value?.trim() ?? "";

/**
 * Extract the vqd token from the DuckDuckGo bootstrap page.
 * DDG has changed the format several times, so we try multiple patterns.
 */
const extractVqd = (html: string): string | null => {
  // Pattern 1: vqd="..." or vqd='...' (original format)
  const p1 = html.match(/vqd=["']([^"']+)["']/)?.[1];
  if (p1) return p1;

  // Pattern 2: vqd=xxx in a script tag without quotes
  const p2 = html.match(/vqd=([a-zA-Z0-9_-]{20,})/)?.[1];
  if (p2) return p2;

  // Pattern 3: "vqd":"..." in JSON embedded in the page
  const p3 = html.match(/"vqd"\s*:\s*"([^"]+)"/)?.[1];
  if (p3) return p3;

  // Pattern 4: vqd-xxx format sometimes used in newer DDG pages
  const p4 = html.match(/vqd[_-](\d+)\s*=\s*["']([^"']+)["']/)?.[2];
  if (p4) return p4;

  // Pattern 5: Look in nrj() or similar script function calls
  const p5 = html.match(/nrj\(\s*["']\/i\.js[^"']*vqd=([^&"']+)/)?.[1];
  if (p5) return p5;

  return null;
};

const getSourceDomain = (value?: string) => {
  if (!value) {
    return "";
  }

  try {
    return new URL(value).hostname.replace(/^www\./, "");
  } catch {
    return "";
  }
};

const typeHint = (type?: string) => {
  const normalized = normalize(type).toLowerCase();
  if (!normalized) return "cannabis product packaging";
  if (normalized.includes("vape")) return "vape cartridge packaging";
  if (normalized.includes("pre-roll")) return "pre-roll tube packaging";
  if (normalized.includes("edible")) return "edible package packaging";
  return `${normalized} packaging`;
};

const buildQueries = ({ name, brand, type, packageSize, sku, vendor }: SearchRequest) => {
  const queries = [
    [brand, name, type, packageSize, "cannabis product packaging"].filter(Boolean).join(" "),
    [brand, name, typeHint(type), "official product photo"].filter(Boolean).join(" "),
    [brand, name, sku, "product image"].filter(Boolean).join(" "),
    [vendor, brand, name, type, "dispensary menu photo"].filter(Boolean).join(" "),
  ];

  return [...new Set(queries.map((query) => query.trim()).filter(Boolean))].slice(0, 4);
};

/**
 * Fetch images from DuckDuckGo with retry logic and robust error handling.
 */
const fetchDuckDuckGoImages = async (query: string, attempt = 0): Promise<DuckDuckGoImageResult[]> => {
  const ua = pickUserAgent();
  const headers: Record<string, string> = {
    "Accept-Language": "en-US,en;q=0.9",
    "User-Agent": ua,
  };

  // Step 1: Get vqd token from bootstrap page
  const bootstrapParams = new URLSearchParams({
    q: query,
    iax: "images",
    ia: "images",
  });

  let bootstrapResponse: Response;
  try {
    bootstrapResponse = await fetch(`${DUCKDUCKGO_ORIGIN}/?${bootstrapParams.toString()}`, {
      headers,
    });
  } catch (fetchErr) {
    console.error("DuckDuckGo bootstrap network error", query, fetchErr);
    if (attempt < 2) {
      // Wait briefly and retry
      await new Promise((r) => setTimeout(r, 500 + attempt * 500));
      return fetchDuckDuckGoImages(query, attempt + 1);
    }
    throw new Error(`Network error reaching DuckDuckGo for "${query}"`);
  }

  const bootstrapHtml = await bootstrapResponse.text();

  if (!bootstrapResponse.ok) {
    console.error("DuckDuckGo bootstrap failed", query, bootstrapResponse.status);
    if (bootstrapResponse.status === 429 && attempt < 2) {
      // Rate limited — back off and retry
      await new Promise((r) => setTimeout(r, 1000 + attempt * 1500));
      return fetchDuckDuckGoImages(query, attempt + 1);
    }
    throw new Error(`DuckDuckGo returned ${bootstrapResponse.status} for "${query}"`);
  }

  const vqd = extractVqd(bootstrapHtml);
  if (!vqd) {
    console.error("DuckDuckGo bootstrap missing vqd token", query, "HTML length:", bootstrapHtml.length);
    if (attempt < 2) {
      await new Promise((r) => setTimeout(r, 800 + attempt * 600));
      return fetchDuckDuckGoImages(query, attempt + 1);
    }
    throw new Error(`DuckDuckGo did not return an image search token for "${query}"`);
  }

  // Step 2: Fetch actual image results
  const imageParams = new URLSearchParams({
    l: "us-en",
    o: "json",
    q: query,
    vqd,
    f: ",,,",
    p: "1",
  });

  let response: Response;
  try {
    response = await fetch(`${DUCKDUCKGO_ORIGIN}/i.js?${imageParams.toString()}`, {
      headers: {
        ...headers,
        Accept: "application/json",
        Referer: `${DUCKDUCKGO_ORIGIN}/`,
      },
    });
  } catch (fetchErr) {
    console.error("DuckDuckGo image fetch network error", query, fetchErr);
    if (attempt < 2) {
      await new Promise((r) => setTimeout(r, 500 + attempt * 500));
      return fetchDuckDuckGoImages(query, attempt + 1);
    }
    throw new Error(`Network error fetching images for "${query}"`);
  }

  const payload = (await response.json().catch(() => ({}))) as DuckDuckGoImageResponse;

  if (!response.ok) {
    console.error("DuckDuckGo image search failed", query, response.status);
    if (response.status === 429 && attempt < 2) {
      await new Promise((r) => setTimeout(r, 1000 + attempt * 1500));
      return fetchDuckDuckGoImages(query, attempt + 1);
    }
    throw new Error(`DuckDuckGo returned ${response.status} for "${query}"`);
  }

  return payload.results ?? [];
};

const heuristicScore = (image: ImageCandidate, request: SearchRequest): VerificationResult => {
  const haystack = `${normalize(image.alt)} ${normalize(image.source)} ${normalize(image.pageUrl)}`.toLowerCase();
  const brand = normalize(request.brand).toLowerCase();
  const name = normalize(request.name).toLowerCase();
  const type = normalize(request.type).toLowerCase();
  const packageSize = normalize(request.packageSize).toLowerCase();
  const sku = normalize(request.sku).toLowerCase();
  const vendor = normalize(request.vendor).toLowerCase();

  let score = 18;
  const reasons: string[] = [];

  if (brand && haystack.includes(brand)) {
    score += 24;
    reasons.push("brand match");
  }
  if (name && haystack.includes(name)) {
    score += 28;
    reasons.push("product name match");
  }
  if (type && haystack.includes(type)) {
    score += 10;
    reasons.push("product type match");
  }
  if (packageSize && haystack.includes(packageSize)) {
    score += 10;
    reasons.push("package size match");
  }
  if (sku && haystack.includes(sku)) {
    score += 18;
    reasons.push("SKU match");
  }
  if (vendor && haystack.includes(vendor)) {
    score += 8;
    reasons.push("vendor match");
  }

  if (TRUSTED_CANNABIS_DOMAINS.some((domain) => haystack.includes(domain))) {
    score += 8;
    reasons.push("trusted catalog source");
  }

  const packagingTerms = ["packaging", "jar", "bag", "box", "tube", "product", "label"];
  if (packagingTerms.some((term) => haystack.includes(term))) {
    score += 8;
    reasons.push("packaging terms");
  }

  const genericTerms = ["plant", "flower closeup", "bud", "buds", "leaf", "strain effects", "wallpaper"];
  if (genericTerms.some((term) => haystack.includes(term))) {
    score -= 18;
    reasons.push("generic strain photo");
  }

  if (image.width >= 1200) {
    score += 6;
  } else if (image.width >= 800) {
    score += 3;
  }

  const confidence = Math.max(5, Math.min(95, score));
  return {
    isMatch: confidence >= 45,
    confidence,
    reason: reasons.length > 0
      ? `DuckDuckGo image ranking: ${reasons.slice(0, 3).join(", ")}`
      : "DuckDuckGo image ranking: weak metadata match",
  };
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const authResult = await requireAuthenticatedUser(req);
    if (authResult instanceof Response) {
      return authResult;
    }

    const request = (await req.json()) as SearchRequest;
    if (!request.name && !request.brand) {
      return new Response(
        JSON.stringify({ error: "At least one of 'name' or 'brand' is required" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } },
      );
    }

    const queries = buildQueries(request);
    const candidates = new Map<string, ImageCandidate>();
    const searchErrors: string[] = [];

    // Run queries sequentially with small delays to avoid rate-limiting
    for (let i = 0; i < queries.length; i++) {
      const query = queries[i];
      try {
        if (i > 0) {
          // Small delay between queries to be respectful
          await new Promise((r) => setTimeout(r, 300));
        }
        const results = await fetchDuckDuckGoImages(query);
        for (const item of results.slice(0, 8)) {
          if (!item.image || candidates.has(item.image)) {
            continue;
          }

          candidates.set(item.image, {
            id: `ddg-${crypto.randomUUID()}`,
            url: item.image,
            alt: item.title || `${request.name || request.brand} product image`,
            width: item.width || 0,
            height: item.height || 0,
            fileSize: "Unknown",
            thumbnailUrl: item.thumbnail || item.image,
            source: getSourceDomain(item.url) || "DuckDuckGo",
            pageUrl: item.url,
          });
        }

        // If we already have enough candidates after the first query, skip remaining
        if (candidates.size >= 8) break;
      } catch (error) {
        const message = error instanceof Error ? error.message : "unknown search failure";
        searchErrors.push(message);
        continue;
      }
    }

    if (candidates.size === 0 && searchErrors.length > 0) {
      // Return an empty array with a warning instead of a hard error
      // This lets the client show "no results" instead of an error toast
      console.warn("All image search queries failed:", searchErrors);
      return new Response(
        JSON.stringify({ images: [], warning: searchErrors[0] }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } },
      );
    }

    const verifiedImages: ImageCandidate[] = [];
    for (const image of Array.from(candidates.values()).slice(0, 12)) {
      image.verification = heuristicScore(image, request);
      verifiedImages.push(image);
    }

    const realProductImages = verifiedImages
      .filter((image) => image.verification?.isMatch)
      .sort((left, right) => (right.verification?.confidence ?? 0) - (left.verification?.confidence ?? 0))
      .slice(0, 8);

    // If no images passed the match threshold, return the top-scoring ones anyway
    // so the user has something to choose from
    const finalImages = realProductImages.length > 0
      ? realProductImages
      : verifiedImages
          .sort((left, right) => (right.verification?.confidence ?? 0) - (left.verification?.confidence ?? 0))
          .slice(0, 4);

    return new Response(JSON.stringify({ images: finalImages }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (error: unknown) {
    console.error("fetch-product-images error:", error);
    const message = error instanceof Error ? error.message : "Unknown server error";
    return new Response(
      JSON.stringify({ error: message }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  }
});
