import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { handleDraftRequest } from "../_shared/generateDraft.ts";
import { requireAuthenticatedUser } from "../_shared/auth.ts";

serve(async (req) => {
  if (req.method !== "OPTIONS") {
    const authResult = await requireAuthenticatedUser(req);
    if (authResult instanceof Response) {
      return authResult;
    }
  }
  return handleDraftRequest(req, "generate-product-draft");
});
