import { createClient } from "https://esm.sh/@supabase/supabase-js@2.39.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

interface MetrcRequest {
  endpoint: string;
  method?: "GET" | "POST";
  body?: unknown;
  licenseNumber?: string;
}

function basicAuth(user: string, pass: string) {
  return "Basic " + btoa(`${user}:${pass}`);
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  const supabaseAdmin = createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
  );

  // Verify caller is authenticated
  const authHeader = req.headers.get("authorization");
  if (!authHeader) {
    return new Response(JSON.stringify({ error: "Missing authorization" }), {
      status: 401,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  const { data: { user }, error: userError } = await supabaseAdmin.auth.getUser(
    authHeader.replace("Bearer ", ""),
  );

  if (userError || !user) {
    return new Response(JSON.stringify({ error: "Unauthorized" }), {
      status: 401,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  // Check admin role
  const { data: roles } = await supabaseAdmin
    .from("user_roles")
    .select("role")
    .eq("user_id", user.id)
    .eq("role", "admin")
    .maybeSingle();

  if (!roles) {
    return new Response(JSON.stringify({ error: "Admin access required" }), {
      status: 403,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  // Parse request body
  let payload: MetrcRequest;
  try {
    payload = await req.json();
  } catch {
    return new Response(JSON.stringify({ error: "Invalid JSON body" }), {
      status: 400,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  const baseUrl = Deno.env.get("METRC_BASE_URL") || "https://sandbox-api-ca.metrc.com";
  const vendorKey = Deno.env.get("METRC_VENDOR_API_KEY");
  const userKey = Deno.env.get("METRC_USER_API_KEY");

  if (!vendorKey || !userKey) {
    return new Response(
      JSON.stringify({ error: "Metrc credentials not configured" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  }

  // Get license number from request or env fallback
  const licenseNumber = payload.licenseNumber || Deno.env.get("METRC_LICENSE_NUMBER");
  if (!licenseNumber) {
    return new Response(
      JSON.stringify({ error: "License number required" }),
      { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  }

  const url = new URL(payload.endpoint, baseUrl);
  url.searchParams.set("licenseNumber", licenseNumber);

  try {
    const fetchOptions: RequestInit = {
      method: payload.method || "GET",
      headers: {
        "Authorization": basicAuth(vendorKey, userKey),
        "Content-Type": "application/json",
      },
    };

    if (payload.method === "POST" && payload.body) {
      fetchOptions.body = JSON.stringify(payload.body);
    }

    const metrcRes = await fetch(url.toString(), fetchOptions);
    const text = await metrcRes.text();

    let json: unknown = null;
    try {
      json = JSON.parse(text);
    } catch {
      json = text;
    }

    // Log the operation
    await supabaseAdmin.from("metrc_sync_log").insert({
      operation: `${payload.method || "GET"} ${payload.endpoint}`,
      status: metrcRes.ok ? "success" : "error",
      details: {
        license_number: licenseNumber,
        status_code: metrcRes.status,
        response: json,
        request_body: payload.body,
      },
    });

    return new Response(
      JSON.stringify({ status: metrcRes.status, data: json }),
      {
        status: metrcRes.ok ? 200 : 502,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      },
    );
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    await supabaseAdmin.from("metrc_sync_log").insert({
      operation: `${payload.method || "GET"} ${payload.endpoint}`,
      status: "error",
      details: { error: message },
    });

    return new Response(
      JSON.stringify({ error: message }),
      { status: 502, headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  }
});
