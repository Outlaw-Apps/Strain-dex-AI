
import { serve } from "https://deno.land/std@0.177.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.57.4";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-pos-provider, x-pos-signature",
};

interface WebhookPayload {
  provider: "dutchie" | "jane" | "flowhub" | "blaze";
  event: "sale.created" | "inventory.updated" | "order.fulfilled" | "customer.updated";
  data: Record<string, unknown>;
  timestamp: string;
  signature?: string;
}

const encoder = new TextEncoder();

const json = (body: Record<string, unknown>, status = 200) =>
  new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });

const toHex = (buffer: ArrayBuffer) =>
  [...new Uint8Array(buffer)].map((byte) => byte.toString(16).padStart(2, "0")).join("");

const timingSafeEqual = (left: string, right: string) => {
  const leftBytes = encoder.encode(left);
  const rightBytes = encoder.encode(right);
  if (leftBytes.length !== rightBytes.length) return false;

  let diff = 0;
  for (let index = 0; index < leftBytes.length; index += 1) {
    diff |= leftBytes[index] ^ rightBytes[index];
  }
  return diff === 0;
};

const verifySignature = async (body: string, signatureHeader: string | null, secret: string) => {
  if (!signatureHeader) return false;
  const signature = signatureHeader.trim().replace(/^sha256=/i, "").toLowerCase();
  const key = await crypto.subtle.importKey(
    "raw",
    encoder.encode(secret),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"],
  );
  const digest = toHex(await crypto.subtle.sign("HMAC", key, encoder.encode(body)));
  return timingSafeEqual(digest, signature);
};

serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const webhookSecret = Deno.env.get("POS_WEBHOOK_SECRET");
    if (!webhookSecret) {
      return json({ error: "POS webhook secret is not configured." }, 500);
    }

    const bodyText = await req.text();
    const signatureHeader =
      req.headers.get("x-pos-signature") ?? req.headers.get("x-hub-signature-256");
    const signatureValid = await verifySignature(bodyText, signatureHeader, webhookSecret);
    if (!signatureValid) {
      return json({ error: "Invalid POS webhook signature." }, 401);
    }

    const supabase = createClient(supabaseUrl, serviceKey);

    let payload: WebhookPayload;
    try {
      payload = JSON.parse(bodyText) as WebhookPayload;
    } catch (error) {
      if (error instanceof SyntaxError) {
        return json({ error: "Invalid JSON payload." }, 400);
      }
      throw error;
    }
    const provider = req.headers.get("x-pos-provider") || payload.provider;

    console.log(`[POS Webhook] ${provider} - ${payload.event}`);

    switch (payload.event) {
      case "sale.created": {
        const externalId = String(payload.data.id ?? "").trim();
        if (!externalId) {
          return json({ error: "sale.created requires payload.data.id." }, 400);
        }
        const items = payload.data.items as
          | Array<{ product_id: string; quantity: number }>
          | undefined;
        if (Array.isArray(items) && items.length > 0) {
          const missingProductId = items.some((item) => !String(item.product_id ?? "").trim());
          if (missingProductId) {
            return json({ error: "sale.created items require product_id values." }, 400);
          }
        }

        const { data: saleProcessed, error } = await supabase.rpc("process_pos_sale", {
          _provider: provider,
          _external_id: externalId,
          _total: Number.isFinite(Number(payload.data.total)) ? Number(payload.data.total) : 0,
          _items: Array.isArray(items) ? items : [],
          _customer_id: payload.data.customer_id ? String(payload.data.customer_id) : null,
          _payload: payload.data,
          _occurred_at: payload.timestamp || new Date().toISOString(),
        });
        if (error) throw error;
        if (!saleProcessed) {
          return json({
            success: true,
            received: payload.event,
            duplicate: true,
            message: "Duplicate POS sale ignored.",
          });
        }
        break;
      }

      case "inventory.updated": {
        const productId = String(payload.data.product_id ?? "").trim();
        const stock = Number(payload.data.new_stock);
        if (!productId || !Number.isFinite(stock)) {
          return json({ error: "inventory.updated requires product_id and numeric new_stock." }, 400);
        }
        const { data: inventoryRows, error: inventoryError } = await supabase.from("products").update({
          stock,
          in_stock: stock > 0,
          last_synced_at: new Date().toISOString(),
        }).eq("external_pos_id", productId).select("id");
        if (inventoryError) throw inventoryError;
        if (!inventoryRows?.length) {
          return json({ error: `No product found for POS product_id "${productId}".` }, 404);
        }
        break;
      }

      case "order.fulfilled": {
        const orderId = String(payload.data.order_id ?? "").trim();
        if (!orderId) {
          return json({ error: "order.fulfilled requires payload.data.order_id." }, 400);
        }
        const { data: orderRows, error: orderError } = await supabase
          .from("orders")
          .update({ status: "completed" })
          .eq("external_id", orderId)
          .select("id");
        if (orderError) throw orderError;
        if (!orderRows?.length) {
          return json({ error: `No order found for POS order_id "${orderId}".` }, 404);
        }
        break;
      }

      default:
        console.log("Unhandled event:", payload.event);
    }

    return json({ success: true, received: payload.event });
  } catch (error) {
    console.error("POS webhook error:", error);
    return json({ error: error instanceof Error ? error.message : "Unknown error" }, 500);
  }
});