import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

// Provisions a "short-ID + PIN" user. Business operators use a short
// memorable ID (e.g. "DW01") plus a 4-6 digit PIN instead of an email +
// password. Under the hood we still use Supabase Auth — we synthesize a
// stable email from the short ID and derive the password from the PIN.

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
};

// Keep these in sync with src/lib/pinAuth.ts (client-side helper).
const SHORT_ID_EMAIL_DOMAIN = "pin.strainventory.local";
const PIN_PASSWORD_SUFFIX = ":strainv-pin";

const SHORT_ID_PATTERN = /^[A-Za-z0-9]{3,10}$/;
const PIN_PATTERN = /^\d{4,6}$/;

const VALID_ROLES = new Set(["admin", "reviewer", "staff"]);

interface ProvisionBody {
  short_id?: string;
  pin?: string;
  display_name?: string;
  role?: string;
  employee_id?: string | null;
}

interface UpdatePinBody {
  user_id?: string;
  short_id?: string;
  pin?: string;
}

interface DeleteBody {
  user_id?: string;
}

const json = (body: Record<string, unknown>, status = 200) =>
  new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });

const shortIdToEmail = (shortId: string) =>
  `${shortId.trim().toLowerCase()}@${SHORT_ID_EMAIL_DOMAIN}`;

const pinToPassword = (pin: string) => `${pin}${PIN_PASSWORD_SUFFIX}`;

// Deterministic hash so we can enforce a UNIQUE index on pin_hash without
// ever storing the raw PIN. Same PIN -> same hash, so duplicates collide.
const hashPin = async (pin: string): Promise<string> => {
  const data = new TextEncoder().encode(`strainv-pin-v1:${pin}`);
  const digest = await crypto.subtle.digest("SHA-256", data);
  return Array.from(new Uint8Array(digest))
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
};

const isPinTakenError = (msg: string | null | undefined) =>
  !!msg && /user_credentials_pin_hash_unique/i.test(msg);

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const serviceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const anonKey = Deno.env.get("SUPABASE_ANON_KEY")!;

    const authHeader = req.headers.get("Authorization");
    if (!authHeader) return json({ error: "No authorization header" }, 401);

    const anonClient = createClient(supabaseUrl, anonKey, {
      global: { headers: { Authorization: authHeader } },
    });
    const {
      data: { user: caller },
    } = await anonClient.auth.getUser();
    if (!caller) return json({ error: "Unauthorized" }, 401);

    const adminClient = createClient(supabaseUrl, serviceRoleKey);
    const { data: isAdmin, error: hasRoleError } = await adminClient.rpc("has_role", {
      _user_id: caller.id,
      _role: "admin",
    });
    if (hasRoleError) {
      return json({ error: `Failed to verify admin role: ${hasRoleError.message}` }, 500);
    }
    if (!isAdmin) return json({ error: "Admin access required" }, 403);

    if (req.method === "GET") {
      const { data, error } = await adminClient
        .from("user_credentials")
        .select("id, user_id, short_id, display_name, created_at, updated_at")
        .order("short_id");
      if (error) throw error;
      return json({ credentials: data ?? [] });
    }

    if (req.method !== "POST" && req.method !== "DELETE") {
      return json({ error: "Method not allowed" }, 405);
    }

    const payload = await req.json().catch(() => ({}));
    const payloadAction = (payload as { action?: unknown }).action;
    let action = "provision";
    if (typeof payloadAction === "string") {
      action = payloadAction;
    } else if (req.method === "DELETE") {
      action = "delete";
    }

    if (action === "provision") {
      const body = payload as ProvisionBody;
      const shortId = (body.short_id || "").trim();
      const pin = (body.pin || "").trim();
      const displayName = (body.display_name || "").trim() || null;
      const role = body.role && VALID_ROLES.has(body.role) ? body.role : "staff";
      const employeeId =
        typeof body.employee_id === "string" && body.employee_id.length > 0
          ? body.employee_id
          : null;

      if (!SHORT_ID_PATTERN.test(shortId)) {
        return json(
          {
            error:
              "Short ID must be 3-10 letters or digits (e.g. DW01, MAX, 4321).",
          },
          400,
        );
      }
      if (!PIN_PATTERN.test(pin)) {
        return json({ error: "PIN must be 4-6 digits." }, 400);
      }

      // Pre-flight: reject early with a clear message if this short_id is
      // already taken. Without this check the create-user call below would
      // fail with an opaque Supabase Auth error like "User already registered",
      // which admins see as a generic "Failed to create auth user..." toast.
      const { data: existingCred, error: credLookupErr } = await adminClient
        .from("user_credentials")
        .select("user_id, short_id, display_name")
        .ilike("short_id", shortId)
        .maybeSingle();
      if (credLookupErr) {
        return json(
          { error: `Short ID lookup failed: ${credLookupErr.message}` },
          500,
        );
      }
      if (existingCred) {
        return json(
          {
            error:
              `Short ID "${shortId}" is already assigned to ${existingCred.display_name ?? "another employee"}. ` +
              `Choose a different short ID, or use "Reset PIN" on the existing employee.`,
            code: "short_id_taken",
            existing: {
              user_id: existingCred.user_id,
              short_id: existingCred.short_id,
              display_name: existingCred.display_name,
            },
          },
          409,
        );
      }

      // Pre-flight: enforce PIN uniqueness across the whole organization.
      const pinHash = await hashPin(pin);
      const { data: pinClash, error: pinLookupErr } = await adminClient
        .from("user_credentials")
        .select("short_id, display_name")
        .eq("pin_hash", pinHash)
        .maybeSingle();
      if (pinLookupErr) {
        return json(
          { error: `PIN uniqueness check failed: ${pinLookupErr.message}` },
          500,
        );
      }
      if (pinClash) {
        return json(
          {
            error:
              `That PIN is already in use by ${pinClash.display_name ?? pinClash.short_id}. ` +
              `Every employee must have a unique PIN — please choose a different one.`,
            code: "pin_taken",
          },
          409,
        );
      }

      const email = shortIdToEmail(shortId);
      const password = pinToPassword(pin);

      const { data: created, error: createErr } =
        await adminClient.auth.admin.createUser({
          email,
          password,
          email_confirm: true,
          user_metadata: {
            short_id: shortId,
            display_name: displayName,
          },
        });
      if (createErr || !created.user) {
        const raw = createErr?.message ?? "";
        const normalized = raw.toLowerCase();
        // Orphan auth user: email exists in auth.users but no credential row
        // (e.g. a previous partial failure left the auth user behind). Give
        // the admin an actionable hint instead of the opaque Auth error.
        const isDuplicate =
          normalized.includes("already been registered") ||
          normalized.includes("already registered") ||
          normalized.includes("duplicate");
        if (isDuplicate) {
          return json(
            {
              error:
                `A login account already exists for short ID "${shortId}" but has no credential record. ` +
                `Ask a developer to delete the orphaned auth user, then retry.`,
              code: "auth_user_orphaned",
            },
            409,
          );
        }
        return json(
          {
            error: raw || "Failed to create auth user for the supplied short ID.",
          },
          400,
        );
      }
      const newUserId = created.user.id;

      // Assign role. The auth.users INSERT trigger already inserts a 'staff'
      // row, so we only upsert if the requested role is different.
      if (role !== "staff") {
        const { error: roleErr } = await adminClient
          .from("user_roles")
          .upsert({ user_id: newUserId, role }, { onConflict: "user_id,role" });
        if (roleErr) {
          await adminClient.auth.admin.deleteUser(newUserId);
          return json({ error: `Failed to assign role: ${roleErr.message}` }, 400);
        }
      }

      const { error: credErr } = await adminClient
        .from("user_credentials")
        .insert({
          user_id: newUserId,
          short_id: shortId,
          display_name: displayName,
          pin_hash: pinHash,
          created_by: caller.id,
        });
      if (credErr) {
        await adminClient.auth.admin.deleteUser(newUserId);
        if (isPinTakenError(credErr.message)) {
          return json(
            {
              error:
                "That PIN was just claimed by another employee. Please choose a different PIN.",
              code: "pin_taken",
            },
            409,
          );
        }
        return json(
          { error: `Failed to record credential: ${credErr.message}` },
          400,
        );
      }

      if (employeeId) {
        const { error: empErr } = await adminClient
          .from("employees")
          .update({
            user_id: newUserId,
            status: "approved",
            approved_at: new Date().toISOString(),
            approved_by: caller.id,
            rejected_at: null,
            rejection_reason: null,
          })
          .eq("id", employeeId);
        if (empErr) {
          // Non-fatal — the auth user and credential were already created.
          console.warn("Failed to link employee:", empErr.message);
        }
      }

      return json({
        success: true,
        user: { id: newUserId, short_id: shortId, email },
      });
    }

    if (action === "update_pin" || action === "reset_pin") {
      const body = payload as UpdatePinBody;
      let userId = (body.user_id || "").trim();
      const shortId = (body.short_id || "").trim();
      const pin = (body.pin || "").trim();
      if (!PIN_PATTERN.test(pin)) {
        return json({ error: "PIN must be 4-6 digits." }, 400);
      }
      if (!userId && shortId) {
        const { data: cred, error: credErr } = await adminClient
          .from("user_credentials")
          .select("user_id")
          .ilike("short_id", shortId)
          .maybeSingle();
        if (credErr) {
          return json(
            { error: `Short ID lookup failed: ${credErr.message}` },
            500,
          );
        }
        if (!cred?.user_id) {
          return json(
            { error: `No login exists for short ID "${shortId}".` },
            404,
          );
        }
        userId = cred.user_id;
      }
      if (!userId) {
        return json({ error: "Either user_id or short_id is required." }, 400);
      }

      // Enforce PIN uniqueness across the organization, ignoring this user's own row.
      const pinHash = await hashPin(pin);
      const { data: pinClash, error: pinLookupErr } = await adminClient
        .from("user_credentials")
        .select("user_id, short_id, display_name")
        .eq("pin_hash", pinHash)
        .neq("user_id", userId)
        .maybeSingle();
      if (pinLookupErr) {
        return json(
          { error: `PIN uniqueness check failed: ${pinLookupErr.message}` },
          500,
        );
      }
      if (pinClash) {
        return json(
          {
            error:
              `That PIN is already in use by ${pinClash.display_name ?? pinClash.short_id}. ` +
              `Every employee must have a unique PIN — please choose a different one.`,
            code: "pin_taken",
          },
          409,
        );
      }

      const { error } = await adminClient.auth.admin.updateUserById(userId, {
        password: pinToPassword(pin),
      });
      if (error) return json({ error: error.message }, 400);

      const { error: credUpdateErr } = await adminClient
        .from("user_credentials")
        .update({ pin_hash: pinHash })
        .eq("user_id", userId);
      if (credUpdateErr) {
        if (isPinTakenError(credUpdateErr.message)) {
          return json(
            {
              error:
                "That PIN was just claimed by another employee. Please choose a different PIN.",
              code: "pin_taken",
            },
            409,
          );
        }
        return json(
          { error: `Failed to record PIN hash: ${credUpdateErr.message}` },
          400,
        );
      }
      return json({ success: true, user_id: userId });
    }

    if (action === "delete") {
      const body = payload as DeleteBody;
      const userId = (body.user_id || "").trim();
      if (!userId) return json({ error: "user_id is required." }, 400);
      const { error } = await adminClient.auth.admin.deleteUser(userId);
      if (error) return json({ error: error.message }, 400);
      return json({ success: true });
    }

    return json({ error: "Unknown action" }, 400);
  } catch (err: unknown) {
    return json(
      { error: err instanceof Error ? err.message : "Unknown error" },
      500,
    );
  }
});
