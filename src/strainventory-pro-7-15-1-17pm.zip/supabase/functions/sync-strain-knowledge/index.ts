import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.57.4";
import { buildSyncPlan, toIso } from "../_shared/strainKnowledgeSync.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

interface StrainKnowledgePhotoAttachment {
  local_photo_id: number;
  file_name: string;
  content_type: string;
  data_uri: string;
  added_at: string;
}

interface StrainKnowledgeRecord {
  stable_key: string;
  source_updated_at: string;
  name: string;
  type: "indica" | "sativa" | "hybrid";
  thc: string;
  cbd: string;
  cbn: string | null;
  effects: string[];
  flavors: string[];
  aromas: string[];
  description: string;
  terpenes: string[];
  lineage: string;
  grow_difficulty: "easy" | "moderate" | "hard";
  flowering_time: string;
  photos: StrainKnowledgePhotoAttachment[];
}

interface StrainKnowledgeExportV1 {
  version: string;
  source_app: string;
  generated_at: string;
  device_id: string;
  strains: StrainKnowledgeRecord[];
}

const jsonResponse = (body: Record<string, unknown>, status = 200) =>
  new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });

const readEnv = () => {
  const url = Deno.env.get("SUPABASE_URL");
  const anonKey = Deno.env.get("SUPABASE_ANON_KEY") ?? Deno.env.get("SUPABASE_PUBLISHABLE_KEY");
  const serviceRole = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
  if (!url || !anonKey || !serviceRole) {
    throw new Error("Missing required Supabase function environment variables.");
  }
  return { url, anonKey, serviceRole };
};

const toArray = (value: unknown) => (Array.isArray(value) ? value : []);

const validatePayload = (payload: unknown): payload is StrainKnowledgeExportV1 => {
  if (!payload || typeof payload !== "object" || Array.isArray(payload)) return false;
  const obj = payload as Record<string, unknown>;
  return (
    typeof obj.version === "string" &&
    typeof obj.source_app === "string" &&
    typeof obj.generated_at === "string" &&
    typeof obj.device_id === "string" &&
    Array.isArray(obj.strains)
  );
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { url, anonKey, serviceRole } = readEnv();
    const authClient = createClient(url, anonKey, {
      global: { headers: { Authorization: req.headers.get("Authorization") ?? "" } },
      auth: { persistSession: false },
    });
    const { data: authData, error: authError } = await authClient.auth.getUser();
    if (authError || !authData.user) {
      return jsonResponse({ error: "Authentication required for sync-strain-knowledge." }, 401);
    }
    const user = authData.user;

    const payload = await req.json();
    if (!validatePayload(payload)) {
      return jsonResponse({ error: "Invalid payload. Expected StrainKnowledgeExportV1." }, 400);
    }

    const admin = createClient(url, serviceRole, { auth: { persistSession: false } });
    const strainRecords = payload.strains;
    if (strainRecords.length === 0) {
      return jsonResponse({
        success: true,
        synced: 0,
        skipped: 0,
        images_synced: 0,
      });
    }

    const stableKeys = strainRecords.map((record) => record.stable_key);
    const { data: existingRows, error: existingError } = await admin
      .from("strain_knowledge_entries")
      .select("id, stable_key, source_updated_at")
      .in("stable_key", stableKeys);
    if (existingError) throw existingError;

    const existingMap = new Map<string, { id: string; source_updated_at: string }>();
    for (const row of existingRows ?? []) {
      existingMap.set(String(row.stable_key), {
        id: String(row.id),
        source_updated_at: String(row.source_updated_at),
      });
    }

    const { toUpsert: planRows, skipped } = buildSyncPlan(
      Array.from(existingMap.entries()).map(([stable_key, value]) => ({
        stable_key,
        source_updated_at: value.source_updated_at,
      })),
      strainRecords.map((record) => ({
        stable_key: record.stable_key,
        source_updated_at: record.source_updated_at,
      })),
    );

    const toUpsert = planRows
      .map((planRow) => strainRecords.find((record) => record.stable_key === planRow.stable_key))
      .filter((record): record is StrainKnowledgeRecord => !!record)
      .map((record) => ({
        stable_key: record.stable_key,
        name: record.name,
        type: record.type,
        thc: record.thc,
        cbd: record.cbd,
        cbn: record.cbn,
        effects: record.effects,
        flavors: record.flavors,
        aromas: record.aromas,
        description: record.description,
        terpenes: record.terpenes,
        lineage: record.lineage,
        grow_difficulty: record.grow_difficulty,
        flowering_time: record.flowering_time,
        source_updated_at: toIso(record.source_updated_at),
        source_device_id: payload.device_id,
        source_app: payload.source_app,
        source_user_id: user.id,
      }));

    let synced = 0;
    let imagesSynced = 0;
    const upsertedByKey = new Map<string, string>();

    if (toUpsert.length > 0) {
      const { data: upsertedRows, error: upsertError } = await admin
        .from("strain_knowledge_entries")
        .upsert(toUpsert, { onConflict: "stable_key" })
        .select("id, stable_key");
      if (upsertError) throw upsertError;

      for (const row of upsertedRows ?? []) {
        upsertedByKey.set(String(row.stable_key), String(row.id));
      }
      synced = toUpsert.length;
    }

    for (const record of strainRecords) {
      const entryId = upsertedByKey.get(record.stable_key);
      if (!entryId) continue;

      await admin
        .from("strain_knowledge_images")
        .delete()
        .eq("entry_id", entryId);

      const photos = toArray(record.photos)
        .map((photo) => {
          const obj = photo as Record<string, unknown>;
          return {
            entry_id: entryId,
            local_photo_id: Number(obj.local_photo_id ?? -1),
            file_name: String(obj.file_name ?? "photo"),
            content_type: String(obj.content_type ?? "image/jpeg"),
            data_uri: String(obj.data_uri ?? ""),
            added_at: typeof obj.added_at === "string" ? toIso(obj.added_at) : new Date().toISOString(),
          };
        })
        .filter((photo) => photo.data_uri.startsWith("data:image/"));

      if (photos.length > 0) {
        const { error: imageInsertError } = await admin.from("strain_knowledge_images").insert(photos);
        if (imageInsertError) throw imageInsertError;
        imagesSynced += photos.length;
      }
    }

    return jsonResponse({
      success: true,
      synced,
      skipped,
      images_synced: imagesSynced,
    });
  } catch (error: unknown) {
    console.error("sync-strain-knowledge error:", error);
    const message = error instanceof Error ? error.message : "Unknown sync-strain-knowledge error";
    return jsonResponse({ error: message }, 500);
  }
});
