
-- Create products table
CREATE TABLE IF NOT EXISTS public.products (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  brand TEXT NOT NULL,
  type TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'draft',
  confidence INTEGER NOT NULL DEFAULT 0,
  thc TEXT NOT NULL DEFAULT '',
  cbd TEXT NOT NULL DEFAULT '',
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  strain TEXT NOT NULL DEFAULT '',
  sku TEXT NOT NULL DEFAULT '',
  package_size TEXT NOT NULL DEFAULT '',
  terpenes TEXT NOT NULL DEFAULT '',
  aroma TEXT NOT NULL DEFAULT '',
  taste TEXT NOT NULL DEFAULT '',
  effects TEXT NOT NULL DEFAULT '',
  medical_uses TEXT NOT NULL DEFAULT '',
  short_description TEXT NOT NULL DEFAULT '',
  long_description TEXT NOT NULL DEFAULT '',
  images JSONB NOT NULL DEFAULT '[]'::jsonb,
  created_by UUID REFERENCES auth.users(id),
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.products ENABLE ROW LEVEL SECURITY;

-- All authenticated users can read products
DROP POLICY IF EXISTS "Authenticated users can view products" ON public.products;
CREATE POLICY "Authenticated users can view products"
  ON public.products FOR SELECT TO authenticated
  USING (true);

-- Staff, admin, reviewer can insert
DROP POLICY IF EXISTS "Authenticated users can insert products" ON public.products;
CREATE POLICY "Authenticated users can insert products"
  ON public.products FOR INSERT TO authenticated
  WITH CHECK (true);

-- Admin and reviewer can update
DROP POLICY IF EXISTS "Admin and reviewer can update products" ON public.products;
CREATE POLICY "Admin and reviewer can update products"
  ON public.products FOR UPDATE TO authenticated
  USING (
    public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'reviewer')
  );

-- Admin can delete
DROP POLICY IF EXISTS "Admin can delete products" ON public.products;
CREATE POLICY "Admin can delete products"
  ON public.products FOR DELETE TO authenticated
  USING (public.has_role(auth.uid(), 'admin'));
