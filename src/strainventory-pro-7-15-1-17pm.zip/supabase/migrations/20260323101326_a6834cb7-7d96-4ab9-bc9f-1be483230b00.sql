
-- Time entries table for clock-in/clock-out tracking
CREATE TABLE IF NOT EXISTS public.time_entries (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  clock_in timestamptz NOT NULL DEFAULT now(),
  clock_out timestamptz,
  notes text NOT NULL DEFAULT '',
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.time_entries ENABLE ROW LEVEL SECURITY;

-- Users can view their own entries
DROP POLICY IF EXISTS "Users can view own time entries" ON public.time_entries;
CREATE POLICY "Users can view own time entries"
  ON public.time_entries FOR SELECT TO authenticated
  USING (auth.uid() = user_id);

-- Admins can view all entries
DROP POLICY IF EXISTS "Admins can view all time entries" ON public.time_entries;
CREATE POLICY "Admins can view all time entries"
  ON public.time_entries FOR SELECT TO authenticated
  USING (public.has_role(auth.uid(), 'admin'));

-- Users can insert their own entries
DROP POLICY IF EXISTS "Users can clock in" ON public.time_entries;
CREATE POLICY "Users can clock in"
  ON public.time_entries FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- Users can update their own entries (clock out)
DROP POLICY IF EXISTS "Users can clock out" ON public.time_entries;
CREATE POLICY "Users can clock out"
  ON public.time_entries FOR UPDATE TO authenticated
  USING (auth.uid() = user_id);

-- Admins can update any entry
DROP POLICY IF EXISTS "Admins can update time entries" ON public.time_entries;
CREATE POLICY "Admins can update time entries"
  ON public.time_entries FOR UPDATE TO authenticated
  USING (public.has_role(auth.uid(), 'admin'));
