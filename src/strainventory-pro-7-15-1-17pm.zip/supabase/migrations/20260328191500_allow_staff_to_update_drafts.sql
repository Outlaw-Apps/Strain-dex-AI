DROP POLICY IF EXISTS "Admin and reviewer can update products" ON public.products;
DROP POLICY IF EXISTS "Authenticated users can update drafts" ON public.products;

CREATE POLICY "Authenticated users can update drafts"
  ON public.products FOR UPDATE TO authenticated
  USING (
    status = 'draft'
    OR public.has_role(auth.uid(), 'admin')
    OR public.has_role(auth.uid(), 'reviewer')
  )
  WITH CHECK (
    status = 'draft'
    OR public.has_role(auth.uid(), 'admin')
    OR public.has_role(auth.uid(), 'reviewer')
  );
