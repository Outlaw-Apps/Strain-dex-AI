-- Customer fields for driver's license scanning + age verification
ALTER TABLE public.customers ADD COLUMN IF NOT EXISTS license_number text;
ALTER TABLE public.customers ADD COLUMN IF NOT EXISTS date_of_birth date;
ALTER TABLE public.customers ADD COLUMN IF NOT EXISTS last_age_verified_at timestamptz;

-- Unique index so license_number lookups are fast and prevent duplicates
CREATE UNIQUE INDEX IF NOT EXISTS customers_license_number_unique
  ON public.customers (license_number)
  WHERE license_number IS NOT NULL;

-- Employee badge number for time-clock scanning
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS badge_number text;

CREATE UNIQUE INDEX IF NOT EXISTS profiles_badge_number_unique
  ON public.profiles (badge_number)
  WHERE badge_number IS NOT NULL;
