-- Payroll tables (idempotent: safe to re-run after a failed or partial migration)
-- Uses IF NOT EXISTS for tables and DROP POLICY IF EXISTS before each CREATE POLICY.

CREATE TABLE IF NOT EXISTS public.employee_payroll_profiles (
    employee_id        UUID PRIMARY KEY REFERENCES auth.users (id) ON DELETE CASCADE,
    hourly_rate_cents  INTEGER     NOT NULL DEFAULT 0,
    tax_withholding_pct NUMERIC(5, 2) DEFAULT 0,
    notes              TEXT,
    created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at         TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.pay_periods (
    id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    label       TEXT        NOT NULL,
    period_start DATE       NOT NULL,
    period_end   DATE       NOT NULL,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.payslips (
    id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    employee_id    UUID        NOT NULL REFERENCES auth.users (id) ON DELETE CASCADE,
    pay_period_id  UUID        NOT NULL REFERENCES public.pay_periods (id) ON DELETE CASCADE,
    gross_cents    INTEGER     NOT NULL DEFAULT 0,
    net_cents      INTEGER     NOT NULL DEFAULT 0,
    hours_worked   NUMERIC(10, 2),
    metadata       JSONB       NOT NULL DEFAULT '{}',
    created_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (employee_id, pay_period_id)
);

CREATE INDEX IF NOT EXISTS payslips_employee_id_idx ON public.payslips (employee_id);
CREATE INDEX IF NOT EXISTS payslips_pay_period_id_idx ON public.payslips (pay_period_id);

ALTER TABLE public.employee_payroll_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.pay_periods ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.payslips ENABLE ROW LEVEL SECURITY;

-- employee_payroll_profiles
DROP POLICY IF EXISTS "Admins full access on payroll profiles" ON public.employee_payroll_profiles;
CREATE POLICY "Admins full access on payroll profiles"
    ON public.employee_payroll_profiles FOR ALL
    USING (public.has_role(auth.uid(), 'admin'))
    WITH CHECK (public.has_role(auth.uid(), 'admin'));

DROP POLICY IF EXISTS "Users can view own payroll profile" ON public.employee_payroll_profiles;
CREATE POLICY "Users can view own payroll profile"
    ON public.employee_payroll_profiles FOR SELECT
    USING (auth.uid() = employee_id);

-- pay_periods
DROP POLICY IF EXISTS "Admins full access on pay periods" ON public.pay_periods;
CREATE POLICY "Admins full access on pay periods"
    ON public.pay_periods FOR ALL
    USING (public.has_role(auth.uid(), 'admin'))
    WITH CHECK (public.has_role(auth.uid(), 'admin'));

DROP POLICY IF EXISTS "Authenticated users can read pay periods" ON public.pay_periods;
CREATE POLICY "Authenticated users can read pay periods"
    ON public.pay_periods FOR SELECT
    USING (auth.uid() IS NOT NULL);

-- payslips
DROP POLICY IF EXISTS "Admins full access on payslips" ON public.payslips;
CREATE POLICY "Admins full access on payslips"
    ON public.payslips FOR ALL
    USING (public.has_role(auth.uid(), 'admin'))
    WITH CHECK (public.has_role(auth.uid(), 'admin'));

DROP POLICY IF EXISTS "Users can view own payslips" ON public.payslips;
CREATE POLICY "Users can view own payslips"
    ON public.payslips FOR SELECT
    USING (auth.uid() = employee_id);
