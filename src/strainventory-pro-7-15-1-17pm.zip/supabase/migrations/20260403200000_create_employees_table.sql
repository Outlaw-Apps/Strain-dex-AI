-- Create employees table for onboarding records (idempotent)
CREATE TABLE IF NOT EXISTS public.employees (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  full_name TEXT NOT NULL,
  date_of_birth DATE NOT NULL,
  phone TEXT NOT NULL,
  email TEXT NOT NULL,
  emergency_contact TEXT NOT NULL,
  role TEXT NOT NULL CHECK (role IN ('budtender', 'shift_lead', 'inventory', 'security')),
  badge_number TEXT NOT NULL,
  live_scan_status TEXT NOT NULL CHECK (live_scan_status IN ('pending', 'cleared')),
  mmic_number TEXT,
  government_id_url TEXT,
  sop_handbook_acknowledged BOOLEAN NOT NULL DEFAULT false,
  status TEXT NOT NULL DEFAULT 'pending_review',
  assigned_role TEXT NOT NULL DEFAULT 'staff',
  created_by UUID REFERENCES auth.users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Enable RLS (safe to call repeatedly)
ALTER TABLE public.employees ENABLE ROW LEVEL SECURITY;

-- Policies: drop-then-create to avoid "already exists" errors on re-run
DO $$ BEGIN
  DROP POLICY IF EXISTS "Admins have full access to employees" ON public.employees;
  DROP POLICY IF EXISTS "Admins can insert employees" ON public.employees;
  DROP POLICY IF EXISTS "Users can read own created employees" ON public.employees;
END $$;

CREATE POLICY "Admins have full access to employees"
  ON public.employees FOR ALL
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can insert employees"
  ON public.employees FOR INSERT TO authenticated
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Users can read own created employees"
  ON public.employees FOR SELECT
  USING (auth.uid() = created_by);

-- Auto-update updated_at on row changes
CREATE OR REPLACE FUNCTION public.handle_employees_updated_at()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS on_employees_updated ON public.employees;
CREATE TRIGGER on_employees_updated
  BEFORE UPDATE ON public.employees
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_employees_updated_at();
