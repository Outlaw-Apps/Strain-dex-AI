-- Create private storage bucket for employee documents (government IDs, etc.)
INSERT INTO storage.buckets (id, name, public) VALUES ('employee-documents', 'employee-documents', false) ON CONFLICT (id) DO NOTHING;

-- Only admins can upload employee documents
DROP POLICY IF EXISTS "Admins can upload employee documents" ON storage.objects;
CREATE POLICY "Admins can upload employee documents"
ON storage.objects FOR INSERT TO authenticated
WITH CHECK (
  bucket_id = 'employee-documents'
  AND public.has_role(auth.uid(), 'admin')
);

-- Only admins can read employee documents
DROP POLICY IF EXISTS "Admins can read employee documents" ON storage.objects;
CREATE POLICY "Admins can read employee documents"
ON storage.objects FOR SELECT TO authenticated
USING (
  bucket_id = 'employee-documents'
  AND public.has_role(auth.uid(), 'admin')
);

-- Only admins can delete employee documents
DROP POLICY IF EXISTS "Admins can delete employee documents" ON storage.objects;
CREATE POLICY "Admins can delete employee documents"
ON storage.objects FOR DELETE TO authenticated
USING (
  bucket_id = 'employee-documents'
  AND public.has_role(auth.uid(), 'admin')
);
