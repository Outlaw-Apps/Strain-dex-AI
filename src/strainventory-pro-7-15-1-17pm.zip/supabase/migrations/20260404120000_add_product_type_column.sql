ALTER TABLE public.products
ADD COLUMN IF NOT EXISTS product_type text;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1
    FROM pg_constraint
    WHERE conname = 'products_product_type_check'
      AND conrelid = 'public.products'::regclass
  ) THEN
    ALTER TABLE public.products
    ADD CONSTRAINT products_product_type_check
    CHECK (product_type IS NULL OR product_type = ANY (ARRAY[
      'Flower'::text,
      'Wax'::text,
      'Live Resin'::text,
      'Vape (All in One)'::text,
      'Vape Cartridge'::text,
      'Edible'::text,
      'Pre roll'::text,
      'Concentrate'::text,
      'Tincture'::text,
      'Topical'::text
    ]));
  END IF;
END
$$;
