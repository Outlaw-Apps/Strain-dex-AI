-- Allow admins to delete time entries (manager override)
DROP POLICY IF EXISTS "Admins can delete time entries" ON public.time_entries;
CREATE POLICY "Admins can delete time entries"
  ON public.time_entries FOR DELETE TO authenticated
  USING (public.has_role(auth.uid(), 'admin'));
