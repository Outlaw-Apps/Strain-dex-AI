-- Shift reports + POS audit journal (append-style events)

CREATE TABLE IF NOT EXISTS public.pos_audit_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  event_type text NOT NULL,
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.pos_audit_events ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Authenticated users can view pos_audit_events" ON public.pos_audit_events;
CREATE POLICY "Authenticated users can view pos_audit_events"
  ON public.pos_audit_events FOR SELECT TO authenticated USING (true);

DROP POLICY IF EXISTS "Authenticated users can insert pos_audit_events" ON public.pos_audit_events;
CREATE POLICY "Authenticated users can insert pos_audit_events"
  ON public.pos_audit_events FOR INSERT TO authenticated WITH CHECK (true);

CREATE TABLE IF NOT EXISTS public.shift_reports (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  period_start timestamptz NOT NULL,
  period_end timestamptz NOT NULL,
  closed_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  order_count integer NOT NULL DEFAULT 0,
  total_sales numeric(12,2) NOT NULL DEFAULT 0,
  total_cash numeric(12,2) NOT NULL DEFAULT 0,
  total_card numeric(12,2) NOT NULL DEFAULT 0,
  total_other numeric(12,2) NOT NULL DEFAULT 0,
  opening_float numeric(12,2),
  counted_cash numeric(12,2),
  expected_cash numeric(12,2),
  variance_notes text NOT NULL DEFAULT '',
  notes text NOT NULL DEFAULT '',
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.shift_reports ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Authenticated users can view shift_reports" ON public.shift_reports;
CREATE POLICY "Authenticated users can view shift_reports"
  ON public.shift_reports FOR SELECT TO authenticated USING (true);

DROP POLICY IF EXISTS "Authenticated users can insert shift_reports" ON public.shift_reports;
CREATE POLICY "Authenticated users can insert shift_reports"
  ON public.shift_reports FOR INSERT TO authenticated WITH CHECK (true);
