-- Business-wide settings (single row)
CREATE TABLE IF NOT EXISTS public.business_settings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  geofence_enabled BOOLEAN NOT NULL DEFAULT false,
  geofence_lat NUMERIC(10, 8),
  geofence_lng NUMERIC(11, 8),
  geofence_radius_meters INTEGER NOT NULL DEFAULT 150,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Insert default row if none exists
INSERT INTO public.business_settings (id, geofence_enabled, geofence_radius_meters)
VALUES ('00000000-0000-0000-0000-000000000001', false, 150)
ON CONFLICT (id) DO NOTHING;

ALTER TABLE public.business_settings ENABLE ROW LEVEL SECURITY;

-- Everyone can read settings
DROP POLICY IF EXISTS "Authenticated users can read business settings" ON public.business_settings;
CREATE POLICY "Authenticated users can read business settings"
  ON public.business_settings FOR SELECT TO authenticated USING (true);

-- Only admins can update
DROP POLICY IF EXISTS "Admins can update business settings" ON public.business_settings;
CREATE POLICY "Admins can update business settings"
  ON public.business_settings FOR UPDATE TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));