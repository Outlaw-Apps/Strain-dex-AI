-- Shared synced strain knowledge from Straindex
CREATE TABLE IF NOT EXISTS public.strain_knowledge_entries (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  stable_key TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  type TEXT NOT NULL CHECK (type IN ('indica', 'sativa', 'hybrid')),
  thc TEXT NOT NULL DEFAULT '',
  cbd TEXT NOT NULL DEFAULT '',
  cbn TEXT,
  effects JSONB NOT NULL DEFAULT '[]'::jsonb,
  flavors JSONB NOT NULL DEFAULT '[]'::jsonb,
  aromas JSONB NOT NULL DEFAULT '[]'::jsonb,
  description TEXT NOT NULL DEFAULT '',
  terpenes JSONB NOT NULL DEFAULT '[]'::jsonb,
  lineage TEXT NOT NULL DEFAULT '',
  grow_difficulty TEXT NOT NULL DEFAULT 'moderate' CHECK (grow_difficulty IN ('easy', 'moderate', 'hard')),
  flowering_time TEXT NOT NULL DEFAULT '',
  source_updated_at TIMESTAMPTZ NOT NULL,
  source_device_id TEXT,
  source_app TEXT,
  source_user_id UUID REFERENCES auth.users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS strain_knowledge_entries_name_idx
  ON public.strain_knowledge_entries (name);
CREATE INDEX IF NOT EXISTS strain_knowledge_entries_source_updated_at_idx
  ON public.strain_knowledge_entries (source_updated_at DESC);

CREATE TABLE IF NOT EXISTS public.strain_knowledge_images (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  entry_id UUID NOT NULL REFERENCES public.strain_knowledge_entries(id) ON DELETE CASCADE,
  local_photo_id INTEGER NOT NULL DEFAULT -1,
  file_name TEXT NOT NULL,
  content_type TEXT NOT NULL,
  data_uri TEXT NOT NULL,
  added_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS strain_knowledge_images_entry_id_idx
  ON public.strain_knowledge_images (entry_id);

-- Assistant conversation data
CREATE TABLE IF NOT EXISTS public.assistant_threads (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  title TEXT NOT NULL DEFAULT 'Assistant Thread',
  audience_role TEXT NOT NULL DEFAULT 'employee' CHECK (audience_role IN ('employee', 'vendor', 'management')),
  page_context JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS assistant_threads_user_id_idx
  ON public.assistant_threads (user_id, updated_at DESC);

CREATE TABLE IF NOT EXISTS public.assistant_messages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  thread_id UUID NOT NULL REFERENCES public.assistant_threads(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  role TEXT NOT NULL CHECK (role IN ('user', 'assistant')),
  content TEXT NOT NULL,
  context JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS assistant_messages_thread_id_idx
  ON public.assistant_messages (thread_id, created_at);

CREATE TABLE IF NOT EXISTS public.assistant_action_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  thread_id UUID REFERENCES public.assistant_threads(id) ON DELETE CASCADE,
  message_id UUID REFERENCES public.assistant_messages(id) ON DELETE SET NULL,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  intent TEXT NOT NULL,
  summary TEXT NOT NULL,
  proposed_changes JSONB NOT NULL DEFAULT '[]'::jsonb,
  execution_payload JSONB NOT NULL DEFAULT '{}'::jsonb,
  status TEXT NOT NULL DEFAULT 'recommended' CHECK (status IN ('recommended', 'confirmed', 'executed', 'failed', 'dismissed')),
  error TEXT,
  confirmed_at TIMESTAMPTZ,
  executed_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS assistant_action_logs_user_id_idx
  ON public.assistant_action_logs (user_id, created_at DESC);

-- Shared updated_at trigger helper
CREATE OR REPLACE FUNCTION public.handle_assistant_updated_at()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS on_strain_knowledge_entries_updated ON public.strain_knowledge_entries;
CREATE TRIGGER on_strain_knowledge_entries_updated
  BEFORE UPDATE ON public.strain_knowledge_entries
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_assistant_updated_at();

DROP TRIGGER IF EXISTS on_assistant_threads_updated ON public.assistant_threads;
CREATE TRIGGER on_assistant_threads_updated
  BEFORE UPDATE ON public.assistant_threads
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_assistant_updated_at();

-- RLS
ALTER TABLE public.strain_knowledge_entries ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.strain_knowledge_images ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.assistant_threads ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.assistant_messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.assistant_action_logs ENABLE ROW LEVEL SECURITY;

DO $$ BEGIN
  DROP POLICY IF EXISTS "Authenticated users can read strain knowledge entries" ON public.strain_knowledge_entries;
  DROP POLICY IF EXISTS "Authenticated users can read strain knowledge images" ON public.strain_knowledge_images;
  DROP POLICY IF EXISTS "Users can manage own assistant threads" ON public.assistant_threads;
  DROP POLICY IF EXISTS "Users can manage own assistant messages" ON public.assistant_messages;
  DROP POLICY IF EXISTS "Users can manage own assistant action logs" ON public.assistant_action_logs;
END $$;

CREATE POLICY "Authenticated users can read strain knowledge entries"
  ON public.strain_knowledge_entries FOR SELECT TO authenticated USING (true);

CREATE POLICY "Authenticated users can read strain knowledge images"
  ON public.strain_knowledge_images FOR SELECT TO authenticated USING (true);

CREATE POLICY "Users can manage own assistant threads"
  ON public.assistant_threads FOR ALL TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can manage own assistant messages"
  ON public.assistant_messages FOR ALL TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (
    auth.uid() = user_id
    AND EXISTS (
      SELECT 1
      FROM public.assistant_threads t
      WHERE t.id = assistant_messages.thread_id
        AND t.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can manage own assistant action logs"
  ON public.assistant_action_logs FOR ALL TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

