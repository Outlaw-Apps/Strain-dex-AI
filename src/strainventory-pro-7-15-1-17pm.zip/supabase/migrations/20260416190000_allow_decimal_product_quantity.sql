DO $$
BEGIN
  IF EXISTS (
    SELECT 1
    FROM information_schema.columns
    WHERE table_schema = 'public'
      AND table_name = 'products'
      AND column_name = 'quantity'
      AND data_type = 'integer'
  ) THEN
    ALTER TABLE public.products
      ALTER COLUMN quantity TYPE numeric(10,2)
      USING quantity::numeric(10,2);
  END IF;
END
$$;

ALTER TABLE public.products
  ALTER COLUMN quantity SET DEFAULT 0,
  ALTER COLUMN quantity SET NOT NULL;
